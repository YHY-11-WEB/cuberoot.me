(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,23094,e=>{"use strict";var t=e.i(95216),i=e.i(204801),a=e.i(619720),r=e.i(120848);let o=(0,r.default)("arrow-down-to-line",[["path",{d:"M12 17V3",key:"1cwfxf"}],["path",{d:"m6 11 6 6 6-6",key:"12ii2o"}],["path",{d:"M19 21H5",key:"150jfl"}]]);var s=e.i(664779),n=e.i(715519),l=e.i(648121);let h=(0,r.default)("arrow-up-from-line",[["path",{d:"m18 9-6-6-6 6",key:"kcunyi"}],["path",{d:"M12 3v14",key:"7cf3v8"}],["path",{d:"M5 21h14",key:"11awu3"}]]),c=(0,r.default)("cloud-sun",[["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}],["path",{d:"M15.947 12.65a4 4 0 0 0-5.925-4.128",key:"dpwdj0"}],["path",{d:"M13 22H7a5 5 0 1 1 4.9-6H13a3 3 0 0 1 0 6Z",key:"s09mg5"}]]);var d=e.i(498227);let u=(0,r.default)("crosshair",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"22",x2:"18",y1:"12",y2:"12",key:"l9bcsi"}],["line",{x1:"6",x2:"2",y1:"12",y2:"12",key:"13hhkx"}],["line",{x1:"12",x2:"12",y1:"6",y2:"2",key:"10w3f3"}],["line",{x1:"12",x2:"12",y1:"22",y2:"18",key:"15g9kq"}]]),m=(0,r.default)("drone",[["path",{d:"M10 10 7 7",key:"zp14k7"}],["path",{d:"m10 14-3 3",key:"1jrpxk"}],["path",{d:"m14 10 3-3",key:"7tigam"}],["path",{d:"m14 14 3 3",key:"vm23p3"}],["path",{d:"M14.205 4.139a4 4 0 1 1 5.439 5.863",key:"1tm5p2"}],["path",{d:"M19.637 14a4 4 0 1 1-5.432 5.868",key:"16egi2"}],["path",{d:"M4.367 10a4 4 0 1 1 5.438-5.862",key:"1wta6a"}],["path",{d:"M9.795 19.862a4 4 0 1 1-5.429-5.873",key:"q39hpv"}],["rect",{x:"10",y:"8",width:"4",height:"8",rx:"1",key:"phrjt1"}]]),p=(0,r.default)("footprints",[["path",{d:"M4 16v-2.38C4 11.5 2.97 10.5 3 8c.03-2.72 1.49-6 4.5-6C9.37 2 10 3.8 10 5.5c0 3.11-2 5.66-2 8.68V16a2 2 0 1 1-4 0Z",key:"1dudjm"}],["path",{d:"M20 20v-2.38c0-2.12 1.03-3.12 1-5.62-.03-2.72-1.49-6-4.5-6C14.63 6 14 7.8 14 9.5c0 3.11 2 5.66 2 8.68V20a2 2 0 1 0 4 0Z",key:"l2t8xc"}],["path",{d:"M16 17h4",key:"1dejxt"}],["path",{d:"M4 13h4",key:"1bwh8b"}]]),f=(0,r.default)("maximize",[["path",{d:"M8 3H5a2 2 0 0 0-2 2v3",key:"1dcmit"}],["path",{d:"M21 8V5a2 2 0 0 0-2-2h-3",key:"1e4gt3"}],["path",{d:"M3 16v3a2 2 0 0 0 2 2h3",key:"wsl5sc"}],["path",{d:"M16 21h3a2 2 0 0 0 2-2v-3",key:"18trek"}]]),g=(0,r.default)("move",[["path",{d:"M12 2v20",key:"t6zp3m"}],["path",{d:"m15 19-3 3-3-3",key:"11eu04"}],["path",{d:"m19 9 3 3-3 3",key:"1mg7y2"}],["path",{d:"M2 12h20",key:"9i4pu4"}],["path",{d:"m5 9-3 3 3 3",key:"j64kie"}],["path",{d:"m9 5 3-3 3 3",key:"l8vdw6"}]]);var v=e.i(343);let b=(0,r.default)("redo-2",[["path",{d:"m15 14 5-5-5-5",key:"12vg1m"}],["path",{d:"M20 9H9.5A5.5 5.5 0 0 0 4 14.5A5.5 5.5 0 0 0 9.5 20H13",key:"6uklza"}]]);var w=e.i(763707),y=e.i(777926),x=e.i(738984),M=e.i(946150),S=e.i(168052),T=e.i(837862),C=e.i(868906),P=e.i(936439);e.i(97394);var A=e.i(394470),k=e.i(906721);function D({value:e,min:a,max:r,allowDecimal:o=!1,onCommit:s,onKeyDown:n,onFocus:l,...h}){let[c,d]=(0,i.useState)(String(e)),u=(0,i.useRef)(!1);return(0,i.useEffect)(()=>{d(String(e))},[e]),(0,t.jsx)("input",{...h,type:"number",min:a,max:r,value:c,onChange:e=>d(e.target.value),onBlur:()=>{if(u.current){u.current=!1;return}let t=o?c.trim()?Number(c):NaN:parseInt(c,10);if(isFinite(t)){let i=Math.max(a,Math.min(r,t));i!==e&&s(i),String(i)!==c&&d(String(i))}else d(String(e))},onFocus:e=>{e.currentTarget.select(),l?.(e)},onKeyDown:t=>{"Enter"===t.key?(t.preventDefault(),t.currentTarget.blur()):"Escape"===t.key&&(t.preventDefault(),u.current=!0,d(String(e)),t.currentTarget.blur()),n?.(t)}})}var z=e.i(494908),_=e.i(10421),L=e.i(703626),R=e.i(277863),E=L;let F={type:"change"},I={type:"start"},U={type:"end"},N=new E.Ray,B=new E.Plane,V=Math.cos(70*E.MathUtils.DEG2RAD),O=new E.Vector3,G=2*Math.PI;class j extends E.Controls{constructor(e,t=null){super(e,t),this.state=-1,this.target=new E.Vector3,this.cursor=new E.Vector3,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:E.MOUSE.ROTATE,MIDDLE:E.MOUSE.DOLLY,RIGHT:E.MOUSE.PAN},this.touches={ONE:E.TOUCH.ROTATE,TWO:E.TOUCH.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle="auto",this._domElementKeyEvents=null,this._lastPosition=new E.Vector3,this._lastQuaternion=new E.Quaternion,this._lastTargetPosition=new E.Vector3,this._quat=new E.Quaternion().setFromUnitVectors(e.up,new E.Vector3(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new E.Spherical,this._sphericalDelta=new E.Spherical,this._scale=1,this._panOffset=new E.Vector3,this._rotateStart=new E.Vector2,this._rotateEnd=new E.Vector2,this._rotateDelta=new E.Vector2,this._panStart=new E.Vector2,this._panEnd=new E.Vector2,this._panDelta=new E.Vector2,this._dollyStart=new E.Vector2,this._dollyEnd=new E.Vector2,this._dollyDelta=new E.Vector2,this._dollyDirection=new E.Vector3,this._mouse=new E.Vector2,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=W.bind(this),this._onPointerDown=H.bind(this),this._onPointerUp=q.bind(this),this._onContextMenu=J.bind(this),this._onMouseWheel=Y.bind(this),this._onKeyDown=Z.bind(this),this._onTouchStart=$.bind(this),this._onTouchMove=Q.bind(this),this._onMouseDown=X.bind(this),this._onMouseMove=K.bind(this),this._interceptControlDown=ee.bind(this),this._interceptControlUp=et.bind(this),null!==this.domElement&&this.connect(this.domElement),this.update()}set cursorStyle(e){this._cursorStyle=e,"grab"===e?this.domElement.style.cursor="grab":this.domElement.style.cursor="auto"}get cursorStyle(){return this._cursorStyle}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){null!==this._domElementKeyEvents&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(F),this.update(),this.state=-1}pan(e,t){this._pan(e,t),this.update()}dollyIn(e){this._dollyIn(e),this.update()}dollyOut(e){this._dollyOut(e),this.update()}rotateLeft(e){this._rotateLeft(e),this.update()}rotateUp(e){this._rotateUp(e),this.update()}update(e=null){let t=this.object.position;O.copy(t).sub(this.target),O.applyQuaternion(this._quat),this._spherical.setFromVector3(O),this.autoRotate&&-1===this.state&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let i=this.minAzimuthAngle,a=this.maxAzimuthAngle;isFinite(i)&&isFinite(a)&&(i<-Math.PI?i+=G:i>Math.PI&&(i-=G),a<-Math.PI?a+=G:a>Math.PI&&(a-=G),i<=a?this._spherical.theta=Math.max(i,Math.min(a,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(i+a)/2?Math.max(i,this._spherical.theta):Math.min(a,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),!0===this.enableDamping?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let r=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{let e=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),r=e!=this._spherical.radius}if(O.setFromSpherical(this._spherical),O.applyQuaternion(this._quatInverse),t.copy(this.target).add(O),this.object.lookAt(this.target),!0===this.enableDamping?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let e=null;if(this.object.isPerspectiveCamera){let t=O.length();e=this._clampDistance(t*this._scale);let i=t-e;this.object.position.addScaledVector(this._dollyDirection,i),this.object.updateMatrixWorld(),r=!!i}else if(this.object.isOrthographicCamera){let t=new E.Vector3(this._mouse.x,this._mouse.y,0);t.unproject(this.object);let i=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),r=i!==this.object.zoom;let a=new E.Vector3(this._mouse.x,this._mouse.y,0);a.unproject(this.object),this.object.position.sub(a).add(t),this.object.updateMatrixWorld(),e=O.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;null!==e&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(e).add(this.object.position):(N.origin.copy(this.object.position),N.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(N.direction))<V?this.object.lookAt(this.target):(B.setFromNormalAndCoplanarPoint(this.object.up,this.target),N.intersectPlane(B,this.target))))}else if(this.object.isOrthographicCamera){let e=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),e!==this.object.zoom&&(this.object.updateProjectionMatrix(),r=!0)}return this._scale=1,this._performCursorZoom=!1,!!(r||this._lastPosition.distanceToSquared(this.object.position)>1e-6||8*(1-this._lastQuaternion.dot(this.object.quaternion))>1e-6||this._lastTargetPosition.distanceToSquared(this.target)>1e-6)&&(this.dispatchEvent(F),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0)}_getAutoRotationAngle(e){return null!==e?G/60*this.autoRotateSpeed*e:G/60/60*this.autoRotateSpeed}_getZoomScale(e){let t=Math.abs(.01*e);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){O.setFromMatrixColumn(t,0),O.multiplyScalar(-e),this._panOffset.add(O)}_panUp(e,t){!0===this.screenSpacePanning?O.setFromMatrixColumn(t,1):(O.setFromMatrixColumn(t,0),O.crossVectors(this.object.up,O)),O.multiplyScalar(e),this._panOffset.add(O)}_pan(e,t){let i=this.domElement;if(this.object.isPerspectiveCamera){let a=this.object.position;O.copy(a).sub(this.target);let r=O.length();r*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*r/i.clientHeight,this.object.matrix),this._panUp(2*t*r/i.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/i.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/i.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;let i=this.domElement.getBoundingClientRect(),a=e-i.left,r=t-i.top,o=i.width,s=i.height;this._mouse.x=a/o*2-1,this._mouse.y=-(r/s*2)+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let t=this.domElement;this._rotateLeft(G*this._rotateDelta.x/t.clientHeight),this._rotateUp(G*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(G*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-G*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(G*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-G*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(1===this._pointers.length)this._rotateStart.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),a=.5*(e.pageY+t.y);this._rotateStart.set(i,a)}}_handleTouchStartPan(e){if(1===this._pointers.length)this._panStart.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),a=.5*(e.pageY+t.y);this._panStart.set(i,a)}}_handleTouchStartDolly(e){let t=this._getSecondPointerPosition(e),i=e.pageX-t.x,a=e.pageY-t.y,r=Math.sqrt(i*i+a*a);this._dollyStart.set(0,r)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(1==this._pointers.length)this._rotateEnd.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),a=.5*(e.pageY+t.y);this._rotateEnd.set(i,a)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let t=this.domElement;this._rotateLeft(G*this._rotateDelta.x/t.clientHeight),this._rotateUp(G*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(1===this._pointers.length)this._panEnd.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),a=.5*(e.pageY+t.y);this._panEnd.set(i,a)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){let t=this._getSecondPointerPosition(e),i=e.pageX-t.x,a=e.pageY-t.y,r=Math.sqrt(i*i+a*a);this._dollyEnd.set(0,r),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);let o=(e.pageX+t.x)*.5,s=(e.pageY+t.y)*.5;this._updateZoomParameters(o,s)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return void this._pointers.splice(t,1)}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];void 0===t&&(t=new E.Vector2,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){let t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){let t=e.deltaMode,i={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:i.deltaY*=16;break;case 2:i.deltaY*=100}return e.ctrlKey&&!this._controlActive&&(i.deltaY*=10),i}}function H(e){!1===this.enabled||(0===this._pointers.length&&(this.domElement.setPointerCapture(e.pointerId),this.domElement.ownerDocument.addEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.addEventListener("pointerup",this._onPointerUp)),this._isTrackingPointer(e)||(this._addPointer(e),"touch"===e.pointerType?this._onTouchStart(e):this._onMouseDown(e),"grab"===this._cursorStyle&&(this.domElement.style.cursor="grabbing")))}function W(e){!1!==this.enabled&&("touch"===e.pointerType?this._onTouchMove(e):this._onMouseMove(e))}function q(e){switch(this._removePointer(e),this._pointers.length){case 0:this.domElement.releasePointerCapture(e.pointerId),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(U),this.state=-1,"grab"===this._cursorStyle&&(this.domElement.style.cursor="grab");break;case 1:let t=this._pointers[0],i=this._pointerPositions[t];this._onTouchStart({pointerId:t,pageX:i.x,pageY:i.y})}}function X(e){let t;switch(e.button){case 0:t=this.mouseButtons.LEFT;break;case 1:t=this.mouseButtons.MIDDLE;break;case 2:t=this.mouseButtons.RIGHT;break;default:t=-1}switch(t){case E.MOUSE.DOLLY:if(!1===this.enableZoom)return;this._handleMouseDownDolly(e),this.state=1;break;case E.MOUSE.ROTATE:if(e.ctrlKey||e.metaKey||e.shiftKey){if(!1===this.enablePan)return;this._handleMouseDownPan(e),this.state=2}else{if(!1===this.enableRotate)return;this._handleMouseDownRotate(e),this.state=0}break;case E.MOUSE.PAN:if(e.ctrlKey||e.metaKey||e.shiftKey){if(!1===this.enableRotate)return;this._handleMouseDownRotate(e),this.state=0}else{if(!1===this.enablePan)return;this._handleMouseDownPan(e),this.state=2}break;default:this.state=-1}-1!==this.state&&this.dispatchEvent(I)}function K(e){switch(this.state){case 0:if(!1===this.enableRotate)return;this._handleMouseMoveRotate(e);break;case 1:if(!1===this.enableZoom)return;this._handleMouseMoveDolly(e);break;case 2:if(!1===this.enablePan)return;this._handleMouseMovePan(e)}}function Y(e){!1!==this.enabled&&!1!==this.enableZoom&&-1===this.state&&(e.preventDefault(),this.dispatchEvent(I),this._handleMouseWheel(this._customWheelEvent(e)),this.dispatchEvent(U))}function Z(e){!1!==this.enabled&&this._handleKeyDown(e)}function $(e){switch(this._trackPointer(e),this._pointers.length){case 1:switch(this.touches.ONE){case E.TOUCH.ROTATE:if(!1===this.enableRotate)return;this._handleTouchStartRotate(e),this.state=3;break;case E.TOUCH.PAN:if(!1===this.enablePan)return;this._handleTouchStartPan(e),this.state=4;break;default:this.state=-1}break;case 2:switch(this.touches.TWO){case E.TOUCH.DOLLY_PAN:if(!1===this.enableZoom&&!1===this.enablePan)return;this._handleTouchStartDollyPan(e),this.state=5;break;case E.TOUCH.DOLLY_ROTATE:if(!1===this.enableZoom&&!1===this.enableRotate)return;this._handleTouchStartDollyRotate(e),this.state=6;break;default:this.state=-1}break;default:this.state=-1}-1!==this.state&&this.dispatchEvent(I)}function Q(e){switch(this._trackPointer(e),this.state){case 3:if(!1===this.enableRotate)return;this._handleTouchMoveRotate(e),this.update();break;case 4:if(!1===this.enablePan)return;this._handleTouchMovePan(e),this.update();break;case 5:if(!1===this.enableZoom&&!1===this.enablePan)return;this._handleTouchMoveDollyPan(e),this.update();break;case 6:if(!1===this.enableZoom&&!1===this.enableRotate)return;this._handleTouchMoveDollyRotate(e),this.update();break;default:this.state=-1}}function J(e){!1!==this.enabled&&e.preventDefault()}function ee(e){"Control"===e.key&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function et(e){"Control"===e.key&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}var ei=L;let ea=new ei.Raycaster,er=new ei.Vector3,eo=new ei.Vector3,es=new ei.Quaternion,en={X:new ei.Vector3(1,0,0),Y:new ei.Vector3(0,1,0),Z:new ei.Vector3(0,0,1)},el={type:"change"},eh={type:"mouseDown",mode:null},ec={type:"mouseUp",mode:null},ed={type:"objectChange"};class eu extends ei.Controls{constructor(e,t=null){super(void 0,t);const i=new eR(this);this._root=i;const a=new eE;this._gizmo=a,i.add(a);const r=new eF;this._plane=r,i.add(r);const o=this;function s(e,t){let i=t;Object.defineProperty(o,e,{get:function(){return void 0!==i?i:t},set:function(t){i!==t&&(i=t,r[e]=t,a[e]=t,o.dispatchEvent({type:e+"-changed",value:t}),o.dispatchEvent(el))}}),o[e]=t,r[e]=t,a[e]=t}s("camera",e),s("object",void 0),s("enabled",!0),s("axis",null),s("mode","translate"),s("translationSnap",null),s("rotationSnap",null),s("scaleSnap",null),s("space","world"),s("size",1),s("dragging",!1),s("showX",!0),s("showY",!0),s("showZ",!0),s("minX",-1/0),s("maxX",1/0),s("minY",-1/0),s("maxY",1/0),s("minZ",-1/0),s("maxZ",1/0);const n=new ei.Vector3,l=new ei.Vector3,h=new ei.Quaternion,c=new ei.Quaternion,d=new ei.Vector3,u=new ei.Quaternion,m=new ei.Vector3,p=new ei.Vector3,f=new ei.Vector3,g=new ei.Vector3;s("worldPosition",n),s("worldPositionStart",l),s("worldQuaternion",h),s("worldQuaternionStart",c),s("cameraPosition",d),s("cameraQuaternion",u),s("pointStart",m),s("pointEnd",p),s("rotationAxis",f),s("rotationAngle",0),s("eye",g),this._offset=new ei.Vector3,this._startNorm=new ei.Vector3,this._endNorm=new ei.Vector3,this._cameraScale=new ei.Vector3,this._parentPosition=new ei.Vector3,this._parentQuaternion=new ei.Quaternion,this._parentQuaternionInv=new ei.Quaternion,this._parentScale=new ei.Vector3,this._worldScaleStart=new ei.Vector3,this._worldQuaternionInv=new ei.Quaternion,this._worldScale=new ei.Vector3,this._positionStart=new ei.Vector3,this._quaternionStart=new ei.Quaternion,this._scaleStart=new ei.Vector3,this._getPointer=em.bind(this),this._onPointerDown=ef.bind(this),this._onPointerHover=ep.bind(this),this._onPointerMove=eg.bind(this),this._onPointerUp=ev.bind(this),null!==t&&this.connect(t)}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointermove",this._onPointerHover),this.domElement.addEventListener("pointerup",this._onPointerUp),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerHover),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.style.touchAction="auto"}getHelper(){return this._root}pointerHover(e){if(void 0===this.object||!0===this.dragging)return;null!==e&&ea.setFromCamera(e,this.camera);let t=eb(this._gizmo.picker[this.mode],ea);t?this.axis=t.object.name:this.axis=null}pointerDown(e){if(void 0!==this.object&&!0!==this.dragging&&(null==e||0===e.button)&&null!==this.axis){null!==e&&ea.setFromCamera(e,this.camera);let t=eb(this._plane,ea,!0);t&&(this.object.updateMatrixWorld(),this.object.parent.updateMatrixWorld(),this._positionStart.copy(this.object.position),this._quaternionStart.copy(this.object.quaternion),this._scaleStart.copy(this.object.scale),this.object.matrixWorld.decompose(this.worldPositionStart,this.worldQuaternionStart,this._worldScaleStart),this.pointStart.copy(t.point).sub(this.worldPositionStart)),this.dragging=!0,eh.mode=this.mode,this.dispatchEvent(eh)}}pointerMove(e){let t=this.axis,i=this.mode,a=this.object,r=this.space;if("scale"===i?r="local":("E"===t||"XYZE"===t||"XYZ"===t)&&(r="world"),void 0===a||null===t||!1===this.dragging||null!==e&&-1!==e.button)return;null!==e&&ea.setFromCamera(e,this.camera);let o=eb(this._plane,ea,!0);if(o){if(this.pointEnd.copy(o.point).sub(this.worldPositionStart),"translate"===i)this._offset.copy(this.pointEnd).sub(this.pointStart),"local"===r&&"XYZ"!==t&&this._offset.applyQuaternion(this._worldQuaternionInv),-1===t.indexOf("X")&&(this._offset.x=0),-1===t.indexOf("Y")&&(this._offset.y=0),-1===t.indexOf("Z")&&(this._offset.z=0),"local"===r&&"XYZ"!==t?this._offset.applyQuaternion(this._quaternionStart).divide(this._parentScale):this._offset.applyQuaternion(this._parentQuaternionInv).divide(this._parentScale),a.position.copy(this._offset).add(this._positionStart),this.translationSnap&&("local"===r&&(a.position.applyQuaternion(es.copy(this._quaternionStart).invert()),-1!==t.search("X")&&(a.position.x=Math.round(a.position.x/this.translationSnap)*this.translationSnap),-1!==t.search("Y")&&(a.position.y=Math.round(a.position.y/this.translationSnap)*this.translationSnap),-1!==t.search("Z")&&(a.position.z=Math.round(a.position.z/this.translationSnap)*this.translationSnap),a.position.applyQuaternion(this._quaternionStart)),"world"===r&&(a.parent&&a.position.add(er.setFromMatrixPosition(a.parent.matrixWorld)),-1!==t.search("X")&&(a.position.x=Math.round(a.position.x/this.translationSnap)*this.translationSnap),-1!==t.search("Y")&&(a.position.y=Math.round(a.position.y/this.translationSnap)*this.translationSnap),-1!==t.search("Z")&&(a.position.z=Math.round(a.position.z/this.translationSnap)*this.translationSnap),a.parent&&a.position.sub(er.setFromMatrixPosition(a.parent.matrixWorld)))),a.position.x=Math.max(this.minX,Math.min(this.maxX,a.position.x)),a.position.y=Math.max(this.minY,Math.min(this.maxY,a.position.y)),a.position.z=Math.max(this.minZ,Math.min(this.maxZ,a.position.z));else if("scale"===i){if(-1!==t.search("XYZ")){let e=this.pointEnd.length()/this.pointStart.length();0>this.pointEnd.dot(this.pointStart)&&(e*=-1),eo.set(e,e,e)}else er.copy(this.pointStart),eo.copy(this.pointEnd),er.applyQuaternion(this._worldQuaternionInv),eo.applyQuaternion(this._worldQuaternionInv),eo.divide(er),-1===t.search("X")&&(eo.x=1),-1===t.search("Y")&&(eo.y=1),-1===t.search("Z")&&(eo.z=1);a.scale.copy(this._scaleStart).multiply(eo),this.scaleSnap&&(-1!==t.search("X")&&(a.scale.x=Math.round(a.scale.x/this.scaleSnap)*this.scaleSnap||this.scaleSnap),-1!==t.search("Y")&&(a.scale.y=Math.round(a.scale.y/this.scaleSnap)*this.scaleSnap||this.scaleSnap),-1!==t.search("Z")&&(a.scale.z=Math.round(a.scale.z/this.scaleSnap)*this.scaleSnap||this.scaleSnap))}else if("rotate"===i){this._offset.copy(this.pointEnd).sub(this.pointStart);let e=20/this.worldPosition.distanceTo(er.setFromMatrixPosition(this.camera.matrixWorld)),i=!1;"XYZE"===t?(this.rotationAxis.copy(this._offset).cross(this.eye).normalize(),this.rotationAngle=this._offset.dot(er.copy(this.rotationAxis).cross(this.eye))*e):("X"===t||"Y"===t||"Z"===t)&&(this.rotationAxis.copy(en[t]),er.copy(en[t]),"local"===r&&er.applyQuaternion(this.worldQuaternion),er.cross(this.eye),0===er.length()?i=!0:this.rotationAngle=this._offset.dot(er.normalize())*e),("E"===t||i)&&(this.rotationAxis.copy(this.eye),this.rotationAngle=this.pointEnd.angleTo(this.pointStart),this._startNorm.copy(this.pointStart).normalize(),this._endNorm.copy(this.pointEnd).normalize(),this.rotationAngle*=0>this._endNorm.cross(this._startNorm).dot(this.eye)?1:-1),this.rotationSnap&&(this.rotationAngle=Math.round(this.rotationAngle/this.rotationSnap)*this.rotationSnap),"local"===r&&"E"!==t&&"XYZE"!==t?(a.quaternion.copy(this._quaternionStart),a.quaternion.multiply(es.setFromAxisAngle(this.rotationAxis,this.rotationAngle)).normalize()):(this.rotationAxis.applyQuaternion(this._parentQuaternionInv),a.quaternion.copy(es.setFromAxisAngle(this.rotationAxis,this.rotationAngle)),a.quaternion.multiply(this._quaternionStart).normalize())}this.dispatchEvent(el),this.dispatchEvent(ed)}}pointerUp(e){(null===e||0===e.button)&&(this.dragging&&null!==this.axis&&(ec.mode=this.mode,this.dispatchEvent(ec)),this.dragging=!1,this.axis=null)}dispose(){this.disconnect(),this._root.dispose()}attach(e){return this.object=e,this._root.visible=!0,this}detach(){return this.object=void 0,this.axis=null,this._root.visible=!1,this}reset(){this.enabled&&this.dragging&&(this.object.position.copy(this._positionStart),this.object.quaternion.copy(this._quaternionStart),this.object.scale.copy(this._scaleStart),this.dispatchEvent(el),this.dispatchEvent(ed),this.pointStart.copy(this.pointEnd))}getRaycaster(){return ea}getMode(){return this.mode}setMode(e){this.mode=e}setTranslationSnap(e){this.translationSnap=e}setRotationSnap(e){this.rotationSnap=e}setScaleSnap(e){this.scaleSnap=e}setSize(e){this.size=e}setSpace(e){this.space=e}setColors(e,t,i,a){let r=this._gizmo.materialLib;r.xAxis.color.set(e),r.yAxis.color.set(t),r.zAxis.color.set(i),r.active.color.set(a),r.xAxisTransparent.color.set(e),r.yAxisTransparent.color.set(t),r.zAxisTransparent.color.set(i),r.activeTransparent.color.set(a),r.xAxis._color&&r.xAxis._color.set(e),r.yAxis._color&&r.yAxis._color.set(t),r.zAxis._color&&r.zAxis._color.set(i),r.active._color&&r.active._color.set(a),r.xAxisTransparent._color&&r.xAxisTransparent._color.set(e),r.yAxisTransparent._color&&r.yAxisTransparent._color.set(t),r.zAxisTransparent._color&&r.zAxisTransparent._color.set(i),r.activeTransparent._color&&r.activeTransparent._color.set(a)}}function em(e){if(this.domElement.ownerDocument.pointerLockElement)return{x:0,y:0,button:e.button};{let t=this.domElement.getBoundingClientRect();return{x:(e.clientX-t.left)/t.width*2-1,y:-(e.clientY-t.top)/t.height*2+1,button:e.button}}}function ep(e){if(this.enabled)switch(e.pointerType){case"mouse":case"pen":this.pointerHover(this._getPointer(e))}}function ef(e){this.enabled&&(document.pointerLockElement||this.domElement.setPointerCapture(e.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.pointerHover(this._getPointer(e)),this.pointerDown(this._getPointer(e)))}function eg(e){this.enabled&&this.pointerMove(this._getPointer(e))}function ev(e){this.enabled&&(this.domElement.releasePointerCapture(e.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.pointerUp(this._getPointer(e)))}function eb(e,t,i){let a=t.intersectObject(e,!0);for(let e=0;e<a.length;e++)if(a[e].object.visible||i)return a[e];return!1}let ew=new ei.Euler,ey=new ei.Vector3(0,1,0),ex=new ei.Vector3(0,0,0),eM=new ei.Matrix4,eS=new ei.Quaternion,eT=new ei.Quaternion,eC=new ei.Vector3,eP=new ei.Matrix4,eA=new ei.Vector3(1,0,0),ek=new ei.Vector3(0,1,0),eD=new ei.Vector3(0,0,1),ez=new ei.Vector3,e_=new ei.Vector3,eL=new ei.Vector3;class eR extends ei.Object3D{constructor(e){super(),this.isTransformControlsRoot=!0,this.controls=e,this.visible=!1}updateMatrixWorld(e){let t=this.controls;void 0!==t.object&&(t.object.updateMatrixWorld(),null===t.object.parent?console.error("TransformControls: The attached 3D object must be a part of the scene graph."):t.object.parent.matrixWorld.decompose(t._parentPosition,t._parentQuaternion,t._parentScale),t.object.matrixWorld.decompose(t.worldPosition,t.worldQuaternion,t._worldScale),t._parentQuaternionInv.copy(t._parentQuaternion).invert(),t._worldQuaternionInv.copy(t.worldQuaternion).invert()),t.camera.updateMatrixWorld(),t.camera.matrixWorld.decompose(t.cameraPosition,t.cameraQuaternion,t._cameraScale),t.camera.isOrthographicCamera?t.camera.getWorldDirection(t.eye).negate():t.eye.copy(t.cameraPosition).sub(t.worldPosition).normalize(),super.updateMatrixWorld(e)}dispose(){this.traverse(function(e){e.geometry&&e.geometry.dispose(),e.material&&e.material.dispose()})}}class eE extends ei.Object3D{constructor(){super(),this.isTransformControlsGizmo=!0,this.type="TransformControlsGizmo";const e=new ei.MeshBasicMaterial({depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1,transparent:!0}),t=new ei.LineBasicMaterial({depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1,transparent:!0}),i=e.clone();i.opacity=.15;const a=t.clone();a.opacity=.5;const r=e.clone();r.color.setHex(0xff0000);const o=e.clone();o.color.setHex(65280);const s=e.clone();s.color.setHex(255);const n=e.clone();n.color.setHex(0xff0000),n.opacity=.5;const l=e.clone();l.color.setHex(65280),l.opacity=.5;const h=e.clone();h.color.setHex(255),h.opacity=.5;const c=e.clone();c.opacity=.25;const d=e.clone();d.color.setHex(0xffff00),d.opacity=.25;const u=e.clone();u.color.setHex(0xffff00);const m=e.clone();m.color.setHex(7895160),this.materialLib={xAxis:r,yAxis:o,zAxis:s,active:u,xAxisTransparent:n,yAxisTransparent:l,zAxisTransparent:h,activeTransparent:d};const p=new ei.CylinderGeometry(0,.04,.1,12);p.translate(0,.05,0);const f=new ei.BoxGeometry(.08,.08,.08);f.translate(0,.04,0);const g=new ei.BufferGeometry;g.setAttribute("position",new ei.Float32BufferAttribute([0,0,0,1,0,0],3));const v=new ei.CylinderGeometry(.0075,.0075,.5,3);function b(e,t){let i=new ei.TorusGeometry(e,.0075,3,64,t*Math.PI*2);return i.rotateY(Math.PI/2),i.rotateX(Math.PI/2),i}v.translate(0,.25,0);const w={X:[[new ei.Mesh(p,r),[.5,0,0],[0,0,-Math.PI/2]],[new ei.Mesh(p,r),[-.5,0,0],[0,0,Math.PI/2]],[new ei.Mesh(v,r),[0,0,0],[0,0,-Math.PI/2]]],Y:[[new ei.Mesh(p,o),[0,.5,0]],[new ei.Mesh(p,o),[0,-.5,0],[Math.PI,0,0]],[new ei.Mesh(v,o)]],Z:[[new ei.Mesh(p,s),[0,0,.5],[Math.PI/2,0,0]],[new ei.Mesh(p,s),[0,0,-.5],[-Math.PI/2,0,0]],[new ei.Mesh(v,s),null,[Math.PI/2,0,0]]],XYZ:[[new ei.Mesh(new ei.OctahedronGeometry(.1,0),c),[0,0,0]]],XY:[[new ei.Mesh(new ei.BoxGeometry(.15,.15,.01),h),[.15,.15,0]]],YZ:[[new ei.Mesh(new ei.BoxGeometry(.15,.15,.01),n),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ei.Mesh(new ei.BoxGeometry(.15,.15,.01),l),[.15,0,.15],[-Math.PI/2,0,0]]]},y={X:[[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[.3,0,0],[0,0,-Math.PI/2]],[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[-.3,0,0],[0,0,Math.PI/2]]],Y:[[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[0,.3,0]],[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[0,-.3,0],[0,0,Math.PI]]],Z:[[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[0,0,.3],[Math.PI/2,0,0]],[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[0,0,-.3],[-Math.PI/2,0,0]]],XYZ:[[new ei.Mesh(new ei.OctahedronGeometry(.2,0),i)]],XY:[[new ei.Mesh(new ei.BoxGeometry(.2,.2,.01),i),[.15,.15,0]]],YZ:[[new ei.Mesh(new ei.BoxGeometry(.2,.2,.01),i),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ei.Mesh(new ei.BoxGeometry(.2,.2,.01),i),[.15,0,.15],[-Math.PI/2,0,0]]]},x={START:[[new ei.Mesh(new ei.OctahedronGeometry(.01,2),a),null,null,null,"helper"]],END:[[new ei.Mesh(new ei.OctahedronGeometry(.01,2),a),null,null,null,"helper"]],DELTA:[[new ei.Line(function(){let e=new ei.BufferGeometry;return e.setAttribute("position",new ei.Float32BufferAttribute([0,0,0,1,1,1],3)),e}(),a),null,null,null,"helper"]],X:[[new ei.Line(g,a),[-1e3,0,0],null,[1e6,1,1],"helper"]],Y:[[new ei.Line(g,a),[0,-1e3,0],[0,0,Math.PI/2],[1e6,1,1],"helper"]],Z:[[new ei.Line(g,a),[0,0,-1e3],[0,-Math.PI/2,0],[1e6,1,1],"helper"]]},M={XYZE:[[new ei.Mesh(b(.5,1),m),null,[0,Math.PI/2,0]]],X:[[new ei.Mesh(b(.5,.5),r)]],Y:[[new ei.Mesh(b(.5,.5),o),null,[0,0,-Math.PI/2]]],Z:[[new ei.Mesh(b(.5,.5),s),null,[0,Math.PI/2,0]]],E:[[new ei.Mesh(b(.75,1),d),null,[0,Math.PI/2,0]]]},S={AXIS:[[new ei.Line(g,a),[-1e3,0,0],null,[1e6,1,1],"helper"]]},T={XYZE:[[new ei.Mesh(new ei.SphereGeometry(.25,10,8),i)]],X:[[new ei.Mesh(new ei.TorusGeometry(.5,.1,4,24),i),[0,0,0],[0,-Math.PI/2,-Math.PI/2]]],Y:[[new ei.Mesh(new ei.TorusGeometry(.5,.1,4,24),i),[0,0,0],[Math.PI/2,0,0]]],Z:[[new ei.Mesh(new ei.TorusGeometry(.5,.1,4,24),i),[0,0,0],[0,0,-Math.PI/2]]],E:[[new ei.Mesh(new ei.TorusGeometry(.75,.1,2,24),i)]]},C={X:[[new ei.Mesh(f,r),[.5,0,0],[0,0,-Math.PI/2]],[new ei.Mesh(v,r),[0,0,0],[0,0,-Math.PI/2]],[new ei.Mesh(f,r),[-.5,0,0],[0,0,Math.PI/2]]],Y:[[new ei.Mesh(f,o),[0,.5,0]],[new ei.Mesh(v,o)],[new ei.Mesh(f,o),[0,-.5,0],[0,0,Math.PI]]],Z:[[new ei.Mesh(f,s),[0,0,.5],[Math.PI/2,0,0]],[new ei.Mesh(v,s),[0,0,0],[Math.PI/2,0,0]],[new ei.Mesh(f,s),[0,0,-.5],[-Math.PI/2,0,0]]],XY:[[new ei.Mesh(new ei.BoxGeometry(.15,.15,.01),h),[.15,.15,0]]],YZ:[[new ei.Mesh(new ei.BoxGeometry(.15,.15,.01),n),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ei.Mesh(new ei.BoxGeometry(.15,.15,.01),l),[.15,0,.15],[-Math.PI/2,0,0]]],XYZ:[[new ei.Mesh(new ei.BoxGeometry(.1,.1,.1),c)]]},P={X:[[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[.3,0,0],[0,0,-Math.PI/2]],[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[-.3,0,0],[0,0,Math.PI/2]]],Y:[[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[0,.3,0]],[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[0,-.3,0],[0,0,Math.PI]]],Z:[[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[0,0,.3],[Math.PI/2,0,0]],[new ei.Mesh(new ei.CylinderGeometry(.2,0,.6,4),i),[0,0,-.3],[-Math.PI/2,0,0]]],XY:[[new ei.Mesh(new ei.BoxGeometry(.2,.2,.01),i),[.15,.15,0]]],YZ:[[new ei.Mesh(new ei.BoxGeometry(.2,.2,.01),i),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ei.Mesh(new ei.BoxGeometry(.2,.2,.01),i),[.15,0,.15],[-Math.PI/2,0,0]]],XYZ:[[new ei.Mesh(new ei.BoxGeometry(.2,.2,.2),i),[0,0,0]]]},A={X:[[new ei.Line(g,a),[-1e3,0,0],null,[1e6,1,1],"helper"]],Y:[[new ei.Line(g,a),[0,-1e3,0],[0,0,Math.PI/2],[1e6,1,1],"helper"]],Z:[[new ei.Line(g,a),[0,0,-1e3],[0,-Math.PI/2,0],[1e6,1,1],"helper"]]};function k(e){let t=new ei.Object3D;for(let i in e)for(let a=e[i].length;a--;){let r=e[i][a][0].clone(),o=e[i][a][1],s=e[i][a][2],n=e[i][a][3],l=e[i][a][4];r.name=i,r.tag=l,o&&r.position.set(o[0],o[1],o[2]),s&&r.rotation.set(s[0],s[1],s[2]),n&&r.scale.set(n[0],n[1],n[2]),r.updateMatrix();let h=r.geometry.clone();h.applyMatrix4(r.matrix),r.geometry=h,r.renderOrder=1/0,r.position.set(0,0,0),r.rotation.set(0,0,0),r.scale.set(1,1,1),t.add(r)}return t}this.gizmo={},this.picker={},this.helper={},this.add(this.gizmo.translate=k(w)),this.add(this.gizmo.rotate=k(M)),this.add(this.gizmo.scale=k(C)),this.add(this.picker.translate=k(y)),this.add(this.picker.rotate=k(T)),this.add(this.picker.scale=k(P)),this.add(this.helper.translate=k(x)),this.add(this.helper.rotate=k(S)),this.add(this.helper.scale=k(A)),this.picker.translate.visible=!1,this.picker.rotate.visible=!1,this.picker.scale.visible=!1}updateMatrixWorld(e){let t="local"===("scale"===this.mode?"local":this.space)?this.worldQuaternion:eT;this.gizmo.translate.visible="translate"===this.mode,this.gizmo.rotate.visible="rotate"===this.mode,this.gizmo.scale.visible="scale"===this.mode,this.helper.translate.visible="translate"===this.mode,this.helper.rotate.visible="rotate"===this.mode,this.helper.scale.visible="scale"===this.mode;let i=[];i=(i=(i=i.concat(this.picker[this.mode].children)).concat(this.gizmo[this.mode].children)).concat(this.helper[this.mode].children);for(let e=0;e<i.length;e++){let a,r=i[e];if(r.visible=!0,r.rotation.set(0,0,0),r.position.copy(this.worldPosition),a=this.camera.isOrthographicCamera?(this.camera.top-this.camera.bottom)/this.camera.zoom:this.worldPosition.distanceTo(this.cameraPosition)*Math.min(1.9*Math.tan(Math.PI*this.camera.fov/360)/this.camera.zoom,7),r.scale.set(1,1,1).multiplyScalar(a*this.size/4),"helper"===r.tag){r.visible=!1,"AXIS"===r.name?(r.visible=!!this.axis,"X"===this.axis&&(es.setFromEuler(ew.set(0,0,0)),r.quaternion.copy(t).multiply(es),Math.abs(ey.copy(eA).applyQuaternion(t).dot(this.eye))>.9&&(r.visible=!1)),"Y"===this.axis&&(es.setFromEuler(ew.set(0,0,Math.PI/2)),r.quaternion.copy(t).multiply(es),Math.abs(ey.copy(ek).applyQuaternion(t).dot(this.eye))>.9&&(r.visible=!1)),"Z"===this.axis&&(es.setFromEuler(ew.set(0,Math.PI/2,0)),r.quaternion.copy(t).multiply(es),Math.abs(ey.copy(eD).applyQuaternion(t).dot(this.eye))>.9&&(r.visible=!1)),"XYZE"===this.axis&&(es.setFromEuler(ew.set(0,Math.PI/2,0)),ey.copy(this.rotationAxis),r.quaternion.setFromRotationMatrix(eM.lookAt(ex,ey,ek)),r.quaternion.multiply(es),r.visible=this.dragging),"E"===this.axis&&(r.visible=!1)):"START"===r.name?(r.position.copy(this.worldPositionStart),r.visible=this.dragging):"END"===r.name?(r.position.copy(this.worldPosition),r.visible=this.dragging):"DELTA"===r.name?(r.position.copy(this.worldPositionStart),r.quaternion.copy(this.worldQuaternionStart),er.set(1e-10,1e-10,1e-10).add(this.worldPositionStart).sub(this.worldPosition).multiplyScalar(-1),er.applyQuaternion(this.worldQuaternionStart.clone().invert()),r.scale.copy(er),r.visible=this.dragging):(r.quaternion.copy(t),this.dragging?r.position.copy(this.worldPositionStart):r.position.copy(this.worldPosition),this.axis&&(r.visible=-1!==this.axis.search(r.name)));continue}r.quaternion.copy(t),"translate"===this.mode||"scale"===this.mode?("X"===r.name&&Math.abs(ey.copy(eA).applyQuaternion(t).dot(this.eye))>.99&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),"Y"===r.name&&Math.abs(ey.copy(ek).applyQuaternion(t).dot(this.eye))>.99&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),"Z"===r.name&&Math.abs(ey.copy(eD).applyQuaternion(t).dot(this.eye))>.99&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),"XY"===r.name&&.2>Math.abs(ey.copy(eD).applyQuaternion(t).dot(this.eye))&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),"YZ"===r.name&&.2>Math.abs(ey.copy(eA).applyQuaternion(t).dot(this.eye))&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),"XZ"===r.name&&.2>Math.abs(ey.copy(ek).applyQuaternion(t).dot(this.eye))&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1)):"rotate"===this.mode&&(eS.copy(t),ey.copy(this.eye).applyQuaternion(es.copy(t).invert()),-1!==r.name.search("E")&&r.quaternion.setFromRotationMatrix(eM.lookAt(this.eye,ex,ek)),"X"===r.name&&(es.setFromAxisAngle(eA,Math.atan2(-ey.y,ey.z)),es.multiplyQuaternions(eS,es),r.quaternion.copy(es)),"Y"===r.name&&(es.setFromAxisAngle(ek,Math.atan2(ey.x,ey.z)),es.multiplyQuaternions(eS,es),r.quaternion.copy(es)),"Z"===r.name&&(es.setFromAxisAngle(eD,Math.atan2(ey.y,ey.x)),es.multiplyQuaternions(eS,es),r.quaternion.copy(es))),r.visible=r.visible&&(-1===r.name.indexOf("X")||this.showX),r.visible=r.visible&&(-1===r.name.indexOf("Y")||this.showY),r.visible=r.visible&&(-1===r.name.indexOf("Z")||this.showZ),r.visible=r.visible&&(-1===r.name.indexOf("E")||this.showX&&this.showY&&this.showZ),r.material._color=r.material._color||r.material.color.clone(),r.material._opacity=r.material._opacity||r.material.opacity,r.material.color.copy(r.material._color),r.material.opacity=r.material._opacity,this.enabled&&this.axis&&(r.name===this.axis?(r.material.color.copy(this.materialLib.active.color),r.material.opacity=1):this.axis.split("").some(function(e){return r.name===e})&&(r.material.color.copy(this.materialLib.active.color),r.material.opacity=1))}super.updateMatrixWorld(e)}}class eF extends ei.Mesh{constructor(){super(new ei.PlaneGeometry(1e5,1e5,2,2),new ei.MeshBasicMaterial({visible:!1,wireframe:!0,side:ei.DoubleSide,transparent:!0,opacity:.1,toneMapped:!1})),this.isTransformControlsPlane=!0,this.type="TransformControlsPlane"}updateMatrixWorld(e){let t=this.space;switch(this.position.copy(this.worldPosition),"scale"===this.mode&&(t="local"),ez.copy(eA).applyQuaternion("local"===t?this.worldQuaternion:eT),e_.copy(ek).applyQuaternion("local"===t?this.worldQuaternion:eT),eL.copy(eD).applyQuaternion("local"===t?this.worldQuaternion:eT),ey.copy(e_),this.mode){case"translate":case"scale":switch(this.axis){case"X":ey.copy(this.eye).cross(ez),eC.copy(ez).cross(ey);break;case"Y":ey.copy(this.eye).cross(e_),eC.copy(e_).cross(ey);break;case"Z":ey.copy(this.eye).cross(eL),eC.copy(eL).cross(ey);break;case"XY":eC.copy(eL);break;case"YZ":eC.copy(ez);break;case"XZ":ey.copy(eL),eC.copy(e_);break;case"XYZ":case"E":eC.set(0,0,0)}break;default:eC.set(0,0,0)}0===eC.length()?this.quaternion.copy(this.cameraQuaternion):(eP.lookAt(er.set(0,0,0),eC,ey),this.quaternion.setFromRotationMatrix(eP)),super.updateMatrixWorld(e)}}var eI=L;class eU extends eI.Scene{constructor(){super(),this.name="RoomEnvironment",this.position.y=-3.5;const e=new eI.BoxGeometry;e.deleteAttribute("uv");const t=new eI.MeshStandardMaterial({side:eI.BackSide}),i=new eI.MeshStandardMaterial,a=new eI.PointLight(0xffffff,900,28,2);a.position.set(.418,16.199,.3),this.add(a);const r=new eI.Mesh(e,t);r.position.set(-.757,13.219,.717),r.scale.set(31.713,28.305,28.591),this.add(r);const o=new eI.InstancedMesh(e,i,6),s=new eI.Object3D;s.position.set(-10.906,2.009,1.846),s.rotation.set(0,-.195,0),s.scale.set(2.328,7.905,4.651),s.updateMatrix(),o.setMatrixAt(0,s.matrix),s.position.set(-5.607,-.754,-.758),s.rotation.set(0,.994,0),s.scale.set(1.97,1.534,3.955),s.updateMatrix(),o.setMatrixAt(1,s.matrix),s.position.set(6.167,.857,7.803),s.rotation.set(0,.561,0),s.scale.set(3.927,6.285,3.687),s.updateMatrix(),o.setMatrixAt(2,s.matrix),s.position.set(-2.017,.018,6.124),s.rotation.set(0,.333,0),s.scale.set(2.002,4.566,2.064),s.updateMatrix(),o.setMatrixAt(3,s.matrix),s.position.set(2.291,-.756,-2.621),s.rotation.set(0,-.286,0),s.scale.set(1.546,1.552,1.496),s.updateMatrix(),o.setMatrixAt(4,s.matrix),s.position.set(-2.193,-.369,-5.547),s.rotation.set(0,.516,0),s.scale.set(3.875,3.487,2.986),s.updateMatrix(),o.setMatrixAt(5,s.matrix),this.add(o);const n=new eI.Mesh(e,eN(50));n.position.set(-16.116,14.37,8.208),n.scale.set(.1,2.428,2.739),this.add(n);const l=new eI.Mesh(e,eN(50));l.position.set(-16.109,18.021,-8.207),l.scale.set(.1,2.425,2.751),this.add(l);const h=new eI.Mesh(e,eN(17));h.position.set(14.904,12.198,-1.832),h.scale.set(.15,4.265,6.331),this.add(h);const c=new eI.Mesh(e,eN(43));c.position.set(-.462,8.89,14.52),c.scale.set(4.38,5.441,.088),this.add(c);const d=new eI.Mesh(e,eN(20));d.position.set(3.235,11.486,-12.541),d.scale.set(2.5,2,.1),this.add(d);const u=new eI.Mesh(e,eN(100));u.position.set(0,20,0),u.scale.set(1,.1,1),this.add(u)}dispose(){let e=new Set;for(let t of(this.traverse(t=>{t.isMesh&&(e.add(t.geometry),e.add(t.material))}),e))t.dispose()}}function eN(e){return new eI.MeshLambertMaterial({color:0,emissive:0xffffff,emissiveIntensity:e})}var eB=L;class eV extends eB.DataTextureLoader{constructor(e){super(e),this.type=eB.HalfFloatType}parse(e){let t,i,a,r=function(e,t){switch(e){case 1:throw Error("THREE.HDRLoader: Read Error: "+(t||""));case 2:throw Error("THREE.HDRLoader: Write Error: "+(t||""));case 3:throw Error("THREE.HDRLoader: Bad File Format: "+(t||""));default:throw Error("THREE.HDRLoader: Memory Error: "+(t||""))}},o=function(e,t,i){t=t||1024;let a=e.pos,r=-1,o=0,s="",n=String.fromCharCode.apply(null,new Uint16Array(e.subarray(a,a+128)));for(;0>(r=n.indexOf("\n"))&&o<t&&a<e.byteLength;)s+=n,o+=n.length,a+=128,n+=String.fromCharCode.apply(null,new Uint16Array(e.subarray(a,a+128)));return -1<r&&(!1!==i&&(e.pos+=o+r+1),s+n.slice(0,r))},s=new Uint8Array(e);s.pos=0;let n=function(e){let t,i,a=/^\s*GAMMA\s*=\s*(\d+(\.\d+)?)\s*$/,s=/^\s*EXPOSURE\s*=\s*(\d+(\.\d+)?)\s*$/,n=/^\s*FORMAT=(\S+)\s*$/,l=/^\s*\-Y\s+(\d+)\s+\+X\s+(\d+)\s*$/,h={valid:0,string:"",comments:"",programtype:"RGBE",format:"",gamma:1,exposure:1,width:0,height:0};for(!(e.pos>=e.byteLength)&&(t=o(e))||r(1,"no header found"),(i=t.match(/^#\?(\S+)/))||r(3,"bad initial token"),h.valid|=1,h.programtype=i[1],h.string+=t+"\n";!1!==(t=o(e));){if(h.string+=t+"\n","#"===t.charAt(0)){h.comments+=t+"\n";continue}if((i=t.match(a))&&(h.gamma=parseFloat(i[1])),(i=t.match(s))&&(h.exposure=parseFloat(i[1])),(i=t.match(n))&&(h.valid|=2,h.format=i[1]),(i=t.match(l))&&(h.valid|=4,h.height=parseInt(i[1],10),h.width=parseInt(i[2],10)),2&h.valid&&4&h.valid)break}return 2&h.valid||r(3,"missing format specifier"),4&h.valid||r(3,"missing image size specifier"),h}(s),l=n.width,h=n.height,c=function(e,t,i){if(t<8||t>32767||2!==e[0]||2!==e[1]||128&e[2])return new Uint8Array(e);t!==(e[2]<<8|e[3])&&r(3,"wrong scanline width");let a=new Uint8Array(4*t*i);a.length||r(4,"unable to allocate buffer space");let o=0,s=0,n=4*t,l=new Uint8Array(4),h=new Uint8Array(n),c=i;for(;c>0&&s<e.byteLength;){s+4>e.byteLength&&r(1),l[0]=e[s++],l[1]=e[s++],l[2]=e[s++],l[3]=e[s++],(2!=l[0]||2!=l[1]||(l[2]<<8|l[3])!=t)&&r(3,"bad rgbe scanline format");let i=0,d;for(;i<n&&s<e.byteLength;){let t=(d=e[s++])>128;if(t&&(d-=128),(0===d||i+d>n)&&r(3,"bad scanline data"),t){let t=e[s++];for(let e=0;e<d;e++)h[i++]=t}else h.set(e.subarray(s,s+d),i),i+=d,s+=d}for(let e=0;e<t;e++){let i=0;a[o]=h[e+i],i+=t,a[o+1]=h[e+i],i+=t,a[o+2]=h[e+i],i+=t,a[o+3]=h[e+i],o+=4}c--}return a}(s.subarray(s.pos),l,h);switch(this.type){case eB.FloatType:let d=new Float32Array(4*(a=c.length/4));for(let e=0;e<a;e++)!function(e,t,i,a){let r=Math.pow(2,e[t+3]-128)/255;i[a+0]=e[t+0]*r,i[a+1]=e[t+1]*r,i[a+2]=e[t+2]*r,i[a+3]=1}(c,4*e,d,4*e);t=d,i=eB.FloatType;break;case eB.HalfFloatType:let u=new Uint16Array(4*(a=c.length/4));for(let e=0;e<a;e++)!function(e,t,i,a){let r=Math.pow(2,e[t+3]-128)/255;i[a+0]=eB.DataUtils.toHalfFloat(Math.min(e[t+0]*r,65504)),i[a+1]=eB.DataUtils.toHalfFloat(Math.min(e[t+1]*r,65504)),i[a+2]=eB.DataUtils.toHalfFloat(Math.min(e[t+2]*r,65504)),i[a+3]=eB.DataUtils.toHalfFloat(1)}(c,4*e,u,4*e);t=u,i=eB.HalfFloatType;break;default:throw Error("THREE.HDRLoader: Unsupported type: "+this.type)}return{width:l,height:h,data:t,header:n.string,gamma:n.gamma,exposure:n.exposure,type:i}}setDataType(e){return this.type=e,this}load(e,t,i,a){return super.load(e,function(e,i){switch(e.type){case eB.FloatType:case eB.HalfFloatType:e.colorSpace=eB.LinearSRGBColorSpace,e.minFilter=eB.LinearFilter,e.magFilter=eB.LinearFilter,e.generateMipmaps=!1,e.flipY=!0}t&&t(e,i)},i,a)}}var eO=e.i(64154);let eG={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};var ej=L;class eH{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}}let eW=new ej.OrthographicCamera(-1,1,1,-1,0,1);class eq extends ej.BufferGeometry{constructor(){super(),this.setAttribute("position",new ej.Float32BufferAttribute([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new ej.Float32BufferAttribute([0,2,0,0,2,0],2))}}let eX=new eq;class eK{constructor(e){this._mesh=new ej.Mesh(eX,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,eW)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}}class eY extends eH{constructor(e,t="tDiffuse"){super(),this.textureID=t,this.uniforms=null,this.material=null,e instanceof L.ShaderMaterial?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=L.UniformsUtils.clone(e.uniforms),this.material=new L.ShaderMaterial({name:void 0!==e.name?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this._fsQuad=new eK(this.material)}render(e,t,i){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=i.texture),this._fsQuad.material=this.material,this.renderToScreen?e.setRenderTarget(null):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil)),this._fsQuad.render(e)}dispose(){this.material.dispose(),this._fsQuad.dispose()}}class eZ extends eH{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,i){let a,r,o=e.getContext(),s=e.state;s.buffers.color.setMask(!1),s.buffers.depth.setMask(!1),s.buffers.color.setLocked(!0),s.buffers.depth.setLocked(!0),this.inverse?(a=0,r=1):(a=1,r=0),s.buffers.stencil.setTest(!0),s.buffers.stencil.setOp(o.REPLACE,o.REPLACE,o.REPLACE),s.buffers.stencil.setFunc(o.ALWAYS,a,0xffffffff),s.buffers.stencil.setClear(r),s.buffers.stencil.setLocked(!0),e.setRenderTarget(i),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),s.buffers.color.setLocked(!1),s.buffers.depth.setLocked(!1),s.buffers.color.setMask(!0),s.buffers.depth.setMask(!0),s.buffers.stencil.setLocked(!1),s.buffers.stencil.setFunc(o.EQUAL,1,0xffffffff),s.buffers.stencil.setOp(o.KEEP,o.KEEP,o.KEEP),s.buffers.stencil.setLocked(!0)}}class e$ extends eH{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}}class eQ{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),void 0===t){const i=e.getSize(new L.Vector2);this._width=i.width,this._height=i.height,(t=new L.WebGLRenderTarget(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:L.HalfFloatType})).texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new eY(eG),this.copyPass.material.blending=L.NoBlending,this.timer=new L.Timer}swapBuffers(){let e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){let t=this.passes.indexOf(e);-1!==t&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){this.timer.update(),void 0===e&&(e=this.timer.getDelta());let t=this.renderer.getRenderTarget(),i=!1;for(let t=0,a=this.passes.length;t<a;t++){let a=this.passes[t];if(!1!==a.enabled){if(a.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(t),a.render(this.renderer,this.writeBuffer,this.readBuffer,e,i),a.needsSwap){if(i){let t=this.renderer.getContext(),i=this.renderer.state.buffers.stencil;i.setFunc(t.NOTEQUAL,1,0xffffffff),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),i.setFunc(t.EQUAL,1,0xffffffff)}this.swapBuffers()}void 0!==eZ&&(a instanceof eZ?i=!0:a instanceof e$&&(i=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(void 0===e){let t=this.renderer.getSize(new L.Vector2);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,(e=this.renderTarget1.clone()).setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;let i=this._width*this._pixelRatio,a=this._height*this._pixelRatio;this.renderTarget1.setSize(i,a),this.renderTarget2.setSize(i,a);for(let e=0;e<this.passes.length;e++)this.passes[e].setSize(i,a)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}}class eJ extends eH{constructor(e,t,i=null,a=null,r=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=i,this.clearColor=a,this.clearAlpha=r,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this.isRenderPass=!0,this._oldClearColor=new L.Color}render(e,t,i){let a,r,o=e.autoClear;e.autoClear=!1,null!==this.overrideMaterial&&(r=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),null!==this.clearColor&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),null!==this.clearAlpha&&(a=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),!0==this.clearDepth&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:i),!0===this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),null!==this.clearColor&&e.setClearColor(this._oldClearColor),null!==this.clearAlpha&&e.setClearAlpha(a),null!==this.overrideMaterial&&(this.scene.overrideMaterial=r),e.autoClear=o}}let e0={name:"LuminosityHighPassShader",uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new L.Color(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};class e1 extends eH{constructor(e,t=1,i,a){super(),this.strength=t,this.radius=i,this.threshold=a,this.resolution=void 0!==e?new L.Vector2(e.x,e.y):new L.Vector2(256,256),this.clearColor=new L.Color(0,0,0),this.needsSwap=!1,this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let r=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);this.renderTargetBright=new L.WebGLRenderTarget(r,o,{type:L.HalfFloatType}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let e=0;e<this.nMips;e++){const t=new L.WebGLRenderTarget(r,o,{type:L.HalfFloatType});t.texture.name="UnrealBloomPass.h"+e,t.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(t);const i=new L.WebGLRenderTarget(r,o,{type:L.HalfFloatType});i.texture.name="UnrealBloomPass.v"+e,i.texture.generateMipmaps=!1,this.renderTargetsVertical.push(i),r=Math.round(r/2),o=Math.round(o/2)}this.highPassUniforms=L.UniformsUtils.clone(e0.uniforms),this.highPassUniforms.luminosityThreshold.value=a,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new L.ShaderMaterial({uniforms:this.highPassUniforms,vertexShader:e0.vertexShader,fragmentShader:e0.fragmentShader}),this.separableBlurMaterials=[];const s=[6,10,14,18,22];r=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);for(let e=0;e<this.nMips;e++)this.separableBlurMaterials.push(this._getSeparableBlurMaterial(s[e])),this.separableBlurMaterials[e].uniforms.invSize.value=new L.Vector2(1/r,1/o),r=Math.round(r/2),o=Math.round(o/2);this.compositeMaterial=this._getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1,this.compositeMaterial.uniforms.bloomFactors.value=[1,.8,.6,.4,.2],this.bloomTintColors=[new L.Vector3(1,1,1),new L.Vector3(1,1,1),new L.Vector3(1,1,1),new L.Vector3(1,1,1),new L.Vector3(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,this.copyUniforms=L.UniformsUtils.clone(eG.uniforms),this.blendMaterial=new L.ShaderMaterial({uniforms:this.copyUniforms,vertexShader:eG.vertexShader,fragmentShader:eG.fragmentShader,premultipliedAlpha:!0,blending:L.AdditiveBlending,depthTest:!1,depthWrite:!1,transparent:!0}),this._oldClearColor=new L.Color,this._oldClearAlpha=1,this._basic=new L.MeshBasicMaterial,this._fsQuad=new eK(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this._basic.dispose(),this._fsQuad.dispose()}setSize(e,t){let i=Math.round(e/2),a=Math.round(t/2);this.renderTargetBright.setSize(i,a);for(let e=0;e<this.nMips;e++)this.renderTargetsHorizontal[e].setSize(i,a),this.renderTargetsVertical[e].setSize(i,a),this.separableBlurMaterials[e].uniforms.invSize.value=new L.Vector2(1/i,1/a),i=Math.round(i/2),a=Math.round(a/2)}render(e,t,i,a,r){e.getClearColor(this._oldClearColor),this._oldClearAlpha=e.getClearAlpha();let o=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),r&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this._fsQuad.material=this._basic,this._basic.map=i.texture,e.setRenderTarget(null),e.clear(),this._fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=i.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this._fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this._fsQuad.render(e);let s=this.renderTargetBright;for(let t=0;t<this.nMips;t++)this._fsQuad.material=this.separableBlurMaterials[t],this.separableBlurMaterials[t].uniforms.colorTexture.value=s.texture,this.separableBlurMaterials[t].uniforms.direction.value=e1.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[t]),e.clear(),this._fsQuad.render(e),this.separableBlurMaterials[t].uniforms.colorTexture.value=this.renderTargetsHorizontal[t].texture,this.separableBlurMaterials[t].uniforms.direction.value=e1.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[t]),e.clear(),this._fsQuad.render(e),s=this.renderTargetsVertical[t];this._fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this._fsQuad.render(e),this._fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,r&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?e.setRenderTarget(null):e.setRenderTarget(i),this._fsQuad.render(e),e.setClearColor(this._oldClearColor,this._oldClearAlpha),e.autoClear=o}_getSeparableBlurMaterial(e){let t=[],i=e/3;for(let a=0;a<e;a++)t.push(.39894*Math.exp(-.5*a*a/(i*i))/i);return new L.ShaderMaterial({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new L.Vector2(.5,.5)},direction:{value:new L.Vector2(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				#include <common>

				varying vec2 vUv;

				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {

					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;

					for ( int i = 1; i < KERNEL_RADIUS; i ++ ) {

						float x = float( i );
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += ( sample1 + sample2 ) * w;

					}

					gl_FragColor = vec4( diffuseSum, 1.0 );

				}`})}_getCompositeMaterial(e){return new L.ShaderMaterial({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				varying vec2 vUv;

				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor( const in float factor ) {

					float mirrorFactor = 1.2 - factor;
					return mix( factor, mirrorFactor, bloomRadius );

				}

				void main() {

					// 3.0 for backwards compatibility with previous alpha-based intensity
					vec3 bloom = 3.0 * bloomStrength * (
						lerpBloomFactor( bloomFactors[ 0 ] ) * bloomTintColors[ 0 ] * texture2D( blurTexture1, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 1 ] ) * bloomTintColors[ 1 ] * texture2D( blurTexture2, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 2 ] ) * bloomTintColors[ 2 ] * texture2D( blurTexture3, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 3 ] ) * bloomTintColors[ 3 ] * texture2D( blurTexture4, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 4 ] ) * bloomTintColors[ 4 ] * texture2D( blurTexture5, vUv ).rgb
					);

					float bloomAlpha = max( bloom.r, max( bloom.g, bloom.b ) );
					gl_FragColor = vec4( bloom, bloomAlpha );

				}`})}}e1.BlurDirectionX=new L.Vector2(1,0),e1.BlurDirectionY=new L.Vector2(0,1);let e2={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#elif defined( NEUTRAL_TONE_MAPPING )

				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );

			#elif defined( CUSTOM_TONE_MAPPING )

				gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};class e9 extends eH{constructor(){super(),this.isOutputPass=!0,this.uniforms=L.UniformsUtils.clone(e2.uniforms),this.material=new L.RawShaderMaterial({name:e2.name,uniforms:this.uniforms,vertexShader:e2.vertexShader,fragmentShader:e2.fragmentShader}),this._fsQuad=new eK(this.material),this._outputColorSpace=null,this._toneMapping=null}render(e,t,i){this.uniforms.tDiffuse.value=i.texture,this.uniforms.toneMappingExposure.value=e.toneMappingExposure,(this._outputColorSpace!==e.outputColorSpace||this._toneMapping!==e.toneMapping)&&(this._outputColorSpace=e.outputColorSpace,this._toneMapping=e.toneMapping,this.material.defines={},L.ColorManagement.getTransfer(this._outputColorSpace)===L.SRGBTransfer&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===L.LinearToneMapping?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===L.ReinhardToneMapping?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===L.CineonToneMapping?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===L.ACESFilmicToneMapping?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===L.AgXToneMapping?this.material.defines.AGX_TONE_MAPPING="":this._toneMapping===L.NeutralToneMapping?this.material.defines.NEUTRAL_TONE_MAPPING="":this._toneMapping===L.CustomToneMapping&&(this.material.defines.CUSTOM_TONE_MAPPING=""),this.material.needsUpdate=!0),!0===this.renderToScreen?e.setRenderTarget(null):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil)),this._fsQuad.render(e)}dispose(){this.material.dispose(),this._fsQuad.dispose()}}let e3={name:"GTAOShader",defines:{PERSPECTIVE_CAMERA:1,SAMPLES:16,NORMAL_VECTOR_TYPE:1,DEPTH_SWIZZLING:"x",SCREEN_SPACE_RADIUS:0,SCREEN_SPACE_RADIUS_SCALE:100,SCENE_CLIP_BOX:0},uniforms:{tNormal:{value:null},tDepth:{value:null},tNoise:{value:null},resolution:{value:new L.Vector2},cameraNear:{value:null},cameraFar:{value:null},cameraProjectionMatrix:{value:new L.Matrix4},cameraProjectionMatrixInverse:{value:new L.Matrix4},cameraWorldMatrix:{value:new L.Matrix4},radius:{value:.25},distanceExponent:{value:1},thickness:{value:1},distanceFallOff:{value:1},scale:{value:1},sceneBoxMin:{value:new L.Vector3(-1,-1,-1)},sceneBoxMax:{value:new L.Vector3(1,1,1)}},vertexShader:`

		varying vec2 vUv;

		void main() {
			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
		}`,fragmentShader:`
		varying vec2 vUv;
		uniform highp sampler2D tNormal;
		uniform highp sampler2D tDepth;
		uniform sampler2D tNoise;
		uniform vec2 resolution;
		uniform float cameraNear;
		uniform float cameraFar;
		uniform mat4 cameraProjectionMatrix;
		uniform mat4 cameraProjectionMatrixInverse;
		uniform mat4 cameraWorldMatrix;
		uniform float radius;
		uniform float distanceExponent;
		uniform float thickness;
		uniform float distanceFallOff;
		uniform float scale;
		#if SCENE_CLIP_BOX == 1
			uniform vec3 sceneBoxMin;
			uniform vec3 sceneBoxMax;
		#endif

		#include <common>
		#include <packing>

		#ifndef FRAGMENT_OUTPUT
		#define FRAGMENT_OUTPUT vec4(vec3(ao), 1.)
		#endif

		vec3 getViewPosition( const in vec2 screenPosition, const in float depth ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				vec4 clipSpacePosition = vec4( vec2( screenPosition ) * 2.0 - 1.0, depth, 1.0 );
			#else
				vec4 clipSpacePosition = vec4( vec3( screenPosition, depth ) * 2.0 - 1.0, 1.0 );
			#endif
			vec4 viewSpacePosition = cameraProjectionMatrixInverse * clipSpacePosition;
			return viewSpacePosition.xyz / viewSpacePosition.w;
		}

		float getDepth(const vec2 uv) {
			return textureLod(tDepth, uv.xy, 0.0).DEPTH_SWIZZLING;
		}

		float fetchDepth(const ivec2 uv) {
			return texelFetch(tDepth, uv.xy, 0).DEPTH_SWIZZLING;
		}

		float getViewZ(const in float depth) {
			#if PERSPECTIVE_CAMERA == 1
				return perspectiveDepthToViewZ(depth, cameraNear, cameraFar);
			#else
				return orthographicDepthToViewZ(depth, cameraNear, cameraFar);
			#endif
		}

		vec3 computeNormalFromDepth(const vec2 uv) {
			vec2 size = vec2(textureSize(tDepth, 0));
			ivec2 p = ivec2(uv * size);
			float c0 = fetchDepth(p);
			float l2 = fetchDepth(p - ivec2(2, 0));
			float l1 = fetchDepth(p - ivec2(1, 0));
			float r1 = fetchDepth(p + ivec2(1, 0));
			float r2 = fetchDepth(p + ivec2(2, 0));
			float b2 = fetchDepth(p - ivec2(0, 2));
			float b1 = fetchDepth(p - ivec2(0, 1));
			float t1 = fetchDepth(p + ivec2(0, 1));
			float t2 = fetchDepth(p + ivec2(0, 2));
			float dl = abs((2.0 * l1 - l2) - c0);
			float dr = abs((2.0 * r1 - r2) - c0);
			float db = abs((2.0 * b1 - b2) - c0);
			float dt = abs((2.0 * t1 - t2) - c0);
			vec3 ce = getViewPosition(uv, c0).xyz;
			vec3 dpdx = (dl < dr) ? ce - getViewPosition((uv - vec2(1.0 / size.x, 0.0)), l1).xyz : -ce + getViewPosition((uv + vec2(1.0 / size.x, 0.0)), r1).xyz;
			vec3 dpdy = (db < dt) ? ce - getViewPosition((uv - vec2(0.0, 1.0 / size.y)), b1).xyz : -ce + getViewPosition((uv + vec2(0.0, 1.0 / size.y)), t1).xyz;
			return normalize(cross(dpdx, dpdy));
		}

		vec3 getViewNormal(const vec2 uv) {
			#if NORMAL_VECTOR_TYPE == 2
				return normalize(textureLod(tNormal, uv, 0.).rgb);
			#elif NORMAL_VECTOR_TYPE == 1
				return unpackRGBToNormal(textureLod(tNormal, uv, 0.).rgb);
			#else
				return computeNormalFromDepth(uv);
			#endif
		}

		vec3 getSceneUvAndDepth(vec3 sampleViewPos) {
			vec4 sampleClipPos = cameraProjectionMatrix * vec4(sampleViewPos, 1.);
			vec2 sampleUv = sampleClipPos.xy / sampleClipPos.w * 0.5 + 0.5;
			float sampleSceneDepth = getDepth(sampleUv);
			return vec3(sampleUv, sampleSceneDepth);
		}

		void main() {
			float depth = getDepth(vUv.xy);

			#ifdef USE_REVERSED_DEPTH_BUFFER
				if (depth <= 0.0) {
					discard;
					return;
				}
			#else
				if (depth >= 1.0) {
					discard;
					return;
				}
			#endif
			
			vec3 viewPos = getViewPosition(vUv, depth);
			vec3 viewNormal = getViewNormal(vUv);

			float radiusToUse = radius;
			float distanceFalloffToUse = thickness;
			#if SCREEN_SPACE_RADIUS == 1
				float radiusScale = getViewPosition(vec2(0.5 + float(SCREEN_SPACE_RADIUS_SCALE) / resolution.x, 0.0), depth).x;
				radiusToUse *= radiusScale;
				distanceFalloffToUse *= radiusScale;
			#endif

			#if SCENE_CLIP_BOX == 1
				vec3 worldPos = (cameraWorldMatrix * vec4(viewPos, 1.0)).xyz;
				float boxDistance = length(max(vec3(0.0), max(sceneBoxMin - worldPos, worldPos - sceneBoxMax)));
				if (boxDistance > radiusToUse) {
					discard;
					return;
				}
			#endif

			vec2 noiseResolution = vec2(textureSize(tNoise, 0));
			vec2 noiseUv = vUv * resolution / noiseResolution;
			vec4 noiseTexel = textureLod(tNoise, noiseUv, 0.0);
			vec3 randomVec = noiseTexel.xyz * 2.0 - 1.0;
			vec3 tangent = normalize(vec3(randomVec.xy, 0.));
			vec3 bitangent = vec3(-tangent.y, tangent.x, 0.);
			mat3 kernelMatrix = mat3(tangent, bitangent, vec3(0., 0., 1.));

			const int DIRECTIONS = SAMPLES < 30 ? 3 : 5;
			const int STEPS = (SAMPLES + DIRECTIONS - 1) / DIRECTIONS;
			float ao = 0.0;
			for (int i = 0; i < DIRECTIONS; ++i) {

				float angle = float(i) / float(DIRECTIONS) * PI;
				vec4 sampleDir = vec4(cos(angle), sin(angle), 0., 0.5 + 0.5 * noiseTexel.w);
				sampleDir.xyz = normalize(kernelMatrix * sampleDir.xyz);

				vec3 viewDir = normalize(-viewPos.xyz);
				vec3 sliceBitangent = normalize(cross(sampleDir.xyz, viewDir));
				vec3 sliceTangent = cross(sliceBitangent, viewDir);
				vec3 normalInSlice = normalize(viewNormal - sliceBitangent * dot(viewNormal, sliceBitangent));

				vec3 tangentToNormalInSlice = cross(normalInSlice, sliceBitangent);
				vec2 cosHorizons = vec2(dot(viewDir, tangentToNormalInSlice), dot(viewDir, -tangentToNormalInSlice));

				for (int j = 0; j < STEPS; ++j) {
					vec3 sampleViewOffset = sampleDir.xyz * radiusToUse * sampleDir.w * pow(float(j + 1) / float(STEPS), distanceExponent);

					vec3 sampleSceneUvDepth = getSceneUvAndDepth(viewPos + sampleViewOffset);
					vec3 sampleSceneViewPos = getViewPosition(sampleSceneUvDepth.xy, sampleSceneUvDepth.z);
					vec3 viewDelta = sampleSceneViewPos - viewPos;
					if (abs(viewDelta.z) < thickness) {
						float sampleCosHorizon = dot(viewDir, normalize(viewDelta));
						cosHorizons.x += max(0., (sampleCosHorizon - cosHorizons.x) * mix(1., 2. / float(j + 2), distanceFallOff));
					}

					sampleSceneUvDepth = getSceneUvAndDepth(viewPos - sampleViewOffset);
					sampleSceneViewPos = getViewPosition(sampleSceneUvDepth.xy, sampleSceneUvDepth.z);
					viewDelta = sampleSceneViewPos - viewPos;
					if (abs(viewDelta.z) < thickness) {
						float sampleCosHorizon = dot(viewDir, normalize(viewDelta));
						cosHorizons.y += max(0., (sampleCosHorizon - cosHorizons.y) * mix(1., 2. / float(j + 2), distanceFallOff));
					}
				}

				vec2 sinHorizons = sqrt(1. - cosHorizons * cosHorizons);
				float nx = dot(normalInSlice, sliceTangent);
				float ny = dot(normalInSlice, viewDir);
				float nxb = 1. / 2. * (acos(cosHorizons.y) - acos(cosHorizons.x) + sinHorizons.x * cosHorizons.x - sinHorizons.y * cosHorizons.y);
				float nyb = 1. / 2. * (2. - cosHorizons.x * cosHorizons.x - cosHorizons.y * cosHorizons.y);
				float occlusion = nx * nxb + ny * nyb;
				ao += occlusion;
			}

			ao = clamp(ao / float(DIRECTIONS), 0., 1.);
		#if SCENE_CLIP_BOX == 1
			ao = mix(ao, 1., smoothstep(0., radiusToUse, boxDistance));
		#endif
			ao = pow(ao, scale);

			gl_FragColor = FRAGMENT_OUTPUT;
		}`},e5={name:"GTAODepthShader",defines:{PERSPECTIVE_CAMERA:1},uniforms:{tDepth:{value:null},cameraNear:{value:null},cameraFar:{value:null}},vertexShader:`
		varying vec2 vUv;

		void main() {
			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
		}`,fragmentShader:`
		uniform sampler2D tDepth;
		uniform float cameraNear;
		uniform float cameraFar;
		varying vec2 vUv;

		#include <packing>

		float getLinearDepth( const in vec2 screenPosition ) {
			#if PERSPECTIVE_CAMERA == 1
				float fragCoordZ = texture2D( tDepth, screenPosition ).x;
				float viewZ = perspectiveDepthToViewZ( fragCoordZ, cameraNear, cameraFar );
				return viewZToOrthographicDepth( viewZ, cameraNear, cameraFar );
			#else
				return texture2D( tDepth, screenPosition ).x;
			#endif
		}

		void main() {
			float depth = getLinearDepth( vUv );
			gl_FragColor = vec4( vec3( 1.0 - depth ), 1.0 );

		}`},e4={name:"GTAOBlendShader",uniforms:{tDiffuse:{value:null},intensity:{value:1}},vertexShader:`
		varying vec2 vUv;

		void main() {
			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
		}`,fragmentShader:`
		uniform float intensity;
		uniform sampler2D tDiffuse;
		varying vec2 vUv;

		void main() {
			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = vec4(mix(vec3(1.), texel.rgb, intensity), texel.a);
		}`},e8={name:"PoissonDenoiseShader",defines:{SAMPLES:16,SAMPLE_VECTORS:e6(16,2,1),NORMAL_VECTOR_TYPE:1,DEPTH_VALUE_SOURCE:0},uniforms:{tDiffuse:{value:null},tNormal:{value:null},tDepth:{value:null},tNoise:{value:null},resolution:{value:new L.Vector2},cameraProjectionMatrixInverse:{value:new L.Matrix4},lumaPhi:{value:5},depthPhi:{value:5},normalPhi:{value:5},radius:{value:4},index:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {
			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
		}`,fragmentShader:`

		varying vec2 vUv;

		uniform sampler2D tDiffuse;
		uniform sampler2D tNormal;
		uniform sampler2D tDepth;
		uniform sampler2D tNoise;
		uniform vec2 resolution;
		uniform mat4 cameraProjectionMatrixInverse;
		uniform float lumaPhi;
		uniform float depthPhi;
		uniform float normalPhi;
		uniform float radius;
		uniform int index;

		#include <common>
		#include <packing>

		#ifndef SAMPLE_LUMINANCE
		#define SAMPLE_LUMINANCE dot(vec3(0.2125, 0.7154, 0.0721), a)
		#endif

		#ifndef FRAGMENT_OUTPUT
		#define FRAGMENT_OUTPUT vec4(denoised, 1.)
		#endif

		float getLuminance(const in vec3 a) {
			return SAMPLE_LUMINANCE;
		}

		const vec3 poissonDisk[SAMPLES] = SAMPLE_VECTORS;

		vec3 getViewPosition( const in vec2 screenPosition, const in float depth ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				vec4 clipSpacePosition = vec4( vec2( screenPosition ) * 2.0 - 1.0, depth, 1.0 );
			#else
				vec4 clipSpacePosition = vec4( vec3( screenPosition, depth ) * 2.0 - 1.0, 1.0 );
			#endif
			vec4 viewSpacePosition = cameraProjectionMatrixInverse * clipSpacePosition;
			return viewSpacePosition.xyz / viewSpacePosition.w;
		}

		float getDepth(const vec2 uv) {
		#if DEPTH_VALUE_SOURCE == 1
			return textureLod(tDepth, uv.xy, 0.0).a;
		#else
			return textureLod(tDepth, uv.xy, 0.0).r;
		#endif
		}

		float fetchDepth(const ivec2 uv) {
			#if DEPTH_VALUE_SOURCE == 1
				return texelFetch(tDepth, uv.xy, 0).a;
			#else
				return texelFetch(tDepth, uv.xy, 0).r;
			#endif
		}

		vec3 computeNormalFromDepth(const vec2 uv) {
			vec2 size = vec2(textureSize(tDepth, 0));
			ivec2 p = ivec2(uv * size);
			float c0 = fetchDepth(p);
			float l2 = fetchDepth(p - ivec2(2, 0));
			float l1 = fetchDepth(p - ivec2(1, 0));
			float r1 = fetchDepth(p + ivec2(1, 0));
			float r2 = fetchDepth(p + ivec2(2, 0));
			float b2 = fetchDepth(p - ivec2(0, 2));
			float b1 = fetchDepth(p - ivec2(0, 1));
			float t1 = fetchDepth(p + ivec2(0, 1));
			float t2 = fetchDepth(p + ivec2(0, 2));
			float dl = abs((2.0 * l1 - l2) - c0);
			float dr = abs((2.0 * r1 - r2) - c0);
			float db = abs((2.0 * b1 - b2) - c0);
			float dt = abs((2.0 * t1 - t2) - c0);
			vec3 ce = getViewPosition(uv, c0).xyz;
			vec3 dpdx = (dl < dr) ?  ce - getViewPosition((uv - vec2(1.0 / size.x, 0.0)), l1).xyz
									: -ce + getViewPosition((uv + vec2(1.0 / size.x, 0.0)), r1).xyz;
			vec3 dpdy = (db < dt) ?  ce - getViewPosition((uv - vec2(0.0, 1.0 / size.y)), b1).xyz
									: -ce + getViewPosition((uv + vec2(0.0, 1.0 / size.y)), t1).xyz;
			return normalize(cross(dpdx, dpdy));
		}

		vec3 getViewNormal(const vec2 uv) {
		#if NORMAL_VECTOR_TYPE == 2
			return normalize(textureLod(tNormal, uv, 0.).rgb);
		#elif NORMAL_VECTOR_TYPE == 1
			return unpackRGBToNormal(textureLod(tNormal, uv, 0.).rgb);
		#else
			return computeNormalFromDepth(uv);
		#endif
		}

		void denoiseSample(in vec3 center, in vec3 viewNormal, in vec3 viewPos, in vec2 sampleUv, inout vec3 denoised, inout float totalWeight) {
			vec4 sampleTexel = textureLod(tDiffuse, sampleUv, 0.0);
			float sampleDepth = getDepth(sampleUv);
			vec3 sampleNormal = getViewNormal(sampleUv);
			vec3 neighborColor = sampleTexel.rgb;
			vec3 viewPosSample = getViewPosition(sampleUv, sampleDepth);

			float normalDiff = dot(viewNormal, sampleNormal);
			float normalSimilarity = pow(max(normalDiff, 0.), normalPhi);
			float lumaDiff = abs(getLuminance(neighborColor) - getLuminance(center));
			float lumaSimilarity = max(1.0 - lumaDiff / lumaPhi, 0.0);
			float depthDiff = abs(dot(viewPos - viewPosSample, viewNormal));
			float depthSimilarity = max(1. - depthDiff / depthPhi, 0.);
			float w = lumaSimilarity * depthSimilarity * normalSimilarity;

			denoised += w * neighborColor;
			totalWeight += w;
		}

		void main() {
			float depth = getDepth(vUv.xy);
			vec3 viewNormal = getViewNormal(vUv);
			if (depth == 1. || dot(viewNormal, viewNormal) == 0.) {
				discard;
				return;
			}
			vec4 texel = textureLod(tDiffuse, vUv, 0.0);
			vec3 center = texel.rgb;
			vec3 viewPos = getViewPosition(vUv, depth);

			vec2 noiseResolution = vec2(textureSize(tNoise, 0));
			vec2 noiseUv = vUv * resolution / noiseResolution;
			vec4 noiseTexel = textureLod(tNoise, noiseUv, 0.0);
      		vec2 noiseVec = vec2(sin(noiseTexel[index % 4] * 2. * PI), cos(noiseTexel[index % 4] * 2. * PI));
    		mat2 rotationMatrix = mat2(noiseVec.x, -noiseVec.y, noiseVec.x, noiseVec.y);

			float totalWeight = 1.0;
			vec3 denoised = texel.rgb;
			for (int i = 0; i < SAMPLES; i++) {
				vec3 sampleDir = poissonDisk[i];
				vec2 offset = rotationMatrix * (sampleDir.xy * (1. + sampleDir.z * (radius - 1.)) / resolution);
				vec2 sampleUv = vUv + offset;
				denoiseSample(center, viewNormal, viewPos, sampleUv, denoised, totalWeight);
			}

			if (totalWeight > 0.) {
				denoised /= totalWeight;
			}
			gl_FragColor = FRAGMENT_OUTPUT;
		}`};function e6(e,t,i){let a=function(e,t,i){let a=[];for(let r=0;r<e;r++){let o=2*Math.PI*t*r/e,s=Math.pow(r/(e-1),i);a.push(new L.Vector3(Math.cos(o),Math.sin(o),s))}return a}(e,t,i),r="vec3[SAMPLES](";for(let t=0;t<e;t++){let i=a[t];r+=`vec3(${i.x}, ${i.y}, ${i.z})${t<e-1?",":")"}`}return r}class e7{constructor(e=Math){this.grad3=[[1,1,0],[-1,1,0],[1,-1,0],[-1,-1,0],[1,0,1],[-1,0,1],[1,0,-1],[-1,0,-1],[0,1,1],[0,-1,1],[0,1,-1],[0,-1,-1]],this.grad4=[[0,1,1,1],[0,1,1,-1],[0,1,-1,1],[0,1,-1,-1],[0,-1,1,1],[0,-1,1,-1],[0,-1,-1,1],[0,-1,-1,-1],[1,0,1,1],[1,0,1,-1],[1,0,-1,1],[1,0,-1,-1],[-1,0,1,1],[-1,0,1,-1],[-1,0,-1,1],[-1,0,-1,-1],[1,1,0,1],[1,1,0,-1],[1,-1,0,1],[1,-1,0,-1],[-1,1,0,1],[-1,1,0,-1],[-1,-1,0,1],[-1,-1,0,-1],[1,1,1,0],[1,1,-1,0],[1,-1,1,0],[1,-1,-1,0],[-1,1,1,0],[-1,1,-1,0],[-1,-1,1,0],[-1,-1,-1,0]],this.p=[];for(let t=0;t<256;t++)this.p[t]=Math.floor(256*e.random());this.perm=[];for(let e=0;e<512;e++)this.perm[e]=this.p[255&e];this.simplex=[[0,1,2,3],[0,1,3,2],[0,0,0,0],[0,2,3,1],[0,0,0,0],[0,0,0,0],[0,0,0,0],[1,2,3,0],[0,2,1,3],[0,0,0,0],[0,3,1,2],[0,3,2,1],[0,0,0,0],[0,0,0,0],[0,0,0,0],[1,3,2,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[1,2,0,3],[0,0,0,0],[1,3,0,2],[0,0,0,0],[0,0,0,0],[0,0,0,0],[2,3,0,1],[2,3,1,0],[1,0,2,3],[1,0,3,2],[0,0,0,0],[0,0,0,0],[0,0,0,0],[2,0,3,1],[0,0,0,0],[2,1,3,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0],[2,0,1,3],[0,0,0,0],[0,0,0,0],[0,0,0,0],[3,0,1,2],[3,0,2,1],[0,0,0,0],[3,1,2,0],[2,1,0,3],[0,0,0,0],[0,0,0,0],[0,0,0,0],[3,1,0,2],[0,0,0,0],[3,2,0,1],[3,2,1,0]]}noise(e,t){let i,a,r,o,s,n=.5*(Math.sqrt(3)-1)*(e+t),l=Math.floor(e+n),h=Math.floor(t+n),c=(3-Math.sqrt(3))/6,d=(l+h)*c,u=e-(l-d),m=t-(h-d);u>m?(o=1,s=0):(o=0,s=1);let p=u-o+c,f=m-s+c,g=u-1+2*c,v=m-1+2*c,b=255&l,w=255&h,y=this.perm[b+this.perm[w]]%12,x=this.perm[b+o+this.perm[w+s]]%12,M=this.perm[b+1+this.perm[w+1]]%12,S=.5-u*u-m*m;S<0?i=0:(S*=S,i=S*S*this._dot(this.grad3[y],u,m));let T=.5-p*p-f*f;T<0?a=0:(T*=T,a=T*T*this._dot(this.grad3[x],p,f));let C=.5-g*g-v*v;return C<0?r=0:(C*=C,r=C*C*this._dot(this.grad3[M],g,v)),70*(i+a+r)}noise3d(e,t,i){let a,r,o,s,n,l,h,c,d,u,m=1/3*(e+t+i),p=Math.floor(e+m),f=Math.floor(t+m),g=Math.floor(i+m),v=1/6*(p+f+g),b=e-(p-v),w=t-(f-v),y=i-(g-v);b>=w?w>=y?(n=1,l=0,h=0,c=1,d=1,u=0):(b>=y?(n=1,l=0,h=0):(n=0,l=0,h=1),c=1,d=0,u=1):w<y?(n=0,l=0,h=1,c=0,d=1,u=1):b<y?(n=0,l=1,h=0,c=0,d=1,u=1):(n=0,l=1,h=0,c=1,d=1,u=0);let x=b-n+1/6,M=w-l+1/6,S=y-h+1/6,T=b-c+1/6*2,C=w-d+1/6*2,P=y-u+1/6*2,A=b-1+1/6*3,k=w-1+1/6*3,D=y-1+1/6*3,z=255&p,_=255&f,L=255&g,R=this.perm[z+this.perm[_+this.perm[L]]]%12,E=this.perm[z+n+this.perm[_+l+this.perm[L+h]]]%12,F=this.perm[z+c+this.perm[_+d+this.perm[L+u]]]%12,I=this.perm[z+1+this.perm[_+1+this.perm[L+1]]]%12,U=.6-b*b-w*w-y*y;U<0?a=0:(U*=U,a=U*U*this._dot3(this.grad3[R],b,w,y));let N=.6-x*x-M*M-S*S;N<0?r=0:(N*=N,r=N*N*this._dot3(this.grad3[E],x,M,S));let B=.6-T*T-C*C-P*P;B<0?o=0:(B*=B,o=B*B*this._dot3(this.grad3[F],T,C,P));let V=.6-A*A-k*k-D*D;return V<0?s=0:(V*=V,s=V*V*this._dot3(this.grad3[I],A,k,D)),32*(a+r+o+s)}noise4d(e,t,i,a){let r,o,s,n,l,h=this.grad4,c=this.simplex,d=this.perm,u=(5-Math.sqrt(5))/20,m=(Math.sqrt(5)-1)/4*(e+t+i+a),p=Math.floor(e+m),f=Math.floor(t+m),g=Math.floor(i+m),v=Math.floor(a+m),b=(p+f+g+v)*u,w=e-(p-b),y=t-(f-b),x=i-(g-b),M=a-(v-b),S=32*(w>y)+16*(w>x)+8*(y>x)+4*(w>M)+2*(y>M)+ +(x>M),T=+(c[S][0]>=3),C=+(c[S][1]>=3),P=+(c[S][2]>=3),A=+(c[S][3]>=3),k=+(c[S][0]>=2),D=+(c[S][1]>=2),z=+(c[S][2]>=2),_=+(c[S][3]>=2),L=+(c[S][0]>=1),R=+(c[S][1]>=1),E=+(c[S][2]>=1),F=+(c[S][3]>=1),I=w-T+u,U=y-C+u,N=x-P+u,B=M-A+u,V=w-k+2*u,O=y-D+2*u,G=x-z+2*u,j=M-_+2*u,H=w-L+3*u,W=y-R+3*u,q=x-E+3*u,X=M-F+3*u,K=w-1+4*u,Y=y-1+4*u,Z=x-1+4*u,$=M-1+4*u,Q=255&p,J=255&f,ee=255&g,et=255&v,ei=d[Q+d[J+d[ee+d[et]]]]%32,ea=d[Q+T+d[J+C+d[ee+P+d[et+A]]]]%32,er=d[Q+k+d[J+D+d[ee+z+d[et+_]]]]%32,eo=d[Q+L+d[J+R+d[ee+E+d[et+F]]]]%32,es=d[Q+1+d[J+1+d[ee+1+d[et+1]]]]%32,en=.6-w*w-y*y-x*x-M*M;en<0?r=0:(en*=en,r=en*en*this._dot4(h[ei],w,y,x,M));let el=.6-I*I-U*U-N*N-B*B;el<0?o=0:(el*=el,o=el*el*this._dot4(h[ea],I,U,N,B));let eh=.6-V*V-O*O-G*G-j*j;eh<0?s=0:(eh*=eh,s=eh*eh*this._dot4(h[er],V,O,G,j));let ec=.6-H*H-W*W-q*q-X*X;ec<0?n=0:(ec*=ec,n=ec*ec*this._dot4(h[eo],H,W,q,X));let ed=.6-K*K-Y*Y-Z*Z-$*$;return ed<0?l=0:(ed*=ed,l=ed*ed*this._dot4(h[es],K,Y,Z,$)),27*(r+o+s+n+l)}_dot(e,t,i){return e[0]*t+e[1]*i}_dot3(e,t,i,a){return e[0]*t+e[1]*i+e[2]*a}_dot4(e,t,i,a,r){return e[0]*t+e[1]*i+e[2]*a+e[3]*r}}class te extends eH{constructor(e,t,i=512,a=512,r,o,s){super(),this.width=i,this.height=a,this.clear=!0,this.camera=t,this.scene=e,this.output=0,this._renderGBuffer=!0,this._visibilityCache=[],this.blendIntensity=1,this.pdRings=2,this.pdRadiusExponent=2,this.pdSamples=16,this.gtaoNoiseTexture=function(e=5){let t=Math.floor(e)%2==0?Math.floor(e)+1:Math.floor(e),i=function(e){let t=Math.floor(e)%2==0?Math.floor(e)+1:Math.floor(e),i=t*t,a=Array(i).fill(0),r=Math.floor(t/2),o=t-1;for(let e=1;e<=i;){if(-1===r&&o===t?(o=t-2,r=0):(o===t&&(o=0),r<0&&(r=t-1)),0!==a[r*t+o]){o-=2,r++;continue}a[r*t+o]=e++,o++,r--}return a}(t),a=i.length,r=new Uint8Array(4*a);for(let e=0;e<a;++e){let t=2*Math.PI*i[e]/a,o=new L.Vector3(Math.cos(t),Math.sin(t),0).normalize();r[4*e]=(.5*o.x+.5)*255,r[4*e+1]=(.5*o.y+.5)*255,r[4*e+2]=127,r[4*e+3]=255}let o=new L.DataTexture(r,t,t);return o.wrapS=L.RepeatWrapping,o.wrapT=L.RepeatWrapping,o.needsUpdate=!0,o}(),this.pdNoiseTexture=this._generateNoise(),this.gtaoRenderTarget=new L.WebGLRenderTarget(this.width,this.height,{type:L.HalfFloatType}),this.pdRenderTarget=this.gtaoRenderTarget.clone(),this.gtaoMaterial=new L.ShaderMaterial({defines:Object.assign({},e3.defines),uniforms:L.UniformsUtils.clone(e3.uniforms),vertexShader:e3.vertexShader,fragmentShader:e3.fragmentShader,blending:L.NoBlending,depthTest:!1,depthWrite:!1}),this.gtaoMaterial.defines.PERSPECTIVE_CAMERA=+!!this.camera.isPerspectiveCamera,this.gtaoMaterial.uniforms.tNoise.value=this.gtaoNoiseTexture,this.gtaoMaterial.uniforms.resolution.value.set(this.width,this.height),this.gtaoMaterial.uniforms.cameraNear.value=this.camera.near,this.gtaoMaterial.uniforms.cameraFar.value=this.camera.far,this.normalMaterial=new L.MeshNormalMaterial,this.normalMaterial.blending=L.NoBlending,this.pdMaterial=new L.ShaderMaterial({defines:Object.assign({},e8.defines),uniforms:L.UniformsUtils.clone(e8.uniforms),vertexShader:e8.vertexShader,fragmentShader:e8.fragmentShader,depthTest:!1,depthWrite:!1}),this.pdMaterial.uniforms.tDiffuse.value=this.gtaoRenderTarget.texture,this.pdMaterial.uniforms.tNoise.value=this.pdNoiseTexture,this.pdMaterial.uniforms.resolution.value.set(this.width,this.height),this.pdMaterial.uniforms.lumaPhi.value=10,this.pdMaterial.uniforms.depthPhi.value=2,this.pdMaterial.uniforms.normalPhi.value=3,this.pdMaterial.uniforms.radius.value=8,this.depthRenderMaterial=new L.ShaderMaterial({defines:Object.assign({},e5.defines),uniforms:L.UniformsUtils.clone(e5.uniforms),vertexShader:e5.vertexShader,fragmentShader:e5.fragmentShader,blending:L.NoBlending}),this.depthRenderMaterial.uniforms.cameraNear.value=this.camera.near,this.depthRenderMaterial.uniforms.cameraFar.value=this.camera.far,this.copyMaterial=new L.ShaderMaterial({uniforms:L.UniformsUtils.clone(eG.uniforms),vertexShader:eG.vertexShader,fragmentShader:eG.fragmentShader,transparent:!0,depthTest:!1,depthWrite:!1,blendSrc:L.DstColorFactor,blendDst:L.ZeroFactor,blendEquation:L.AddEquation,blendSrcAlpha:L.DstAlphaFactor,blendDstAlpha:L.ZeroFactor,blendEquationAlpha:L.AddEquation}),this.blendMaterial=new L.ShaderMaterial({uniforms:L.UniformsUtils.clone(e4.uniforms),vertexShader:e4.vertexShader,fragmentShader:e4.fragmentShader,transparent:!0,depthTest:!1,depthWrite:!1,blending:L.CustomBlending,blendSrc:L.DstColorFactor,blendDst:L.ZeroFactor,blendEquation:L.AddEquation,blendSrcAlpha:L.DstAlphaFactor,blendDstAlpha:L.ZeroFactor,blendEquationAlpha:L.AddEquation}),this._fsQuad=new eK(null),this._originalClearColor=new L.Color,this.setGBuffer(r?r.depthTexture:void 0,r?r.normalTexture:void 0),void 0!==o&&this.updateGtaoMaterial(o),void 0!==s&&this.updatePdMaterial(s)}setSize(e,t){this.width=e,this.height=t,this.gtaoRenderTarget.setSize(e,t),this.normalRenderTarget.setSize(e,t),this.pdRenderTarget.setSize(e,t),this.gtaoMaterial.uniforms.resolution.value.set(e,t),this.gtaoMaterial.uniforms.cameraProjectionMatrix.value.copy(this.camera.projectionMatrix),this.gtaoMaterial.uniforms.cameraProjectionMatrixInverse.value.copy(this.camera.projectionMatrixInverse),this.pdMaterial.uniforms.resolution.value.set(e,t),this.pdMaterial.uniforms.cameraProjectionMatrixInverse.value.copy(this.camera.projectionMatrixInverse)}dispose(){this.gtaoNoiseTexture.dispose(),this.pdNoiseTexture.dispose(),this.normalRenderTarget.dispose(),this.gtaoRenderTarget.dispose(),this.pdRenderTarget.dispose(),this.normalMaterial.dispose(),this.pdMaterial.dispose(),this.copyMaterial.dispose(),this.depthRenderMaterial.dispose(),this._fsQuad.dispose()}get gtaoMap(){return this.pdRenderTarget.texture}setGBuffer(e,t){void 0!==e?(this.depthTexture=e,this.normalTexture=t,this._renderGBuffer=!1):(this.depthTexture=new L.DepthTexture,this.depthTexture.format=L.DepthStencilFormat,this.depthTexture.type=L.UnsignedInt248Type,this.normalRenderTarget=new L.WebGLRenderTarget(this.width,this.height,{minFilter:L.NearestFilter,magFilter:L.NearestFilter,type:L.HalfFloatType,depthTexture:this.depthTexture}),this.normalTexture=this.normalRenderTarget.texture,this._renderGBuffer=!0);let i=+!!this.normalTexture,a=this.depthTexture===this.normalTexture?"w":"x";this.gtaoMaterial.defines.NORMAL_VECTOR_TYPE=i,this.gtaoMaterial.defines.DEPTH_SWIZZLING=a,this.gtaoMaterial.uniforms.tNormal.value=this.normalTexture,this.gtaoMaterial.uniforms.tDepth.value=this.depthTexture,this.pdMaterial.defines.NORMAL_VECTOR_TYPE=i,this.pdMaterial.defines.DEPTH_SWIZZLING=a,this.pdMaterial.uniforms.tNormal.value=this.normalTexture,this.pdMaterial.uniforms.tDepth.value=this.depthTexture,this.depthRenderMaterial.uniforms.tDepth.value=this.normalRenderTarget.depthTexture}setSceneClipBox(e){e?(this.gtaoMaterial.needsUpdate=1!==this.gtaoMaterial.defines.SCENE_CLIP_BOX,this.gtaoMaterial.defines.SCENE_CLIP_BOX=1,this.gtaoMaterial.uniforms.sceneBoxMin.value.copy(e.min),this.gtaoMaterial.uniforms.sceneBoxMax.value.copy(e.max)):(this.gtaoMaterial.needsUpdate=0===this.gtaoMaterial.defines.SCENE_CLIP_BOX,this.gtaoMaterial.defines.SCENE_CLIP_BOX=0)}updateGtaoMaterial(e){void 0!==e.radius&&(this.gtaoMaterial.uniforms.radius.value=e.radius),void 0!==e.distanceExponent&&(this.gtaoMaterial.uniforms.distanceExponent.value=e.distanceExponent),void 0!==e.thickness&&(this.gtaoMaterial.uniforms.thickness.value=e.thickness),void 0!==e.distanceFallOff&&(this.gtaoMaterial.uniforms.distanceFallOff.value=e.distanceFallOff,this.gtaoMaterial.needsUpdate=!0),void 0!==e.scale&&(this.gtaoMaterial.uniforms.scale.value=e.scale),void 0!==e.samples&&e.samples!==this.gtaoMaterial.defines.SAMPLES&&(this.gtaoMaterial.defines.SAMPLES=e.samples,this.gtaoMaterial.needsUpdate=!0),void 0!==e.screenSpaceRadius&&+!!e.screenSpaceRadius!==this.gtaoMaterial.defines.SCREEN_SPACE_RADIUS&&(this.gtaoMaterial.defines.SCREEN_SPACE_RADIUS=+!!e.screenSpaceRadius,this.gtaoMaterial.needsUpdate=!0)}updatePdMaterial(e){let t=!1;void 0!==e.lumaPhi&&(this.pdMaterial.uniforms.lumaPhi.value=e.lumaPhi),void 0!==e.depthPhi&&(this.pdMaterial.uniforms.depthPhi.value=e.depthPhi),void 0!==e.normalPhi&&(this.pdMaterial.uniforms.normalPhi.value=e.normalPhi),void 0!==e.radius&&e.radius!==this.radius&&(this.pdMaterial.uniforms.radius.value=e.radius),void 0!==e.radiusExponent&&e.radiusExponent!==this.pdRadiusExponent&&(this.pdRadiusExponent=e.radiusExponent,t=!0),void 0!==e.rings&&e.rings!==this.pdRings&&(this.pdRings=e.rings,t=!0),void 0!==e.samples&&e.samples!==this.pdSamples&&(this.pdSamples=e.samples,t=!0),t&&(this.pdMaterial.defines.SAMPLES=this.pdSamples,this.pdMaterial.defines.SAMPLE_VECTORS=e6(this.pdSamples,this.pdRings,this.pdRadiusExponent),this.pdMaterial.needsUpdate=!0)}render(e,t,i){switch(this._renderGBuffer&&(this._overrideVisibility(),this._renderOverride(e,this.normalMaterial,this.normalRenderTarget,7829503,1),this._restoreVisibility()),this.gtaoMaterial.uniforms.cameraNear.value=this.camera.near,this.gtaoMaterial.uniforms.cameraFar.value=this.camera.far,this.gtaoMaterial.uniforms.cameraProjectionMatrix.value.copy(this.camera.projectionMatrix),this.gtaoMaterial.uniforms.cameraProjectionMatrixInverse.value.copy(this.camera.projectionMatrixInverse),this.gtaoMaterial.uniforms.cameraWorldMatrix.value.copy(this.camera.matrixWorld),this._renderPass(e,this.gtaoMaterial,this.gtaoRenderTarget,0xffffff,1),this.pdMaterial.uniforms.cameraProjectionMatrixInverse.value.copy(this.camera.projectionMatrixInverse),this._renderPass(e,this.pdMaterial,this.pdRenderTarget,0xffffff,1),this.output){case te.OUTPUT.Off:break;case te.OUTPUT.Diffuse:this.copyMaterial.uniforms.tDiffuse.value=i.texture,this.copyMaterial.blending=L.NoBlending,this._renderPass(e,this.copyMaterial,this.renderToScreen?null:t);break;case te.OUTPUT.AO:this.copyMaterial.uniforms.tDiffuse.value=this.gtaoRenderTarget.texture,this.copyMaterial.blending=L.NoBlending,this._renderPass(e,this.copyMaterial,this.renderToScreen?null:t);break;case te.OUTPUT.Denoise:this.copyMaterial.uniforms.tDiffuse.value=this.pdRenderTarget.texture,this.copyMaterial.blending=L.NoBlending,this._renderPass(e,this.copyMaterial,this.renderToScreen?null:t);break;case te.OUTPUT.Depth:this.depthRenderMaterial.uniforms.cameraNear.value=this.camera.near,this.depthRenderMaterial.uniforms.cameraFar.value=this.camera.far,this._renderPass(e,this.depthRenderMaterial,this.renderToScreen?null:t);break;case te.OUTPUT.Normal:this.copyMaterial.uniforms.tDiffuse.value=this.normalRenderTarget.texture,this.copyMaterial.blending=L.NoBlending,this._renderPass(e,this.copyMaterial,this.renderToScreen?null:t);break;case te.OUTPUT.Default:this.copyMaterial.uniforms.tDiffuse.value=i.texture,this.copyMaterial.blending=L.NoBlending,this._renderPass(e,this.copyMaterial,this.renderToScreen?null:t),this.blendMaterial.uniforms.intensity.value=this.blendIntensity,this.blendMaterial.uniforms.tDiffuse.value=this.pdRenderTarget.texture,this._renderPass(e,this.blendMaterial,this.renderToScreen?null:t);break;default:console.warn("THREE.GTAOPass: Unknown output type.")}}_renderPass(e,t,i,a,r){e.getClearColor(this._originalClearColor);let o=e.getClearAlpha(),s=e.autoClear;e.setRenderTarget(i),e.autoClear=!1,null!=a&&(e.setClearColor(a),e.setClearAlpha(r||0),e.clear()),this._fsQuad.material=t,this._fsQuad.render(e),e.autoClear=s,e.setClearColor(this._originalClearColor),e.setClearAlpha(o)}_renderOverride(e,t,i,a,r){e.getClearColor(this._originalClearColor);let o=e.getClearAlpha(),s=e.autoClear;e.setRenderTarget(i),e.autoClear=!1,a=t.clearColor||a,r=t.clearAlpha||r,null!=a&&(e.setClearColor(a),e.setClearAlpha(r||0),e.clear()),this.scene.overrideMaterial=t,e.render(this.scene,this.camera),this.scene.overrideMaterial=null,e.autoClear=s,e.setClearColor(this._originalClearColor),e.setClearAlpha(o)}_overrideVisibility(){let e=this.scene,t=this._visibilityCache;e.traverse(function(e){(e.isPoints||e.isLine||e.isLine2)&&e.visible&&(e.visible=!1,t.push(e))})}_restoreVisibility(){let e=this._visibilityCache;for(let t=0;t<e.length;t++)e[t].visible=!0;e.length=0}_generateNoise(e=64){let t=new e7,i=new Uint8Array(e*e*4);for(let a=0;a<e;a++)for(let r=0;r<e;r++){let o=a,s=r;i[(a*e+r)*4]=(.5*t.noise(o,s)+.5)*255,i[(a*e+r)*4+1]=(.5*t.noise(o+e,s)+.5)*255,i[(a*e+r)*4+2]=(.5*t.noise(o,s+e)+.5)*255,i[(a*e+r)*4+3]=(.5*t.noise(o+e,s+e)+.5)*255}let a=new L.DataTexture(i,e,e,L.RGBAFormat,L.UnsignedByteType);return a.wrapS=L.RepeatWrapping,a.wrapT=L.RepeatWrapping,a.needsUpdate=!0,a}}te.OUTPUT={Off:-1,Default:0,Diffuse:1,Depth:2,Normal:3,AO:4,Denoise:5};let tt={name:"FXAAShader",uniforms:{tDiffuse:{value:null},resolution:{value:new L.Vector2(1/1024,1/512)}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec2 resolution;
		varying vec2 vUv;

		#define EDGE_STEP_COUNT 6
		#define EDGE_GUESS 8.0
		#define EDGE_STEPS 1.0, 1.5, 2.0, 2.0, 2.0, 4.0
		const float edgeSteps[EDGE_STEP_COUNT] = float[EDGE_STEP_COUNT]( EDGE_STEPS );

		float _ContrastThreshold = 0.0312;
		float _RelativeThreshold = 0.063;
		float _SubpixelBlending = 1.0;

		vec4 Sample( sampler2D  tex2D, vec2 uv ) {

			return texture( tex2D, uv );

		}

		float SampleLuminance( sampler2D tex2D, vec2 uv ) {

			return dot( Sample( tex2D, uv ).rgb, vec3( 0.3, 0.59, 0.11 ) );

		}

		float SampleLuminance( sampler2D tex2D, vec2 texSize, vec2 uv, float uOffset, float vOffset ) {

			uv += texSize * vec2(uOffset, vOffset);
			return SampleLuminance(tex2D, uv);

		}

		struct LuminanceData {

			float m, n, e, s, w;
			float ne, nw, se, sw;
			float highest, lowest, contrast;

		};

		LuminanceData SampleLuminanceNeighborhood( sampler2D tex2D, vec2 texSize, vec2 uv ) {

			LuminanceData l;
			l.m = SampleLuminance( tex2D, uv );
			l.n = SampleLuminance( tex2D, texSize, uv,  0.0,  1.0 );
			l.e = SampleLuminance( tex2D, texSize, uv,  1.0,  0.0 );
			l.s = SampleLuminance( tex2D, texSize, uv,  0.0, -1.0 );
			l.w = SampleLuminance( tex2D, texSize, uv, -1.0,  0.0 );

			l.ne = SampleLuminance( tex2D, texSize, uv,  1.0,  1.0 );
			l.nw = SampleLuminance( tex2D, texSize, uv, -1.0,  1.0 );
			l.se = SampleLuminance( tex2D, texSize, uv,  1.0, -1.0 );
			l.sw = SampleLuminance( tex2D, texSize, uv, -1.0, -1.0 );

			l.highest = max( max( max( max( l.n, l.e ), l.s ), l.w ), l.m );
			l.lowest = min( min( min( min( l.n, l.e ), l.s ), l.w ), l.m );
			l.contrast = l.highest - l.lowest;
			return l;

		}

		bool ShouldSkipPixel( LuminanceData l ) {

			float threshold = max( _ContrastThreshold, _RelativeThreshold * l.highest );
			return l.contrast < threshold;

		}

		float DeterminePixelBlendFactor( LuminanceData l ) {

			float f = 2.0 * ( l.n + l.e + l.s + l.w );
			f += l.ne + l.nw + l.se + l.sw;
			f *= 1.0 / 12.0;
			f = abs( f - l.m );
			f = clamp( f / l.contrast, 0.0, 1.0 );

			float blendFactor = smoothstep( 0.0, 1.0, f );
			return blendFactor * blendFactor * _SubpixelBlending;

		}

		struct EdgeData {

			bool isHorizontal;
			float pixelStep;
			float oppositeLuminance, gradient;

		};

		EdgeData DetermineEdge( vec2 texSize, LuminanceData l ) {

			EdgeData e;
			float horizontal =
				abs( l.n + l.s - 2.0 * l.m ) * 2.0 +
				abs( l.ne + l.se - 2.0 * l.e ) +
				abs( l.nw + l.sw - 2.0 * l.w );
			float vertical =
				abs( l.e + l.w - 2.0 * l.m ) * 2.0 +
				abs( l.ne + l.nw - 2.0 * l.n ) +
				abs( l.se + l.sw - 2.0 * l.s );
			e.isHorizontal = horizontal >= vertical;

			float pLuminance = e.isHorizontal ? l.n : l.e;
			float nLuminance = e.isHorizontal ? l.s : l.w;
			float pGradient = abs( pLuminance - l.m );
			float nGradient = abs( nLuminance - l.m );

			e.pixelStep = e.isHorizontal ? texSize.y : texSize.x;

			if (pGradient < nGradient) {

				e.pixelStep = -e.pixelStep;
				e.oppositeLuminance = nLuminance;
				e.gradient = nGradient;

			} else {

				e.oppositeLuminance = pLuminance;
				e.gradient = pGradient;

			}

			return e;

		}

		float DetermineEdgeBlendFactor( sampler2D  tex2D, vec2 texSize, LuminanceData l, EdgeData e, vec2 uv ) {

			vec2 uvEdge = uv;
			vec2 edgeStep;
			if (e.isHorizontal) {

				uvEdge.y += e.pixelStep * 0.5;
				edgeStep = vec2( texSize.x, 0.0 );

			} else {

				uvEdge.x += e.pixelStep * 0.5;
				edgeStep = vec2( 0.0, texSize.y );

			}

			float edgeLuminance = ( l.m + e.oppositeLuminance ) * 0.5;
			float gradientThreshold = e.gradient * 0.25;

			vec2 puv = uvEdge + edgeStep * edgeSteps[0];
			float pLuminanceDelta = SampleLuminance( tex2D, puv ) - edgeLuminance;
			bool pAtEnd = abs( pLuminanceDelta ) >= gradientThreshold;

			for ( int i = 1; i < EDGE_STEP_COUNT && !pAtEnd; i++ ) {

				puv += edgeStep * edgeSteps[i];
				pLuminanceDelta = SampleLuminance( tex2D, puv ) - edgeLuminance;
				pAtEnd = abs( pLuminanceDelta ) >= gradientThreshold;

			}

			if ( !pAtEnd ) {

				puv += edgeStep * EDGE_GUESS;

			}

			vec2 nuv = uvEdge - edgeStep * edgeSteps[0];
			float nLuminanceDelta = SampleLuminance( tex2D, nuv ) - edgeLuminance;
			bool nAtEnd = abs( nLuminanceDelta ) >= gradientThreshold;

			for ( int i = 1; i < EDGE_STEP_COUNT && !nAtEnd; i++ ) {

				nuv -= edgeStep * edgeSteps[i];
				nLuminanceDelta = SampleLuminance( tex2D, nuv ) - edgeLuminance;
				nAtEnd = abs( nLuminanceDelta ) >= gradientThreshold;

			}

			if ( !nAtEnd ) {

				nuv -= edgeStep * EDGE_GUESS;

			}

			float pDistance, nDistance;
			if ( e.isHorizontal ) {

				pDistance = puv.x - uv.x;
				nDistance = uv.x - nuv.x;

			} else {

				pDistance = puv.y - uv.y;
				nDistance = uv.y - nuv.y;

			}

			float shortestDistance;
			bool deltaSign;
			if ( pDistance <= nDistance ) {

				shortestDistance = pDistance;
				deltaSign = pLuminanceDelta >= 0.0;

			} else {

				shortestDistance = nDistance;
				deltaSign = nLuminanceDelta >= 0.0;

			}

			if ( deltaSign == ( l.m - edgeLuminance >= 0.0 ) ) {

				return 0.0;

			}

			return 0.5 - shortestDistance / ( pDistance + nDistance );

		}

		vec4 ApplyFXAA( sampler2D  tex2D, vec2 texSize, vec2 uv ) {

			LuminanceData luminance = SampleLuminanceNeighborhood( tex2D, texSize, uv );
			if ( ShouldSkipPixel( luminance ) ) {

				return Sample( tex2D, uv );

			}

			float pixelBlend = DeterminePixelBlendFactor( luminance );
			EdgeData edge = DetermineEdge( texSize, luminance );
			float edgeBlend = DetermineEdgeBlendFactor( tex2D, texSize, luminance, edge, uv );
			float finalBlend = max( pixelBlend, edgeBlend );

			if (edge.isHorizontal) {

				uv.y += edge.pixelStep * finalBlend;

			} else {

				uv.x += edge.pixelStep * finalBlend;

			}

			return Sample( tex2D, uv );

		}

		void main() {

			gl_FragColor = ApplyFXAA( tDiffuse, resolution.xy, vUv );

		}`};class ti extends eY{constructor(){super(tt)}setSize(e,t){this.material.uniforms.resolution.value.set(1/e,1/t)}}var ta=e.i(710071),tr=e.i(839944),to=e.i(74279),ts=e.i(442998),tn=e.i(403204),tl=e.i(435453),th=e.i(211296),tc=e.i(248414),td=e.i(183937),tu=e.i(77176);let tm="cuberoot.space.v1",tp={minimal:{zh:"镜面简约",en:"Mirror minimal"},cyberpunk:{zh:"赛博朋克",en:"Cyberpunk"},modern:{zh:"现代住宅",en:"Modern residence"},vintage:{zh:"复古宅邸",en:"Vintage residence"},italian:{zh:"意大利别墅",en:"Italian villa"},penthouse:{zh:"纽约顶层公寓",en:"New York penthouse"},japanese:{zh:"日式庭院",en:"Japanese courtyard"},company:{zh:"我的公司",en:"My company"}},tf={original:{zh:"原有环境",en:"Original setting"},island:{zh:"孤岛大海",en:"Ocean island"},shanghai:{zh:"上海黄浦江",en:"Shanghai Huangpu"}},tg={huangpu:{zh:"黄浦江原色",en:"Huangpu natural",color:5068614},yellow:{zh:"黄褐色",en:"Yellow brown",color:0x997438},sanya:{zh:"三亚浅蓝",en:"Sanya light blue",color:2733775},tahiti:{zh:"大溪地碧蓝",en:"Tahiti turquoise",color:575928},lightBlue:{zh:"浅蓝",en:"Light blue",color:6531550},blue:{zh:"蔚蓝",en:"Azure blue",color:1408970},deepBlue:{zh:"深蓝",en:"Deep blue",color:1063273}},tv={sunny:{zh:"晴天",en:"Sunny"},cloudy:{zh:"多云",en:"Cloudy"},overcast:{zh:"阴天",en:"Overcast"},windy:{zh:"大风",en:"Windy"},drizzle:{zh:"毛毛雨",en:"Drizzle"},rain:{zh:"下雨",en:"Rain"},downpour:{zh:"暴雨",en:"Downpour"},lightning:{zh:"闪电",en:"Lightning"},thunderstorm:{zh:"雷暴",en:"Thunderstorm"},fog:{zh:"浓雾",en:"Fog"},snow:{zh:"下雪",en:"Snow"},blizzard:{zh:"暴风雪",en:"Blizzard"},sleet:{zh:"雨夹雪",en:"Sleet"},hail:{zh:"冰雹",en:"Hail"},sandstorm:{zh:"沙尘暴",en:"Sandstorm"},typhoon:{zh:"台风",en:"Typhoon"},tornado:{zh:"龙卷风",en:"Tornado"},mudslide:{zh:"泥石流",en:"Mudslide"},rainbow:{zh:"彩虹",en:"Rainbow"}},tb={exterior:{zh:"建筑外观",en:"Exterior"},interior:{zh:"客厅",en:"Living room"},study:{zh:"书房",en:"Study"},bedroom:{zh:"卧室",en:"Bedroom"},bathroom:{zh:"卫生间",en:"Bathroom"},courtyard:{zh:"庭院",en:"Courtyard"},garage:{zh:"车库",en:"Garage"},cinema:{zh:"影音室",en:"Cinema"},gym:{zh:"健身房",en:"Gym"}},tw={interior:{x:0,z:0,width:20,depth:18,level:0,ceiling:7.8},study:{x:-23,z:2,width:12,depth:16,level:0,ceiling:4.75},bedroom:{x:-23,z:3,width:12,depth:14,level:1,ceiling:9.4},bathroom:{x:-23,z:-10,width:12,depth:12,level:1,ceiling:9.4},gallery:{x:-9.5,z:-12.5,width:39,depth:7,level:0,ceiling:4.75},bridge:{x:-9.5,z:-12.5,width:15,depth:7,level:1,ceiling:9.4},passage:{x:11,z:4,width:2,depth:40,level:0,ceiling:4.2},garage:{x:21,z:-10,width:18,depth:12,level:0,ceiling:4.2},cinema:{x:21,z:3,width:18,depth:14,level:0,ceiling:4.2},gym:{x:21,z:17,width:18,depth:14,level:0,ceiling:4.2}},ty={222:{zh:"二阶魔方",en:"2×2 Cube",icon:"event-222"},333:{zh:"三阶魔方",en:"3×3 Cube",icon:"event-333"},444:{zh:"四阶魔方",en:"4×4 Cube",icon:"event-444"},555:{zh:"五阶魔方",en:"5×5 Cube",icon:"event-555"},mirror:{zh:"镜面魔方",en:"Mirror Cube",icon:"event-333"},sq1:{zh:"Square-1",en:"Square-1",icon:"event-sq1"},pyram:{zh:"金字塔",en:"Pyraminx",icon:"event-pyram"},minx:{zh:"五魔方",en:"Megaminx",icon:"event-minx"},skewb:{zh:"斜转",en:"Skewb",icon:"event-skewb"}};function tx(e){return"string"==typeof e&&/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/.test(e)}function tM(e){return e.timeOfDay??("cyberpunk"===e.room?"21:00":"09:00")}let tS={version:1,objects:[{id:"initial-333",kind:"333",position:[0,0],rotation:[0,.2,0],scale:1.15},{id:"initial-222",kind:"222",position:[-3.4,1.8],rotation:[0,-.2,0],scale:.85},{id:"initial-mirror",kind:"mirror",position:[-3.5,-2],rotation:[0,.3,0],scale:.85},{id:"initial-minx",kind:"minx",position:[3.6,-1.4],rotation:[0,.2,0],scale:1},{id:"initial-444",kind:"444",position:[3.6,2.1],rotation:[0,-.2,0],scale:.85},{id:"initial-pyram",kind:"pyram",position:[0,-3.7],rotation:[0,0,0],scale:1}]},tT=[{x:0,z:0,width:3.1,depth:3.1,height:.55,level:0},{x:-3.5,z:-2,width:2.5,depth:2.5,height:1.1,level:0},{x:3.6,z:-1.4,width:2.6,depth:2.6,height:.3,level:0}];function tC(e,t,i,a){if(![e,t,i].every(Number.isFinite))return null;if("company"===a)return e>-25.7&&e<.4&&t>-5.4&&t<12.6?0:null;if(t>-13.6&&t<-11.1&&e>-2.25&&e<9.5){let t=Math.min(5,Math.max(0,.27+.2*Math.floor((9.25-e)/.44)));if(.32>=Math.abs(t-i))return t}let r=Object.values(tw).filter(i=>Math.abs(e-i.x)<i.width/2&&Math.abs(t-i.z)<i.depth/2).map(e=>5*e.level),o=e>-30.2&&e<12.2&&t>-17.7&&t<12.7,s="penthouse"!==a&&"cyberpunk"!==a&&e>-29&&e<11&&t>=12.7&&t<25,n=e>-16.7&&e<-10.3&&t>-9.2&&t<9.2&&Math.abs(t-5)>.4;return(o&&!n||s)&&r.push(0),r.filter(e=>.32>=Math.abs(e-i)).sort((e,t)=>t-e)[0]??null}function tP(e){return"string"==typeof e&&Object.hasOwn(ty,e)}function tA(e,t){return!(t.length>12)&&("sq1"===e?/^(\/|\(-?[0-6],-?[0-6]\))$/.test(t):"pyram"===e?/^(?:[ULRBulrb]|[DLRF]w)'?$/.test(t):"minx"===e?/^(?:BL|BR|BF|[UFLRCAIED])'?$/.test(t):"skewb"===e?/^(?:UL|UR|[RULBFD])'?$/.test(t):/^(?:[2-5]?[RLUDFB]w?)'?$/.test(t)&&(!/^[2-5]/.test(t)||Number(t[0])<=("mirror"===e?3:Number(e[0]))))}function tk(e){if(e.length>128e3)throw Error("size");let t=JSON.parse(e);if(!t||"object"!=typeof t||!("version"in t)||1!==t.version||!("objects"in t)||!Array.isArray(t.objects)||t.objects.length>64)throw Error("layout");if("room"in t&&("string"!=typeof t.room||!Object.hasOwn(tp,t.room)))throw Error("room");if("environment"in t&&("string"!=typeof t.environment||!Object.hasOwn(tf,t.environment)))throw Error("environment");if("weather"in t&&("string"!=typeof t.weather||!Object.hasOwn(tv,t.weather)))throw Error("weather");if("riverColor"in t&&("string"!=typeof t.riverColor||!Object.hasOwn(tg,t.riverColor)))throw Error("riverColor");if("weatherMotion"in t&&"boolean"!=typeof t.weatherMotion)throw Error("weatherMotion");if("timeOfDay"in t&&!tx(t.timeOfDay))throw Error("timeOfDay");let i=new Set,a=(e,t,i)=>Array.isArray(e)&&e.length===t&&e.every(e=>"number"==typeof e&&Number.isFinite(e)&&Math.abs(e)<=i),r=t.objects.map(e=>{if(!e||"object"!=typeof e||"string"!=typeof e.id||!/^[a-zA-Z0-9_-]{1,80}$/.test(e.id)||i.has(e.id)||!tP(e.kind)||!a(e.position,2,32)||!a(e.rotation,3,2*Math.PI)||"number"!=typeof e.scale||!Number.isFinite(e.scale)||e.scale<.04||e.scale>2.5)throw Error("object");if("level"in e&&0!==e.level&&1!==e.level)throw Error("level");if("moves"in e&&(!Array.isArray(e.moves)||e.moves.length>2e3||e.moves.some(t=>"string"!=typeof t||!tA(e.kind,t))))throw Error("moves");if("sq1"===e.kind&&Array.isArray(e.moves)){let t=(0,tu.solvedSq1)();for(let i of(0,tu.parseSq1Scramble)(e.moves.join(" "))){if("slice"===i.kind&&!(0,tu.isSlashValid)(t))throw Error("moves");t=(0,td.applySq1Move)(t,i)}}return i.add(e.id),{id:e.id,kind:e.kind,position:[...e.position],rotation:[...e.rotation],scale:e.scale,..."level"in e?{level:e.level}:{},..."moves"in e?{moves:[...e.moves]}:{}}});return{version:1,..."environment"in t?{environment:t.environment}:{},..."room"in t?{room:t.room}:{},..."weather"in t?{weather:t.weather}:{},..."weatherMotion"in t?{weatherMotion:t.weatherMotion}:{},..."timeOfDay"in t?{timeOfDay:t.timeOfDay}:{},..."riverColor"in t?{riverColor:t.riverColor}:{},objects:r}}function tD(e,t){return JSON.stringify(e.current)===JSON.stringify(t)?e:{past:[...e.past.slice(-99),e.current],current:t,future:[]}}function tz(e,t){return e.map(e=>Math.max(-32,Math.min(32,t?Math.round(2*e)/2:e)))}var t_=L;class tL extends t_.Mesh{constructor(e,t={}){super(e),this.isReflector=!0,this.type="Reflector",this.forceUpdate=!1,this.camera=new t_.PerspectiveCamera;const i=this,a=new t_.Color(void 0!==t.color?t.color:8355711),r=t.textureWidth||512,o=t.textureHeight||512,s=t.clipBias||0,n=t.shader||tL.ReflectorShader,l=void 0!==t.multisample?t.multisample:4,h=new t_.Plane,c=new t_.Vector3,d=new t_.Vector3,u=new t_.Vector3,m=new t_.Matrix4,p=new t_.Vector3(0,0,-1),f=new t_.Vector4,g=new t_.Vector3,v=new t_.Vector3,b=new t_.Vector4,w=new t_.Matrix4,y=this.camera,x=new t_.WebGLRenderTarget(r,o,{samples:l,type:t_.HalfFloatType}),M=new t_.ShaderMaterial({name:void 0!==n.name?n.name:"unspecified",uniforms:t_.UniformsUtils.clone(n.uniforms),fragmentShader:n.fragmentShader,vertexShader:n.vertexShader});M.uniforms.tDiffuse.value=x.texture,M.uniforms.color.value=a,M.uniforms.textureMatrix.value=w,this.material=M,this.onBeforeRender=function(e,t,a){if(d.setFromMatrixPosition(i.matrixWorld),u.setFromMatrixPosition(a.matrixWorld),m.extractRotation(i.matrixWorld),c.set(0,0,1),c.applyMatrix4(m),g.subVectors(d,u),!0==g.dot(c)>0&&!1===this.forceUpdate)return;g.reflect(c).negate(),g.add(d),m.extractRotation(a.matrixWorld),p.set(0,0,-1),p.applyMatrix4(m),p.add(u),v.subVectors(d,p),v.reflect(c).negate(),v.add(d),y.position.copy(g),y.up.set(0,1,0),y.up.applyMatrix4(m),y.up.reflect(c),y.lookAt(v),y.far=a.far,y.updateMatrixWorld(),y.projectionMatrix.copy(a.projectionMatrix),w.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),w.multiply(y.projectionMatrix),w.multiply(y.matrixWorldInverse),w.multiply(i.matrixWorld),h.setFromNormalAndCoplanarPoint(c,d),h.applyMatrix4(y.matrixWorldInverse),f.set(h.normal.x,h.normal.y,h.normal.z,h.constant);let r=y.projectionMatrix;b.x=(Math.sign(f.x)+r.elements[8])/r.elements[0],b.y=(Math.sign(f.y)+r.elements[9])/r.elements[5],b.z=-1,b.w=(1+r.elements[10])/r.elements[14],f.multiplyScalar(2/f.dot(b)),r.elements[2]=f.x,r.elements[6]=f.y,r.elements[10]=f.z+1-s,r.elements[14]=f.w,i.visible=!1;let o=e.getRenderTarget(),n=e.xr.enabled,l=e.shadowMap.autoUpdate;e.xr.enabled=!1,e.shadowMap.autoUpdate=!1,e.setRenderTarget(x),e.state.buffers.depth.setMask(!0),!1===e.autoClear&&e.clear(),e.render(t,y),e.xr.enabled=n,e.shadowMap.autoUpdate=l,e.setRenderTarget(o);let M=a.viewport;void 0!==M&&e.state.viewport(M),i.visible=!0,this.forceUpdate=!1},this.getRenderTarget=function(){return x},this.dispose=function(){x.dispose(),i.material.dispose()}}}tL.ReflectorShader={name:"ReflectorShader",uniforms:{color:{value:null},tDiffuse:{value:null},textureMatrix:{value:null}},vertexShader:`
		uniform mat4 textureMatrix;
		varying vec4 vUv;

		#include <common>
		#include <logdepthbuf_pars_vertex>

		void main() {

			vUv = textureMatrix * vec4( position, 1.0 );

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

			#include <logdepthbuf_vertex>

		}`,fragmentShader:`
		uniform vec3 color;
		uniform sampler2D tDiffuse;
		varying vec4 vUv;

		#include <logdepthbuf_pars_fragment>

		float blendOverlay( float base, float blend ) {

			return( base < 0.5 ? ( 2.0 * base * blend ) : ( 1.0 - 2.0 * ( 1.0 - base ) * ( 1.0 - blend ) ) );

		}

		vec3 blendOverlay( vec3 base, vec3 blend ) {

			return vec3( blendOverlay( base.r, blend.r ), blendOverlay( base.g, blend.g ), blendOverlay( base.b, blend.b ) );

		}

		void main() {

			#include <logdepthbuf_fragment>

			vec4 base = texture2DProj( tDiffuse, vUv );
			gl_FragColor = vec4( blendOverlay( base.rgb, color ), 1.0 );

			#include <tonemapping_fragment>
			#include <colorspace_fragment>

		}`};var tR=e.i(758611);let tE=new WeakSet;function tF(e,t=[]){let i=e.onBeforeRender;e.onBeforeRender=(...a)=>{let r=a[0];if(tE.has(r))return;tE.add(r);let o=t.map(e=>e.visible);t.forEach(e=>{e.visible=!1});try{i.apply(e,a)}finally{t.forEach((e,t)=>{e.visible=o[t]}),tE.delete(r)}}}class tI{source;mirrors;bounds;cameraPosition;camera;rendered;probe;bounceTarget;probeMaterials;probeDirty;lightingReady;near;invalidateProbe(){this.probeDirty=!0}constructor(e,t,i,a=[],r){this.source=e,this.mirrors=[],this.bounds=new L.Box3,this.cameraPosition=new L.Vector3,this.rendered=new Set,this.probeMaterials=[],this.probeDirty=!0,this.lightingReady=!0,this.near=!1,e.geometry.computeBoundingBox();const o=e.geometry.boundingBox.getCenter(new L.Vector3),s=(e,t,i=!1,a)=>(function(e,t=!1,i=4,a){let r=e.getAttribute("position"),o=e.index,s=e.getAttribute("uv");if(!r||r.count<3)return[];e.computeBoundingBox();let n=e.boundingBox.getCenter(new L.Vector3),l=new L.Vector3,h=new L.Vector3,c=new L.Vector3,d=new L.Vector3,u=new L.Vector3,m=[],p=o?.count??r.count;for(let e=0;e+2<p;e+=3){l.fromBufferAttribute(r,o?o.getX(e):e),h.fromBufferAttribute(r,o?o.getX(e+1):e+1),c.fromBufferAttribute(r,o?o.getX(e+2):e+2),d.subVectors(h,l).cross(u.subVectors(c,l));let i=d.length()/2;if(!Number.isFinite(i)||i<1e-8)continue;d.normalize();let p=new L.Plane().setFromNormalAndCoplanarPoint(d,l);if(!t&&.7>Math.abs(d.y)||.001>=p.distanceToPoint(a??n))continue;let f=m.find(e=>e.plane.normal.dot(d)>1-1e-6&&.002>Math.abs(e.plane.distanceToPoint(l)));f||(f={plane:p,points:[],uv:[],area:0},m.push(f)),f.points.push(...l.toArray(),...h.toArray(),...c.toArray());for(let t=e;t<e+3;t++){let e=o?o.getX(t):t;f.uv.push(s?.getX(e)??0,s?.getY(e)??0)}f.area+=i}return m.filter(e=>e.area>=i).map(e=>{let t=e.plane.projectPoint(n,new L.Vector3),i=new L.Quaternion().setFromUnitVectors(new L.Vector3(0,0,1),e.plane.normal),a=i.clone().invert();for(let i=0;i<e.points.length;i+=3)l.fromArray(e.points,i).sub(t).applyQuaternion(a),l.z=0,l.toArray(e.points,i);let r=new L.BufferGeometry().setAttribute("position",new L.Float32BufferAttribute(e.points,3));return r.setAttribute("uv",new L.Float32BufferAttribute(e.uv,2)),r.computeVertexNormals(),{geometry:r,origin:t,rotation:i,area:e.area}})})(e,i,i?12:4,a).map(e=>{let i=e.geometry.getAttribute("position").count,a=[],r=[],o=[],s=e.geometry.getAttribute("uv");t.normalMap?.updateMatrix();let n=new L.Vector2;for(let e=0;e<i;e++)a.push(t.normalMap?t.normalScale.x:0,t.normalMap?t.normalScale.y:0,t.roughness),r.push(...t.color.toArray()),o.push(t.metalness),t.normalMap&&(n.set(s.getX(e),s.getY(e)).applyMatrix3(t.normalMap.matrix),s.setXY(e,n.x,n.y));return e.geometry.setAttribute("mirrorFinish",new L.Float32BufferAttribute(a,3)),e.geometry.setAttribute("mirrorColor",new L.Float32BufferAttribute(r,3)),e.geometry.setAttribute("mirrorMetalness",new L.Float32BufferAttribute(o,1)),{...e,normalMap:t.normalMap}}),n=s(e.geometry,e.material);if(r){e.updateWorldMatrix(!0,!1),r.updateWorldMatrix(!0,!1);const t=r.geometry.clone().applyMatrix4(new L.Matrix4().copy(e.matrixWorld).invert().multiply(r.matrixWorld));n.push(...s(t,r.material,!1,o)),t.dispose()}if(i){e.updateWorldMatrix(!0,!1),i.updateWorldMatrix(!0,!1);const o=i.geometry.clone().applyMatrix4(new L.Matrix4().copy(e.matrixWorld).invert().multiply(i.matrixWorld)),l=s(o,i.material,!0);for(const e of(o.dispose(),l)){const t=new L.Vector3(0,0,1).applyQuaternion(e.rotation),i=n.find(i=>i.normalMap===e.normalMap&&new L.Vector3(0,0,1).applyQuaternion(i.rotation).dot(t)>1-1e-6&&.002>Math.abs(t.dot(i.origin.clone().sub(e.origin))));if(!i){n.push(e);continue}const a=new L.Matrix4().compose(i.origin,i.rotation,new L.Vector3(1,1,1)).invert().multiply(new L.Matrix4().compose(e.origin,e.rotation,new L.Vector3(1,1,1)));e.geometry.applyMatrix4(a);const r=(0,tR.mergeGeometries)([i.geometry,e.geometry]);i.geometry.dispose(),e.geometry.dispose(),i.geometry=r}for(const o of(this.probe=new L.CubeCamera(.05,2e4,new R.WebGLCubeRenderTarget(t?64:128,{type:L.HalfFloatType})),this.bounceTarget=this.probe.renderTarget.clone(),new Set([e.material,i.material,...r?[r.material]:[],...a])))!Array.isArray(o)&&o.isMeshStandardMaterial&&this.probeMaterials.push({material:o,envMap:o.envMap,intensity:o.envMapIntensity})}if(n.length>8)throw n.forEach(e=>e.geometry.dispose()),this.probe?.renderTarget.dispose(),this.bounceTarget?.dispose(),Error("Authored interior exceeds eight planar reflection surfaces");const l=t?384:768;for(const t of n){const i=new tL(t.geometry,{color:e.material.color,textureWidth:l,textureHeight:l,multisample:0});i.position.copy(t.origin),i.quaternion.copy(t.rotation),i.name=`${e.name} reflection`,i.userData.spaceRuntime="interior-reflection",i.visible=!1;const a=i.material;a.polygonOffset=!0,a.polygonOffsetFactor=0,a.polygonOffsetUnits=-4,a.uniforms.mirrorTexel={value:new L.Vector2(1/l,1/l)};const r="varying vec2 metalUv; varying vec3 metalPosition, metalFinish, metalColor, mirrorView, mirrorNormal; varying float metalness;";a.vertexShader=a.vertexShader.replace("varying vec4 vUv;",`varying vec4 vUv; ${r} attribute vec3 mirrorFinish, mirrorColor; attribute float mirrorMetalness;`).replace("void main() {","void main() { metalUv = uv; metalPosition = position; metalFinish = mirrorFinish; metalColor = mirrorColor; metalness = mirrorMetalness; mirrorView = -(modelViewMatrix * vec4(position, 1.)).xyz; mirrorNormal = normalMatrix * vec3(0., 0., 1.);"),a.uniforms.metalNormal={value:t.normalMap},t.normalMap&&(a.defines.METAL_NORMAL=""),a.fragmentShader=a.fragmentShader.replace("varying vec4 vUv;",`varying vec4 vUv; ${r} uniform vec2 mirrorTexel; uniform sampler2D metalNormal; uniform mat4 textureMatrix;`).replace("vec4 base = texture2DProj( tDiffuse, vUv );",`
          vec4 projected = vUv;
          #ifdef METAL_NORMAL
            vec2 du = dFdx(metalUv), dv = dFdy(metalUv);
            float determinant = du.x * dv.y - du.y * dv.x;
            // Collapsed UVs deliberately keep smooth floor tiles undistorted.
            if (abs(determinant) > 1e-12) {
              vec3 dx = dFdx(metalPosition), dy = dFdy(metalPosition);
              vec3 tangent = normalize(dx * dv.y - dy * du.y) * sign(determinant);
              vec3 bitangent = normalize(dy * du.x - dx * dv.x) * sign(determinant);
              vec2 slope = (texture2D(metalNormal, metalUv).xy * 2. - 1.) * metalFinish.xy;
              // First-order planar approximation at an estimated 2 m optical
              // distance. The perturbation stays in the authored UV basis.
              projected += textureMatrix * vec4(2. * (tangent * slope.x + bitangent * slope.y), 0.);
            }
          #endif
          vec2 uv = clamp(projected.xy / projected.w, mirrorTexel, vec2(1.) - mirrorTexel);
          vec2 stepUv = mirrorTexel * metalFinish.z * 12.;
          vec4 base = texture2D(tDiffuse, uv) * .5;
          base += (texture2D(tDiffuse, uv + vec2(stepUv.x, 0.)) + texture2D(tDiffuse, uv - vec2(stepUv.x, 0.))
                 + texture2D(tDiffuse, uv + vec2(0., stepUv.y)) + texture2D(tDiffuse, uv - vec2(0., stepUv.y))) * .125;
          // Match the authored metallic/roughness distinction. Polished dark
          // dielectric flooring reflects weakly head-on and strongly at grazing
          // angles; it must not inherit the ceiling's coloured metal reflectance.
          float grazing = pow(1. - clamp(abs(dot(normalize(mirrorView), normalize(mirrorNormal))), 0., 1.), 5.);
          vec3 f0 = mix(vec3(.04), metalColor, metalness);
          vec3 fresnel = f0 + (vec3(1.) - f0) * grazing;
        `).replace("blendOverlay( base.rgb, color )","base.rgb * fresnel"),tF(i,this.mirrors);const o=i.onBeforeRender;i.onBeforeRender=(...e)=>{e[2]!==this.camera||this.rendered.has(i)||(this.probeDirty&&this.lightingReady&&!tE.has(e[0])&&this.captureProbe(e[0],e[1]),o.apply(i,e),this.rendered.add(i))},e.add(i),this.mirrors.push(i)}}captureProbe(e,t){if(!this.probe)return;let i=this.mirrors.map(e=>e.visible),a=e.getRenderTarget(),r=e.getActiveCubeFace(),o=e.getActiveMipmapLevel(),s=e.xr.enabled;tE.add(e),this.mirrors.forEach(e=>{e.visible=!1}),this.setProbeMaterials(!1),this.source.geometry.boundingBox.getCenter(this.probe.position).applyMatrix4(this.source.matrixWorld);try{this.probe.update(e,t),this.setProbeMaterials(!0);let i=this.probe.renderTarget;this.probe.renderTarget=this.bounceTarget,this.bounceTarget=i,this.probe.update(e,t),this.probeDirty=!1}finally{e.setRenderTarget(a,r,o),e.xr.enabled=s,this.mirrors.forEach((e,t)=>{e.visible=i[t]}),tE.delete(e),this.setProbeMaterials(!this.probeDirty)}}setProbeMaterials(e){for(let t of this.probeMaterials){let i=e?this.probe.renderTarget.texture:t.envMap;t.material.envMap!==i&&(t.material.envMap=i,t.material.envMapIntensity=e?1:t.intensity,t.material.needsUpdate=!0)}}update(e,t=!0){if(this.camera=e,this.rendered.clear(),this.lightingReady=t,t||(this.probeDirty=!0),!this.mirrors.length)return;this.source.updateWorldMatrix(!0,!1),this.bounds.copy(this.source.geometry.boundingBox).applyMatrix4(this.source.matrixWorld),e.getWorldPosition(this.cameraPosition);let i=25>this.bounds.distanceToPoint(this.cameraPosition);for(let e of(i&&!this.near&&(this.probeDirty=!0),i||this.setProbeMaterials(!1),this.near=i,this.mirrors))e.visible=i}dispose(){for(let e of(this.setProbeMaterials(!1),this.probe?.renderTarget.dispose(),this.probe=void 0,this.bounceTarget?.dispose(),this.bounceTarget=void 0,this.probeMaterials.length=0,this.mirrors))e.removeFromParent(),e.geometry.dispose(),e.dispose();this.mirrors.length=0,this.rendered.clear(),this.camera=void 0}}class tU{static init(){let e=[1,0,0,2e-5,1,0,0,503905e-9,1,0,0,.00201562,1,0,0,.00453516,1,0,0,.00806253,1,0,0,.0125978,1,0,0,.018141,1,0,0,.0246924,1,0,0,.0322525,1,0,0,.0408213,1,0,0,.0503999,1,0,0,.0609894,1,0,0,.0725906,1,0,0,.0852058,1,0,0,.0988363,1,0,0,.113484,1,0,0,.129153,1,0,0,.145839,1,0,0,.163548,1,0,0,.182266,1,0,0,.201942,1,0,0,.222314,1,0,0,.241906,1,0,0,.262314,1,0,0,.285754,1,0,0,.310159,1,0,0,.335426,1,0,0,.361341,1,0,0,.387445,1,0,0,.412784,1,0,0,.438197,1,0,0,.466966,1,0,0,.49559,1,0,0,.523448,1,0,0,.549938,1,0,0,.57979,1,0,0,.608746,1,0,0,.636185,1,0,0,.664748,1,0,0,.69313,1,0,0,.71966,1,0,0,.747662,1,0,0,.774023,1,0,0,.799775,1,0,0,.825274,1,0,0,.849156,1,0,0,.873248,1,0,0,.89532,1,0,0,.917565,1,0,0,.937863,1,0,0,.958139,1,0,0,.976563,1,0,0,.994658,1,0,0,1.0112,1,0,0,1.02712,1,0,0,1.04189,1,0,0,1.05568,1,0,0,1.06877,1,0,0,1.08058,1,0,0,1.09194,1,0,0,1.10191,1,0,0,1.11161,1,0,0,1.1199,1,0,0,1.12813,.999547,-448815e-12,.0224417,199902e-10,.999495,-113079e-10,.0224406,503651e-9,.999496,-452317e-10,.0224406,.00201461,.999496,-101772e-9,.0224406,.00453287,.999495,-180928e-9,.0224406,.00805845,.999497,-282702e-9,.0224406,.0125914,.999496,-407096e-9,.0224406,.0181319,.999498,-554114e-9,.0224406,.02468,.999499,-723768e-9,.0224406,.0322363,.999495,-916058e-9,.0224405,.0408009,.999499,-.00113101,.0224408,.050375,.999494,-.00136863,.0224405,.0609586,.999489,-.00162896,.0224401,.0725537,.999489,-.00191201,.0224414,.0851619,.999498,-.00221787,.0224413,.0987867,.999492,-.00254642,.0224409,.113426,.999507,-.00289779,.0224417,.129088,.999494,-.0032716,.0224386,.145767,.999546,-.0036673,.0224424,.163472,.999543,-.00408166,.0224387,.182182,.999499,-.00450056,.0224338,.201843,.999503,-.00483661,.0224203,.222198,.999546,-.00452928,.022315,.241714,.999508,-.00587403,.0224329,.262184,.999509,-.00638806,.0224271,.285609,.999501,-.00691028,.0224166,.309998,.999539,-.00741979,.0223989,.335262,.999454,-.00786282,.0223675,.361154,.999529,-.00811928,.0222828,.387224,.999503,-.00799941,.0221063,.41252,.999561,-.00952753,.0223057,.438006,.999557,-.0099134,.0222065,.466735,.999541,-.0100935,.0220402,.495332,.999562,-.00996821,.0218067,.523197,.999556,-.0105031,.0217096,.550223,.999561,-.0114191,.0217215,.579498,.999588,-.0111818,.0213357,.608416,.999633,-.0107725,.0208689,.635965,.999527,-.0121671,.0210149,.664476,.999508,-.0116005,.020431,.692786,.999568,-.0115604,.0199791,.719709,.999671,-.0121117,.0197415,.74737,.999688,-.0110769,.0188846,.773692,.99962,-.0122368,.0188452,.799534,.999823,-.0110325,.0178001,.825046,.999599,-.0114923,.0174221,.849075,.999619,-.0105923,.0164345,.872999,.999613,-.0105988,.0158227,.895371,.99964,-.00979861,.0148131,.917364,.99977,-.00967238,.0140721,.938002,.999726,-.00869175,.0129543,.957917,.99973,-.00866872,.0122329,.976557,.999773,-.00731956,.0108958,.994459,.999811,-.00756027,.0102715,1.01118,.999862,-.00583732,.00878781,1.02701,.999835,-.00631438,.00827529,1.04186,.999871,-.00450785,.00674583,1.05569,.999867,-.00486079,.00621041,1.06861,.999939,-.00322072,.00478301,1.08064,.999918,-.00318199,.00406395,1.09181,1.00003,-.00193348,.00280682,1.10207,.999928,-.00153729,.00198741,1.11152,.999933,-623666e-9,917714e-9,1.12009,1,-102387e-11,907581e-12,1.12813,.997866,-896716e-12,.0448334,199584e-10,.997987,-225945e-10,.0448389,502891e-9,.997987,-903781e-10,.0448388,.00201156,.997985,-203351e-9,.0448388,.00452602,.997986,-361514e-9,.0448388,.00804629,.997987,-56487e-8,.0448389,.0125724,.997988,-813423e-9,.0448389,.0181045,.997984,-.00110718,.0448387,.0246427,.997985,-.00144616,.0448388,.0321875,.997987,-.00183038,.044839,.0407392,.997983,-.00225987,.0448387,.0502986,.997991,-.00273467,.0448389,.0608667,.997984,-.00325481,.0448384,.0724444,.998002,-.00382043,.044839,.0850348,.997997,-.00443145,.0448396,.0986372,.998007,-.00508796,.0448397,.113255,.998008,-.00578985,.04484,.128891,.998003,-.00653683,.0448384,.145548,.997983,-.00732713,.0448358,.163221,.997985,-.00815454,.0448358,.181899,.998005,-.00898985,.0448286,.201533,.998026,-.00964404,.0447934,.221821,.998055,-.00922677,.044611,.241282,.99804,-.0117361,.0448245,.261791,.998048,-.0127628,.0448159,.285181,.998088,-.0138055,.0447996,.30954,.998058,-.0148206,.0447669,.334751,.998099,-.0156998,.044697,.36061,.998116,-.0161976,.0445122,.386603,.998195,-.015945,.0441711,.411844,.998168,-.0183947,.0444255,.43773,.998184,-.0197913,.0443809,.466009,.998251,-.0201426,.0440689,.494574,.998305,-.0198847,.0435632,.522405,.998273,-.0210577,.043414,.549967,.998254,-.0227901,.0433943,.578655,.998349,-.0223108,.0426529,.60758,.99843,-.0223088,.042,.635524,.998373,-.0241141,.0418987,.663621,.998425,-.0231446,.0408118,.691906,.998504,-.0233684,.0400565,.719339,.998443,-.0241652,.0394634,.74643,.99848,-.0228715,.0380002,.773086,.998569,-.023519,.0372322,.798988,.998619,-.0223108,.0356468,.824249,.998594,-.0223105,.034523,.848808,.998622,-.0213426,.0328887,.87227,.998669,-.0207912,.0314374,.895157,.998705,-.0198416,.0296925,.916769,.998786,-.0189168,.0279634,.937773,.998888,-.0178811,.0261597,.957431,.99906,-.0166845,.0242159,.976495,.999038,-.0155464,.0222638,.994169,.999237,-.0141349,.0201967,1.01112,.999378,-.0129324,.0181744,1.02692,.999433,-.0113192,.0159898,1.04174,.999439,-.0101244,.0140385,1.05559,.999614,-.00837456,.0117826,1.06852,.999722,-.00721769,.00983745,1.08069,.999817,-.00554067,.00769002,1.09176,.99983,-.00426961,.005782,1.10211,.999964,-.00273904,.00374503,1.11152,1.00001,-.00136739,.00187176,1.12031,.999946,393227e-10,-28919e-9,1.12804,.995847,-13435e-10,.0671785,19916e-9,.995464,-338387e-10,.0671527,501622e-9,.99547,-135355e-9,.0671531,.00200649,.995471,-30455e-8,.0671532,.00451461,.99547,-541423e-9,.0671531,.008026,.995471,-84598e-8,.0671531,.0125407,.99547,-.00121823,.0671531,.0180589,.99547,-.00165817,.0671531,.0245806,.995463,-.00216583,.0671526,.0321062,.995468,-.00274127,.0671527,.0406366,.995474,-.00338447,.0671534,.0501717,.995473,-.00409554,.0671533,.0607131,.995478,-.00487451,.0671531,.0722618,.995476,-.00572148,.0671532,.0848191,.995477,-.00663658,.0671539,.0983882,.995498,-.00761986,.0671541,.112972,.995509,-.00867094,.0671542,.128568,.995509,-.00978951,.0671531,.145183,.995503,-.0109725,.0671491,.162808,.995501,-.012211,.0671465,.181441,.99553,-.0134565,.0671371,.201015,.99555,-.014391,.0670831,.221206,.99558,-.014351,.0668883,.240813,.995577,-.0173997,.0671055,.261257,.995602,-.0191111,.0671178,.284467,.995623,-.0206705,.0670946,.308765,.995658,-.022184,.0670472,.333905,.995705,-.0234832,.0669417,.359677,.995719,-.0241933,.0666714,.385554,.995786,-.0243539,.066266,.410951,.995887,-.0271866,.0664367,.437163,.995944,-.0296012,.0664931,.464842,.996004,-.0301045,.0660105,.49332,.996128,-.0298311,.0652694,.521131,.996253,-.0316426,.0650739,.549167,.996244,-.0339043,.0649433,.57737,.996309,-.033329,.0638926,.606073,.996417,-.0338935,.0630849,.634527,.996372,-.0353104,.0625083,.66256,.996542,-.0348942,.0611986,.690516,.996568,-.0351614,.060069,.718317,.996711,-.0354317,.0588522,.74528,.996671,-.0349513,.0571902,.772061,.996865,-.0345622,.0555321,.798089,.996802,-.0342566,.0537816,.823178,.996992,-.0330862,.0516095,.847949,.996944,-.0324666,.0495537,.871431,.997146,-.0309544,.0470302,.894357,.997189,-.0299372,.0446043,.916142,.997471,-.0281389,.0418812,.937193,.997515,-.0268702,.0391823,.957,.997812,-.0247166,.0361338,.975936,.998027,-.0233525,.0333945,.99391,.998233,-.0209839,.0301917,1.01075,.998481,-.0194309,.027271,1.02669,.998859,-.0169728,.0240162,1.04173,.99894,-.0152322,.0210517,1.05551,.999132,-.0127497,.0178632,1.06856,.999369,-.0108282,.014787,1.08054,.999549,-.00845886,.0116185,1.09185,.999805,-.0063937,.00867209,1.10207,.99985,-.00414582,.00566823,1.1117,.999912,-.00207443,.00277562,1.12022,1.00001,870226e-10,-53766e-9,1.12832,.991943,-178672e-11,.0893382,198384e-10,.991952,-450183e-10,.089339,499849e-9,.991956,-180074e-9,.0893394,.0019994,.991955,-405167e-9,.0893393,.00449867,.991953,-720298e-9,.0893391,.00799764,.991955,-.00112548,.0893393,.0124964,.991957,-.0016207,.0893395,.0179951,.991958,-.00220601,.0893396,.0244939,.991947,-.00288137,.0893385,.0319929,.991962,-.00364693,.0893399,.0404933,.991965,-.00450264,.0893399,.049995,.99198,-.00544862,.0893411,.0604995,.99197,-.00648491,.0893397,.0720074,.991976,-.00761164,.089341,.0845207,.99198,-.00882891,.0893405,.0980413,.991982,-.0101367,.0893396,.112571,.992008,-.011535,.0893415,.128115,.992026,-.0130228,.0893414,.144672,.992064,-.0145966,.0893418,.162241,.992041,-.0162421,.0893359,.180801,.992086,-.0178888,.0893214,.200302,.992157,-.0190368,.0892401,.220332,.992181,-.0195584,.0890525,.240144,.992175,-.0227257,.0892153,.260728,.99221,-.0254195,.089304,.283473,.99222,-.0274883,.0892703,.307673,.992317,-.0294905,.0892027,.332729,.992374,-.0311861,.0890577,.358387,.992505,-.0320656,.0886994,.384102,.992568,-.0329715,.0883198,.409767,.992675,-.036006,.0883602,.436145,.992746,-.0392897,.0884591,.463217,.992873,-.0399337,.0878287,.491557,.992934,-.040231,.0870108,.519516,.993091,-.0422013,.0865857,.547741,.993259,-.0443503,.0861937,.575792,.993455,-.0446368,.0851187,.604233,.993497,-.0454299,.0840576,.632925,.993694,-.0463296,.0829671,.660985,.993718,-.0470619,.0817185,.688714,.993973,-.0468838,.0800294,.716743,.994207,-.046705,.0781286,.74377,.994168,-.0469698,.0763337,.77042,.9945,-.0456816,.0738184,.796659,.994356,-.0455518,.0715545,.821868,.994747,-.0439488,.0686085,.846572,.994937,-.0430056,.065869,.870435,.995142,-.0413414,.0626446,.893272,.995451,-.0396521,.05929,.915376,.995445,-.0378453,.0558503,.936196,.995967,-.0355219,.0520949,.956376,.996094,-.0335146,.048377,.975327,.996622,-.030682,.0442575,.993471,.996938,-.0285504,.0404693,1.01052,.997383,-.0253399,.0360903,1.02637,.997714,-.0231651,.0322176,1.04139,.998249,-.0198138,.0278433,1.05542,.998596,-.0174337,.0238759,1.06846,.998946,-.0141349,.0195944,1.08056,.99928,-.0115603,.0156279,1.09181,.999507,-.00839065,.0114607,1.10213,.999697,-.005666,.00763325,1.11169,.999869,-.00269902,.00364946,1.12042,1.00001,623836e-10,-319288e-10,1.12832,.987221,-222675e-11,.111332,197456e-10,.98739,-561116e-10,.111351,497563e-9,.987448,-224453e-9,.111357,.00199031,.987441,-505019e-9,.111357,.0044782,.987442,-897816e-9,.111357,.00796129,.987442,-.00140284,.111357,.0124396,.987444,-.00202012,.111357,.0179132,.987442,-.00274964,.111357,.0243824,.987446,-.00359147,.111357,.0318474,.987435,-.00454562,.111356,.0403086,.987461,-.00561225,.111358,.0497678,.987458,-.00679125,.111358,.0602239,.987443,-.0080828,.111356,.0716792,.987476,-.0094872,.111358,.0841364,.98749,-.0110044,.111361,.097597,.987508,-.0126344,.111362,.112062,.987494,-.0143767,.111357,.127533,.987526,-.0162307,.111359,.144015,.987558,-.0181912,.111361,.161502,.987602,-.0202393,.111355,.179979,.987692,-.022273,.111346,.199386,.987702,-.0235306,.111215,.219183,.987789,-.0247628,.111061,.239202,.987776,-.0280668,.111171,.259957,.987856,-.0316751,.111327,.282198,.987912,-.0342468,.111282,.306294,.988,-.0367205,.111198,.331219,.988055,-.0387766,.110994,.356708,.988241,-.0397722,.110547,.382234,.988399,-.0416076,.110198,.408227,.988539,-.0448192,.110137,.434662,.988661,-.0483793,.110143,.461442,.988967,-.0495895,.109453,.489318,.989073,-.0506797,.108628,.517516,.989274,-.0526953,.108003,.545844,.989528,-.054578,.107255,.573823,.989709,-.0561503,.106294,.601944,.989991,-.056866,.104896,.630855,.990392,-.0572914,.103336,.658925,.990374,-.0586224,.10189,.686661,.990747,-.0584764,.099783,.714548,.991041,-.0582662,.0974309,.74186,.991236,-.0584118,.0951678,.768422,.991585,-.0573055,.0921581,.794817,.991984,-.0564241,.0891167,.820336,.9921,-.0553608,.085805,.84493,.992749,-.0533816,.0820354,.868961,.99288,-.0518661,.0782181,.891931,.993511,-.0492492,.0738935,.914186,.993617,-.0471956,.0696402,.93532,.99411,-.044216,.0649659,.95543,.994595,-.0416654,.0603177,.974685,.994976,-.0384314,.0553493,.992807,.995579,-.0353491,.0503942,1.00996,.996069,-.0319787,.0452123,1.02606,.996718,-.028472,.0400112,1.04114,.997173,-.0250789,.0349456,1.05517,.997818,-.0213326,.029653,1.0683,.998318,-.0178509,.024549,1.0805,.998853,-.0141118,.0194197,1.09177,.999218,-.0105914,.0143869,1.1022,.999594,-.00693474,.00943517,1.11175,.99975,-.00340478,.00464051,1.12056,1.00001,109172e-9,-112821e-9,1.12853,.983383,-266524e-11,.133358,196534e-10,.981942,-671009e-10,.133162,494804e-9,.981946,-268405e-9,.133163,.00197923,.981944,-603912e-9,.133163,.00445326,.981941,-.00107362,.133162,.00791693,.981946,-.00167755,.133163,.0123703,.981944,-.00241569,.133162,.0178135,.981945,-.00328807,.133163,.0242466,.981945,-.00429472,.133162,.03167,.981955,-.00543573,.133164,.0400846,.981951,-.00671105,.133163,.0494901,.981968,-.00812092,.133165,.0598886,.981979,-.00966541,.133166,.0712811,.981996,-.0113446,.133168,.083669,.982014,-.0131585,.133169,.0970533,.982011,-.0151073,.133167,.111438,.982062,-.0171906,.133172,.126826,.9821,-.0194067,.133175,.143215,.982149,-.0217502,.133176,.160609,.982163,-.0241945,.133173,.178981,.982247,-.0265907,.133148,.198249,.982291,-.027916,.132974,.217795,.982396,-.0299663,.132868,.238042,.982456,-.0334544,.132934,.258901,.982499,-.0378636,.133137,.280639,.982617,-.0409274,.133085,.304604,.98274,-.0438523,.132985,.329376,.982944,-.0462288,.132728,.354697,.98308,-.0475995,.132228,.380102,.983391,-.0501901,.131924,.406256,.983514,-.0535899,.131737,.432735,.98373,-.0571858,.131567,.459359,.984056,-.0592353,.130932,.486637,.984234,-.0610488,.130092,.51509,.984748,-.0630758,.12923,.543461,.985073,-.0647398,.128174,.571376,.985195,-.0671941,.127133,.599414,.985734,-.0681345,.125576,.628134,.986241,-.0686089,.123639,.656399,.986356,-.0698511,.121834,.684258,.986894,-.0700931,.119454,.711818,.987382,-.0698321,.116718,.739511,.988109,-.0693975,.113699,.766267,.988363,-.0689584,.110454,.792456,.989112,-.0672353,.106602,.81813,.989241,-.0662034,.10267,.842889,.990333,-.0638938,.0981381,.867204,.990591,-.0618534,.0935388,.89038,.991106,-.0593117,.088553,.912576,.991919,-.0562676,.0832187,.934118,.992111,-.0534085,.0778302,.954254,.992997,-.0495459,.0720453,.973722,.993317,-.0463707,.0663458,.991949,.994133,-.0421245,.0601883,1.00936,.994705,-.0384977,.0542501,1.02559,.995495,-.0340956,.0479862,1.04083,.996206,-.030105,.041887,1.05497,.996971,-.0256095,.0355355,1.06824,.997796,-.0213932,.0293655,1.08056,.998272,-.0169612,.0232926,1.09182,.998857,-.0126756,.0172786,1.10219,.99939,-.00832486,.0113156,1.11192,.999752,-.00410826,.00557892,1.12075,1,150957e-9,-119101e-9,1.12885,.975169,-309397e-11,.154669,195073e-10,.975439,-779608e-10,.154712,491534e-9,.975464,-311847e-9,.154716,.00196617,.975464,-701656e-9,.154716,.00442387,.975462,-.0012474,.154715,.0078647,.975461,-.00194906,.154715,.0122886,.975464,-.00280667,.154715,.0176959,.975468,-.00382025,.154716,.0240867,.975471,-.00498985,.154716,.0314612,.975472,-.00631541,.154717,.0398199,.975486,-.00779719,.154718,.0491639,.975489,-.00943505,.154718,.0594932,.975509,-.0112295,.154721,.0708113,.97554,-.0131802,.154724,.0831176,.975557,-.0152876,.154726,.096415,.975585,-.0175512,.154728,.110705,.975605,-.0199713,.154729,.125992,.975645,-.0225447,.154729,.142272,.975711,-.0252649,.154735,.159549,.975788,-.0280986,.154736,.177805,.975872,-.0308232,.154704,.196911,.975968,-.0324841,.154525,.216324,.976063,-.0351281,.154432,.236628,.976157,-.0388618,.15446,.257539,.976204,-.0437704,.154665,.278975,.976358,-.047514,.154652,.302606,.976571,-.0508638,.154535,.327204,.976725,-.0534995,.154221,.352276,.977013,-.0555547,.153737,.377696,.977294,-.0586728,.153403,.403855,.977602,-.0622715,.15312,.430333,.977932,-.0658166,.152755,.456855,.978241,-.0689877,.152233,.483668,.978602,-.0712805,.15132,.512097,.979234,-.0732775,.150235,.540455,.97977,-.075163,.148978,.568486,.979995,-.0778026,.147755,.596524,.98078,-.0791854,.146019,.624825,.981628,-.0799666,.143906,.653403,.982067,-.0808532,.141561,.681445,.98271,-.0816024,.139025,.708918,.983734,-.0812511,.135764,.736594,.98431,-.0806201,.132152,.763576,.985071,-.0801605,.12846,.789797,.98618,-.0784208,.124084,.815804,.986886,-.0766643,.1193,.840869,.987485,-.0747744,.114236,.864952,.988431,-.0716701,.108654,.888431,.988886,-.0691609,.102994,.910963,.990024,-.0654048,.0967278,.932629,.990401,-.0619765,.090384,.95313,.991093,-.0579296,.0837885,.972587,.992018,-.0536576,.0770171,.991184,.992536,-.0493719,.0701486,1.00863,.993421,-.0444813,.062953,1.02494,.993928,-.040008,.0560455,1.04017,.994994,-.0347982,.04856,1.05463,.995866,-.0301017,.0416152,1.06807,.996916,-.0248225,.0342597,1.08039,.997766,-.0199229,.0271668,1.09177,.998479,-.0147422,.0201387,1.10235,.99921,-.00980173,.0131944,1.11206,.999652,-.0047426,.00640712,1.12104,.999998,891673e-10,-10379e-8,1.12906,.967868,-351885e-11,.175947,193569e-10,.968001,-886733e-10,.175972,487782e-9,.96801,-354697e-9,.175973,.00195115,.968012,-798063e-9,.175974,.00439006,.968011,-.00141879,.175973,.00780461,.968011,-.00221686,.175973,.0121948,.968016,-.00319231,.175974,.0175607,.968019,-.00434515,.175974,.0239027,.968018,-.00567538,.175974,.0312208,.968033,-.00718308,.175977,.0395158,.968049,-.00886836,.175979,.0487885,.968047,-.0107312,.175978,.0590394,.968072,-.0127719,.175981,.0702705,.968108,-.0149905,.175986,.0824836,.968112,-.0173866,.175985,.0956783,.968173,-.0199611,.175993,.109862,.96827,-.0227128,.176008,.125033,.968292,-.025639,.17601,.141193,.968339,-.0287299,.176007,.158336,.968389,-.0319399,.176001,.176441,.968501,-.034941,.175962,.195359,.968646,-.0370812,.175793,.214686,.968789,-.0402329,.175708,.234973,.96886,-.0442601,.1757,.255871,.969013,-.049398,.175876,.277238,.969242,-.0539932,.17594,.300326,.969419,-.0577299,.175781,.324702,.969763,-.0605643,.175432,.349527,.970093,-.0634488,.174992,.374976,.970361,-.0670589,.174611,.401097,.970825,-.0708246,.174226,.427496,.971214,-.0742871,.173684,.453858,.971622,-.0782608,.173186,.480637,.972175,-.0813151,.172288,.508655,.972944,-.0832678,.170979,.536973,.973595,-.0855964,.169573,.565138,.974345,-.0882163,.168152,.593222,.975233,-.0901671,.166314,.621201,.976239,-.0912111,.163931,.649919,.977289,-.0916959,.161106,.678011,.978076,-.0927061,.158272,.705717,.979533,-.0925562,.15475,.733228,.980335,-.0918159,.150638,.760454,.981808,-.0908508,.146201,.786918,.983061,-.0896172,.141386,.812953,.984148,-.0871588,.135837,.838281,.985047,-.0850624,.130135,.862594,.986219,-.0818541,.123882,.88633,.987043,-.0784523,.117126,.908952,.988107,-.0749601,.110341,.930744,.988955,-.0703548,.102885,.951728,.989426,-.0662798,.0954167,.971166,.990421,-.0610834,.0876331,.989984,.991032,-.0562936,.0797785,1.00765,.992041,-.0508154,.0718166,1.02434,.992794,-.0454045,.0637125,1.03976,.993691,-.0398194,.0555338,1.05418,.994778,-.0341482,.0473388,1.06772,.995915,-.028428,.0391016,1.08028,.997109,-.022642,.0309953,1.09185,.998095,-.0168738,.0230288,1.10247,.998985,-.0111274,.0150722,1.11229,.999581,-.00543881,.00740605,1.12131,1.00003,162239e-9,-105549e-9,1.12946,.959505,-393734e-11,.196876,191893e-10,.959599,-992157e-10,.196895,483544e-9,.959641,-396868e-9,.196903,.0019342,.959599,-892948e-9,.196895,.00435193,.959603,-.00158747,.196896,.0077368,.959604,-.00248042,.196896,.0120888,.959605,-.00357184,.196896,.0174082,.959605,-.00486169,.196896,.0236949,.959613,-.00635008,.196897,.0309497,.959619,-.00803696,.196898,.0391725,.959636,-.00992255,.196901,.0483649,.959634,-.0120067,.1969,.0585266,.959675,-.0142898,.196906,.0696609,.959712,-.0167717,.196911,.0817678,.959752,-.0194524,.196918,.0948494,.959807,-.0223321,.196925,.10891,.959828,-.0254091,.196924,.123947,.959906,-.0286815,.196934,.139968,.960005,-.0321371,.196944,.156968,.960071,-.0357114,.196936,.17491,.960237,-.0389064,.196882,.193597,.960367,-.041623,.196731,.21285,.960562,-.0452655,.196654,.233075,.960735,-.0496207,.196643,.253941,.960913,-.0549379,.196774,.275278,.961121,-.0603414,.196893,.297733,.96139,-.0644244,.196717,.321877,.961818,-.067556,.196314,.346476,.962175,-.0712709,.195917,.371907,.96255,-.0752848,.1955,.397916,.963164,-.0792073,.195026,.424229,.963782,-.0828225,.194424,.450637,.964306,-.0873119,.193831,.477288,.964923,-.0911051,.192973,.504716,.966048,-.093251,.19151,.533053,.967024,-.0958983,.190013,.561366,.968038,-.09835,.188253,.589464,.969152,-.100754,.186257,.617433,.970557,-.102239,.183775,.645801,.972104,-.102767,.180645,.674278,.973203,-.103492,.177242,.702004,.975123,-.103793,.17345,.729529,.97641,-.102839,.168886,.756712,.978313,-.101687,.163892,.783801,.980036,-.100314,.158439,.809671,.981339,-.097836,.152211,.835402,.982794,-.0950006,.145679,.860081,.984123,-.0920994,.138949,.883757,.984918,-.0878641,.131283,.90685,.985999,-.083939,.123464,.928786,.987151,-.0791234,.115324,.94983,.987827,-.0739332,.106854,.96962,.988806,-.0688088,.0982691,.98861,.989588,-.0628962,.0893456,1.00667,.990438,-.0573146,.0805392,1.02344,.991506,-.0509433,.0713725,1.03933,.992492,-.0448724,.0623732,1.05378,.993663,-.0383497,.0530838,1.06747,.994956,-.0319593,.0439512,1.08007,.99634,-.025401,.0347803,1.09182,.99761,-.0189687,.0257954,1.1025,.99863,-.0124441,.0169893,1.11247,.99947,-.00614003,.00829498,1.12151,1.00008,216624e-9,-146107e-9,1.12993,.950129,-434955e-11,.217413,190081e-10,.950264,-10957e-8,.217444,47884e-8,.9503,-438299e-9,.217451,.00191543,.950246,-986124e-9,.21744,.00430951,.950246,-.00175311,.21744,.00766137,.950245,-.00273923,.21744,.011971,.950253,-.00394453,.217441,.0172385,.950258,-.00536897,.217442,.0234641,.950267,-.00701262,.217444,.030648,.950277,-.00887551,.217446,.038791,.950284,-.0109576,.217446,.0478931,.950312,-.0132591,.217451,.0579568,.950334,-.01578,.217454,.0689821,.950378,-.0185204,.217462,.0809714,.950417,-.0214803,.217467,.0939265,.950488,-.0246594,.217479,.10785,.950534,-.0280565,.217483,.122743,.950633,-.0316685,.217498,.138611,.950698,-.0354787,.217499,.155442,.950844,-.0394003,.217507,.173208,.950999,-.0426812,.217419,.191605,.951221,-.0461302,.217317,.21084,.951412,-.0502131,.217238,.230945,.951623,-.0549183,.21722,.251745,.951867,-.0604493,.217306,.273001,.952069,-.0665189,.217466,.294874,.952459,-.0709179,.217266,.318732,.952996,-.0746112,.216891,.34318,.953425,-.0789252,.216503,.36849,.953885,-.0833293,.216042,.394373,.954617,-.087371,.215469,.420505,.955429,-.0914054,.214802,.446907,.956068,-.0961671,.214146,.473522,.957094,-.10048,.213286,.50052,.958372,-.103248,.211796,.528715,.959654,-.106033,.21016,.557065,.961305,-.108384,.208149,.585286,.962785,-.111122,.206024,.613334,.964848,-.112981,.203442,.641334,.966498,-.113717,.19996,.669955,.968678,-.114121,.196105,.698094,.970489,-.114524,.191906,.725643,.972903,-.113792,.186963,.752856,.974701,-.112406,.181343,.780013,.976718,-.110685,.175185,.806268,.978905,-.108468,.168535,.832073,.980267,-.105061,.161106,.857149,.981967,-.101675,.153387,.881145,.983063,-.0974492,.145199,.904255,.984432,-.0925815,.136527,.926686,.985734,-.0877983,.127584,.947901,.986228,-.081884,.118125,.968111,.98719,-.0761208,.108594,.98719,.988228,-.0698196,.0989996,1.00559,.989046,-.0632739,.0890074,1.02246,.990242,-.056522,.0790832,1.03841,.991252,-.0495272,.0689182,1.05347,.992542,-.0425373,.0588592,1.06724,.994096,-.0353198,.0486833,1.08009,.995593,-.028235,.0385977,1.09177,.99711,-.0209511,.0286457,1.10274,.998263,-.0139289,.0188497,1.11262,.999254,-.0067359,.009208,1.12191,.999967,141846e-9,-657764e-10,1.13024,.935608,-474692e-11,.236466,187817e-10,.93996,-11971e-8,.237568,473646e-9,.939959,-478845e-9,.237567,.0018946,.939954,-.0010774,.237566,.00426284,.939956,-.00191538,.237566,.00757842,.939954,-.00299277,.237566,.0118413,.93996,-.00430961,.237567,.0170518,.939969,-.00586589,.237569,.02321,.939982,-.00766166,.237572,.0303164,.939987,-.00969686,.237572,.0383711,.939997,-.0119715,.237574,.0473751,.940031,-.0144858,.237581,.0573298,.940073,-.0172399,.237589,.0682366,.94012,-.0202335,.237598,.080097,.940162,-.0234663,.237604,.0929116,.940237,-.0269387,.237615,.106686,.940328,-.0306489,.237632,.121421,.940419,-.0345917,.237645,.137115,.940522,-.0387481,.237654,.153766,.940702,-.0429906,.237661,.17133,.940871,-.0465089,.237561,.189502,.941103,-.050531,.23748,.208616,.941369,-.0550657,.237423,.228595,.941641,-.0601337,.237399,.249287,.941903,-.0658804,.237443,.270467,.942224,-.0722674,.237597,.292024,.942633,-.0771788,.237419,.315272,.943172,-.0815623,.237068,.339579,.943691,-.0863973,.236682,.364717,.944382,-.0911536,.236213,.390435,.945392,-.0952967,.235562,.416425,.946185,-.0998948,.234832,.442772,.947212,-.104796,.234114,.469347,.948778,-.10928,.233222,.496162,.950149,-.113081,.231845,.523978,.951989,-.115893,.230005,.552295,.953921,-.11846,.227862,.580569,.955624,-.12115,.225439,.608698,.958234,-.123373,.222635,.636696,.960593,-.124519,.219093,.665208,.963201,-.124736,.214749,.693557,.965642,-.125012,.210059,.721334,.968765,-.124661,.204935,.748613,.971753,-.122996,.198661,.776224,.973751,-.120998,.191823,.802461,.976709,-.118583,.184359,.828399,.977956,-.115102,.176437,.853693,.979672,-.111077,.167681,.877962,.981816,-.10688,.158872,.901564,.98238,-.101469,.149398,.924057,.983964,-.0960013,.139436,.945751,.984933,-.0899626,.12943,.966272,.985694,-.0832973,.11894,.985741,.986822,-.0767082,.108349,1.00407,.987725,-.0693614,.0976026,1.02154,.98877,-.06211,.086652,1.03757,.990129,-.0544143,.0756182,1.05296,.991337,-.046744,.0645753,1.06683,.992978,-.0387931,.0534683,1.0798,.994676,-.030973,.0424137,1.09181,.99645,-.0230311,.0314035,1.10286,.997967,-.0152065,.0206869,1.11291,.99922,-.00744837,.010155,1.12237,1.00002,240209e-9,-752767e-10,1.13089,.922948,-515351e-11,.255626,186069e-10,.928785,-129623e-9,.257244,468009e-9,.928761,-51849e-8,.257237,.00187202,.928751,-.0011666,.257235,.00421204,.928751,-.00207395,.257234,.0074881,.928754,-.00324055,.257235,.0117002,.92876,-.00466639,.257236,.0168486,.928763,-.00635149,.257237,.0229334,.928774,-.00829584,.257239,.029955,.928791,-.0104995,.257243,.0379139,.928804,-.0129623,.257245,.0468108,.928847,-.0156846,.257255,.0566473,.92889,-.0186661,.257263,.0674246,.928924,-.0219067,.257268,.0791433,.928989,-.0254066,.257282,.0918076,.92909,-.0291651,.257301,.105419,.92918,-.0331801,.257316,.119978,.92929,-.0374469,.257332,.135491,.929453,-.041939,.257357,.151948,.929586,-.0464612,.257347,.169275,.929858,-.0503426,.257269,.187257,.930125,-.0548409,.257199,.206204,.930403,-.0598063,.257149,.22601,.930726,-.0652437,.257122,.246561,.931098,-.0712376,.257153,.267618,.931396,-.0777506,.257237,.288993,.931947,-.0832374,.257124,.311527,.932579,-.0883955,.25683,.335697,.933194,-.0937037,.256444,.360634,.934013,-.0987292,.255939,.386126,.935307,-.103215,.255282,.412018,.936374,-.108234,.254538,.438292,.93776,-.113234,.253728,.464805,.939599,-.118013,.25275,.491464,.941036,-.122661,.251404,.518751,.94337,-.125477,.249435,.547133,.945318,-.128374,.247113,.575456,.947995,-.130996,.244441,.60372,.950818,-.133438,.241352,.63174,.954378,-.135004,.237849,.659971,.957151,-.135313,.233188,.688478,.960743,-.13521,.228001,.716767,.964352,-.135007,.222249,.744349,.967273,-.133523,.21542,.771786,.969767,-.131155,.208039,.798639,.973195,-.128492,.200076,.824774,.975557,-.125094,.191451,.850222,.977692,-.120578,.18184,.874761,.98026,-.115882,.172102,.898497,.981394,-.110372,.161859,.921636,.982386,-.10415,.15108,.943467,.983783,-.0978128,.140407,.964045,.98422,-.0906171,.129058,.98398,.985447,-.0832921,.117614,1.00276,.986682,-.0754412,.10585,1.02047,.987326,-.0673885,.0940943,1.03678,.988707,-.0592565,.0822093,1.05218,.990185,-.050717,.070192,1.06652,.991866,-.0423486,.0582081,1.07965,.993897,-.0336118,.0460985,1.09188,.995841,-.0252178,.0342737,1.10307,.997605,-.0164893,.0224829,1.11324,.999037,-.00817112,.0110647,1.12262,1.00003,291686e-9,-168673e-9,1.13139,.915304,-552675e-11,.275999,183285e-10,.91668,-139285e-9,.276414,461914e-9,.916664,-55713e-8,.276409,.00184763,.916653,-.00125354,.276406,.00415715,.916651,-.00222851,.276405,.00739053,.916655,-.00348205,.276406,.0115478,.916653,-.00501414,.276405,.0166291,.916667,-.00682478,.276409,.0226346,.91668,-.00891398,.276412,.0295648,.91669,-.0112817,.276413,.0374199,.916727,-.013928,.276422,.0462016,.916759,-.0168528,.276429,.0559101,.916793,-.0200558,.276436,.0665466,.916849,-.0235373,.276448,.0781139,.916964,-.0272973,.276474,.0906156,.917047,-.0313344,.276491,.104051,.917152,-.0356465,.276511,.118424,.917286,-.0402271,.276533,.133736,.917469,-.0450408,.276564,.149978,.917686,-.0497872,.276563,.167057,.917953,-.0540937,.276493,.184846,.918228,-.0590709,.276437,.203614,.918572,-.0644277,.276398,.223212,.918918,-.0702326,.276362,.243584,.919356,-.076484,.276383,.264465,.919842,-.0830808,.276434,.285701,.920451,-.0892972,.276407,.307559,.921113,-.095016,.276128,.331501,.921881,-.100771,.275754,.356207,.923027,-.106029,.275254,.381477,.924364,-.111029,.274595,.40722,.925818,-.116345,.273841,.433385,.92746,-.121424,.272913,.459848,.929167,-.12657,.271837,.486493,.931426,-.131581,.270575,.513432,.934001,-.135038,.268512,.541502,.936296,-.138039,.266135,.569658,.939985,-.140687,.263271,.598375,.943516,-.143247,.260058,.626563,.94782,-.145135,.256138,.654711,.951023,-.145733,.251154,.683285,.955338,-.145554,.245562,.711831,.959629,-.145008,.239265,.739573,.963123,-.144003,.232064,.767027,.966742,-.141289,.224036,.794359,.969991,-.138247,.215305,.820361,.973403,-.134786,.206051,.846548,.975317,-.129966,.195914,.871541,.977647,-.12471,.185184,.895313,.980137,-.119086,.174161,.918398,.981031,-.112297,.162792,.940679,.982037,-.105372,.150952,.961991,.983164,-.097821,.138921,.981913,.983757,-.0897245,.126611,1.00109,.985036,-.0815974,.114228,1.01902,.986289,-.0727725,.101389,1.03604,.987329,-.0639323,.0886476,1.05149,.989193,-.0548109,.0756837,1.06619,.990716,-.045687,.0627581,1.07948,.992769,-.0364315,.0498337,1.09172,.99524,-.0271761,.0370305,1.1033,.997154,-.0179609,.0243959,1.11353,.998845,-.00878063,.0119567,1.12319,1.00002,259038e-9,-108146e-9,1.13177,.903945,-591681e-11,.295126,181226e-10,.903668,-148672e-9,.295037,455367e-9,.903677,-594683e-9,.29504,.00182145,.903673,-.00133805,.295039,.00409831,.903666,-.00237872,.295036,.00728584,.903668,-.00371676,.295037,.0113842,.903679,-.00535212,.29504,.0163936,.903684,-.00728479,.295041,.0223141,.903698,-.00951473,.295044,.0291462,.903718,-.0120419,.295049,.0368904,.903754,-.0148664,.295058,.0455477,.903801,-.017988,.29507,.0551194,.903851,-.0214064,.295082,.0656058,.903921,-.0251219,.295097,.0770109,.904002,-.0291337,.295116,.0893354,.904111,-.033441,.29514,.102583,.904246,-.0380415,.295169,.116755,.904408,-.0429258,.295202,.131853,.904637,-.0480468,.295245,.147869,.904821,-.0529208,.295214,.164658,.905163,-.0577748,.295185,.182274,.905469,-.0631763,.295143,.200828,.905851,-.068917,.295112,.2202,.906322,-.0750861,.295104,.240372,.906761,-.0815855,.295086,.261082,.90735,-.0882138,.295095,.282123,.908087,-.095082,.295139,.303563,.908826,-.101488,.29492,.327028,.909832,-.107577,.294577,.351464,.911393,-.113033,.294115,.376497,.912804,-.118629,.293446,.402115,.914081,-.124232,.292581,.428111,.91637,-.129399,.29166,.454442,.91814,-.134892,.290422,.481024,.921179,-.140069,.289194,.507924,.924544,-.144431,.287421,.535557,.927995,-.147498,.284867,.563984,.931556,-.150197,.281722,.5923,.935777,-.152711,.278207,.620832,.940869,-.154836,.274148,.649069,.945994,-.155912,.269057,.677746,.949634,-.155641,.262799,.706293,.955032,-.154809,.256097,.734278,.95917,-.153678,.248618,.761751,.962931,-.151253,.239794,.789032,.966045,-.147625,.230281,.815422,.96971,-.143964,.220382,.841787,.972747,-.139464,.209846,.867446,.975545,-.133459,.198189,.892004,.978381,-.127424,.186362,.915458,.979935,-.120506,.173964,.937948,.980948,-.11282,.161429,.959732,.982234,-.104941,.148557,.980118,.982767,-.0962905,.135508,.999463,.983544,-.0873625,.122338,1.01756,.984965,-.0783447,.108669,1.03492,.986233,-.0684798,.0949911,1.05087,.987796,-.0590867,.0811386,1.0656,.989885,-.0489145,.0673099,1.0794,.991821,-.0391,.0535665,1.09174,.99448,-.029087,.0397529,1.10341,.996769,-.019114,.0261463,1.11383,.998641,-.00947007,.0128731,1.1237,.999978,446316e-9,-169093e-9,1.13253,.888362,-627064e-11,.312578,178215e-10,.889988,-157791e-9,.313148,448451e-9,.889825,-631076e-9,.313092,.00179356,.88984,-.00141994,.313097,.00403554,.889828,-.0025243,.313092,.00717429,.889831,-.00394421,.313093,.0112099,.889831,-.00567962,.313093,.0161425,.889844,-.00773051,.313096,.0219724,.889858,-.0100968,.3131,.0286999,.889882,-.0127786,.313106,.0363256,.889918,-.0157757,.313116,.0448509,.889967,-.0190878,.313129,.0542758,.89003,-.022715,.313145,.0646032,.890108,-.0266566,.313165,.0758339,.890218,-.0309131,.313193,.0879729,.890351,-.0354819,.313226,.101019,.89051,-.0403613,.313263,.114979,.890672,-.0455385,.313294,.129848,.890882,-.0509444,.313333,.145616,.891189,-.0559657,.313324,.162122,.891457,-.0613123,.313281,.179524,.891856,-.0671488,.313281,.197855,.892312,-.0732732,.313268,.216991,.892819,-.0797865,.313263,.236924,.893369,-.0865269,.313247,.257433,.894045,-.0931592,.313205,.278215,.894884,-.100532,.313276,.299467,.895832,-.107716,.313205,.322276,.897043,-.114099,.312873,.34642,.898515,-.119941,.312331,.371187,.900191,-.126044,.311731,.396656,.90188,-.131808,.310859,.422488,.904359,-.137289,.309857,.448744,.906923,-.142991,.308714,.475239,.910634,-.148253,.307465,.501983,.914502,-.153332,.305774,.529254,.919046,-.156646,.303156,.557709,.923194,-.159612,.299928,.586267,.928858,-.162027,.296245,.614925,.934464,-.164203,.291832,.643187,.939824,-.165602,.286565,.671601,.944582,-.165383,.280073,.700213,.949257,-.164439,.272891,.728432,.954389,-.162953,.264771,.756082,.958595,-.161007,.255927,.78369,.962138,-.157243,.245769,.810769,.966979,-.152872,.235127,.836999,.969566,-.148209,.22347,.862684,.972372,-.142211,.211147,.887847,.975916,-.135458,.198606,.911843,.978026,-.128398,.185498,.934795,.979686,-.120313,.17171,.956787,.980748,-.11166,.158159,.978046,.981622,-.103035,.144399,.997693,.982356,-.0930328,.13001,1.01642,.983308,-.0834627,.115778,1.03366,.985037,-.0732249,.101327,1.05014,.986493,-.0628145,.086554,1.06507,.988484,-.0526556,.0720413,1.07907,.991051,-.0415744,.0571151,1.09189,.993523,-.0314275,.0426643,1.10369,.99628,-.0203603,.0279325,1.11423,.998344,-.0102446,.0138182,1.12421,.999997,42612e-8,-193628e-9,1.1333,.871555,-660007e-11,.329176,174749e-10,.875255,-166579e-9,.330571,441051e-9,.875644,-666394e-9,.330718,.00176441,.875159,-.00149903,.330536,.00396899,.87516,-.00266493,.330536,.007056,.875158,-.00416393,.330535,.0110251,.87516,-.00599598,.330535,.0158764,.875163,-.00816108,.330536,.0216101,.875174,-.0106591,.330538,.0282266,.875199,-.0134899,.330545,.0357266,.875257,-.0166538,.330563,.0441117,.875304,-.0201501,.330575,.0533821,.875373,-.0239785,.330595,.0635395,.875464,-.0281389,.330619,.0745872,.875565,-.0326301,.330645,.0865255,.875691,-.0374516,.330676,.0993599,.875897,-.0425993,.330733,.113093,.876091,-.0480576,.330776,.127722,.876353,-.0537216,.330826,.143227,.876649,-.0589807,.330809,.159462,.877034,-.0647865,.330819,.176642,.877443,-.0709789,.330817,.194702,.877956,-.0774782,.330832,.213577,.878499,-.0843175,.330822,.233246,.879144,-.0912714,.330804,.253512,.879982,-.0980824,.330766,.274137,.88097,-.105823,.330864,.295209,.882051,-.113671,.330896,.317226,.883397,-.120303,.330545,.341068,.884987,-.12667,.330068,.365613,.886789,-.133118,.329418,.390807,.889311,-.139024,.328683,.416494,.891995,-.144971,.327729,.442618,.895106,-.150747,.326521,.469131,.899527,-.156283,.325229,.495921,.90504,-.161707,.32378,.523162,.909875,-.165661,.32122,.55092,.91561,-.168755,.317942,.579928,.921225,-.171193,.313983,.608539,.927308,-.17319,.309636,.636854,.933077,-.174819,.304262,.66523,.938766,-.175002,.297563,.693609,.943667,-.173946,.289613,.722157,.949033,-.172221,.281227,.750021,.953765,-.169869,.271545,.777466,.95804,-.166578,.261034,.804853,.962302,-.161761,.249434,.831569,.966544,-.156636,.237484,.857779,.969372,-.150784,.224395,.883051,.972486,-.143672,.210786,.907864,.975853,-.135772,.196556,.931223,.977975,-.127942,.182307,.954061,.979122,-.118347,.167607,.97531,.980719,-.109112,.152739,.995666,.981223,-.0991789,.137932,1.01475,.98216,-.0883553,.122692,1.03253,.983379,-.0780825,.107493,1.04917,.985434,-.0665646,.0917791,1.06464,.987332,-.0557714,.0764949,1.07896,.990004,-.0442805,.060721,1.09199,.992975,-.0331676,.0452284,1.10393,.995811,-.0219547,.0297934,1.11476,.9982,-.0107613,.0146415,1.12484,1.00002,248678e-9,-14555e-8,1.13413,.859519,-693595e-11,.347264,171673e-10,.859843,-17503e-8,.347394,433219e-9,.859656,-700076e-9,.347319,.00173277,.859671,-.00157517,.347325,.00389875,.859669,-.00280028,.347324,.00693112,.85967,-.0043754,.347324,.01083,.859665,-.00630049,.347321,.0155954,.859685,-.0085755,.347328,.0212278,.859694,-.0112003,.347329,.0277273,.859718,-.0141747,.347336,.0350946,.85976,-.0174988,.347348,.0433314,.85982,-.0211722,.347366,.0524384,.859892,-.0251941,.347387,.0624168,.860006,-.0295649,.347422,.0732708,.860122,-.0342825,.347453,.0849999,.860282,-.0393462,.347499,.0976102,.860482,-.0447513,.347554,.111104,.860719,-.0504775,.347614,.125479,.860998,-.0563577,.347666,.140703,.861322,-.0619473,.347662,.156681,.861724,-.0681277,.347684,.173597,.862198,-.0746567,.347709,.191371,.862733,-.0815234,.347727,.209976,.863371,-.0886643,.347744,.229351,.86414,-.0957908,.347734,.24934,.865138,-.102912,.34772,.269797,.866182,-.110924,.3478,.290654,.867436,-.119223,.347911,.312074,.869087,-.126197,.347649,.335438,.870859,-.133145,.347222,.359732,.872997,-.139869,.346645,.38467,.875939,-.146089,.345935,.41019,.879012,-.152334,.345012,.436218,.883353,-.15821,.343924,.462641,.888362,-.164097,.342636,.489449,.895026,-.169528,.341351,.516629,.900753,-.174408,.339115,.544109,.906814,-.17751,.335809,.572857,.912855,-.180101,.331597,.601554,.919438,-.182116,.32698,.630198,.925962,-.183494,.321449,.658404,.931734,-.184159,.314595,.686625,.93762,-.18304,.306462,.71531,.943858,-.181323,.297514,.744272,.948662,-.178683,.287447,.771462,.953299,-.175379,.276166,.798593,.957346,-.170395,.263758,.8256,.962565,-.165042,.251019,.852575,.966075,-.158655,.237011,.878316,.969048,-.151707,.222518,.90329,.972423,-.143271,.207848,.927745,.975833,-.134824,.192463,.950859,.977629,-.125444,.1768,.972947,.978995,-.114949,.161033,.993263,.980533,-.104936,.145523,1.01337,.980745,-.0935577,.129799,1.03128,.981814,-.0822956,.113486,1.04825,.983943,-.0710082,.0972925,1.06405,.986141,-.0587931,.0808138,1.0785,.988878,-.0472755,.0644915,1.09204,.992132,-.0349128,.0478128,1.10413,.9953,-.0232407,.031621,1.11527,.998117,-.0112713,.0154935,1.12551,1.00003,339743e-9,-195763e-9,1.13504,.845441,-729126e-11,.364305,169208e-10,.843588,-183164e-9,.363506,425067e-9,.843412,-73253e-8,.36343,.00169999,.843401,-.00164818,.363426,.00382495,.843399,-.00293008,.363425,.00679993,.843401,-.00457822,.363425,.010625,.843394,-.00659249,.363421,.0153002,.843398,-.00897282,.363421,.0208258,.843415,-.0117191,.363426,.0272024,.843438,-.0148312,.363432,.0344305,.843483,-.018309,.363447,.0425116,.84356,-.0221521,.363472,.0514471,.843646,-.0263597,.363499,.061238,.843743,-.0309315,.363527,.0718873,.84388,-.0358658,.363569,.0833969,.844079,-.0411624,.363631,.0957742,.844279,-.0468128,.363688,.109015,.844549,-.0527923,.363761,.123124,.844858,-.0588204,.363817,.138044,.84522,-.0647573,.36383,.153755,.845669,-.0713181,.363879,.170394,.846155,-.0781697,.363908,.187861,.846789,-.0853913,.363969,.206176,.847502,-.0928086,.363999,.225244,.8484,-.10005,.363997,.244926,.849461,-.107615,.364008,.265188,.850562,-.115814,.364055,.28587,.851962,-.124334,.364179,.306926,.854326,-.131995,.364233,.329605,.856295,-.139338,.363856,.35359,.858857,-.146346,.363347,.37831,.862428,-.152994,.362807,.403722,.866203,-.159463,.361963,.429537,.871629,-.165623,.36112,.456,.877365,-.171649,.359917,.482773,.883744,-.177151,.35848,.509705,.890693,-.182381,.356523,.537215,.897278,-.186076,.3533,.565493,.903958,-.188602,.349095,.594293,.910908,-.190755,.344215,.623165,.918117,-.192063,.338606,.651573,.924644,-.192758,.331544,.679869,.931054,-.192238,.323163,.708668,.937303,-.190035,.313529,.737201,.943387,-.187162,.303152,.764977,.948494,-.183876,.29146,.792683,.952546,-.178901,.277917,.819228,.958077,-.173173,.264753,.846559,.962462,-.16645,.25002,.872962,.966569,-.159452,.234873,.898729,.969108,-.15074,.218752,.923126,.973072,-.141523,.202673,.947278,.975452,-.132075,.186326,.969938,.977784,-.121257,.169396,.991325,.97899,-.110182,.153044,1.01123,.979777,-.0989634,.136485,1.0299,.980865,-.0865894,.119343,1.04727,.982432,-.0746115,.102452,1.06341,.984935,-.0621822,.0852423,1.07834,.987776,-.0495694,.0678546,1.092,.99103,-.0372386,.0506917,1.1043,.99474,-.0244353,.0333316,1.11576,.997768,-.0121448,.0164348,1.12617,1.00003,31774e-8,-169504e-9,1.13598,.825551,-756799e-11,.378425,165099e-10,.82664,-190922e-9,.378923,416504e-9,.826323,-763495e-9,.378779,.0016656,.826359,-.00171789,.378795,.00374768,.82636,-.00305402,.378795,.00666259,.826368,-.00477185,.378798,.0104104,.826364,-.00687131,.378795,.0149912,.826368,-.00935232,.378795,.0204054,.826376,-.0122146,.378797,.0266532,.826399,-.0154581,.378803,.0337355,.82646,-.0190825,.378824,.0416537,.826525,-.0230873,.378846,.0504091,.826614,-.0274719,.378876,.0600032,.82674,-.0322355,.378917,.0704393,.826888,-.0373766,.378964,.0817195,.827078,-.0428936,.379024,.0938492,.827318,-.0487778,.379099,.106828,.82764,-.0549935,.379199,.120659,.827926,-.0611058,.379227,.13526,.828325,-.0675054,.379275,.150713,.828801,-.0743455,.379332,.167034,.8294,-.0815523,.379415,.184209,.830094,-.0890779,.379495,.202203,.8309,-.096736,.379555,.220945,.831943,-.104135,.379577,.240306,.833037,-.112106,.379604,.260317,.834278,-.120554,.379668,.2808,.836192,-.129128,.3799,.301654,.838671,-.137541,.380109,.323502,.840939,-.14523,.379809,.347176,.844575,-.15248,.379593,.371706,.848379,-.159607,.37909,.39688,.853616,-.166267,.378617,.422702,.858921,-.172698,.377746,.448919,.865324,-.178823,.376749,.475661,.872207,-.184542,.375363,.502599,.880018,-.189836,.373657,.529914,.88694,-.194294,.370673,.557683,.894779,-.197022,.36662,.586848,.902242,-.199108,.36138,.615831,.909914,-.200398,.355434,.644478,.917088,-.20094,.348173,.672905,.923888,-.200671,.339482,.701327,.930495,-.198773,.32956,.730101,.937247,-.195394,.318363,.758383,.943108,-.191956,.306323,.786539,.948296,-.187227,.292576,.813637,.953472,-.181165,.278234,.840793,.958485,-.174119,.263054,.867712,.962714,-.166564,.246756,.893635,.966185,-.158181,.229945,.919028,.970146,-.148275,.212633,.943413,.973491,-.138157,.195229,.966627,.975741,-.127574,.178048,.988817,.977238,-.11554,.160312,1.00924,.978411,-.10364,.142857,1.02845,.979811,-.0913122,.125317,1.04648,.98116,-.0782558,.107627,1.06284,.983543,-.0655957,.0895862,1.07798,.986789,-.0520411,.0713756,1.092,.990292,-.0389727,.053228,1.10484,.994187,-.025808,.0351945,1.11642,.997499,-.0126071,.0173198,1.12703,.999999,275604e-9,-148602e-9,1.13674,.81075,-78735e-10,.394456,161829e-10,.808692,-198293e-9,.393453,407564e-9,.80846,-792877e-9,.39334,.00162965,.808595,-.00178416,.393407,.00366711,.808597,-.00317182,.393408,.00651934,.808598,-.00495589,.393408,.0101866,.808591,-.00713627,.393403,.0146689,.808592,-.00971285,.393402,.0199667,.80861,-.0126855,.393407,.0260803,.808633,-.0160538,.393413,.0330107,.80868,-.0198175,.393429,.0407589,.808748,-.0239758,.393453,.0493264,.808854,-.0285286,.39349,.0587161,.808992,-.0334748,.39354,.0689304,.809141,-.0388116,.393588,.0799707,.809352,-.0445375,.39366,.0918432,.809608,-.0506427,.393742,.104549,.809915,-.0570708,.393834,.118085,.810253,-.0633526,.393885,.132377,.810687,-.0700966,.393953,.147537,.811233,-.0772274,.394047,.163543,.811865,-.0847629,.394148,.180394,.812648,-.0925663,.394265,.198051,.813583,-.100416,.394363,.216443,.814683,-.108119,.394402,.235502,.815948,-.11644,.394489,.255242,.817278,-.125036,.394542,.275441,.819605,-.133655,.39486,.296094,.822256,-.142682,.395248,.317309,.825349,-.150756,.395241,.340516,.829605,-.158392,.395285,.364819,.83391,-.165801,.394922,.389736,.839808,-.172677,.394691,.415409,.845708,-.179448,.394006,.441546,.853025,-.185746,.393279,.46832,.859666,-.191684,.391655,.495302,.86789,-.197146,.390068,.52262,.875845,-.201904,.38727,.550336,.882634,-.205023,.382688,.578825,.891076,-.207098,.377543,.608103,.900589,-.208474,.371752,.63723,.90791,-.209068,.364016,.665769,.915971,-.208655,.355593,.694428,.923455,-.20729,.345439,.723224,.931514,-.203821,.334099,.751925,.937885,-.19986,.321069,.780249,.943136,-.194993,.306571,.8077,.948818,-.189132,.291556,.83497,.954433,-.181617,.275745,.86188,.959078,-.173595,.258695,.888562,.962705,-.164855,.240825,.914008,.966753,-.155129,.22268,.939145,.970704,-.144241,.204542,.963393,.973367,-.133188,.185927,.985983,.975984,-.121146,.167743,1.00704,.976994,-.108366,.149218,1.02715,.978485,-.0956746,.13131,1.0455,.980074,-.0820733,.112513,1.06221,.98225,-.0684061,.0938323,1.07782,.98553,-.0549503,.0749508,1.09199,.989529,-.0407857,.055848,1.10508,.993536,-.0271978,.0368581,1.11684,.997247,-.0132716,.0181845,1.12789,1,431817e-9,-198809e-9,1.13792,.785886,-812608e-11,.405036,157669e-10,.790388,-205278e-9,.407355,398297e-9,.790145,-820824e-9,.407231,.00159263,.790135,-.00184681,.407226,.00358336,.790119,-.00328316,.407218,.00637039,.790126,-.00512988,.40722,.0099539,.79013,-.00738684,.407221,.0143339,.790135,-.0100538,.407221,.0195107,.790134,-.0131306,.407217,.0254848,.79016,-.0166169,.407224,.0322572,.790197,-.020512,.407236,.0398284,.790273,-.0248157,.407263,.0482014,.790381,-.029527,.407304,.0573777,.790521,-.0346446,.407355,.0673602,.790704,-.0401665,.40742,.0781522,.790925,-.0460896,.407499,.0897582,.791195,-.0524017,.407589,.10218,.791522,-.0590121,.407691,.11541,.791878,-.0654876,.407748,.12939,.792361,-.0725207,.407849,.144237,.792942,-.0799844,.407963,.159924,.79362,-.0877896,.408087,.176425,.794529,-.0958451,.408259,.193733,.795521,-.103827,.408362,.211756,.796778,-.111937,.408482,.230524,.798027,-.120521,.408547,.249967,.799813,-.129242,.408721,.269926,.802387,-.138048,.409148,.290338,.805279,-.147301,.409641,.311193,.809251,-.155895,.410154,.333611,.813733,-.163942,.410297,.357615,.819081,-.171666,.410373,.382339,.825427,-.178905,.410348,.407828,.83172,-.185812,.409486,.434034,.83877,-.192318,.408776,.460493,.845817,-.198249,.407176,.487346,.854664,-.204034,.405719,.514832,.863495,-.208908,.403282,.542401,.871883,-.212765,.399293,.570683,.88065,-.214911,.393803,.599947,.89004,-.216214,.387536,.62932,.898476,-.216745,.379846,.658319,.906738,-.216387,.370625,.687138,.914844,-.215053,.360139,.71601,.923877,-.212007,.348849,.745124,.931925,-.207481,.335639,.773366,.938054,-.202418,.320798,.801636,.943895,-.196507,.304772,.829055,.949468,-.189009,.288033,.856097,.955152,-.180539,.270532,.88301,.959403,-.171437,.251639,.909296,.963309,-.161661,.232563,.934868,.967399,-.150425,.213231,.959662,.972009,-.138659,.194247,.98302,.97433,-.126595,.174718,1.00517,.975823,-.113205,.155518,1.02566,.976371,-.0996096,.136709,1.04418,.978705,-.0860754,.117571,1.06146,.981477,-.0714438,.0980046,1.07777,.984263,-.0572304,.0782181,1.09214,.988423,-.0428875,.0584052,1.10553,.993,-.0282442,.038522,1.11758,.99704,-.0140183,.0190148,1.12864,.999913,369494e-9,-145203e-9,1.13901,.777662,-84153e-10,.423844,154403e-10,.770458,-211714e-9,.419915,38845e-8,.770716,-846888e-9,.420055,.00155386,.770982,-.00190567,.420202,.00349653,.770981,-.00338782,.420201,.00621606,.77098,-.00529338,.4202,.00971274,.770983,-.00762223,.4202,.0139867,.770985,-.0103741,.420198,.0190381,.770996,-.0135489,.4202,.0248677,.771029,-.0171461,.420212,.0314764,.771052,-.0211647,.420215,.0388648,.771131,-.0256048,.420245,.047036,.771235,-.0304647,.420284,.0559911,.771383,-.0357436,.420341,.0657346,.771591,-.0414392,.420423,.0762694,.771819,-.0475462,.420506,.0875984,.772123,-.0540506,.420617,.099727,.772464,-.060797,.42072,.112637,.772855,-.0675393,.420799,.126313,.773317,-.0748323,.420893,.140824,.773981,-.0825681,.421058,.15617,.774746,-.0906307,.421226,.172322,.77566,-.0988982,.421397,.189253,.776837,-.106994,.421569,.206912,.778097,-.115528,.421704,.225359,.779588,-.124317,.421849,.24447,.781574,-.133139,.422097,.264156,.784451,-.142179,.422615,.284318,.787682,-.15165,.423269,.304902,.792433,-.160771,.424396,.3265,.797359,-.169166,.424772,.35014,.803986,-.177149,.425475,.374768,.809504,-.184745,.424996,.399928,.815885,-.19173,.424247,.425796,.823513,-.198525,.423515,.452287,.832549,-.204709,.422787,.479321,.841653,-.210447,.421187,.506718,.850401,-.215501,.418519,.53432,.859854,-.219752,.414715,.56242,.869364,-.222305,.409462,.591558,.878837,-.223744,.402926,.621074,.888636,-.224065,.395043,.650538,.898132,-.223742,.38564,.679538,.907181,-.222308,.375378,.708674,.915621,-.219837,.363212,.737714,.9239,-.215233,.349313,.767014,.931644,-.209592,.334162,.795133,.938887,-.203644,.317943,.823228,.945282,-.196349,.300581,.850822,.950758,-.18742,.282195,.877594,.956146,-.177879,.262481,.904564,.960355,-.167643,.242487,.930741,.965256,-.156671,.222668,.955868,.968029,-.144123,.201907,.979869,.97251,-.131305,.18202,1.00291,.974925,-.118335,.161909,1.02392,.975402,-.103714,.142129,1.0433,.976987,-.089415,.122447,1.06089,.979677,-.0748858,.102248,1.07713,.983184,-.0596086,.0814851,1.09218,.987466,-.0447671,.0609484,1.10585,.992348,-.0295217,.0401835,1.11829,.996674,-.0143917,.0198163,1.12966,1.00003,321364e-9,-149983e-9,1.1402,.757901,-869074e-11,.436176,151011e-10,.751195,-217848e-9,.432317,378533e-9,.751178,-871373e-9,.432307,.0015141,.751195,-.00196061,.432317,.0034068,.751198,-.00348552,.432318,.00605659,.751195,-.00544599,.432315,.00946353,.751207,-.00784203,.43232,.013628,.751213,-.0106732,.43232,.0185499,.751221,-.0139393,.432319,.0242302,.751244,-.0176398,.432325,.0306694,.7513,-.0217743,.432348,.0378698,.751358,-.0263412,.432367,.0458321,.751458,-.0313396,.432404,.0545587,.751608,-.0367682,.432464,.0640543,.7518,-.0426246,.43254,.0743222,.752065,-.0489031,.432645,.0853668,.752376,-.0555828,.432762,.0971911,.752715,-.0623861,.432859,.109768,.753137,-.069415,.432958,.123126,.753676,-.0770039,.433099,.137308,.754345,-.084971,.433272,.15229,.755235,-.0932681,.433504,.168075,.756186,-.10171,.433693,.184625,.757363,-.110019,.433857,.201897,.75884,-.11887,.434102,.220014,.760467,-.127881,.434306,.238778,.762969,-.136766,.434751,.258172,.765823,-.14612,.43529,.278062,.769676,-.15566,.436236,.298437,.774909,-.165177,.437754,.319532,.77994,-.17402,.438343,.342505,.785757,-.182201,.438609,.366693,.792487,-.190104,.438762,.391668,.80038,-.197438,.438795,.417494,.808494,-.204365,.438226,.443933,.817695,-.210714,.437283,.470929,.828111,-.216651,.436087,.498569,.837901,-.221804,.433717,.526165,.847813,-.226318,.430133,.554155,.858314,-.229297,.425213,.582822,.868891,-.230999,.418576,.612847,.878941,-.231155,.410405,.642445,.888809,-.230935,.400544,.672024,.898089,-.229343,.389613,.701366,.908081,-.226886,.377197,.730763,.916819,-.222676,.363397,.759642,.924968,-.216835,.347437,.788775,.932906,-.210245,.32995,.817135,.940025,-.202992,.312262,.844912,.946101,-.19436,.293313,.872164,.952835,-.184125,.273638,.899443,.957347,-.173657,.252385,.926389,.961434,-.162204,.231038,.951947,.965522,-.14979,.209834,.976751,.969412,-.136307,.188821,1.00022,.973902,-.122527,.168013,1.02229,.974045,-.108213,.147634,1.04199,.975775,-.0927397,.12705,1.06019,.978383,-.0778212,.106309,1.07711,.98211,-.0621216,.0849279,1.09245,.986517,-.0463847,.0633519,1.10651,.991696,-.0309353,.0419698,1.11903,.996349,-.0150914,.0206272,1.13073,1.00003,442449e-9,-231396e-9,1.14146,.727498,-885074e-11,.441528,145832e-10,.730897,-223525e-9,.443589,368298e-9,.730796,-893996e-9,.443528,.00147303,.730805,-.00201149,.443533,.00331433,.730814,-.00357596,.443538,.00589222,.730815,-.00558734,.443538,.00920678,.730822,-.00804544,.44354,.0132582,.730836,-.0109501,.443545,.0180468,.730848,-.0143008,.443546,.0235732,.730871,-.0180969,.443552,.0298382,.730915,-.022338,.443567,.0368438,.730982,-.0270225,.443591,.044591,.731076,-.0321491,.443627,.0530831,.731245,-.0377166,.443699,.0623243,.73144,-.0437216,.443777,.0723181,.7317,-.0501576,.443881,.0830691,.732034,-.0569942,.444014,.0945809,.732388,-.0638756,.444113,.106825,.732853,-.071203,.444247,.119859,.733473,-.0790076,.444442,.13369,.734195,-.0871937,.444645,.148304,.735069,-.095696,.444877,.163702,.736169,-.10426,.445133,.179861,.73747,-.112853,.44537,.196778,.738991,-.12199,.445651,.214496,.740865,-.131153,.445958,.232913,.743637,-.140245,.446548,.251977,.746797,-.149722,.447246,.271551,.751517,-.159341,.448656,.291774,.756156,-.169106,.449866,.312455,.761519,-.178436,.450919,.334552,.768295,-.186904,.451776,.358491,.776613,-.195117,.452832,.383446,.783966,-.202695,.45249,.408945,.793542,-.20985,.452587,.435364,.803192,-.216403,.451852,.462336,.813892,-.22251,.450708,.48987,.824968,-.227676,.4486,.517697,.835859,-.232443,.445156,.545975,.846825,-.235775,.440351,.574483,.858085,-.237897,.433641,.604246,.868825,-.238074,.425354,.634101,.879638,-.237661,.415383,.664201,.889966,-.236186,.404136,.693918,.899479,-.233599,.390917,.723481,.908769,-.229737,.376352,.75258,.917966,-.223836,.360372,.781764,.926304,-.217067,.342551,.811139,.934626,-.209309,.324238,.839585,.941841,-.20071,.304484,.867044,.94789,-.190602,.283607,.894579,.954196,-.179253,.262205,.921743,.958383,-.167646,.239847,.948026,.963119,-.155073,.218078,.973296,.966941,-.141426,.195899,.998135,.970836,-.126849,.174121,1.02021,.973301,-.112296,.153052,1.04085,.97448,-.0964965,.131733,1.05946,.977045,-.080489,.10997,1.07693,.980751,-.064844,.0881657,1.09254,.985475,-.0481938,.0657987,1.10697,.991089,-.0319185,.0435215,1.12004,.996122,-.0158088,.0214779,1.13173,1.00001,372455e-9,-200295e-9,1.14291,.708622,-907597e-11,.45304,141962e-10,.711162,-228911e-9,.454662,358052e-9,.709812,-914446e-9,.453797,.00143034,.709865,-.00205819,.453834,.00321935,.709864,-.00365894,.453833,.00572331,.709855,-.00571692,.453826,.00894278,.709862,-.00823201,.453828,.012878,.709875,-.011204,.453832,.0175295,.709896,-.0146323,.453839,.0228978,.709925,-.0185163,.453847,.0289839,.709974,-.0228551,.453866,.0357894,.710045,-.0276473,.453892,.0433161,.710133,-.032891,.453924,.0515665,.710292,-.0385851,.453992,.0605458,.710485,-.0447254,.45407,.0702574,.710769,-.0513051,.454192,.0807077,.711106,-.0582733,.454329,.091896,.711516,-.0652866,.45446,.103814,.712071,-.0728426,.454653,.116508,.712676,-.0808307,.45484,.129968,.713476,-.0892216,.455096,.144206,.714377,-.0979047,.455346,.159212,.715579,-.106531,.455647,.174973,.716977,-.115492,.455961,.191504,.71862,-.124821,.456315,.208835,.72084,-.134079,.4568,.226869,.723786,-.143427,.457521,.245582,.727464,-.153061,.458475,.264957,.732771,-.162768,.460239,.284948,.736515,-.172627,.460899,.30522,.743519,-.182487,.463225,.326717,.750041,-.191295,.464027,.350113,.758589,-.199746,.465227,.374782,.767703,-.207584,.465877,.400226,.777484,-.214973,.465996,.426442,.788792,-.221796,.466019,.453688,.800194,-.228038,.465083,.481246,.811234,-.233346,.462506,.509086,.822859,-.238073,.459257,.537338,.835082,-.241764,.454863,.566108,.846332,-.244241,.448163,.595126,.858355,-.244736,.439709,.625574,.87034,-.244278,.429837,.65617,.881027,-.24255,.418002,.686029,.891007,-.239912,.404325,.716039,.900874,-.236133,.389222,.745518,.911072,-.230672,.373269,.775026,.920359,-.22356,.355083,.804521,.928604,-.215591,.335533,.834045,.937175,-.206503,.315278,.861612,.942825,-.196684,.293653,.889131,.949805,-.185116,.271503,.916853,.955535,-.172703,.248821,.943541,.959843,-.159978,.225591,.970132,.964393,-.146375,.202719,.994709,.968008,-.131269,.179928,1.0186,.971013,-.11569,.158007,1.03928,.973334,-.1003,.13624,1.05887,.975775,-.0833352,.1138,1.07652,.979579,-.0668981,.0913141,1.09297,.984323,-.0500902,.0683051,1.10734,.990351,-.0332377,.0451771,1.12084,.995823,-.0161491,.0221705,1.13296,1.0001,234083e-9,-108712e-9,1.14441,.683895,-924677e-11,.46015,137429e-10,.68833,-233383e-9,.463134,346865e-9,.688368,-933547e-9,.463159,.00138748,.688367,-.00210049,.463159,.00312187,.688369,-.00373415,.463159,.00555004,.688377,-.00583449,.463163,.00867216,.688386,-.00840128,.463166,.0124884,.688398,-.0114343,.463169,.0169993,.688418,-.0149329,.463175,.0222054,.688453,-.0188964,.463188,.028108,.688515,-.0233239,.463214,.0347085,.68857,-.0282136,.463231,.0420091,.688679,-.033564,.463276,.0500132,.688854,-.0393733,.463356,.0587255,.689038,-.0456354,.46343,.0681476,.689321,-.0523433,.463553,.0782897,.689662,-.059412,.463693,.0891501,.690188,-.0665736,.4639,.100735,.690755,-.0743106,.464107,.113074,.691405,-.0824722,.464329,.126161,.692198,-.0910484,.464585,.140007,.693196,-.0998778,.464893,.154612,.69454,-.108651,.465285,.169984,.695921,-.117855,.465596,.186106,.697749,-.12734,.466056,.203034,.700375,-.136714,.466771,.220703,.703395,-.146386,.467579,.239062,.707904,-.156096,.469067,.258188,.711673,-.165904,.469851,.277759,.717489,-.175812,.471815,.297935,.724051,-.185931,.47389,.318916,.731965,-.195238,.47587,.341591,.741151,-.204021,.477523,.366062,.751416,-.212113,.478881,.391396,.761848,-.21979,.479226,.417599,.771886,-.2267,.478495,.444401,.783998,-.232991,.477622,.472084,.796523,-.238645,.475833,.500193,.808851,-.243396,.472568,.52865,.821191,-.247226,.467857,.557362,.834261,-.250102,.461871,.586768,.846762,-.251056,.453543,.617085,.859867,-.250604,.443494,.647659,.871948,-.248783,.431711,.678119,.882967,-.245855,.417911,.708399,.892826,-.242168,.401993,.738256,.90332,-.237062,.385371,.767999,.913633,-.22997,.366837,.798191,.922774,-.221687,.346372,.827756,.931371,-.212345,.325682,.856425,.938929,-.20206,.303665,.884299,.944821,-.190981,.280786,.912023,.951792,-.178065,.2573,.939669,.957712,-.164634,.233448,.96655,.961912,-.150863,.209504,.992366,.966382,-.13577,.18597,1.01633,.969588,-.119593,.162905,1.03843,.971777,-.103203,.14053,1.05841,.97433,-.0865888,.117909,1.07632,.978686,-.0690829,.0944101,1.09326,.983281,-.0516568,.0705671,1.10796,.989562,-.034558,.0468592,1.12182,.995465,-.0167808,.0229846,1.1342,.999991,373016e-9,-235606e-9,1.1459,.662251,-939016e-11,.468575,132714e-10,.666634,-237624e-9,.471675,335842e-9,.666411,-950385e-9,.471516,.00134321,.666399,-.00213833,.471509,.00302221,.666386,-.0038014,.471499,.00537283,.666405,-.00593958,.471511,.00839533,.666406,-.00855253,.471508,.0120898,.666428,-.0116401,.471519,.0164569,.666444,-.0152015,.471522,.0214971,.66649,-.0192362,.471543,.027212,.666537,-.0237428,.471558,.033603,.666617,-.0287198,.471591,.0406728,.666718,-.0341647,.471631,.0484238,.666889,-.0400759,.47171,.0568621,.667104,-.0464479,.471805,.0659915,.667374,-.0532677,.471923,.0758178,.667772,-.0603805,.472098,.0863425,.668371,-.0677392,.472363,.0975917,.668971,-.0756028,.472596,.109567,.669696,-.0839293,.472869,.122272,.670481,-.0926683,.473126,.135718,.6715,-.1016,.473442,.149914,.672911,-.110566,.47389,.164882,.674512,-.119984,.474354,.180602,.67651,-.129574,.474922,.19711,.679292,-.139106,.475764,.214371,.682798,-.148993,.476886,.232405,.686955,-.158737,.478179,.251153,.691406,-.168754,.479432,.270436,.697438,-.178703,.481481,.290374,.704761,-.188955,.484143,.311044,.713599,-.198814,.487007,.333003,.723194,-.207869,.488962,.357144,.732601,-.216189,.489815,.382169,.744193,-.22398,.490888,.408227,.754907,-.231156,.490355,.434928,.767403,-.23747,.489548,.462599,.78107,-.243503,.488274,.490908,.793893,-.248114,.484843,.519421,.807296,-.25222,.4803,.548561,.820529,-.255265,.474097,.577772,.833716,-.256741,.466041,.607782,.848403,-.25637,.456547,.638807,.860755,-.254804,.443946,.670058,.874012,-.251834,.430852,.700749,.885619,-.247867,.414903,.731446,.896069,-.242634,.397276,.761191,.906266,-.236093,.378535,.791053,.916759,-.227543,.358038,.821298,.92523,-.21783,.335705,.850747,.93436,-.207534,.313797,.879258,.941631,-.195983,.289671,.907734,.947564,-.183567,.265319,.935206,.953681,-.169345,.240815,.962739,.960008,-.154909,.216119,.989227,.964145,-.140161,.192096,1.01465,.968171,-.123411,.167855,1.03737,.969859,-.106525,.144817,1.05767,.972666,-.0891023,.12149,1.0761,.977055,-.0718094,.0975306,1.09336,.982527,-.0534213,.0730217,1.10878,.989001,-.0355579,.0483366,1.12285,.99512,-.0176383,.023938,1.13548,1.00007,368831e-9,-211581e-9,1.14744,.651047,-960845e-11,.484101,12922e-9,.644145,-241347e-9,.478968,324578e-9,.64396,-965142e-9,.478831,.00129798,.64396,-.00217154,.47883,.00292046,.643968,-.00386049,.478835,.00519202,.643974,-.00603186,.478838,.0081128,.643977,-.0086854,.478836,.011683,.643982,-.0118207,.478834,.0159031,.644024,-.0154374,.478856,.0207743,.644059,-.0195343,.478868,.0262975,.644122,-.0241103,.478896,.0324747,.644207,-.0291638,.478933,.039309,.64432,-.0346919,.478981,.0468029,.644481,-.0406919,.479053,.0549614,.644722,-.047159,.479169,.0637909,.645013,-.0540748,.479302,.0732974,.645503,-.0612001,.479541,.0834898,.646117,-.0687303,.479829,.0943873,.646707,-.0767846,.480061,.105991,.647431,-.0852465,.480343,.11831,.64831,-.0940719,.48066,.131348,.649486,-.103056,.481083,.14514,.650864,-.112261,.481528,.159676,.652604,-.121852,.482102,.174979,.654825,-.131505,.482813,.191079,.657876,-.141189,.483876,.207927,.661339,-.151239,.48499,.225586,.665463,-.161091,.486279,.243947,.670542,-.171235,.487968,.262957,.677361,-.181347,.49053,.282781,.685672,-.191679,.493862,.303311,.694551,-.201781,.49699,.324607,.703753,-.211164,.498884,.347916,.713703,-.219675,.500086,.372628,.725911,-.227836,.501554,.398694,.73862,-.23533,.502193,.425529,.752118,-.241786,.501811,.453209,.76579,-.247865,.500185,.481381,.779568,-.252696,.497159,.51011,.793991,-.256802,.492765,.539322,.808182,-.259942,.486827,.569078,.821698,-.261703,.478386,.598818,.836009,-.262006,.468772,.629762,.849824,-.260333,.456352,.661366,.863888,-.257398,.442533,.69295,.876585,-.253264,.426573,.723608,.888665,-.248026,.408964,.754378,.899537,-.241487,.389677,.784761,.9094,-.233463,.368516,.814688,.920166,-.223397,.346624,.845009,.928899,-.21255,.322717,.874431,.937156,-.200869,.298698,.902922,.943861,-.188387,.273491,.931356,.949557,-.174341,.247866,.958854,.955862,-.158994,.222496,.986098,.961721,-.143664,.197522,1.01229,.965976,-.127412,.17302,1.03571,.968652,-.109798,.148954,1.05699,.971084,-.0916787,.125044,1.07587,.975584,-.0739634,.100577,1.09372,.98122,-.055322,.0753666,1.10948,.988253,-.0366825,.0498899,1.12394,.99482,-.0180389,.024611,1.13694,1.00001,229839e-9,-188283e-9,1.14919,.613867,-964198e-11,.479449,123452e-10,.621485,-244534e-9,.485399,313091e-9,.621429,-978202e-9,.485353,.00125245,.62112,-.00220004,.485114,.00281687,.621119,-.0039111,.485112,.00500783,.621122,-.00611091,.485112,.00782498,.621133,-.00879922,.485117,.0112687,.621152,-.0119756,.485125,.0153394,.621183,-.0156396,.485139,.0200382,.621227,-.0197898,.485158,.0253663,.621298,-.0244253,.485192,.0313261,.621388,-.0295441,.485233,.0379204,.621507,-.0351432,.485286,.0451523,.621693,-.0412198,.485378,.0530277,.621933,-.0477673,.485495,.0615522,.622232,-.0547574,.485635,.0707316,.622809,-.0619417,.485943,.0805883,.623407,-.069625,.486232,.0911267,.62406,-.077796,.486516,.102354,.624835,-.0863731,.486838,.114279,.625758,-.095251,.487188,.126902,.627043,-.104299,.487695,.140285,.628438,-.113724,.488163,.154397,.630325,-.123417,.488858,.169267,.632801,-.133137,.489754,.184941,.635784,-.143052,.490815,.20136,.639406,-.153132,.492048,.218643,.643872,-.163143,.49363,.236615,.6499,-.17333,.496009,.255449,.657201,-.183622,.498994,.275006,.666221,-.194019,.502888,.295354,.674419,-.204192,.505459,.316244,.683729,-.21406,.507771,.33849,.695584,-.222854,.510245,.363166,.708583,-.231315,.512293,.389071,.721233,-.238911,.512747,.415737,.735134,-.245657,.512482,.443331,.750179,-.251879,.511526,.471891,.765073,-.256911,.508935,.500892,.779794,-.261144,.504341,.530294,.794801,-.264316,.498515,.560144,.810339,-.266276,.491015,.590213,.824818,-.266981,.481126,.620865,.839375,-.265778,.468685,.652687,.853043,-.262748,.453925,.684759,.867335,-.258474,.437912,.716209,.88037,-.253187,.419648,.747508,.891711,-.246476,.39982,.77797,.902896,-.238735,.37879,.808586,.913601,-.22885,.355891,.838843,.923019,-.217656,.331773,.869014,.933432,-.205539,.307356,.898512,.939691,-.192595,.281321,.9269,.946938,-.178945,.255441,.955297,.952372,-.163587,.229013,.983231,.95909,-.147214,.203179,1.00971,.963675,-.13064,.17792,1.03438,.968247,-.113121,.152898,1.05625,.97001,-.0945824,.128712,1.07598,.974458,-.0755648,.103349,1.094,.980168,-.0571998,.0776731,1.1104,.987295,-.0377994,.0514445,1.12491,.994432,-.0186417,.025429,1.13851,.999975,542714e-9,-282356e-9,1.15108,.592656,-980249e-11,.486018,119532e-10,.598467,-247275e-9,.490781,301531e-9,.597934,-988317e-9,.490343,.00120517,.597903,-.00222366,.490319,.0027116,.597913,-.00395315,.490327,.00482077,.597919,-.00617653,.490329,.00753264,.597936,-.00889375,.490339,.0108478,.597956,-.0121043,.490347,.0147668,.597992,-.0158073,.490365,.0192905,.598032,-.0200017,.490382,.0244204,.598109,-.0246865,.49042,.0301593,.598215,-.0298594,.490474,.03651,.59833,-.0355167,.490524,.0434757,.598525,-.0416559,.490624,.0510629,.598778,-.0482692,.490753,.0592781,.599135,-.0553114,.49094,.0681304,.599802,-.062542,.491328,.0776467,.600361,-.0703638,.491598,.0878184,.60101,-.0786256,.491882,.0986573,.601811,-.0872962,.492232,.11018,.602861,-.0962284,.492684,.1224,.604167,-.10538,.493213,.135354,.605693,-.114896,.493799,.149034,.607682,-.124654,.494576,.163469,.610672,-.13456,.4959,.178747,.613313,-.144581,.496713,.194723,.617603,-.154703,.498499,.211617,.622174,-.16489,.500188,.229183,.628855,-.175164,.503072,.247786,.636963,-.185565,.506798,.267116,.644866,-.195911,.509719,.28702,.653741,-.206104,.512776,.307763,.664942,-.216447,.516812,.329631,.67633,-.22552,.519181,.353515,.690012,-.234316,.521681,.379226,.704243,-.242032,.523129,.405901,.719396,-.249172,.523768,.433585,.734471,-.255543,.522541,.462085,.750539,-.260697,.520217,.491233,.766365,-.26501,.516293,.521094,.781677,-.268409,.509708,.551014,.797132,-.270399,.501944,.581463,.812655,-.271247,.492025,.612402,.828592,-.270708,.480424,.643798,.844044,-.268085,.465955,.67682,.857305,-.263459,.448425,.708496,.87114,-.258151,.430243,.74046,.884936,-.251171,.410578,.771583,.895772,-.243305,.38862,.802234,.906961,-.234037,.365214,.833179,.917775,-.222714,.34116,.86353,.927883,-.210175,.31572,.893557,.936617,-.196925,.289159,.922976,.943384,-.182788,.261996,.951606,.949713,-.167965,.235324,.979958,.955818,-.151109,.208408,1.00765,.961344,-.133834,.182591,1.03329,.965469,-.115987,.156958,1.0557,.968693,-.09746,.132239,1.07583,.973165,-.0778514,.106195,1.09451,.979387,-.0585067,.0797669,1.11137,.98671,-.0390409,.0530263,1.12643,.994093,-.019408,.0263163,1.14016,1.00002,540029e-9,-194487e-9,1.15299,.574483,-989066e-11,.494533,114896e-10,.574478,-249127e-9,.494528,289403e-9,.574607,-996811e-9,.494637,.00115797,.574396,-.00224241,.494458,.00260498,.574377,-.00398632,.49444,.00463102,.574386,-.00622836,.494445,.00723623,.574401,-.0089683,.494453,.010421,.574419,-.0122056,.49446,.0141859,.574459,-.0159396,.494481,.0185322,.574525,-.0201692,.49452,.0234617,.574587,-.0248924,.494547,.0289762,.574697,-.0301074,.494604,.0350797,.574853,-.0358114,.494688,.0417767,.575027,-.041999,.494772,.0490718,.575294,-.0486618,.494915,.0569728,.575733,-.0557148,.495173,.0654955,.576356,-.0630489,.495537,.0746612,.576944,-.0709285,.495836,.0844615,.57765,-.0792723,.496177,.0949142,.578491,-.0880167,.496563,.10603,.579639,-.0969462,.497096,.117841,.580989,-.10622,.497684,.130367,.582587,-.115861,.498337,.143609,.584951,-.125605,.499414,.157625,.587602,-.135608,.500518,.172413,.59076,-.145742,.501767,.187999,.594992,-.155934,.503542,.20445,.600656,-.166303,.506135,.221764,.607816,-.176681,.509542,.24002,.61522,-.187071,.51263,.258992,.623702,-.197465,.516021,.278773,.634192,-.207816,.520422,.299377,.644936,-.218183,.524073,.320802,.657888,-.2278,.528049,.34384,.670666,-.236747,.52986,.36916,.685626,-.24484,.531892,.395867,.701304,-.252071,.532727,.423488,.717727,-.258714,.532146,.452201,.733914,-.264211,.529883,.481579,.750529,-.26859,.5259,.511558,.76747,-.272046,.51999,.542042,.785189,-.274225,.513083,.572799,.800954,-.275189,.502936,.603816,.816962,-.274946,.490921,.635461,.83336,-.272695,.47684,.6676,.848143,-.268223,.459405,.70051,.861818,-.262768,.440319,.732902,.876828,-.255872,.420123,.765084,.889312,-.247703,.398379,.796391,.900412,-.238381,.374496,.827333,.912251,-.227783,.349874,.858385,.921792,-.214832,.323181,.888652,.931273,-.200949,.296624,.917763,.940295,-.186537,.269211,.947878,.946812,-.171538,.241447,.977016,.953588,-.155254,.213829,1.00501,.958841,-.137156,.186807,1.03179,.963746,-.118699,.160706,1.05502,.966468,-.0998358,.135504,1.07568,.971178,-.0805186,.109131,1.09479,.97831,-.0599348,.0818293,1.1123,.985886,-.0399661,.0545872,1.12771,.994021,-.0198682,.0269405,1.14186,1.00009,271022e-9,-12989e-8,1.15514,.538716,-990918e-11,.486732,109675e-10,.550656,-250642e-9,.497518,277412e-9,.55057,-.00100265,.497441,.00110974,.550903,-.00225672,.497733,.00249779,.550568,-.00401046,.497438,.00443906,.550574,-.00626613,.49744,.00693637,.550591,-.0090226,.497449,.00998921,.550623,-.0122795,.497469,.0135984,.550667,-.0160361,.497495,.0177654,.550724,-.0202908,.497526,.0224915,.550792,-.0250421,.497557,.0277795,.550918,-.0302878,.49763,.0336334,.551058,-.0360241,.497701,.0400573,.551276,-.0422473,.497824,.0470585,.551551,-.0489441,.497977,.0546433,.552074,-.0559596,.498312,.0628367,.552681,-.0633978,.498679,.071646,.553324,-.0713176,.499031,.0810746,.554011,-.0797268,.499365,.091129,.55488,-.0885238,.499779,.101837,.556171,-.0974417,.500444,.113239,.557498,-.106841,.501025,.125316,.559299,-.116533,.501864,.138128,.561647,-.126298,.502967,.151695,.564347,-.136388,.504129,.16604,.567863,-.146576,.505713,.181207,.572569,-.156832,.507953,.197259,.578919,-.167323,.511186,.214258,.585387,-.177712,.514042,.232038,.593134,-.188184,.517484,.250733,.603295,-.198717,.522345,.270454,.613854,-.209177,.526751,.290807,.626092,-.219644,.531595,.312202,.637868,-.229494,.534721,.334435,.652458,-.238718,.538304,.359184,.666985,-.247061,.539875,.385637,.683301,-.254652,.541042,.41328,.69998,-.261376,.540735,.441903,.717824,-.267085,.539139,.471609,.734617,-.271465,.534958,.501446,.753663,-.27528,.53032,.532571,.770512,-.277617,.522134,.563641,.787356,-.278525,.51206,.595067,.806252,-.278512,.50119,.627226,.822061,-.277023,.486791,.659402,.838959,-.273175,.470467,.692874,.85379,-.267238,.450688,.725702,.868268,-.260327,.429741,.75832,.881994,-.251946,.407223,.790189,.893885,-.242432,.383214,.821625,.905118,-.231904,.357297,.853011,.916045,-.219545,.330733,.883773,.927614,-.205378,.303916,.914435,.936005,-.190388,.275941,.944502,.944533,-.1749,.247493,.974439,.950758,-.158588,.218996,1.00286,.957078,-.141027,.191559,1.0304,.962448,-.121507,.164457,1.05466,.964993,-.102068,.138636,1.0761,.970017,-.0822598,.111861,1.09541,.97661,-.062033,.0843438,1.11317,.985073,-.0409832,.0558496,1.12911,.993515,-.020146,.0275331,1.1438,1.00006,27329e-8,-107883e-9,1.15736,.525324,-999341e-11,.498153,105385e-10,.526513,-251605e-9,.499277,265329e-9,.526517,-.00100641,.499282,.0010613,.526588,-.00226466,.499337,.00238823,.526539,-.0040255,.499302,.00424535,.526547,-.00628954,.499306,.00663364,.526561,-.00905628,.499313,.00955337,.526593,-.0123253,.499334,.0130054,.526642,-.0160957,.499365,.0169911,.5267,-.0203661,.499396,.0215122,.526792,-.0251347,.499451,.0265718,.526904,-.0303985,.499511,.0321732,.527079,-.0361554,.499617,.0383231,.527285,-.0423982,.499731,.045026,.527602,-.0491121,.499924,.0522936,.528166,-.0561127,.500306,.0601528,.52879,-.0635988,.5007,.0686059,.529421,-.071581,.501048,.0776518,.530144,-.0799854,.501421,.0873148,.531062,-.0888032,.501884,.0976084,.532374,-.0977643,.50259,.108588,.533828,-.107197,.50329,.120234,.53581,-.116887,.504312,.132602,.538063,-.126755,.505365,.145721,.5409,-.136819,.506668,.159617,.544882,-.147117,.508731,.174369,.550238,-.157446,.511601,.190028,.556038,-.167988,.514431,.206587,.563031,-.178364,.517808,.224046,.571543,-.189007,.521937,.242503,.582255,-.199546,.527415,.261977,.59272,-.210084,.531682,.282162,.605648,-.220448,.537123,.303426,.61785,-.230593,.540664,.325323,.632223,-.240238,.544467,.348993,.648819,-.24887,.547594,.375462,.665825,-.256657,.54912,.403024,.683389,-.263711,.549294,.431773,.701495,-.269666,.547649,.461494,.719197,-.274169,.543786,.491623,.737906,-.278124,.538644,.522994,.756652,-.280632,.531057,.554775,.775279,-.281741,.521972,.586441,.792688,-.281652,.509613,.618596,.811894,-.280345,.496497,.651462,.827938,-.277128,.47968,.684023,.844837,-.271646,.460688,.718024,.859239,-.264397,.438872,.751207,.874088,-.256144,.41577,.784232,.887693,-.246311,.391369,.816191,.899402,-.235497,.365872,.847828,.910973,-.223631,.338618,.87934,.92204,-.209874,.310803,.910325,.930987,-.194265,.281802,.940695,.94,-.178125,.252836,.970958,.948018,-.161479,.224239,1.00078,.955141,-.144038,.195857,1.0288,.960513,-.124915,.168487,1.05371,.963964,-.104284,.141495,1.07596,.968713,-.0838732,.114437,1.09628,.975524,-.0635579,.0863105,1.11448,.98431,-.042291,.0574774,1.13069,.992916,-.0209131,.0284343,1.14568,.999926,743097e-9,-379265e-9,1.15955,.501042,-998428e-11,.498726,100306e-10,.502992,-252112e-9,.500665,253283e-9,.502417,-.00100791,.500092,.00101259,.502965,-.00226919,.500621,.00227978,.502318,-.00403109,.499994,.00405011,.502333,-.00629832,.500005,.00632868,.502362,-.00906907,.500027,.00911446,.502369,-.0123423,.500023,.0124078,.50243,-.0161178,.500066,.016211,.502493,-.0203937,.500103,.0205256,.502592,-.0251684,.500166,.0253548,.502707,-.0304389,.50023,.0307029,.502881,-.0362015,.500335,.0365753,.503124,-.0424507,.500488,.0429798,.503443,-.0491582,.500686,.0499268,.504083,-.0561476,.501155,.0574541,.504668,-.0636846,.501524,.0655408,.505319,-.0716834,.501904,.0742072,.50609,-.0800925,.502321,.0834699,.507122,-.0888425,.502896,.0933603,.508414,-.097855,.503603,.10391,.509955,-.107304,.504416,.115113,.512061,-.116921,.505565,.127054,.514419,-.12689,.506732,.139709,.517529,-.136934,.508338,.153173,.522085,-.147327,.510987,.167528,.526986,-.157612,.513527,.182708,.533122,-.168213,.516717,.198881,.540807,-.178688,.520832,.215986,.550687,-.189511,.52632,.234335,.560567,-.199998,.531009,.253375,.571698,-.210652,.535839,.273499,.584364,-.220917,.541091,.294355,.599066,-.23137,.546875,.316525,.614148,-.241206,.551306,.339671,.631157,-.250379,.555187,.36531,.647919,-.258397,.556595,.392767,.666112,-.265528,.556949,.421397,.686158,-.271827,.556617,.451433,.704838,-.27674,.552975,.482131,.723957,-.280733,.547814,.513458,.74262,-.283359,.53997,.545446,.762009,-.284541,.530422,.57775,.781314,-.284507,.518546,.610434,.799116,-.283309,.504178,.643178,.817604,-.280378,.48843,.676248,.83459,-.275619,.469457,.709698,.850974,-.26856,.447698,.744245,.866747,-.260094,.424791,.777695,.881412,-.249929,.399913,.810392,.8936,-.239137,.37308,.842872,.905943,-.226818,.345705,.874677,.916408,-.213699,.31706,.906257,.927215,-.198428,.288444,.936881,.935625,-.181643,.258329,.96795,.944076,-.164386,.228488,.998216,.951229,-.146339,.199763,1.02689,.958793,-.127709,.172153,1.0535,.963219,-.107244,.144989,1.07646,.967562,-.0857764,.11685,1.09675,.974866,-.0645377,.0880571,1.11576,.983353,-.0431732,.0587352,1.13227,.992503,-.0218356,.0294181,1.1478,1.00003,605203e-9,-231013e-9,1.16207,.482935,-101177e-10,.504695,968142e-11,.477554,-251521e-9,.499071,240676e-9,.477904,-.00100683,.499436,96342e-8,.478368,-.00226636,.499899,.0021687,.477977,-.00402719,.499513,.00385384,.477993,-.00629226,.499525,.0060221,.478011,-.00906011,.499536,.00867289,.478051,-.0123305,.499566,.0118074,.478089,-.016102,.499587,.0154269,.478171,-.0203736,.499645,.0195341,.478254,-.025143,.499692,.0241318,.47839,-.0304071,.499779,.0292247,.478588,-.0361631,.499911,.0348196,.478812,-.0424023,.500046,.0409231,.479208,-.0490724,.500326,.047552,.479841,-.0560722,.500805,.0547377,.480392,-.0636125,.501152,.0624607,.481068,-.0716134,.501561,.0707473,.481898,-.0800062,.502054,.0796118,.483022,-.0886568,.502728,.0890974,.484332,-.0977553,.503479,.0992099,.486126,-.107173,.504546,.10999,.488066,-.11677,.50557,.121476,.490521,-.126725,.506849,.133672,.494232,-.136793,.50911,.146731,.498302,-.147116,.511345,.160577,.503565,-.157446,.514344,.175335,.510902,-.168121,.518824,.191207,.519263,-.178799,.523666,.208058,.528204,-.189407,.528296,.225875,.538854,-.200145,.533724,.244782,.551278,-.210701,.539833,.264753,.565222,-.221303,.546131,.285745,.579403,-.231688,.551496,.307592,.595469,-.241718,.556809,.330582,.610929,-.250992,.559641,.354995,.629433,-.259602,.562379,.382471,.648504,-.267038,.563676,.411126,.66756,-.273388,.562092,.440924,.689143,-.278788,.560807,.472118,.709056,-.282783,.555701,.503774,.729855,-.285836,.548698,.536364,.748954,-.287078,.538544,.56895,.768373,-.287133,.526711,.601991,.78827,-.285839,.512511,.635403,.807465,-.283238,.496323,.668797,.825194,-.27906,.477638,.702584,.842203,-.272286,.456253,.736393,.857749,-.263854,.432412,.77096,.874799,-.253943,.407806,.80489,.887497,-.24237,.38033,.83771,.89966,-.230278,.352446,.870376,.911753,-.21646,.323268,.902256,.923011,-.202071,.294314,.933306,.932375,-.185519,.264104,.965177,.940537,-.167604,.234035,.996303,.948904,-.149068,.20412,1.0261,.955263,-.129539,.175431,1.05304,.960303,-.109932,.148116,1.07617,.965512,-.0880572,.119693,1.09742,.973466,-.0660548,.0901619,1.11721,.98284,-.0439228,.0599875,1.13436,.992216,-.0219588,.0298975,1.15006,.999946,119402e-9,-208547e-10,1.16471,.447827,-100414e-10,.491543,914833e-11,.454778,-251257e-9,.499172,22891e-8,.453519,-.00100342,.497787,914184e-9,.45357,-.00225776,.497847,.00205701,.453578,-.00401371,.497855,.00365705,.45357,-.00627107,.497841,.00571453,.453598,-.00902968,.497864,.00823019,.453627,-.0122888,.497882,.0112049,.453684,-.0160475,.497923,.0146405,.453764,-.0203044,.49798,.0185394,.453866,-.0250576,.498049,.0229054,.453996,-.0303028,.49813,.0277424,.454196,-.0360379,.498267,.0330587,.454457,-.0422521,.498445,.0388613,.454926,-.0488393,.498812,.0451767,.455525,-.0558653,.499272,.0520153,.456074,-.0633772,.499625,.0593754,.456752,-.0713606,.500049,.0672751,.457648,-.07971,.500615,.0757447,.458849,-.0883032,.501399,.0848231,.46029,-.0974095,.502293,.0945135,.462,-.106729,.503301,.104848,.464121,-.116354,.504533,.115884,.466889,-.126214,.506172,.127652,.470744,-.136324,.508667,.14024,.47488,-.146595,.510995,.153673,.480845,-.157027,.514832,.168053,.488262,-.167658,.519506,.183508,.496547,-.178343,.524347,.199948,.506254,-.188916,.52983,.217503,.517961,-.199975,.536357,.236272,.531484,-.210624,.543641,.256096,.545496,-.221227,.550048,.277085,.559497,-.231568,.555076,.298615,.575752,-.241698,.560541,.321547,.591999,-.251172,.564156,.345602,.610654,-.260178,.567607,.371851,.630484,-.268094,.56923,.40076,.651807,-.274661,.569779,.430801,.67239,-.280331,.566791,.461939,.693024,-.284501,.562007,.493854,.715473,-.287852,.555791,.526992,.736323,-.28929,.546345,.560102,.755771,-.289405,.534,.593543,.775424,-.2881,.519114,.627256,.795447,-.285562,.502543,.661464,.815319,-.281416,.484773,.695206,.831769,-.275523,.463445,.729044,.849464,-.267516,.440269,.764069,.866775,-.257584,.415049,.799089,.881252,-.245817,.388049,.831948,.894209,-.233127,.35889,.865526,.906922,-.219579,.329915,.89818,.919686,-.204491,.300441,.930013,.929044,-.188962,.269445,.962061,.938393,-.171079,.238402,.994214,.94661,-.15199,.208204,1.02533,.953095,-.131953,.178653,1.0529,.958644,-.111233,.150684,1.0771,.963925,-.0903098,.122359,1.09855,.971995,-.0680505,.0923342,1.11874,.981658,-.0448512,.0614195,1.13635,.991649,-.0221931,.0303582,1.15238,.999985,393403e-9,-111086e-9,1.16772,.396806,-971563e-11,.457671,842355e-11,.429186,-249421e-9,.495017,21625e-8,.429324,-998052e-9,.495173,865322e-9,.429175,-.00224487,.494999,.00194637,.429129,-.00399041,.494952,.00346004,.429153,-.00623476,.494974,.00540684,.429168,-.0089773,.494983,.00778714,.429207,-.0122175,.495012,.0106022,.429257,-.0159542,.495047,.0138535,.429338,-.0201864,.495106,.0175443,.429431,-.0249104,.495165,.0216774,.429587,-.0301252,.495279,.0262594,.429796,-.0358249,.495432,.0312968,.430065,-.0419972,.495621,.0367985,.430588,-.0485144,.496061,.042798,.43113,-.0555028,.496472,.0492914,.431743,-.0629852,.496904,.0562907,.432448,-.0709256,.497369,.0638056,.433414,-.0791942,.498032,.071885,.434638,-.0877346,.498854,.0805517,.43611,-.0968056,.499812,.0898047,.437859,-.106002,.500891,.0997142,.440017,-.115648,.502198,.110289,.443236,-.125427,.504389,.121644,.44697,-.135492,.506809,.133769,.451689,-.145746,.509858,.146787,.45811,-.156219,.514247,.160793,.465305,-.166834,.518816,.175791,.474085,-.177546,.524331,.191906,.484808,-.188262,.53104,.209199,.49732,-.199346,.538511,.227825,.509693,-.209951,.544554,.247269,.524367,-.220533,.551616,.267978,.539228,-.231082,.557368,.289672,.55644,-.241342,.563782,.31268,.574204,-.250964,.568851,.33651,.593388,-.260306,.57312,.362219,.613358,-.268667,.574916,.390322,.634512,-.275591,.575053,.420478,.65563,-.281328,.572404,.451614,.678265,-.285948,.568893,.484112,.70011,-.289408,.561878,.517348,.723005,-.291328,.55359,.551355,.743744,-.291418,.541099,.585109,.763949,-.290252,.526489,.619487,.784186,-.287648,.509496,.65404,.804304,-.283782,.491484,.688649,.823629,-.278067,.470517,.723133,.84094,-.270588,.44705,.757163,.857852,-.261188,.421252,.792816,.874934,-.249313,.394191,.827248,.888709,-.236492,.365359,.861074,.902589,-.222185,.336016,.894417,.914201,-.207314,.30527,.926825,.925978,-.191146,.274532,.9595,.93512,-.174135,.243393,.991583,.943656,-.155231,.212414,1.02356,.951719,-.134403,.182005,1.05239,.957164,-.113023,.153043,1.07754,.962656,-.0914493,.124186,1.09984,.970695,-.0694179,.0941654,1.12,.980749,-.0466199,.0629671,1.13849,.991205,-.0227032,.0311146,1.15494,.999884,632388e-9,-254483e-9,1.1706,.379821,-957289e-11,.460637,789337e-11,.405188,-247483e-9,.491396,204064e-9,.404796,-989434e-9,.490914,815853e-9,.40483,-.00222607,.490949,.00183559,.40473,-.00395723,.49084,.00326332,.404731,-.00618287,.490836,.00509945,.404768,-.00890258,.490871,.00734463,.404791,-.0121156,.490883,.00999992,.404857,-.0158214,.490938,.0130676,.404943,-.0200178,.491004,.0165503,.405059,-.0247027,.491093,.0204521,.405213,-.0298729,.491205,.0247788,.405399,-.0355226,.491333,.0295373,.405731,-.0416352,.491604,.034741,.406303,-.0480807,.492116,.0404255,.406814,-.0550458,.492506,.0465732,.407404,-.0624652,.492926,.0532058,.408149,-.0702958,.493442,.0603442,.409128,-.0784623,.494136,.0680297,.410408,-.087007,.495054,.0762786,.411813,-.0959639,.495962,.0851046,.413735,-.105075,.497257,.0945878,.416137,-.114646,.498882,.104725,.41934,-.124394,.501132,.11563,.423326,-.134328,.503883,.127325,.428419,-.14458,.50747,.139911,.43484,-.154979,.511964,.153481,.442641,-.165628,.517328,.168114,.452511,-.176365,.524258,.183995,.463473,-.187298,.531248,.200953,.475564,-.198244,.538367,.219176,.488664,-.208938,.545175,.238514,.504073,-.219599,.553227,.259129,.520832,-.230378,.560653,.280997,.538455,-.240703,.567523,.303821,.55709,-.250548,.573287,.327948,.576646,-.259964,.577795,.353362,.596705,-.268721,.580077,.380336,.618053,-.276054,.58018,.4101,.640303,-.282176,.578747,.44161,.662365,-.286931,.574294,.474106,.684542,-.290521,.567035,.507549,.707984,-.292672,.558687,.541853,.730913,-.293189,.547606,.576581,.752948,-.292199,.533471,.61172,.773452,-.289508,.516395,.646339,.794715,-.285716,.497873,.682131,.814251,-.280051,.476845,.716396,.833057,-.272873,.453449,.751503,.84959,-.263982,.427857,.786085,.867022,-.252745,.400335,.821355,.882277,-.239655,.371304,.85646,.895375,-.225386,.340397,.890828,.909347,-.209587,.310005,.923532,.921885,-.193433,.2796,.956419,.932127,-.176135,.247276,.989445,.941869,-.157872,.216186,1.02221,.949735,-.137577,.185602,1.05195,.956617,-.115285,.155767,1.07822,.961974,-.0928418,.126103,1.10149,.96972,-.0700592,.0956758,1.12207,.98012,-.0474671,.0643269,1.1408,.990825,-.0238113,.0320863,1.1577,.999876,381574e-9,-812203e-10,1.17403,.367636,-961342e-11,.469176,753287e-11,.380377,-244772e-9,.485434,191797e-9,.380416,-978857e-9,.485475,767015e-9,.380376,-.00220165,.485435,.00172522,.380419,-.00391408,.485487,.00306734,.380438,-.00611549,.485505,.00479332,.380462,-.00880558,.485525,.00690391,.380496,-.0119837,.485551,.00940039,.38056,-.0156487,.485605,.0122848,.38064,-.0197988,.485666,.0155601,.380767,-.0244324,.48577,.0192313,.380909,-.0295444,.485871,.0233032,.381142,-.0351321,.48606,.0277861,.381472,-.0411535,.486336,.0326939,.382015,-.0475408,.486833,.0380565,.382523,-.0544395,.487231,.0438615,.383129,-.061784,.487683,.0501332,.383952,-.0695085,.488313,.0568996,.38498,-.0775819,.489077,.0641952,.386331,-.0860443,.490113,.0720324,.387788,-.0948406,.491099,.0804379,.389808,-.103899,.492566,.0894899,.39252,-.113313,.494601,.0992098,.395493,-.123007,.496619,.109641,.399826,-.132859,.499912,.120919,.405341,-.143077,.504061,.133107,.411932,-.153465,.508905,.146263,.420591,-.164108,.515482,.160544,.43101,-.174893,.523191,.176123,.441881,-.185839,.53026,.192757,.453919,-.196633,.537295,.210535,.468715,-.207611,.546156,.229886,.485182,-.218517,.555173,.250543,.501926,-.229249,.562728,.27221,.51785,-.239481,.567494,.294892,.536947,-.249395,.573889,.318987,.557115,-.259,.578831,.344348,.577966,-.268075,.582055,.371223,.599489,-.276115,.583307,.399834,.62479,-.282523,.583902,.431415,.647504,-.287663,.57953,.464301,.670601,-.291538,.573103,.498123,.693539,-.293842,.563731,.532662,.717385,-.294681,.553169,.567925,.741533,-.293717,.539908,.603502,.762142,-.291156,.521902,.639074,.783014,-.28719,.502815,.674439,.805158,-.281773,.482598,.710497,.823646,-.274682,.458949,.7456,.841879,-.266184,.433129,.781085,.859515,-.255682,.406064,.816,.875335,-.242849,.376509,.851074,.890147,-.228329,.345502,.886473,.903144,-.212491,.31428,.920751,.916618,-.195695,.282994,.954606,.927953,-.178267,.251091,.988402,.937414,-.159549,.219107,1.02141,.946823,-.140022,.18896,1.05167,.954651,-.118154,.158667,1.07819,.959955,-.0946636,.128808,1.1025,.96858,-.0711792,.0973787,1.12391,.97938,-.0475046,.0650965,1.14322,.990498,-.024059,.0326267,1.16077,.999844,-512408e-10,112444e-9,1.17727,.316912,-934977e-11,.425996,695559e-11,.356423,-241372e-9,.479108,179562e-9,.356272,-965292e-9,.478897,71811e-8,.356262,-.00217182,.478894,.00161574,.356265,-.00386092,.478895,.00287261,.356278,-.0060324,.478905,.00448907,.356293,-.00868565,.478914,.00646572,.356346,-.0118207,.478965,.00880438,.356395,-.0154355,.479001,.0115066,.356484,-.019529,.479075,.0145762,.356609,-.0240991,.47918,.018018,.356766,-.0291413,.479305,.0218379,.357009,-.0346498,.479512,.0260454,.357424,-.0405462,.479909,.0306657,.357899,-.0468825,.480337,.0357054,.358424,-.0536887,.480771,.0411728,.359041,-.0609416,.481242,.0470841,.359903,-.0685239,.481943,.0534831,.360932,-.0764883,.482741,.0603795,.362196,-.0848364,.483688,.0678028,.363847,-.0935002,.484947,.0758086,.365972,-.102471,.486588,.0844173,.368741,-.111751,.488787,.0937199,.372146,-.121334,.491405,.103732,.377114,-.131147,.495604,.114608,.38226,-.141213,.499436,.126345,.389609,-.151632,.505334,.139116,.397925,-.162073,.51168,.152995,.407824,-.172819,.518876,.168071,.420014,-.183929,.527639,.184495,.434266,-.195032,.537588,.20232,.447352,-.205792,.544379,.221189,.463726,-.216704,.553422,.241616,.481406,-.227531,.562074,.263298,.498707,-.238017,.568227,.286116,.518039,-.247936,.574473,.3101,.538277,-.257437,.579191,.335401,.561166,-.266829,.584807,.362246,.583189,-.275329,.586476,.390609,.606024,-.28234,.585578,.420998,.632419,-.287924,.584496,.454357,.656128,-.291972,.577766,.488233,.679953,-.29456,.56875,.523248,.704654,-.295816,.558388,.559168,.729016,-.295157,.544826,.595326,.752062,-.292779,.528273,.631864,.773138,-.288681,.508482,.667793,.794869,-.283358,.487341,.704035,.815101,-.27608,.46354,.739925,.834212,-.26767,.438672,.775539,.852368,-.257397,.411239,.810895,.870207,-.245689,.3829,.846472,.884063,-.231452,.351496,.881788,.898284,-.215561,.31895,.917438,.912964,-.198208,.287367,.952422,.924666,-.180426,.254487,.987551,.934429,-.161525,.222226,1.02142,.943485,-.141197,.191143,1.05218,.9521,-.120085,.161112,1.07937,.957876,-.0975881,.130982,1.10403,.966943,-.0726842,.0990553,1.12616,.978313,-.0483705,.0662818,1.14619,.990048,-.0239072,.0329243,1.16413,.999984,461885e-9,-772859e-10,1.18099,.321287,-935049e-11,.455413,659662e-11,.332595,-237513e-9,.471437,167562e-9,.332729,-949964e-9,.471618,670192e-9,.332305,-.00213618,.471028,.00150712,.332326,-.00379765,.471055,.00267959,.332344,-.00593353,.471072,.00418751,.332356,-.00854349,.471077,.00603172,.332403,-.0116268,.471121,.00821362,.332461,-.0151824,.47117,.0107357,.332552,-.0192088,.471251,.0136014,.332657,-.0237024,.47133,.0168152,.332835,-.0286615,.471487,.0203853,.333083,-.0340765,.471708,.0243212,.333547,-.0398563,.47219,.0286518,.333989,-.0460916,.472587,.0333763,.334532,-.0527897,.473054,.0385084,.335167,-.0599284,.473568,.0440638,.33608,-.0673514,.474362,.0500962,.337146,-.0752237,.475231,.0566022,.338462,-.083418,.476282,.0636272,.34014,-.0919382,.477615,.0712153,.342341,-.100741,.479404,.079417,.345088,-.109905,.481618,.0882631,.349049,-.119369,.485081,.0978851,.353939,-.129033,.489317,.108336,.359893,-.139038,.494309,.119698,.366945,-.149411,.499983,.132024,.375814,-.159843,.507185,.145558,.387112,-.170664,.516392,.160433,.40023,-.181897,.526519,.176648,.412555,-.192785,.53423,.193922,.427023,-.203663,.542741,.212662,.443685,-.214695,.552066,.232944,.461499,-.225561,.560762,.254495,.480975,-.236257,.569421,.277531,.501,-.24639,.576101,.301724,.521691,-.256101,.581493,.327112,.543478,-.265289,.585221,.353917,.566094,-.273938,.587614,.381941,.589578,-.281679,.587991,.41172,.614583,-.287655,.585928,.444148,.641813,-.292228,.582092,.478617,.666189,-.295172,.57398,.51397,.690475,-.29648,.561676,.550118,.715543,-.296203,.548758,.586933,.740405,-.293999,.532792,.62384,.762183,-.28998,.512735,.660723,.786069,-.28478,.492402,.69807,.806812,-.277568,.469058,.734422,.826987,-.268951,.443017,.770946,.844588,-.259049,.415501,.80699,.863725,-.2471,.387328,.842107,.879137,-.234157,.356108,.878078,.894634,-.218719,.324315,.914058,.909162,-.201293,.291813,.949922,.92072,-.18267,.258474,.985337,.93158,-.163212,.225593,1.0205,.941238,-.142771,.193986,1.05273,.949293,-.120956,.163392,1.08075,.956226,-.0985743,.132934,1.10559,.96546,-.075118,.101255,1.12823,.977403,-.0497921,.0675441,1.149,.989648,-.0241574,.0334681,1.16765,1.00001,5762e-7,-184807e-9,1.18519,.303474,-916603e-11,.4542,61243e-10,.308894,-232869e-9,.462306,155592e-9,.309426,-931661e-9,.463093,622499e-9,.308643,-.0020949,.461933,.00139979,.308651,-.0037242,.461941,.00248874,.308662,-.00581873,.46195,.00388933,.308687,-.00837818,.461974,.00560247,.308728,-.0114016,.462011,.00762948,.308789,-.0148884,.462067,.00997326,.308882,-.0188369,.462151,.0126375,.309007,-.0232436,.462263,.0156271,.30918,-.0281054,.462417,.0189498,.309442,-.0334065,.462667,.0226167,.309901,-.0390589,.463162,.0266614,.310331,-.0452042,.463555,.0310715,.310858,-.0517735,.464019,.0358698,.311576,-.0587359,.464669,.0410848,.312436,-.0660383,.465406,.0467453,.313526,-.0737266,.466339,.0528718,.314903,-.0817574,.467504,.0595039,.316814,-.090167,.469226,.0666888,.318965,-.0987555,.470981,.0744658,.322077,-.107792,.473814,.082912,.325947,-.117098,.477241,.0920846,.331008,-.126602,.48184,.102137,.337893,-.136619,.488334,.113135,.345106,-.146838,.494415,.12511,.355111,-.157357,.503275,.138356,.365095,-.167955,.510966,.152686,.378344,-.179157,.521508,.16856,.391599,-.190143,.530455,.18561,.407786,-.20123,.541275,.204308,.425294,-.212456,.551784,.224623,.444021,-.223568,.561493,.246172,.463418,-.234154,.569886,.268979,.484077,-.244546,.577116,.293411,.505513,-.254301,.582914,.318936,.527672,-.263564,.587208,.345856,.550565,-.272332,.589277,.374054,.573656,-.280011,.588426,.403276,.59827,-.286924,.587504,.43474,.624731,-.291994,.583401,.468767,.652396,-.295159,.576997,.504411,.67732,-.296954,.565863,.54114,.703147,-.296877,.552316,.57816,.728715,-.295147,.536773,.616124,.752448,-.291275,.51771,.653885,.775169,-.285905,.496087,.691537,.799307,-.279064,.474232,.729251,.819482,-.270294,.447676,.766267,.837659,-.260032,.419656,.802616,.856903,-.248497,.391328,.838583,.873325,-.235252,.360285,.874711,.889788,-.221126,.329215,.91077,.904486,-.204304,.296392,.94653,.917711,-.185562,.262159,.983828,.928969,-.165635,.229142,1.01955,.939707,-.14442,.19673,1.05317,.948167,-.122147,.165095,1.0823,.955222,-.099098,.13451,1.10791,.964401,-.0755332,.102476,1.1312,.976605,-.0513817,.0689667,1.15218,.989085,-.0258499,.034506,1.17129,.999908,617773e-9,-271268e-9,1.18961,.285803,-905752e-11,.452348,572272e-11,.284689,-22732e-8,.450581,143626e-9,.285263,-910214e-9,.451482,575099e-9,.285302,-.00204784,.451553,.00129395,.285318,-.00364057,.451574,.0023006,.28533,-.00568813,.451585,.00359547,.285361,-.00819001,.451618,.00517934,.285397,-.0111458,.45165,.007054,.285447,-.0145536,.451688,.00922167,.285527,-.0184127,.451758,.0116869,.285688,-.0227207,.451929,.0144555,.28584,-.0274712,.452055,.0175341,.286136,-.0326278,.452369,.0209406,.286574,-.0381792,.452853,.0246965,.287012,-.0441879,.453272,.0287996,.287542,-.0506096,.453752,.033268,.288299,-.0573634,.454488,.0381504,.289186,-.0645458,.455294,.0434447,.290302,-.0720405,.456301,.0491973,.291776,-.0799046,.457648,.0554453,.29372,-.088117,.459483,.0622311,.296052,-.0965328,.461571,.0695992,.299563,-.105409,.465085,.077658,.30335,-.114553,.468506,.0864176,.309167,-.123917,.474423,.0961078,.31529,-.13381,.47995,.106643,.324163,-.144021,.488592,.118322,.333272,-.154382,.496461,.131133,.344224,-.165015,.50562,.145208,.357733,-.176168,.516719,.16073,.373046,-.187468,.528513,.177807,.38788,-.198488,.537713,.196072,.405133,-.209545,.547999,.21605,.423845,-.220724,.55759,.237484,.443777,-.231518,.566246,.26039,.464824,-.242035,.574326,.284835,.486635,-.251898,.58037,.310518,.51012,-.261304,.58568,.337678,.535301,-.270384,.590197,.366242,.559193,-.27841,.590569,.395873,.583544,-.285325,.588161,.426857,.608834,-.291113,.584249,.459477,.635753,-.294882,.57763,.494734,.664367,-.297088,.569479,.532023,.689688,-.297364,.555064,.569629,.715732,-.295949,.539522,.608124,.741307,-.292259,.521613,.646231,.764949,-.287063,.49969,.684938,.788599,-.28012,.476747,.723548,.81048,-.27153,.45116,.761135,.831372,-.261289,.424101,.798916,.850092,-.249559,.39443,.835952,.867777,-.236348,.363849,.871606,.884632,-.221569,.332477,.907843,.90047,-.20618,.300667,.944187,.914524,-.188771,.266552,.981371,.926892,-.168362,.232349,1.01841,.937951,-.146761,.199359,1.05308,.947236,-.123813,.1675,1.0839,.954367,-.099984,.136166,1.11047,.963907,-.0759278,.103808,1.13414,.976218,-.0511367,.0697061,1.15575,.988772,-.0267415,.0352529,1.17531,.999888,-520778e-9,289926e-9,1.19389,.263546,-883274e-11,.441896,526783e-11,.262352,-221849e-9,.439889,132311e-9,.262325,-886683e-9,.439848,528824e-9,.26228,-.00199476,.439765,.00118975,.262372,-.00354671,.439922,.00211568,.26239,-.00554141,.439941,.00330652,.262412,-.00797888,.439961,.00476346,.262453,-.0108584,.440002,.00648818,.262528,-.0141788,.440085,.0084835,.262615,-.017938,.440166,.0107533,.262744,-.0221346,.440291,.0133044,.262939,-.026762,.440493,.0161445,.263277,-.0317573,.440889,.0192974,.26368,-.0371832,.441338,.0227699,.264106,-.0430371,.441753,.0265698,.264624,-.0493035,.442227,.0307178,.265378,-.0558669,.442985,.0352616,.266253,-.0628718,.443795,.0401968,.267478,-.0701569,.445008,.04559,.269062,-.077845,.446599,.0514539,.270926,-.0857941,.448349,.0578382,.273693,-.0940773,.451221,.0648363,.276746,-.102704,.454097,.0724389,.281693,-.111735,.459517,.0808744,.287335,-.121004,.46531,.0901551,.29448,-.130734,.472605,.100371,.30257,-.140777,.480251,.111644,.312465,-.15111,.489444,.124111,.324856,-.16189,.500919,.137979,.33774,-.172946,.511317,.153163,.35255,-.184152,.522684,.169817,.367786,-.19522,.53248,.187886,.385474,-.20632,.543326,.207634,.404976,-.217744,.554109,.229165,.425203,-.228691,.563395,.252068,.446704,-.239299,.571565,.276471,.468951,-.249348,.577935,.302323,.493487,-.258933,.584309,.329882,.517861,-.268009,.58773,.358525,.543309,-.276238,.589612,.388585,.569704,-.28356,.589294,.419787,.594871,-.289497,.585137,.452114,.622555,-.294452,.580356,.486466,.651167,-.296918,.57185,.523079,.677332,-.297647,.558428,.5611,.703718,-.296321,.542232,.599592,.730262,-.293339,.524541,.639138,.754304,-.288036,.502691,.677978,.778051,-.281018,.479212,.716537,.801557,-.272414,.454071,.75586,.822559,-.262419,.425952,.794477,.843051,-.250702,.397313,.832664,.86232,-.237264,.366534,.869876,.879044,-.222716,.334816,.906973,.896362,-.206827,.303143,.943558,.910342,-.189659,.269699,.979759,.924119,-.171108,.236411,1.01718,.935374,-.149579,.202224,1.05289,.944295,-.126295,.16989,1.08496,.952227,-.101511,.138089,1.11256,.962041,-.0766392,.105053,1.1375,.97528,-.0511967,.070329,1.15983,.988476,-.025463,.0351268,1.17987,.999962,286808e-10,145564e-10,1.19901,.227089,-841413e-11,.404216,472707e-11,.239725,-215083e-9,.426708,120833e-9,.239904,-860718e-9,.427028,483555e-9,.239911,-.00193661,.427039,.00108806,.239914,-.00344276,.42704,.00193457,.239933,-.00537907,.427064,.00302363,.239944,-.00774482,.427065,.00435604,.239993,-.01054,.427122,.00593398,.240052,-.0137626,.427179,.00775987,.240148,-.0174115,.427279,.00983854,.240278,-.021484,.42741,.0121763,.240472,-.0259729,.427618,.0147827,.240839,-.0308131,.428086,.0176837,.241201,-.0360893,.428482,.0208775,.241626,-.0417723,.428907,.0243821,.242207,-.0478337,.42952,.0282228,.24298,-.0542199,.430332,.0324333,.243881,-.0610015,.431222,.0370252,.245123,-.0680874,.432512,.0420535,.24667,-.0755482,.434088,.0475414,.248779,-.0832873,.436323,.0535542,.251665,-.0913546,.439509,.0601716,.255305,-.0998489,.443478,.0674282,.260049,-.108576,.448713,.0754673,.266192,-.117754,.455524,.084339,.273158,-.127294,.4627,.0941683,.282131,-.137311,.472068,.10515,.293332,-.147736,.483565,.117402,.304667,-.158357,.493702,.130824,.317785,-.169274,.504708,.145724,.333245,-.180595,.517107,.16215,.349843,-.191892,.528849,.180149,.367944,-.203168,.540301,.199746,.387579,-.214443,.551514,.221047,.408247,-.225624,.560906,.243981,.43014,-.236422,.56959,.268513,.452669,-.24654,.576098,.294409,.476196,-.256157,.580925,.322002,.501157,-.265289,.584839,.351052,.527632,-.273671,.587614,.3812,.555754,-.281254,.589119,.412994,.581682,-.287448,.585204,.445498,.608196,-.292614,.579006,.479505,.635661,-.296068,.571297,.514643,.664999,-.297395,.560855,.552213,.691039,-.296645,.544525,.591365,.7179,-.293785,.526535,.630883,.744059,-.289089,.50545,.670932,.76863,-.282239,.482514,.710904,.793273,-.273688,.457246,.750259,.814731,-.26328,.428872,.78948,.835603,-.251526,.399384,.828597,.85489,-.238339,.368811,.866892,.872828,-.223607,.336617,.90563,.889462,-.207538,.303997,.943538,.904929,-.190297,.270812,.980591,.919101,-.172034,.237453,1.01935,.930536,-.152058,.204431,1.05498,.941223,-.129515,.172495,1.08717,.94982,-.104263,.140175,1.11551,.960592,-.0781944,.106465,1.14098,.974629,-.051688,.0711592,1.16418,.98811,-.0253929,.0354432,1.18465,1.00004,804378e-9,-330876e-9,1.20462,.214668,-821282e-11,.406619,433582e-11,.218053,-208144e-9,.413025,109887e-9,.217987,-832212e-9,.412901,439362e-9,.217971,-.00187246,.412876,988623e-9,.217968,-.00332855,.41286,.00175772,.217985,-.00520055,.412882,.00274729,.218014,-.00748814,.412916,.00395842,.218054,-.0101901,.412957,.00539274,.218106,-.0133057,.413005,.00705348,.218217,-.0168342,.413139,.00894581,.218338,-.0207707,.413258,.0110754,.21855,-.0251001,.413509,.0134551,.218913,-.0297861,.413992,.0161081,.219265,-.0348956,.414383,.0190307,.219696,-.0403909,.414839,.0222458,.220329,-.0462003,.415567,.025792,.220989,-.0524208,.41621,.0296637,.222027,-.058948,.417385,.0339323,.223301,-.0658208,.418779,.0386055,.224988,-.0730347,.420665,.0437355,.227211,-.0805274,.423198,.0493844,.230131,-.088395,.426566,.0556135,.233908,-.0966208,.43091,.0624829,.239092,-.105223,.437148,.0701636,.245315,-.11424,.444302,.0786949,.253166,-.12368,.453262,.0882382,.262374,-.133569,.463211,.0988682,.273145,-.143836,.474271,.110727,.285512,-.154577,.4863,.123945,.299512,-.165501,.498817,.138581,.314287,-.176698,.510341,.154676,.331083,-.188066,.522583,.172459,.349615,-.199597,.534879,.191979,.369318,-.210843,.546083,.21309,.390377,-.222068,.5562,.235998,.412411,-.233059,.564704,.260518,.435715,-.24357,.572314,.286795,.461196,-.253356,.579395,.314559,.485587,-.262362,.581985,.343581,.511908,-.270895,.584347,.374367,.539798,-.278452,.58505,.406015,.567974,-.284877,.583344,.439168,.594303,-.290124,.577348,.473005,.622951,-.294183,.570751,.508534,.652404,-.296389,.561541,.544764,.679291,-.296605,.546426,.582927,.706437,-.294095,.528599,.622681,.734485,-.28978,.508676,.663567,.758841,-.283363,.484768,.704092,.78537,-.275015,.460434,.745101,.807315,-.264689,.432166,.784712,.8271,-.252597,.401807,.824241,.849191,-.239154,.371458,.863803,.867046,-.224451,.338873,.903063,.8852,-.208342,.306175,.942763,.901771,-.190684,.272759,.981559,.915958,-.172105,.239306,1.02048,.928046,-.152214,.206071,1.05765,.939961,-.130247,.17367,1.08999,.948711,-.10672,.142201,1.11829,.959305,-.0808688,.108454,1.14467,.973009,-.0539145,.0728109,1.16839,.987631,-.0262947,.0360625,1.19004,.999978,.00132758,-559424e-9,1.21058,.193925,-793421e-11,.391974,392537e-11,.196746,-200315e-9,.397675,991033e-10,.19667,-801099e-9,.397521,396342e-9,.196633,-.00180246,.397445,891829e-9,.196654,-.00320443,.397482,.00158582,.196659,-.00500647,.39748,.00247867,.196683,-.0072086,.397506,.00357167,.196728,-.00981001,.397562,.00486675,.196792,-.0128096,.397633,.00636707,.19689,-.0162055,.397746,.00807752,.197017,-.0199943,.397884,.0100052,.19729,-.024139,.39827,.0121691,.197583,-.0286671,.398639,.0145755,.197927,-.0335858,.399034,.0172355,.198383,-.0388806,.399554,.0201718,.199002,-.0444736,.400289,.0234194,.199739,-.0504583,.401111,.026984,.200784,-.056729,.402349,.0309217,.202075,-.0633643,.403841,.0352496,.203898,-.0703247,.406076,.0400313,.206199,-.0775565,.408841,.0453282,.209252,-.085184,.41259,.0511794,.213638,-.0931994,.418288,.0577459,.21881,-.101617,.424681,.0650508,.225642,-.11052,.433429,.0732759,.233717,-.119772,.442897,.0824683,.242823,-.129505,.452888,.0927484,.254772,-.139906,.466407,.104417,.266603,-.150402,.477413,.117211,.28073,-.161395,.490519,.131598,.295399,-.172465,.50201,.147407,.312705,-.183982,.515311,.165031,.331335,-.195532,.52786,.184336,.351037,-.206971,.5392,.205361,.372175,-.218117,.54941,.228043,.394548,-.229327,.558642,.25267,.419598,-.240052,.567861,.279071,.443922,-.249937,.573332,.306882,.471495,-.259407,.58013,.33661,.496769,-.267749,.580564,.367328,.524951,-.275524,.581696,.399753,.55318,-.282148,.579885,.433134,.581577,-.287533,.575471,.467534,.609231,-.291612,.567445,.502943,.637478,-.293911,.557657,.53871,.667795,-.295096,.546535,.576568,.694272,-.294073,.529561,.614929,.722937,-.290386,.510561,.655909,.749682,-.284481,.487846,.697663,.774754,-.276188,.462487,.738515,.799301,-.266215,.43481,.779802,.820762,-.254116,.404879,.820045,.843231,-.240393,.374559,.860294,.861857,-.225503,.341582,.900965,.880815,-.209382,.308778,.941727,.89766,-.19155,.275232,.980916,.912926,-.172346,.240938,1.02162,.926391,-.151799,.207223,1.0597,.938429,-.129968,.17484,1.09291,.947834,-.10651,.142984,1.12248,.958432,-.0824098,.109902,1.149,.972402,-.0565242,.0744454,1.1733,.987191,-.028427,.0373794,1.19538,.999975,385685e-10,-4203e-8,1.21676,.178114,-766075e-11,.385418,354027e-11,.176074,-191966e-9,.381002,887135e-10,.17601,-767549e-9,.380861,354715e-9,.17598,-.00172696,.380798,798168e-9,.175994,-.00307012,.380824,.00141928,.176017,-.00479684,.380858,.00221859,.176019,-.00690648,.380839,.00319714,.176072,-.00939888,.380913,.0043572,.176131,-.0122726,.380979,.005702,.176239,-.0155264,.38112,.00723689,.176371,-.0191551,.381272,.00896907,.176638,-.023117,.381669,.0109194,.176912,-.0274633,.382015,.0130903,.177279,-.032173,.382476,.0154949,.17774,-.0372219,.383041,.0181669,.178344,-.0426132,.38378,.0211209,.179153,-.0483309,.384773,.0243899,.180197,-.0543447,.386076,.0280062,.181581,-.0607122,.387809,.032004,.18344,-.0673855,.390205,.036453,.186139,-.0743989,.393944,.0414162,.189432,-.0817731,.39832,.0469394,.193795,-.0895464,.404188,.0531442,.199641,-.0978264,.4121,.0601374,.206679,-.106499,.421425,.0680078,.214865,-.115654,.431504,.076919,.224406,-.125268,.442526,.0868835,.235876,-.135475,.455465,.0981875,.248335,-.146023,.4681,.110759,.262868,-.157016,.482069,.124885,.278962,-.168245,.496182,.140645,.295082,-.17958,.507401,.157838,.313738,-.191227,.520252,.17695,.333573,-.202718,.531708,.197817,.356433,-.214424,.544509,.220785,.378853,-.225492,.55373,.245306,.402717,-.236236,.561348,.271593,.428375,-.246568,.568538,.299776,.454724,-.255941,.573462,.329433,.482291,-.264511,.576356,.360598,.509706,-.272129,.576446,.393204,.538805,-.278979,.575298,.427227,.568919,-.284528,.572154,.462157,.596804,-.288801,.564691,.497997,.625987,-.291334,.555134,.534467,.656414,-.292722,.545051,.571736,.683916,-.292185,.528813,.610158,.711809,-.290043,.51106,.649061,.739547,-.285246,.490103,.690081,.766914,-.277647,.465523,.732554,.791375,-.267603,.437718,.773982,.814772,-.256109,.40882,.81609,.836691,-.242281,.377823,.856849,.856984,-.227155,.34496,.898363,.876332,-.210395,.311335,.939471,.894988,-.192612,.277703,.980799,.911113,-.173236,.243019,1.02215,.924092,-.152258,.209037,1.06139,.936828,-.129575,.175909,1.09635,.946869,-.10594,.143852,1.12707,.958284,-.081318,.110289,1.15419,.972325,-.0556133,.0747232,1.17909,.986878,-.0297899,.0383149,1.20163,.999936,-.00197169,912402e-9,1.22338,.151174,-720365e-11,.351531,309789e-11,.155594,-18279e-8,.361806,78608e-9,.156099,-731569e-9,.362982,314615e-9,.156053,-.00164578,.362869,707845e-9,.156093,-.0029261,.362961,.00125884,.156099,-.00457155,.362959,.00196783,.15612,-.00658224,.362982,.00283622,.156168,-.00895774,.363048,.00386625,.156221,-.0116962,.363101,.00506109,.156324,-.0147973,.363241,.00642675,.156476,-.0182503,.363448,.00797175,.156731,-.0220266,.36384,.00971484,.156994,-.026176,.364179,.0116575,.157341,-.0306701,.36462,.0138207,.157867,-.0354591,.365364,.0162356,.15846,-.0406141,.366111,.0189092,.159308,-.0460519,.367248,.021885,.160426,-.0518096,.368767,.0252004,.161877,-.0578906,.370745,.0288825,.163995,-.0642812,.373831,.0330139,.16655,-.0710067,.377366,.0376283,.170237,-.0781522,.382799,.0428493,.175096,-.0857172,.389915,.0487324,.181069,-.0938025,.398487,.0554214,.188487,-.102363,.408799,.0630189,.197029,-.111343,.419991,.071634,.206684,-.120812,.431455,.0812797,.218698,-.131033,.445746,.0923651,.230726,-.141373,.457471,.104545,.245516,-.152387,.472388,.118449,.261551,-.163628,.486671,.133923,.277437,-.174814,.49762,.150849,.296662,-.186713,.51162,.169924,.31795,-.198513,.525435,.190848,.339422,-.210119,.536267,.213504,.362143,-.221354,.545982,.237947,.387198,-.23224,.555364,.264427,.412349,-.24257,.561489,.292519,.439274,-.252284,.566903,.322561,.466779,-.261023,.569614,.353952,.496011,-.26899,.571589,.387278,.524964,-.275498,.570325,.421356,.556518,-.281449,.568792,.457314,.584363,-.285526,.560268,.493199,.614214,-.28844,.55205,.530276,.645684,-.289777,.541906,.56855,.673446,-.289722,.526464,.606927,.701924,-.287792,.509872,.645945,.73037,-.284315,.490649,.685564,.757405,-.278804,.467964,.726511,.784025,-.269543,.441468,.768601,.808255,-.258117,.41216,.811321,.830739,-.244728,.380606,.853496,.851914,-.229428,.348111,.895374,.872586,-.212508,.314732,.937674,.891581,-.194025,.280338,.979869,.907641,-.174711,.245203,1.02253,.922233,-.153509,.21077,1.06371,.935878,-.130418,.177399,1.09972,.946338,-.105558,.144507,1.13124,.957265,-.080059,.110508,1.15973,.971668,-.0539766,.0742311,1.18515,.9866,-.0277101,.0375224,1.20858,1.00021,-515531e-9,135226e-9,1.23135,.137468,-686011e-11,.345041,273315e-11,.13703,-173378e-9,.343936,690761e-10,.136986,-693048e-9,.34383,276126e-9,.136964,-.00155931,.343761,621337e-9,.137003,-.00277211,.343863,.00110494,.137012,-.00433103,.343868,.00172744,.137043,-.00623606,.343916,.00249022,.13709,-.0084868,.343986,.00339559,.137145,-.0110814,.344045,.00444687,.137242,-.0140187,.344177,.00565007,.137431,-.0172713,.344491,.00701868,.137644,-.0208605,.344805,.00856042,.13791,-.024792,.345172,.0102863,.138295,-.0290461,.345734,.0122185,.138764,-.0335957,.346371,.0143771,.139415,-.038467,.347298,.0167894,.140272,-.0436176,.348527,.0194895,.141457,-.0491016,.350276,.0225043,.14303,-.0548764,.352646,.0258962,.145289,-.0610096,.356206,.0297168,.148502,-.0674777,.361488,.0340562,.152188,-.074345,.367103,.0389534,.157359,-.0817442,.375247,.0445541,.16379,-.0896334,.385064,.0509535,.171376,-.098005,.396082,.0582611,.179901,-.106817,.407418,.06654,.189892,-.116239,.420031,.075994,.201838,-.12627,.434321,.0867239,.214311,-.136701,.447631,.0987517,.228902,-.147616,.462046,.112353,.245107,-.158871,.476942,.127605,.262292,-.170261,.490285,.144469,.281215,-.182017,.503783,.163282,.301058,-.193729,.515505,.183873,.322752,-.205512,.52682,.206466,.347547,-.217214,.539473,.231194,.370969,-.227966,.546625,.257288,.397533,-.238555,.55472,.285789,.42398,-.248278,.559468,.315746,.452928,-.257422,.564095,.347724,.482121,-.265306,.565426,.380922,.510438,-.272043,.563205,.415639,.541188,-.277614,.561087,.451702,.571667,-.281927,.554922,.48845,.602432,-.285015,.546838,.526442,.634126,-.286512,.537415,.564896,.662816,-.286388,.522906,.604037,.692411,-.284734,.507003,.643795,.720946,-.281297,.488398,.68298,.748293,-.276262,.466353,.723466,.776931,-.269978,.443573,.764565,.801065,-.260305,.415279,.805838,.825843,-.247426,.384773,.849985,.84807,-.232437,.352555,.893174,.869122,-.215806,.318642,.936564,.888963,-.197307,.28381,.980253,.905547,-.177203,.247888,1.02463,.918554,-.155542,.212904,1.06714,.931395,-.131948,.1787,1.10451,.941749,-.106723,.145902,1.13694,.954551,-.0804939,.111193,1.1666,.970279,-.0534239,.0744697,1.19249,.986117,-.0257452,.0368788,1.21665,.999938,.00190634,-.0010291,1.23981,.118493,-647439e-11,.32272,23772e-10,.118765,-163023e-9,.323456,598573e-10,.118772,-65212e-8,.323477,239447e-9,.118843,-.00146741,.323657,538881e-9,.118804,-.00260846,.323553,95826e-8,.118826,-.00407576,.323595,.00149845,.118846,-.00586826,.323617,.00216047,.118886,-.00798578,.32367,.00294679,.118947,-.0104273,.323753,.00386124,.119055,-.0131909,.323922,.00490999,.119241,-.0162444,.324251,.00610804,.11944,-.0196339,.324544,.00745805,.119739,-.0233378,.325026,.00897805,.12011,-.0273179,.325586,.0106895,.120571,-.0316143,.326231,.0126073,.12124,-.0361939,.327264,.0147654,.122162,-.0410511,.328733,.0172001,.123378,-.0462233,.330659,.0199375,.125183,-.0517109,.333754,.0230498,.127832,-.0575652,.338507,.026597,.130909,-.0637441,.343666,.0306345,.135221,-.0704302,.351063,.035273,.14082,-.0776364,.360604,.0406137,.146781,-.0852293,.369638,.0466788,.155121,-.0935351,.3827,.0537628,.16398,-.102234,.39522,.0617985,.173926,-.111465,.40793,.07097,.185137,-.121296,.42105,.0813426,.19826,-.13169,.435735,.0931596,.212938,-.142614,.450932,.106547,.229046,-.153884,.465726,.121575,.246246,-.165382,.479461,.138286,.264637,-.176806,.492106,.15666,.284959,-.188793,.504774,.17728,.308157,-.200763,.518805,.19988,.330951,-.21239,.528231,.224293,.3549,-.223521,.536376,.250541,.381502,-.234169,.544846,.278902,.409529,-.244077,.551717,.309227,.437523,-.253363,.55517,.341426,.467624,-.261659,.557772,.37518,.497268,-.268498,.556442,.41007,.528294,-.274018,.553915,.446445,.559053,-.278169,.549153,.483779,.589329,-.281229,.539878,.522249,.622503,-.282902,.53162,.561754,.652382,-.282815,.518119,.601544,.681847,-.281247,.502187,.641574,.712285,-.277986,.484824,.682633,.740094,-.273017,.463483,.723426,.768478,-.266692,.441299,.763747,.794556,-.258358,.415238,.805565,.819408,-.248807,.386912,.847254,.843411,-.236214,.356165,.891091,.862397,-.219794,.320562,.936174,.883113,-.201768,.285322,.982562,.90023,-.181672,.249713,1.02862,.915192,-.159279,.214546,1.07163,.928458,-.134725,.180285,1.10995,.94069,-.10913,.147119,1.14354,.953409,-.0821315,.112492,1.17372,.969537,-.0542677,.0752014,1.20043,.985612,-.0259096,.0370361,1.22528,.999835,.00298198,-.00151801,1.24959,.10097,-602574e-11,.300277,202619e-11,.101577,-152164e-9,.302077,511662e-10,.101572,-608889e-9,.302066,204751e-9,.101566,-.00136997,.302047,460753e-9,.101592,-.00243557,.302114,819497e-9,.101608,-.0038053,.30214,.00128154,.101627,-.00547906,.30216,.0018483,.101669,-.00745647,.302224,.00252223,.101732,-.00973615,.302318,.00330716,.101844,-.0123097,.302513,.00421061,.102025,-.0151681,.30285,.00524481,.102224,-.0183334,.303166,.0064154,.102515,-.0217819,.303654,.00774063,.102886,-.0255067,.304243,.0092398,.103395,-.029514,.305089,.0109339,.104109,-.0337912,.306301,.0128561,.105074,-.0383565,.30798,.0150338,.10654,-.0432132,.310726,.0175228,.108478,-.0484244,.314351,.0203648,.111015,-.0539339,.319032,.0236325,.114682,-.0598885,.32605,.0274188,.11911,-.0663375,.334109,.0317905,.124736,-.0733011,.344013,.0368502,.131479,-.0807744,.355358,.0427104,.139283,-.0888204,.367614,.0494788,.148054,-.0973394,.380072,.0572367,.159037,-.10665,.395678,.0662704,.169794,-.116221,.40795,.0763192,.18314,-.126632,.423546,.087956,.197515,-.137383,.438213,.101042,.213514,-.148641,.453248,.115827,.23065,-.160117,.46688,.132283,.249148,-.171807,.479962,.150644,.270219,-.183695,.494618,.171073,.292338,-.195574,.506937,.193378,.314999,-.207205,.516463,.217585,.340991,-.218955,.528123,.24428,.367982,-.229917,.537025,.272784,.39432,-.239737,.541627,.302742,.423364,-.249048,.546466,.335112,.453751,-.257329,.549466,.369032,.48416,-.264623,.549503,.404577,.515262,-.270411,.547008,.441337,.547036,-.274581,.542249,.479162,.576614,-.277266,.533015,.517904,.611143,-.279144,.525512,.558508,.640989,-.279001,.51154,.598995,.671182,-.277324,.495641,.639935,.700848,-.273908,.477526,.681017,.729862,-.269063,.457955,.722764,.758273,-.262282,.434846,.764349,.784121,-.254281,.409203,.806206,.809798,-.24505,.382694,.848617,.834953,-.233861,.354034,.892445,.856817,-.221308,.321764,.936263,.877609,-.205996,.288118,.982401,.897489,-.186702,.253277,1.02975,.913792,-.164618,.217963,1.07488,.92785,-.140023,.183221,1.11487,.940378,-.11328,.149385,1.14947,.95273,-.0853958,.114152,1.1807,.969059,-.0568698,.0769845,1.20912,.985574,-.0276502,.0381186,1.23498,.999943,.00239052,-.00126861,1.25987,.0852715,-560067e-11,.279021,171162e-11,.0854143,-140871e-9,.279483,430516e-10,.0854191,-563385e-9,.2795,172184e-9,.0854188,-.00126753,.279493,387464e-9,.0854229,-.00225337,.279501,68918e-8,.0854443,-.00352086,.279549,.00107803,.0854697,-.00506962,.279591,.00155536,.0855093,-.00689873,.279652,.00212354,.0855724,-.00900821,.279752,.00278703,.0856991,-.0113799,.280011,.0035551,.085855,-.0140314,.280297,.00443449,.0860682,-.016963,.280682,.00543636,.086344,-.0201438,.281159,.0065788,.0867426,-.0235999,.281886,.00787977,.087239,-.0273069,.282745,.0093606,.0879815,-.031269,.284139,.011056,.0891258,-.035531,.28647,.0130065,.0906909,-.0400947,.289708,.0152495,.0927624,-.0449638,.293904,.0178454,.0958376,-.0502427,.300471,.0208915,.0995827,-.0559514,.30806,.0244247,.104526,-.0622152,.317874,.0285721,.110532,-.0690046,.329332,.0334227,.117385,-.0763068,.341217,.0390466,.12522,-.084184,.353968,.0455786,.134037,-.0925248,.366797,.0530773,.144014,-.101487,.380209,.0617424,.156013,-.111273,.395956,.071777,.168872,-.121431,.41053,.0830905,.183089,-.132105,.425073,.0959341,.198763,-.143286,.439833,.110448,.216159,-.154841,.454507,.126769,.234859,-.166588,.468368,.14495,.255879,-.178626,.482846,.165233,.27677,-.190218,.493489,.187217,.301184,-.202227,.506549,.211659,.325852,-.213764,.5158,.237922,.352824,-.22487,.525442,.26632,.380882,-.235246,.532487,.296691,.410137,-.244847,.537703,.329179,.439787,-.253122,.540361,.363135,.472291,-.260517,.542734,.399222,.501856,-.266519,.538826,.436352,.534816,-.270905,.535152,.474505,.565069,-.273826,.525979,.513988,.597154,-.275333,.516394,.554852,.630473,-.275314,.506206,.596592,.660574,-.273323,.489769,.638117,.692015,-.270008,.472578,.680457,.720647,-.265001,.452134,.723008,.750528,-.258311,.430344,.765954,.777568,-.250046,.405624,.809012,.80387,-.240114,.378339,.852425,.828439,-.228737,.349877,.895346,.851472,-.216632,.318968,.940695,.873906,-.202782,.287489,.987235,.89467,-.187059,.254394,1.03348,.912281,-.168818,.221294,1.07812,.927358,-.146494,.18675,1.11928,.940385,-.120009,.152322,1.15609,.952672,-.0917183,.117514,1.18875,.968496,-.0620321,.0797405,1.21821,.985236,-.0314945,.0402383,1.24523,.99998,-575153e-9,110644e-9,1.27133,.0702429,-512222e-11,.255273,140947e-11,.0702981,-128826e-9,.255469,354488e-10,.0703691,-515562e-9,.255727,141874e-9,.0703805,-.00116,.255754,31929e-8,.0703961,-.00206224,.255813,567999e-9,.0704102,-.00322223,.255839,88871e-8,.0704298,-.00463928,.255863,.00128272,.0704759,-.00631375,.255953,.00175283,.0705434,-.00824317,.256079,.00230342,.0706693,-.010412,.25636,.0029443,.0708189,-.0128439,.256647,.00368031,.0710364,-.0155177,.257084,.00452614,.0713223,-.0184374,.257637,.00549706,.0717182,-.0216002,.258416,.00661246,.072321,-.0249966,.259699,.00790147,.0731446,-.0286566,.261475,.0093884,.0743352,-.0325888,.264132,.0111186,.0760676,-.036843,.26815,.013145,.078454,-.0414292,.273636,.0155251,.0818618,-.0464634,.281653,.0183525,.0857382,-.0519478,.289992,.0216642,.0908131,-.0579836,.30066,.0255956,.0967512,-.0645124,.312204,.0301954,.103717,-.0716505,.325001,.0356017,.111596,-.0793232,.338129,.041896,.120933,-.087645,.352853,.0492447,.130787,-.096492,.366192,.0576749,.142311,-.105973,.380864,.0673969,.155344,-.116182,.396575,.0785899,.169535,-.126815,.411443,.0912377,.185173,-.138015,.426256,.105607,.201755,-.149325,.439607,.121551,.221334,-.161207,.455467,.139608,.241461,-.173162,.469096,.159591,.26294,-.18504,.481014,.18156,.286776,-.196881,.493291,.205781,.311596,-.208311,.503556,.231819,.338667,-.219671,.513268,.260274,.366021,-.230451,.519414,.290862,.395875,-.240131,.526766,.323196,.425564,-.248566,.52905,.357071,.457094,-.256195,.530796,.393262,.488286,-.262331,.528703,.430797,.522291,-.267141,.52727,.470231,.554172,-.270411,.519848,.510477,.586427,-.271986,.510307,.551594,.619638,-.27192,.499158,.593849,.650656,-.269817,.483852,.636314,.68284,-.266267,.467515,.679679,.714356,-.26113,.44931,.723884,.742717,-.254067,.425789,.767245,.770894,-.245652,.401144,.811819,.797358,-.235554,.374224,.856315,.823377,-.223896,.346167,.901077,.847456,-.210865,.316056,.946502,.870697,-.196574,.284503,.993711,.891068,-.180814,.251628,1.04134,.909267,-.163314,.219065,1.08609,.925653,-.143304,.186446,1.12702,.940017,-.121322,.153416,1.16371,.952398,-.0973872,.120334,1.19712,.967568,-.0698785,.08352,1.22791,.984772,-.0390031,.0439209,1.25672,1.00026,-.0070087,.00315668,1.28428,.0556653,-459654e-11,.227325,112556e-11,.0565238,-116382e-9,.230826,284985e-10,.0565717,-465666e-9,.231026,114036e-9,.0565859,-.00104773,.231079,256656e-9,.0565761,-.00186255,.231025,45663e-8,.0565913,-.00291002,.231058,714664e-9,.0566108,-.00418998,.231085,.00103224,.0566532,-.00570206,.231169,.00141202,.0567473,-.00743666,.231417,.00186018,.0568567,-.00940298,.231661,.00238264,.0569859,-.0115991,.231895,.00298699,.0572221,-.0140096,.232456,.00368957,.057519,-.0166508,.233096,.00450303,.0579534,-.01951,.234094,.00544945,.0585922,-.0225991,.235629,.00655564,.0595647,-.0259416,.238106,.00785724,.0609109,-.0295661,.241557,.00939127,.0628751,-.0335126,.246652,.0112198,.0656908,-.0378604,.254091,.0134168,.0691347,-.0426543,.262666,.0160374,.0732165,-.0478967,.272029,.0191514,.0782863,-.0536716,.283007,.0228597,.0843973,-.0600683,.295732,.0272829,.0913598,-.0670095,.308779,.032484,.0994407,-.0745516,.322886,.0385886,.108189,-.082712,.336408,.0457133,.118574,-.0914927,.351692,.0539832,.129989,-.100854,.366502,.0635162,.142722,-.110837,.381675,.0744386,.156654,-.121353,.3963,.0868483,.172151,-.132414,.411477,.100963,.188712,-.143809,.42508,.116795,.208093,-.155765,.441328,.134715,.227936,-.167608,.454328,.154396,.249495,-.179579,.467235,.176179,.27362,-.191488,.480248,.200193,.296371,-.202618,.487886,.225775,.324234,-.214133,.499632,.25441,.353049,-.225212,.509532,.285077,.381785,-.234875,.514265,.317047,.414038,-.244205,.521282,.351874,.445251,-.252145,.522931,.388279,.476819,-.258433,.520947,.425825,.509209,-.263411,.517669,.465104,.542759,-.266732,.512841,.505741,.574822,-.268263,.503317,.547611,.609324,-.268489,.493035,.590953,.641772,-.266941,.478816,.63488,.674049,-.263297,.462863,.679072,.705071,-.257618,.442931,.723487,.734709,-.250625,.421299,.768708,.763704,-.24179,.397085,.814375,.791818,-.231115,.370577,.859907,.817439,-.21922,.34232,.906715,.843202,-.205658,.312627,.953943,.866639,-.190563,.280933,1.00185,.888129,-.173978,.248393,1.05105,.907239,-.155485,.216007,1.09704,.923893,-.134782,.183233,1.13857,.938882,-.11249,.150376,1.17539,.952464,-.0890706,.117177,1.20924,.968529,-.0646523,.0813095,1.24055,.984763,-.038606,.0439378,1.27018,1.00053,-.01238,.00598668,1.29873,.0437928,-409594e-11,.204012,879224e-12,.0440166,-103395e-9,.205049,221946e-10,.0440529,-413633e-9,.205225,887981e-10,.0440493,-930594e-9,.2052,199858e-9,.0439884,-.00165352,.204901,355495e-9,.0440716,-.0025849,.205255,556983e-9,.0440968,-.00372222,.205311,805326e-9,.0441359,-.00506478,.205391,.00110333,.0442231,-.00660384,.205638,.00145768,.0443254,-.00835246,.205877,.00187275,.0444832,-.0102992,.20627,.00235938,.0447001,-.0124449,.206796,.0029299,.0450168,-.0147935,.207593,.0036005,.0454816,-.017336,.208819,.00439246,.0462446,-.0201156,.211036,.00533864,.0473694,-.0231568,.214388,.00646984,.0490191,-.0264941,.219357,.00783856,.0512776,-.030184,.226061,.00950182,.0541279,-.0342661,.234094,.0115156,.0578989,-.0388539,.244297,.0139687,.0620835,-.0438735,.254457,.0169015,.0673497,-.04951,.266706,.0204554,.0731759,-.0556263,.278753,.0246606,.0803937,-.0624585,.29309,.0297126,.0879287,-.0697556,.305856,.0355868,.0970669,-.0778795,.321059,.0425768,.106508,-.0863541,.333873,.05056,.11776,-.0955935,.349008,.0598972,.130081,-.105438,.363776,.0706314,.144454,-.115899,.380112,.0828822,.1596,-.126827,.394843,.0967611,.176097,-.138161,.409033,.112381,.194726,-.149904,.424257,.129952,.213944,-.161675,.436945,.149333,.235516,-.173659,.450176,.170892,.260564,-.185963,.466305,.194984,.285183,-.197582,.477328,.220805,.311095,-.208697,.486566,.248694,.338924,-.219519,.494811,.279015,.369757,-.229766,.504065,.311725,.3996,-.238879,.507909,.345844,.430484,-.246802,.509805,.381749,.46413,-.253924,.511436,.420251,.497077,-.259319,.508787,.459957,.530434,-.263297,.50394,.501356,.565725,-.265619,.49804,.544252,.599254,-.265842,.487346,.587856,.631251,-.263978,.472975,.631969,.663972,-.26043,.457135,.677471,.697724,-.255358,.439844,.723744,.727725,-.248308,.417872,.770653,.756417,-.239181,.39273,.817357,.785419,-.22814,.367839,.864221,.81266,-.215681,.339449,.912701,.839391,-.201623,.309279,.962419,.86366,-.185624,.278029,1.0122,.885028,-.16797,.245294,1.06186,.904639,-.148336,.212689,1.10934,.922048,-.12637,.179616,1.15063,.936952,-.102928,.146749,1.18885,.951895,-.0785268,.112733,1.22352,.967198,-.0530153,.0760056,1.25681,.984405,-.02649,.0383183,1.28762,1.00021,70019e-8,-20039e-8,1.31656,.0325964,-355447e-11,.176706,655682e-12,.0329333,-899174e-10,.178527,165869e-10,.0329181,-359637e-9,.178453,663498e-10,.0329085,-808991e-9,.178383,149332e-9,.0329181,-.00143826,.178394,265873e-9,.0329425,-.00224678,.178517,416597e-9,.0329511,-.00323575,.17849,603299e-9,.033011,-.00439875,.178695,829422e-9,.0330733,-.00574059,.178843,.00109908,.0331857,-.00725896,.179176,.00141933,.0333445,-.00895289,.179618,.0017999,.0335674,-.0108219,.180238,.00225316,.033939,-.0128687,.181417,.00279765,.0345239,-.015114,.183395,.0034564,.0354458,-.017596,.186616,.00425864,.0368313,-.0203524,.191547,.00524936,.0386115,-.0234105,.197508,.00647033,.0410303,-.0268509,.205395,.00798121,.0442245,-.0307481,.215365,.0098557,.0478659,-.0350863,.225595,.0121417,.0522416,-.0399506,.236946,.0149385,.0574513,-.045357,.249442,.0183189,.0631208,-.0512863,.261222,.0223644,.0701124,-.0579273,.275418,.0272418,.0777331,-.0650652,.288989,.0329458,.0862709,-.0728813,.302546,.0396819,.096103,-.081363,.317164,.04757,.106976,-.0904463,.331733,.0567012,.119175,-.100105,.34661,.067202,.132919,-.110375,.362249,.0792588,.147727,-.121115,.376978,.0928672,.163618,-.132299,.390681,.108228,.182234,-.143887,.406571,.125502,.201809,-.155827,.42042,.144836,.225041,-.168357,.438411,.166706,.247621,-.18004,.450368,.189909,.27097,-.191536,.460083,.215251,.296658,-.203024,.469765,.243164,.325892,-.214056,.481837,.273388,.35406,-.224104,.487474,.305344,.384372,-.233489,.492773,.339741,.41749,-.241874,.498451,.376287,.45013,-.248834,.499632,.414195,.481285,-.254658,.495233,.454077,.519183,-.259367,.496401,.496352,.551544,-.261818,.487686,.538798,.587349,-.262964,.479453,.583626,.621679,-.262128,.467709,.629451,.654991,-.258998,.452123,.67566,.686873,-.254119,.433495,.723248,.719801,-.246946,.413657,.771156,.750355,-.237709,.390366,.81989,.780033,-.226549,.364947,.868601,.809254,-.214186,.337256,.920034,.836576,-.199639,.307395,.971706,.861774,-.183169,.275431,1.02479,.885707,-.165111,.243431,1.07837,.904742,-.144363,.210921,1.12783,.915604,-.121305,.17647,1.17254,.930959,-.0962119,.143106,1.21012,.948404,-.069969,.108112,1.24474,.967012,-.0427586,.0708478,1.27718,.984183,-.0147043,.032335,1.3083,.999577,.0142165,-.00726867,1.3382,.0229227,-299799e-11,.148623,462391e-12,.0232194,-758796e-10,.15054,117033e-10,.0232315,-303636e-9,.15063,468397e-10,.0232354,-683189e-9,.150624,105472e-9,.0232092,-.0012136,.150445,187744e-9,.0232523,-.00189765,.150679,294847e-9,.0232828,-.00273247,.150789,428013e-9,.0233371,-.00371287,.150995,591134e-9,.0234015,-.00484794,.15118,787642e-9,.023514,-.00612877,.151562,.00102547,.023679,-.00756125,.152116,.00131351,.0239559,-.00914651,.153162,.00166594,.0244334,-.010904,.155133,.00210182,.025139,-.0128615,.158035,.00264406,.0262598,-.0150628,.162751,.00332923,.0277875,-.0175532,.168944,.00419773,.0298472,-.0203981,.176835,.00530034,.0325444,-.023655,.186686,.00669777,.0355581,-.0272982,.196248,.00842661,.0392841,-.0314457,.207352,.0105854,.0436815,-.0361157,.219279,.0132458,.0485272,-.0412932,.230728,.0164736,.0541574,-.0470337,.242994,.0203715,.0609479,-.0535002,.257042,.0250953,.0685228,-.0605409,.27102,.0306856,.0768042,-.0680553,.28406,.037193,.0864844,-.0765011,.299186,.0449795,.0969415,-.0852674,.3132,.0538316,.108478,-.0947333,.327138,.0641149,.121705,-.10481,.342345,.0759185,.136743,-.115474,.358472,.0894116,.152986,-.126536,.374067,.104562,.170397,-.138061,.388267,.121632,.191392,-.150203,.406467,.140996,.211566,-.161751,.418641,.161696,.233567,-.173407,.430418,.184557,.257769,-.185397,.44277,.210092,.28531,-.197048,.457191,.237827,.311726,-.20784,.464712,.267253,.340537,-.218345,.472539,.299332,.372921,-.228306,.482331,.333988,.402924,-.236665,.484378,.369722,.434475,-.244097,.484717,.407836,.469736,-.250547,.487093,.448465,.505045,-.25511,.485575,.490263,.540262,-.258444,.481225,.534495,.576347,-.259903,.473481,.579451,.608656,-.259572,.4603,.625604,.646679,-.257908,.450341,.674511,.679902,-.253663,.431561,.723269,.714159,-.247419,.412684,.773263,.745345,-.239122,.389388,.824182,.778248,-.228837,.365361,.876634,.807208,-.216197,.337667,.92945,.835019,-.201772,.307197,.985261,.860261,-.185291,.274205,1.04299,.877601,-.165809,.240178,1.09816,.898211,-.143897,.207571,1.14694,.915789,-.119513,.174904,1.19008,.931831,-.0932919,.141423,1.2297,.949244,-.0656528,.105603,1.26553,.967527,-.0370262,.0679551,1.29986,.984139,-.00730117,.0283133,1.33252,.999713,.0234648,-.0121785,1.36397,.0152135,-245447e-11,.122795,304092e-12,.0151652,-615778e-10,.122399,76292e-10,.0151181,-245948e-9,.122023,304802e-10,.0151203,-553394e-9,.12203,686634e-10,.015125,-983841e-9,.122037,122463e-9,.0151427,-.00153774,.12214,192706e-9,.0151708,-.0022103,.122237,281219e-9,.0152115,-.00300741,.12238,390804e-9,.0152877,-.00392494,.1227,526317e-9,.015412,-.00496597,.123244,69443e-8,.0156201,-.00613314,.124228,90547e-8,.0159658,-.00744113,.125945,.0011732,.0165674,-.00892546,.129098,.00151888,.017487,-.010627,.133865,.00197007,.018839,-.0126043,.140682,.0025637,.020554,-.0148814,.148534,.00333637,.0226727,-.0175123,.157381,.00433738,.0251879,-.0205266,.166685,.00561664,.0283635,-.0240319,.177796,.00725563,.0318694,-.0279432,.188251,.00928811,.0361044,-.0324313,.200038,.011835,.0406656,-.0373527,.210685,.0149146,.0463846,-.0430132,.224182,.0187254,.0525696,-.0491013,.23634,.0232283,.0598083,-.0559175,.250013,.0286521,.0679437,-.0633657,.263981,.0350634,.0771181,-.0714602,.278072,.0425882,.0881273,-.0803502,.29511,.0514487,.0996628,-.0896903,.309976,.0615766,.112702,-.099644,.325611,.0732139,.126488,-.109829,.339321,.0862324,.142625,-.120859,.35574,.101275,.15953,-.131956,.369845,.117892,.176991,-.143145,.38146,.136205,.199715,-.155292,.40052,.157252,.220787,-.167066,.412055,.179966,.243697,-.178396,.423133,.204418,.272106,-.190433,.439524,.232141,.297637,-.201265,.447041,.261109,.325273,-.211834,.454488,.292627,.357219,-.221889,.465004,.326669,.387362,-.230729,.468527,.362426,.423131,-.23924,.475836,.401533,.45543,-.246067,.475017,.441902,.493393,-.251557,.478017,.484239,.526253,-.255571,.4709,.528586,.560554,-.257752,.463167,.574346,.599306,-.258076,.456452,.621655,.634541,-.256471,.443725,.670492,.668907,-.253283,.428719,.721943,.705619,-.247562,.411348,.772477,.739034,-.240626,.388939,.8264,.771408,-.231493,.36425,.881702,.803312,-.220125,.337321,.9385,.828457,-.206645,.305364,.997437,.854819,-.190664,.273715,1.05693,.878666,-.171429,.242218,1.11251,.898404,-.149235,.209556,1.16398,.917416,-.12435,.176863,1.21014,.933133,-.0972703,.142775,1.25178,.95066,-.0683607,.106735,1.29028,.968589,-.0378724,.0681609,1.32703,.984776,-.00605712,.0273966,1.36158,.99994,.0263276,-.0138124,1.3943,.00867437,-186005e-11,.0928979,173682e-12,.00864003,-466389e-10,.0925237,435505e-11,.00864593,-186594e-9,.0925806,174322e-10,.00864095,-419639e-9,.0924903,392862e-10,.00863851,-746272e-9,.0924589,702598e-10,.00868531,-.00116456,.0929,111188e-9,.00869667,-.00167711,.0928529,163867e-9,.00874332,-.00228051,.0930914,23104e-8,.00882709,-.00297864,.0935679,31741e-8,.00898874,-.00377557,.0946165,430186e-9,.00929346,-.00469247,.0967406,580383e-9,.00978271,-.00575491,.100084,783529e-9,.0105746,-.00701514,.105447,.00106304,.0116949,-.00851797,.112494,.00144685,.0130419,-.0102757,.119876,.00196439,.0148375,-.012381,.129034,.00266433,.0168725,-.01482,.137812,.00358364,.0193689,-.0176563,.147696,.00478132,.0222691,-.0209211,.157795,.00631721,.0256891,-.0246655,.168431,.00826346,.0294686,-.0288597,.178587,.0106714,.0340412,-.0336441,.190251,.0136629,.0393918,-.039033,.202999,.0173272,.0453947,-.0450087,.215655,.0217448,.0521936,-.0515461,.228686,.0269941,.0600279,-.058817,.242838,.033272,.0692398,-.0667228,.258145,.0406457,.0793832,-.0752401,.273565,.0492239,.0902297,-.0841851,.287735,.0590105,.102014,-.0936479,.301161,.0702021,.116054,-.103967,.317438,.0832001,.13191,-.114622,.334166,.0977951,.148239,-.125452,.348192,.113985,.165809,-.136453,.361094,.131928,.184616,-.147648,.373534,.151811,.207491,-.159607,.39101,.174476,.230106,-.171119,.402504,.198798,.257036,-.182906,.418032,.225796,.281172,-.193605,.425468,.254027,.312034,-.204771,.440379,.285713,.340402,-.214988,.445406,.319196,.370231,-.224711,.44968,.35537,.407105,-.233516,.460747,.393838,.439037,-.240801,.460624,.433747,.47781,-.24762,.465957,.477234,.510655,-.251823,.460054,.52044,.550584,-.255552,.459172,.567853,.585872,-.257036,.450311,.615943,.620466,-.257535,.437763,.667693,.660496,-.255248,.426639,.718988,.695578,-.251141,.409185,.772503,.732176,-.244718,.39015,.827023,.760782,-.236782,.362594,.885651,.79422,-.225923,.33711,.943756,.824521,-.213855,.308272,1.00874,.854964,-.197723,.278529,1.06764,.878065,-.179209,.246208,1.12836,.899834,-.157569,.21329,1.18318,.918815,-.133206,.181038,1.23161,.934934,-.106545,.146993,1.27644,.952115,-.0780574,.111175,1.31842,.96906,-.0478279,.0728553,1.35839,.985178,-.0160014,.032579,1.39697,1.00039,.0173126,-.0095256,1.43312,.00384146,-124311e-11,.0613583,778271e-13,.00390023,-314043e-10,.0622919,196626e-11,.00389971,-125622e-9,.0622632,787379e-11,.00389491,-282352e-9,.0620659,1778e-8,.00391618,-502512e-9,.0624687,320918e-10,.00392662,-784458e-9,.0625113,515573e-10,.00396053,-.00112907,.0628175,778668e-10,.00401911,-.00153821,.0633286,113811e-9,.00414994,-.0020208,.0646443,16445e-8,.00441223,-.00260007,.0673886,237734e-9,.00484427,-.0033097,.0716528,345929e-9,.00549109,-.00418966,.0774998,505987e-9,.00636293,-.00527331,.0844758,739208e-9,.00746566,-.00660428,.0921325,.00107347,.00876625,-.00818826,.0997067,.00153691,.0103125,-.0100811,.107433,.00217153,.0123309,-.0123643,.117088,.00303427,.0146274,-.0150007,.126438,.00416018,.0172295,-.0180531,.135672,.00561513,.0204248,-.0215962,.146244,.007478,.0241597,-.0256234,.157481,.00981046,.0284693,-.0302209,.169125,.0127148,.033445,-.0353333,.181659,.0162453,.0391251,-.0410845,.1944,.0205417,.0454721,-.0473451,.207082,.0256333,.0530983,-.0542858,.221656,.0317036,.0615356,-.0618384,.236036,.0388319,.0703363,-.0697631,.248398,.046974,.0810391,-.0784757,.263611,.0565246,.0920144,-.0873488,.275857,.0671724,.105584,-.0973652,.292555,.0798105,.119506,-.107271,.306333,.0935945,.134434,-.117608,.318888,.109106,.153399,-.128938,.337552,.127074,.171258,-.139944,.349955,.14643,.191059,-.151288,.361545,.168,.215069,-.163018,.378421,.192082,.237838,-.174226,.38879,.217838,.266965,-.186063,.405857,.246931,.292827,-.196909,.414146,.277505,.324352,-.207473,.426955,.310711,.354427,-.217713,.433429,.346794,.389854,-.227183,.443966,.385237,.420749,-.235131,.44471,.424955,.459597,-.242786,.451729,.468446,.495316,-.248767,.45072,.513422,.534903,-.253351,.450924,.560618,.572369,-.256277,.445266,.609677,.612383,-.2576,.438798,.660995,.644037,-.256931,.421693,.713807,.686749,-.254036,.4109,.767616,.719814,-.249785,.390151,.82533,.754719,-.244283,.367847,.888311,.792022,-.235076,.345013,.948177,.822404,-.225061,.316193,1.01661,.853084,-.211113,.287013,1.08075,.879871,-.19449,.255424,1.14501,.901655,-.174023,.222879,1.20203,.919957,-.1509,.18989,1.25698,.938412,-.124923,.15606,1.30588,.953471,-.0968139,.120512,1.3529,.970451,-.066734,.0828515,1.3986,.985522,-.034734,.0424458,1.44148,1.00099,-.00102222,678929e-9,1.48398,965494e-9,-627338e-12,.0306409,197672e-13,99168e-8,-158573e-10,.0314638,499803e-12,991068e-9,-634012e-10,.031363,200682e-11,974567e-9,-14144e-8,.03036,457312e-11,998079e-9,-252812e-9,.031496,860131e-11,.00102243,-396506e-9,.0319955,148288e-10,.00107877,-577593e-9,.0331376,249141e-10,.00121622,-816816e-9,.0359396,423011e-10,.0014455,-.00113761,.0399652,724613e-10,.00178791,-.00156959,.0450556,123929e-9,.00225668,-.00214064,.0508025,208531e-9,.00285627,-.00287655,.0568443,341969e-9,.0035991,-.00380271,.0630892,544158e-9,.00455524,-.00496264,.0702204,842423e-9,.00569143,-.0063793,.0773426,.00126704,.00716928,-.00813531,.0860839,.00186642,.00885307,-.0101946,.0944079,.00267014,.0109316,-.0126386,.103951,.00374033,.0133704,-.0154876,.113786,.0051304,.0161525,-.0187317,.123477,.00688858,.0194267,-.0224652,.133986,.00910557,.0230967,-.0265976,.143979,.0118074,.0273627,-.0312848,.154645,.0151266,.0323898,-.0365949,.166765,.0191791,.0379225,-.0422914,.177932,.0239236,.0447501,-.0487469,.19167,.0296568,.0519391,-.0556398,.203224,.0362924,.0599464,-.0631646,.215652,.0440585,.0702427,-.0714308,.232089,.0531619,.0806902,-.0800605,.245258,.0634564,.0923194,-.0892815,.258609,.0752481,.106938,-.09931,.276654,.0888914,.121238,-.109575,.289847,.104055,.138817,-.120461,.307566,.121266,.15595,-.131209,.320117,.139944,.178418,-.143049,.339677,.161591,.197875,-.154074,.349886,.184303,.224368,-.166307,.369352,.210669,.252213,-.178051,.386242,.238895,.277321,-.189335,.395294,.269182,.310332,-.200683,.412148,.302508,.338809,-.210856,.418266,.337264,.372678,-.220655,.428723,.374881,.405632,-.230053,.433887,.415656,.442293,-.237993,.439911,.457982,.477256,-.244897,.440175,.502831,.515592,-.250657,.441079,.550277,.550969,-.255459,.435219,.601102,.592883,-.257696,.432882,.651785,.629092,-.259894,.421054,.708961,.672033,-.258592,.41177,.763806,.709147,-.256525,.395267,.824249,.745367,-.254677,.375013,.8951,.784715,-.247892,.353906,.959317,.818107,-.240162,.327801,1.03153,.847895,-.229741,.298821,1.10601,.879603,-.213084,.269115,1.164,.902605,-.195242,.236606,1.22854,.922788,-.174505,.203442,1.29017,.944831,-.150169,.169594,1.34157,.959656,-.124099,.135909,1.3956,.972399,-.0960626,.0990563,1.45128,.986549,-.0657097,.0602348,1.50312,1.00013,-.0333558,.0186694,1.55364,619747e-11,-1e-7,.00778326,796756e-16,237499e-13,-999999e-13,282592e-10,114596e-15,100292e-11,-166369e-11,250354e-9,677492e-14,350752e-11,-637769e-11,357289e-9,631655e-13,826445e-11,-174689e-10,516179e-9,31851e-11,242481e-10,-450868e-10,.0010223,130577e-11,455631e-10,-89044e-9,.00144302,374587e-11,971222e-10,-178311e-9,.00241912,102584e-10,171403e-9,-313976e-9,.00354938,236481e-10,292747e-9,-520026e-9,.00513765,496014e-10,789827e-9,-.00118187,.0238621,139056e-9,.00114093,-.00171827,.0286691,244093e-9,.00176119,-.00249667,.0368565,420623e-9,.0022233,-.00333742,.0400469,65673e-8,.00343382,-.00481976,.0535751,.00109323,.00427602,-.00600755,.057099,.00155268,.00461435,-.00737637,.0551084,.00215031,.00695698,-.00971401,.0715767,.00316529,.00867619,-.0120943,.0793314,.00436995,.0106694,-.0148202,.0869391,.0058959,.0140351,-.0183501,.101572,.00798757,.0168939,-.022006,.11018,.0104233,.020197,-.0261568,.119041,.0134167,.0254702,-.0312778,.135404,.0173009,.0298384,-.0362469,.1437,.0215428,.035159,-.042237,.15512,.0268882,.0427685,-.0488711,.17128,.033235,.0494848,-.0557997,.181813,.0404443,.0592394,-.0635578,.198745,.0490043,.0681463,-.071838,.210497,.0588239,.0804753,-.0809297,.228864,.0702835,.0942205,-.0906488,.247008,.0834012,.106777,-.100216,.258812,.0975952,.124471,-.110827,.278617,.114162,.138389,-.121193,.287049,.131983,.159543,-.13253,.307151,.152541,.176432,-.143611,.31564,.174673,.201723,-.15548,.33538,.199842,.229721,-.167166,.355256,.227097,.250206,-.178238,.360047,.256014,.282118,-.189905,.378761,.28855,.312821,-.201033,.39181,.323348,.341482,-.211584,.397716,.360564,.377368,-.221314,.410141,.400004,.418229,-.230474,.423485,.442371,.444881,-.239443,.418874,.488796,.488899,-.245987,.427545,.535012,.520317,-.253948,.422147,.589678,.568566,-.256616,.42719,.637683,.599607,-.26376,.415114,.703363,.64222,-.268687,.408715,.771363,.685698,-.2694,.399722,.83574,.732327,-.266642,.388651,.897764,.769873,-.267712,.369198,.983312,.806733,-.263479,.346802,1.06222,.843466,-.254575,.321368,1.13477,.873008,-.242749,.29211,1.20712,.908438,-.22725,.262143,1.27465,.936321,-.207621,.228876,1.33203,.950353,-.187932,.19484,1.40439,.96442,-.165154,.163178,1.4732,.979856,-.139302,.127531,1.53574,.982561,-.11134,.0903457,1.59982,.996389,-.0808124,.0489007,1.6577],t=[1,0,0,0,1,791421e-36,0,0,1,104392e-29,0,0,1,349405e-26,0,0,1,109923e-23,0,0,1,947414e-22,0,0,1,359627e-20,0,0,1,772053e-19,0,0,1,108799e-17,0,0,1,110655e-16,0,0,1,865818e-16,0,0,.999998,545037e-15,0,0,.999994,285095e-14,0,0,.999989,126931e-13,0,0,.999973,489938e-13,0,0,.999947,166347e-12,0,0,.999894,502694e-12,0,0,.999798,136532e-11,0,0,.999617,335898e-11,0,0,.999234,752126e-11,0,0,.998258,152586e-10,0,0,.99504,266207e-10,0,0,.980816,236802e-10,0,0,.967553,207684e-11,0,0,.966877,403733e-11,0,0,.965752,741174e-11,0,0,.96382,127746e-10,0,0,.960306,202792e-10,0,0,.953619,280232e-10,0,0,.941103,278816e-10,0,0,.926619,160221e-10,0,0,.920983,235164e-10,0,0,.912293,311924e-10,0,.0158731,.899277,348118e-10,0,.0476191,.880884,26041e-9,0,.0793651,.870399,338726e-10,0,.111111,.856138,392906e-10,0,.142857,.837436,372874e-10,0,.174603,.820973,392558e-10,0,.206349,.803583,434658e-10,0,.238095,.782168,40256e-9,0,.269841,.764107,448159e-10,0,.301587,.743092,457627e-10,0,.333333,.721626,455314e-10,0,.365079,.700375,477335e-10,0,.396825,.677334,461072e-10,0,.428571,.655702,484393e-10,0,.460317,.632059,464583e-10,0,.492064,.610125,483923e-10,0,.52381,.58653,464342e-10,0,.555556,.564508,477033e-10,0,.587302,.541405,459263e-10,0,.619048,.519556,46412e-9,0,.650794,.497292,448913e-10,0,.68254,.475898,445789e-10,0,.714286,.454722,433496e-10,0,.746032,.434042,423054e-10,0,.777778,.414126,413737e-10,0,.809524,.394387,397265e-10,0,.84127,.375841,390709e-10,0,.873016,.357219,369938e-10,0,.904762,.340084,365618e-10,0,.936508,.322714,342533e-10,0,.968254,.306974,339596e-10,0,1,1,101524e-23,0,0,1,10292e-22,0,0,1,130908e-23,0,0,1,473331e-23,0,0,1,625319e-22,0,0,1,107932e-20,0,0,1,163779e-19,0,0,1,203198e-18,0,0,1,204717e-17,0,0,.999999,168995e-16,0,0,.999998,115855e-15,0,0,.999996,66947e-14,0,0,.999991,330863e-14,0,0,.999983,141737e-13,0,0,.999968,532626e-13,0,0,.99994,177431e-12,0,0,.999891,528835e-12,0,0,.999797,142169e-11,0,0,.999617,347057e-11,0,0,.999227,77231e-10,0,0,.998239,155753e-10,0,0,.994937,268495e-10,0,0,.980225,213742e-10,0,0,.967549,21631e-10,0,0,.966865,417989e-11,0,0,.965739,763341e-11,0,0,.963794,130892e-10,0,0,.960244,206456e-10,0,0,.953495,282016e-10,0,148105e-9,.940876,271581e-10,0,.002454,.926569,164159e-10,0,.00867491,.920905,239521e-10,0,.01956,.912169,315127e-10,0,.035433,.899095,346626e-10,0,.056294,.882209,290223e-10,0,.0818191,.870272,342992e-10,0,.111259,.855977,394164e-10,0,.142857,.837431,372343e-10,0,.174603,.820826,396691e-10,0,.206349,.803408,435395e-10,0,.238095,.782838,419579e-10,0,.269841,.763941,450953e-10,0,.301587,.742904,455847e-10,0,.333333,.721463,458833e-10,0,.365079,.700197,477159e-10,0,.396825,.677501,470641e-10,0,.428571,.655527,484732e-10,0,.460317,.6324,476834e-10,0,.492064,.609964,484213e-10,0,.52381,.586839,475541e-10,0,.555556,.564353,476951e-10,0,.587302,.541589,467611e-10,0,.619048,.519413,463493e-10,0,.650794,.497337,453994e-10,0,.68254,.475797,445308e-10,0,.714286,.454659,435787e-10,0,.746032,.434065,424839e-10,0,.777778,.414018,41436e-9,0,.809524,.39455,401902e-10,0,.84127,.375742,390813e-10,0,.873016,.357501,377116e-10,0,.904762,.339996,36535e-9,0,.936508,.323069,351265e-10,0,.968254,.306897,339112e-10,0,1,1,10396e-19,0,0,1,104326e-20,0,0,1,110153e-20,0,0,1,144668e-20,0,0,1,34528e-19,0,0,1,175958e-19,0,0,1,12627e-17,0,0,1,936074e-18,0,0,1,645742e-17,0,0,.999998,401228e-16,0,0,.999997,222338e-15,0,0,.999995,10967e-13,0,0,.999991,482132e-14,0,0,.999981,189434e-13,0,0,.999967,667716e-13,0,0,.999938,212066e-12,0,0,.999886,60977e-11,0,0,.999792,159504e-11,0,0,.999608,381191e-11,0,0,.999209,833727e-11,0,0,.998179,165288e-10,0,0,.994605,274387e-10,0,0,.979468,167316e-10,0,0,.967529,242877e-11,0,0,.966836,461696e-11,0,0,.96569,830977e-11,0,0,.963706,140427e-10,0,244659e-11,.960063,217353e-10,0,760774e-9,.953113,286606e-10,0,.00367261,.940192,247691e-10,0,.00940263,.927731,195814e-10,0,.018333,.920669,252531e-10,0,.0306825,.911799,324277e-10,0,.0465556,.89857,340982e-10,0,.0659521,.883283,319622e-10,0,.0887677,.86989,35548e-9,0,.114784,.855483,397143e-10,0,.143618,.837987,391665e-10,0,.174606,.820546,411306e-10,0,.206349,.802878,436753e-10,0,.238095,.783402,444e-7,0,.269841,.763439,458726e-10,0,.301587,.742925,467097e-10,0,.333333,.721633,478887e-10,0,.365079,.69985,481251e-10,0,.396825,.67783,491811e-10,0,.428571,.655126,488199e-10,0,.460318,.632697,496025e-10,0,.492064,.609613,48829e-9,0,.52381,.587098,492754e-10,0,.555556,.564119,482625e-10,0,.587302,.541813,482807e-10,0,.619048,.519342,471552e-10,0,.650794,.497514,466765e-10,0,.68254,.475879,455582e-10,0,.714286,.454789,446007e-10,0,.746032,.434217,435382e-10,0,.777778,.414086,421753e-10,0,.809524,.394744,412093e-10,0,.84127,.375782,396634e-10,0,.873016,.357707,386419e-10,0,.904762,.340038,370345e-10,0,.936508,.323284,359725e-10,0,.968254,.306954,3436e-8,0,1,1,599567e-19,0,0,1,600497e-19,0,0,1,614839e-19,0,0,1,686641e-19,0,0,1,972658e-19,0,0,1,221271e-18,0,0,1,833195e-18,0,0,1,403601e-17,0,0,.999999,206001e-16,0,0,.999998,101739e-15,0,0,.999997,470132e-15,0,0,.999993,200436e-14,0,0,.999988,783682e-14,0,0,.999979,280338e-13,0,0,.999962,917033e-13,0,0,.999933,274514e-12,0,0,.999881,753201e-12,0,0,.999783,189826e-11,0,0,.999594,440279e-11,0,0,.999178,93898e-10,0,0,.998073,181265e-10,0,0,.993993,280487e-10,0,0,.979982,149422e-10,0,0,.968145,378481e-11,0,0,.966786,53771e-10,0,0,.965611,947508e-11,0,388934e-10,.963557,156616e-10,0,9693e-7,.959752,235144e-10,0,.00370329,.952461,291568e-10,0,.00868428,.940193,240102e-10,0,.0161889,.929042,231235e-10,0,.0263948,.920266,273968e-10,0,.0394088,.911178,337915e-10,0,.0552818,.897873,333629e-10,0,.0740138,.884053,351405e-10,0,.0955539,.869455,378034e-10,0,.119795,.854655,399378e-10,0,.14656,.838347,419108e-10,0,.175573,.820693,440831e-10,0,.206388,.802277,445599e-10,0,.238095,.783634,472691e-10,0,.269841,.763159,476984e-10,0,.301587,.742914,491487e-10,0,.333333,.721662,502312e-10,0,.365079,.699668,502817e-10,0,.396825,.677839,51406e-9,0,.428571,.655091,511095e-10,0,.460317,.632665,516067e-10,0,.492064,.609734,512255e-10,0,.52381,.587043,510263e-10,0,.555556,.564298,50565e-9,0,.587302,.541769,497951e-10,0,.619048,.519529,492698e-10,0,.650794,.497574,482066e-10,0,.68254,.476028,473689e-10,0,.714286,.454961,461941e-10,0,.746032,.434341,450618e-10,0,.777778,.414364,438355e-10,0,.809524,.394832,424196e-10,0,.84127,.376109,412563e-10,0,.873016,.35779,396226e-10,0,.904762,.340379,384886e-10,0,.936508,.323385,368214e-10,0,.968254,.307295,356636e-10,0,1,1,106465e-17,0,0,1,106555e-17,0,0,1,107966e-17,0,0,1,114601e-17,0,0,1,137123e-17,0,0,1,21243e-16,0,0,.999999,489653e-17,0,0,.999999,160283e-16,0,0,.999998,62269e-15,0,0,.999997,251859e-15,0,0,.999996,996192e-15,0,0,.999992,374531e-14,0,0,.999986,132022e-13,0,0,.999975,433315e-13,0,0,.999959,131956e-12,0,0,.999927,372249e-12,0,0,.999871,972461e-12,0,0,.999771,235343e-11,0,0,.999572,52768e-10,0,0,.999133,109237e-10,0,0,.997912,203675e-10,0,0,.993008,279396e-10,0,0,.980645,139604e-10,0,0,.970057,646596e-11,0,0,.966717,65089e-10,0,474145e-10,.965497,111863e-10,0,89544e-8,.96334,179857e-10,0,.0032647,.959294,259045e-10,0,.0075144,.951519,292327e-10,0,.0138734,.940517,249769e-10,0,.0224952,.93014,26803e-9,0,.0334828,.91972,303656e-10,0,.0468973,.910294,353323e-10,0,.0627703,.897701,351002e-10,0,.0811019,.884522,388104e-10,0,.10186,.869489,412932e-10,0,.124985,.853983,415781e-10,0,.150372,.838425,454066e-10,0,.177868,.820656,471624e-10,0,.207245,.801875,475243e-10,0,.238143,.783521,505621e-10,0,.269841,.763131,50721e-9,0,.301587,.74261,523293e-10,0,.333333,.72148,528699e-10,0,.365079,.699696,538677e-10,0,.396825,.677592,539255e-10,0,.428571,.65525,546367e-10,0,.460317,.632452,541348e-10,0,.492064,.609903,544976e-10,0,.52381,.586928,536201e-10,0,.555556,.564464,535185e-10,0,.587302,.541801,524949e-10,0,.619048,.519681,51812e-9,0,.650794,.497685,507687e-10,0,.68254,.47622,496243e-10,0,.714286,.455135,485714e-10,0,.746032,.4346,471847e-10,0,.777778,.414564,459294e-10,0,.809524,.395165,444705e-10,0,.84127,.376333,430772e-10,0,.873016,.358197,416229e-10,0,.904762,.34064,401019e-10,0,.936508,.323816,386623e-10,0,.968254,.307581,370933e-10,0,1,1,991541e-17,0,0,1,992077e-17,0,0,1,100041e-16,0,0,1,10385e-15,0,0,1,115777e-16,0,0,1,150215e-16,0,0,.999999,254738e-16,0,0,.999999,598822e-16,0,0,.999998,179597e-15,0,0,.999997,602367e-15,0,0,.999994,206835e-14,0,0,.99999,694952e-14,0,0,.999984,223363e-13,0,0,.999972,678578e-13,0,0,.999952,193571e-12,0,0,.999919,516594e-12,0,0,.99986,128739e-11,0,0,.999753,299298e-11,0,0,.999546,648258e-11,0,0,.999074,129985e-10,0,0,.997671,232176e-10,0,0,.991504,256701e-10,0,0,.981148,131141e-10,0,0,.971965,869048e-11,0,280182e-10,.966624,808301e-11,0,695475e-9,.965344,135235e-10,0,.00265522,.963048,210592e-10,0,.00622975,.958673,287473e-10,0,.0116234,.950262,281379e-10,0,.018976,.940836,271089e-10,0,.0283844,.930996,30926e-9,0,.0399151,.919848,348359e-10,0,.0536063,.909136,366092e-10,0,.0694793,.897554,384162e-10,0,.0875342,.884691,430971e-10,0,.107749,.869414,447803e-10,0,.130087,.853462,452858e-10,0,.154481,.838187,495769e-10,0,.180833,.820381,502709e-10,0,.209005,.801844,522713e-10,0,.238791,.783061,541505e-10,0,.269869,.763205,553712e-10,0,.301587,.742362,564909e-10,0,.333333,.721393,572646e-10,0,.365079,.699676,581012e-10,0,.396825,.677395,58096e-9,0,.428571,.655208,585766e-10,0,.460317,.632451,583602e-10,0,.492064,.609839,580234e-10,0,.52381,.587093,577161e-10,0,.555556,.564467,568447e-10,0,.587302,.542043,563166e-10,0,.619048,.519826,55156e-9,0,.650794,.497952,541682e-10,0,.68254,.476477,528971e-10,0,.714286,.455412,514952e-10,0,.746032,.434926,502222e-10,0,.777778,.4149,485779e-10,0,.809524,.395552,472242e-10,0,.84127,.376712,454891e-10,0,.873016,.358622,440924e-10,0,.904762,.341048,422984e-10,0,.936508,.324262,408582e-10,0,.968254,.308013,390839e-10,0,1,1,613913e-16,0,0,1,614145e-16,0,0,1,617708e-16,0,0,1,633717e-16,0,0,1,681648e-16,0,0,1,808291e-16,0,0,1,114608e-15,0,0,.999998,210507e-15,0,0,.999997,499595e-15,0,0,.999995,139897e-14,0,0,.999994,419818e-14,0,0,.999988,127042e-13,0,0,.999979,375153e-13,0,0,.999965,106206e-12,0,0,.999945,285381e-12,0,0,.999908,723611e-12,0,0,.999846,17255e-10,0,0,.999733,386104e-11,0,0,.999511,808493e-11,0,0,.998993,156884e-10,0,0,.997326,265538e-10,0,0,.989706,206466e-10,0,0,.981713,130756e-10,0,70005e-10,.973636,106473e-10,0,464797e-9,.966509,10194e-9,0,.00201743,.965149,165881e-10,0,.00497549,.962669,249147e-10,0,.00953262,.95786,317449e-10,0,.0158211,.949334,281045e-10,0,.0239343,.941041,303263e-10,0,.0339372,.931575,356754e-10,0,.0458738,.920102,397075e-10,0,.059772,.908002,384886e-10,0,.075645,.897269,43027e-9,0,.0934929,.884559,479925e-10,0,.113302,.869161,48246e-9,0,.135045,.853342,509505e-10,0,.158678,.837633,542846e-10,0,.184136,.820252,554139e-10,0,.211325,.801872,581412e-10,0,.240113,.782418,585535e-10,0,.270306,.7631,610923e-10,0,.301594,.742183,613678e-10,0,.333333,.721098,627275e-10,0,.365079,.699512,629413e-10,0,.396825,.677372,636351e-10,0,.428571,.655059,633555e-10,0,.460317,.632567,636513e-10,0,.492064,.609784,628965e-10,0,.52381,.587237,625546e-10,0,.555556,.564525,615825e-10,0,.587302,.542181,605048e-10,0,.619048,.520017,596329e-10,0,.650794,.498204,581516e-10,0,.68254,.476742,569186e-10,0,.714286,.455803,553833e-10,0,.746032,.435251,537807e-10,0,.777778,.415374,522025e-10,0,.809524,.395921,503421e-10,0,.84127,.377253,488211e-10,0,.873016,.359021,468234e-10,0,.904762,.341637,453269e-10,0,.936508,.3247,433014e-10,0,.968254,.308625,418007e-10,0,1,1,286798e-15,0,0,1,286877e-15,0,0,1,288094e-15,0,0,1,293506e-15,0,0,1,309262e-15,0,0,.999999,348593e-15,0,0,.999999,444582e-15,0,0,.999998,688591e-15,0,0,.999996,134391e-14,0,0,.999993,317438e-14,0,0,.999989,835609e-14,0,0,.999983,228677e-13,0,0,.999974,623361e-13,0,0,.999959,165225e-12,0,0,.999936,419983e-12,0,0,.999896,101546e-11,0,0,.99983,232376e-11,0,0,.999709,50156e-10,0,0,.999469,10167e-9,0,0,.998886,190775e-10,0,0,.996819,300511e-10,0,0,.988837,185092e-10,0,168222e-12,.982178,134622e-10,0,259622e-9,.975017,125961e-10,0,.00142595,.967101,13507e-9,0,.00382273,.964905,205003e-10,0,.00764164,.96218,29546e-9,0,.0130121,.956821,343738e-10,0,.0200253,.948829,305063e-10,0,.0287452,.941092,346487e-10,0,.039218,.931883,412061e-10,0,.0514748,.920211,444651e-10,0,.0655351,.907307,431252e-10,0,.0814082,.89684,490382e-10,0,.0990939,.884119,53334e-9,0,.118583,.869148,54114e-9,0,.139856,.853377,578536e-10,0,.162882,.836753,592285e-10,0,.187615,.820063,622787e-10,0,.213991,.801694,645492e-10,0,.241918,.782116,65353e-9,0,.271267,.762673,674344e-10,0,.301847,.742133,682788e-10,0,.333333,.720779,691959e-10,0,.365079,.699386,696817e-10,0,.396826,.67732,699583e-10,0,.428572,.654888,698447e-10,0,.460318,.632499,694063e-10,0,.492064,.609825,691612e-10,0,.52381,.587287,681576e-10,0,.555556,.564743,674138e-10,0,.587302,.542409,661617e-10,0,.619048,.520282,647785e-10,0,.650794,.498506,633836e-10,0,.68254,.477102,615905e-10,0,.714286,.456167,601013e-10,0,.746032,.435728,581457e-10,0,.777778,.415809,564215e-10,0,.809524,.396517,544997e-10,0,.84127,.377737,525061e-10,0,.873016,.359698,506831e-10,0,.904762,.342164,48568e-9,0,.936508,.325417,467826e-10,0,.968254,.309186,446736e-10,0,1,1,109018e-14,0,0,1,10904e-13,0,0,1,109393e-14,0,0,1,11095e-13,0,0,1,1154e-12,0,0,1,126089e-14,0,0,.999999,15059e-13,0,0,.999997,207899e-14,0,0,.999994,348164e-14,0,0,.999993,705728e-14,0,0,.999987,163692e-13,0,0,.999981,406033e-13,0,0,.999969,10245e-11,0,0,.999953,255023e-12,0,0,.999925,61511e-11,0,0,.999881,142218e-11,0,0,.99981,313086e-11,0,0,.99968,653119e-11,0,0,.999418,12832e-9,0,0,.998748,232497e-10,0,0,.996066,329522e-10,0,0,.988379,179613e-10,0,108799e-9,.982567,143715e-10,0,921302e-9,.976097,148096e-10,0,.00280738,.968475,178905e-10,0,.00596622,.964606,253921e-10,0,.0105284,.961564,348623e-10,0,.0165848,.955517,357612e-10,0,.0242,.948381,343493e-10,0,.03342,.941095,405849e-10,0,.0442777,.931923,475394e-10,0,.0567958,.91996,484328e-10,0,.0709879,.907419,502146e-10,0,.086861,.89618,561654e-10,0,.104415,.88337,587612e-10,0,.123643,.869046,618057e-10,0,.144531,.853278,657392e-10,0,.167057,.836091,66303e-9,0,.191188,.819644,704445e-10,0,.216878,.801246,714071e-10,0,.244062,.782031,740093e-10,0,.272649,.762066,74685e-9,0,.302509,.741964,766647e-10,0,.333442,.720554,766328e-10,0,.365079,.699098,777857e-10,0,.396826,.677189,774633e-10,0,.428572,.65484,776235e-10,0,.460318,.632496,770316e-10,0,.492064,.609908,762669e-10,0,.52381,.587312,753972e-10,0,.555556,.564938,739994e-10,0,.587302,.542577,728382e-10,0,.619048,.52062,71112e-9,0,.650794,.498819,694004e-10,0,.68254,.477555,675575e-10,0,.714286,.456568,653449e-10,0,.746032,.436278,636068e-10,0,.777778,.41637,613466e-10,0,.809524,.397144,594177e-10,0,.84127,.378412,570987e-10,0,.873016,.360376,550419e-10,0,.904762,.342906,527422e-10,0,.936508,.326136,506544e-10,0,.968254,.30997,484307e-10,0,1,1,354014e-14,0,0,1,354073e-14,0,0,1,354972e-14,0,0,1,358929e-14,0,0,1,370093e-14,0,0,.999999,396194e-14,0,0,.999998,453352e-14,0,0,.999997,578828e-14,0,0,.999994,863812e-14,0,0,.999991,153622e-13,0,0,.999985,316356e-13,0,0,.999977,712781e-13,0,0,.999964,166725e-12,0,0,.999945,390501e-12,0,0,.999912,895622e-12,0,0,.999866,198428e-11,0,0,.999786,421038e-11,0,0,.999647,850239e-11,0,0,.999356,162059e-10,0,0,.998563,282652e-10,0,0,.994928,336309e-10,0,244244e-10,.987999,178458e-10,0,523891e-9,.982893,159162e-10,0,.00194729,.977044,178056e-10,0,.00451099,.969972,230624e-10,0,.00835132,.964237,313922e-10,0,.013561,.960791,406145e-10,0,.0202056,.954292,372796e-10,0,.0283321,.948052,403199e-10,0,.0379739,.940938,479537e-10,0,.0491551,.931689,545292e-10,0,.0618918,.91987,54038e-9,0,.0761941,.907665,589909e-10,0,.0920672,.895281,642651e-10,0,.109511,.882621,659707e-10,0,.12852,.86873,709973e-10,0,.149085,.853008,742221e-10,0,.171189,.835944,761754e-10,0,.194809,.818949,797052e-10,0,.21991,.800951,812434e-10,0,.246447,.781847,838075e-10,0,.274352,.761649,84501e-9,0,.303535,.74152,860258e-10,0,.333857,.720495,866233e-10,0,.365104,.698742,868326e-10,0,.396826,.677096,87133e-9,0,.428572,.654782,863497e-10,0,.460318,.632335,860206e-10,0,.492064,.610031,849337e-10,0,.52381,.587457,838279e-10,0,.555556,.56513,82309e-9,0,.587302,.542877,803542e-10,0,.619048,.5209,786928e-10,0,.650794,.499291,765171e-10,0,.68254,.477971,744753e-10,0,.714286,.457221,72209e-9,0,.746032,.436803,697448e-10,0,.777778,.417083,675333e-10,0,.809524,.397749,648058e-10,0,.84127,.379177,625759e-10,0,.873016,.361061,598584e-10,0,.904762,.343713,575797e-10,0,.936508,.326894,549999e-10,0,.968254,.310816,527482e-10,0,1,1,10153e-12,0,0,1,101544e-13,0,0,1,101751e-13,0,0,1,102662e-13,0,0,1,10521e-12,0,0,.999999,111049e-13,0,0,.999999,123408e-13,0,0,.999996,14924e-12,0,0,.999992,204471e-13,0,0,.999989,326539e-13,0,0,.99998,603559e-13,0,0,.999971,123936e-12,0,0,.999955,269058e-12,0,0,.999933,593604e-12,0,0,.999901,129633e-11,0,0,.999847,275621e-11,0,0,.999761,564494e-11,0,0,.999607,110485e-10,0,0,.999282,204388e-10,0,0,.99831,341084e-10,0,22038e-11,.993288,294949e-10,0,242388e-9,.987855,192736e-10,0,.0012503,.983167,182383e-10,0,.0032745,.977908,218633e-10,0,.00646321,.971194,290662e-10,0,.0109133,.963867,386401e-10,0,.0166927,.95982,462827e-10,0,.0238494,.953497,420705e-10,0,.0324178,.947621,477743e-10,0,.0424225,.940611,568258e-10,0,.0538808,.931174,618061e-10,0,.0668047,.919919,627098e-10,0,.0812014,.907856,694714e-10,0,.0970745,.894509,735008e-10,0,.114424,.881954,763369e-10,0,.133246,.868309,821896e-10,0,.153534,.852511,83769e-9,0,.175275,.835821,881615e-10,0,.198453,.817981,896368e-10,0,.223042,.800504,930906e-10,0,.249009,.78141,945056e-10,0,.276304,.761427,963605e-10,0,.304862,.74094,968088e-10,0,.334584,.720233,981481e-10,0,.365322,.698592,979122e-10,0,.396826,.676763,981057e-10,0,.428571,.654808,973956e-10,0,.460318,.632326,962619e-10,0,.492064,.610049,952996e-10,0,.52381,.58763,933334e-10,0,.555556,.565261,917573e-10,0,.587302,.543244,896636e-10,0,.619048,.521273,873304e-10,0,.650794,.499818,852648e-10,0,.68254,.478536,823961e-10,0,.714286,.457826,79939e-9,0,.746032,.437549,77126e-9,0,.777778,.41776,743043e-10,0,.809524,.39863,716426e-10,0,.84127,.379954,686456e-10,0,.873016,.362025,660514e-10,0,.904762,.344581,630755e-10,0,.936508,.327909,605439e-10,0,.968254,.311736,576345e-10,0,1,1,263344e-13,0,0,1,263373e-13,0,0,1,263815e-13,0,0,1,265753e-13,0,0,1,271132e-13,0,0,.999999,283279e-13,0,0,.999997,30833e-12,0,0,.999995,358711e-13,0,0,.999992,461266e-13,0,0,.999985,67574e-12,0,0,.999977,11358e-11,0,0,.999966,213657e-12,0,0,.999948,431151e-12,0,0,.999923,896656e-12,0,0,.999884,186603e-11,0,0,.999826,381115e-11,0,0,.999732,754184e-11,0,0,.999561,143192e-10,0,0,.999191,257061e-10,0,0,.997955,405724e-10,0,744132e-10,.992228,276537e-10,0,716477e-9,.987638,208885e-10,0,.0022524,.983395,215226e-10,0,.00484816,.978614,270795e-10,0,.00860962,.972389,365282e-10,0,.0136083,.964392,474747e-10,0,.0198941,.95861,509141e-10,0,.0275023,.952806,48963e-9,0,.0364584,.94712,571119e-10,0,.04678,.940104,671704e-10,0,.0584799,.930398,687586e-10,0,.0715665,.919866,738161e-10,0,.086045,.907853,813235e-10,0,.101918,.894078,834582e-10,0,.119186,.881177,892093e-10,0,.137845,.867575,944548e-10,0,.157891,.852107,969607e-10,0,.179316,.835502,101456e-9,0,.202106,.81756,103256e-9,0,.226243,.79984,106954e-9,0,.251704,.780998,108066e-9,0,.278451,.761132,110111e-9,0,.306436,.740429,110459e-9,0,.335586,.719836,111219e-9,0,.365796,.698467,11145e-8,0,.3969,.676446,110393e-9,0,.428571,.654635,110035e-9,0,.460318,.632411,108548e-9,0,.492064,.609986,106963e-9,0,.52381,.587872,105238e-9,0,.555556,.565528,102665e-9,0,.587302,.543563,100543e-9,0,.619048,.52176,976182e-10,0,.650794,.500188,947099e-10,0,.68254,.479204,919929e-10,0,.714286,.458413,886139e-10,0,.746032,.438314,857839e-10,0,.777778,.418573,82411e-9,0,.809524,.39947,792211e-10,0,.84127,.380892,759546e-10,0,.873016,.362953,727571e-10,0,.904762,.345601,695738e-10,0,.936508,.328895,664907e-10,0,.968254,.312808,634277e-10,0,1,1,628647e-13,0,0,1,628705e-13,0,0,1,629587e-13,0,0,1,633441e-13,0,0,.999999,644087e-13,0,0,.999998,667856e-13,0,0,.999997,715889e-13,0,0,.999995,809577e-13,0,0,.999989,992764e-13,0,0,.999983,135834e-12,0,0,.999974,210482e-12,0,0,.999959,365215e-12,0,0,.999939,686693e-12,0,0,.999911,13472e-10,0,0,.999868,26731e-10,0,0,.999804,524756e-11,0,0,.9997,100403e-10,0,0,.99951,185019e-10,0,0,.999078,322036e-10,0,620676e-11,.997428,470002e-10,0,341552e-9,.99162,287123e-10,0,.00143727,.987479,234706e-10,0,.00349201,.983582,260083e-10,0,.0066242,.979186,337927e-10,0,.0109113,.97325,454689e-10,0,.0164064,.965221,573759e-10,0,.0231463,.957262,544114e-10,0,.0311571,.952211,587006e-10,0,.0404572,.946631,692256e-10,0,.0510592,.939391,787819e-10,0,.0629723,.929795,792368e-10,0,.0762025,.91965,875075e-10,0,.090753,.907737,950903e-10,0,.106626,.893899,972963e-10,0,.123822,.880239,10459e-8,0,.142337,.866562,107689e-9,0,.16217,.85164,113081e-9,0,.183314,.835021,116636e-9,0,.20576,.817311,120074e-9,0,.229496,.798845,121921e-9,0,.254502,.780479,12475e-8,0,.280753,.760694,125255e-9,0,.308212,.740142,126719e-9,0,.336825,.719248,12636e-8,0,.366517,.698209,126712e-9,0,.397167,.676398,125769e-9,0,.428578,.654378,124432e-9,0,.460318,.632484,123272e-9,0,.492064,.610113,12085e-8,0,.52381,.587931,118411e-9,0,.555556,.565872,11569e-8,0,.587302,.543814,112521e-9,0,.619048,.522265,109737e-9,0,.650794,.500835,106228e-9,0,.68254,.479818,102591e-9,0,.714286,.459258,991288e-10,0,.746032,.439061,952325e-10,0,.777778,.419552,91895e-9,0,.809524,.400399,879051e-10,0,.84127,.381976,844775e-10,0,.873016,.364009,806316e-10,0,.904762,.346761,771848e-10,0,.936508,.330049,735429e-10,0,.968254,.314018,702103e-10,0,1,1,139968e-12,0,0,1,139979e-12,0,0,1,140145e-12,0,0,1,14087e-11,0,0,.999999,142865e-12,0,0,.999998,147279e-12,0,0,.999997,156057e-12,0,0,.999992,17276e-11,0,0,.999989,204352e-12,0,0,.99998,26494e-11,0,0,.999969,383435e-12,0,0,.999953,618641e-12,0,0,.999929,108755e-11,0,0,.999898,201497e-11,0,0,.999849,381346e-11,0,0,.999778,719815e-11,0,0,.999661,133215e-10,0,0,.999451,238313e-10,0,0,.998936,401343e-10,0,113724e-9,.99662,517346e-10,0,820171e-9,.991094,304323e-10,0,.00238143,.987487,281757e-10,0,.00493527,.983731,320048e-10,0,.00856859,.979647,423905e-10,0,.0133393,.973837,562935e-10,0,.0192863,.96584,677442e-10,0,.0264369,.956309,623073e-10,0,.03481,.951523,704131e-10,0,.0444184,.946003,836594e-10,0,.0552713,.938454,911736e-10,0,.0673749,.929279,938264e-10,0,.0807329,.919239,103754e-9,0,.0953479,.907293,109928e-9,0,.111221,.893936,115257e-9,0,.128352,.879674,122265e-9,0,.14674,.865668,125733e-9,0,.166382,.850998,132305e-9,0,.187276,.834498,134844e-9,0,.209413,.816903,139276e-9,0,.232786,.798235,140984e-9,0,.257382,.779724,14378e-8,0,.283181,.760251,144623e-9,0,.310156,.739808,145228e-9,0,.338269,.718762,14539e-8,0,.367461,.697815,144432e-9,0,.397646,.67631,143893e-9,0,.428685,.654278,141846e-9,0,.460318,.632347,13935e-8,0,.492064,.610296,137138e-9,0,.52381,.588039,133806e-9,0,.555556,.566218,130755e-9,0,.587302,.544346,127128e-9,0,.619048,.522701,123002e-9,0,.650794,.501542,119443e-9,0,.68254,.480508,115055e-9,0,.714286,.460092,111032e-9,0,.746032,.440021,106635e-9,0,.777778,.420446,102162e-9,0,.809524,.401512,98184e-9,0,.84127,.38299,936497e-10,0,.873016,.365232,89813e-9,0,.904762,.347865,853073e-10,0,.936508,.331342,817068e-10,0,.968254,.315202,773818e-10,0,1,1,29368e-11,0,0,1,2937e-10,0,0,1,293998e-12,0,0,1,295298e-12,0,0,.999999,298865e-12,0,0,.999998,3067e-10,0,0,.999995,322082e-12,0,0,.999992,350767e-12,0,0,.999986,403538e-12,0,0,.999976,501372e-12,0,0,.999964,68562e-11,0,0,.999945,10374e-10,0,0,.999919,171269e-11,0,0,.999882,300175e-11,0,0,.999829,542144e-11,0,0,.999749,984182e-11,0,0,.99962,176213e-10,0,0,.999382,305995e-10,0,138418e-10,.998751,496686e-10,0,389844e-9,.995344,510733e-10,0,.00150343,.990768,345829e-10,0,.00352451,.987464,342841e-10,0,.00655379,.983846,399072e-10,0,.0106554,.980007,533219e-10,0,.0158723,.974494,696992e-10,0,.0222333,.96622,776754e-10,0,.029758,.956273,747718e-10,0,.0384596,.950952,864611e-10,0,.0483473,.945215,100464e-9,0,.0594266,.937287,103729e-9,0,.0717019,.928649,111665e-9,0,.0851752,.918791,12353e-8,0,.0998479,.906685,127115e-9,0,.115721,.893706,13628e-8,0,.132794,.879248,142427e-9,0,.151067,.864685,148091e-9,0,.170538,.850032,153517e-9,0,.191204,.833853,157322e-9,0,.213063,.816353,161086e-9,0,.236107,.797834,164111e-9,0,.260329,.778831,165446e-9,0,.285714,.759756,167492e-9,0,.312243,.739419,166928e-9,0,.339887,.718491,167e-6,0,.368604,.697392,165674e-9,0,.398329,.676102,163815e-9,0,.428961,.654243,162003e-9,0,.460331,.632176,158831e-9,0,.492064,.610407,155463e-9,0,.52381,.588394,152062e-9,0,.555556,.56645,147665e-9,0,.587302,.5449,14375e-8,0,.619048,.523276,138905e-9,0,.650794,.502179,134189e-9,0,.68254,.481359,129392e-9,0,.714286,.46092,124556e-9,0,.746032,.441084,11957e-8,0,.777778,.421517,114652e-9,0,.809524,.402721,109688e-9,0,.84127,.384222,104667e-9,0,.873016,.366534,999633e-10,0,.904762,.349205,950177e-10,0,.936508,.332702,907301e-10,0,.968254,.316599,859769e-10,0,1,1,585473e-12,0,0,1,585507e-12,0,0,1,58602e-11,0,0,.999999,588259e-12,0,0,.999999,594381e-12,0,0,.999998,607754e-12,0,0,.999995,633729e-12,0,0,.99999,68137e-11,0,0,.999984,767003e-12,0,0,.999973,921212e-12,0,0,.999959,120218e-11,0,0,.999936,172024e-11,0,0,.999907,268088e-11,0,0,.999866,445512e-11,0,0,.999806,768481e-11,0,0,.999716,1342e-8,0,0,.999576,232473e-10,0,0,.9993,391694e-10,0,129917e-9,.998498,608429e-10,0,845035e-9,.994132,489743e-10,0,.00237616,.99031,384644e-10,0,.00484456,.987409,421768e-10,0,.00832472,.983981,504854e-10,0,.0128643,.980268,671028e-10,0,.0184947,.974875,852749e-10,0,.025237,.966063,85531e-9,0,.0331046,.956779,900588e-10,0,.0421067,.950259,10577e-8,0,.0522487,.944239,119458e-9,0,.0635343,.936341,122164e-9,0,.0759654,.928047,134929e-9,0,.0895434,.918065,145544e-9,0,.104269,.906267,150531e-9,0,.120142,.893419,161652e-9,0,.137163,.878758,16593e-8,0,.15533,.863699,174014e-9,0,.174645,.848876,177877e-9,0,.195106,.833032,184049e-9,0,.21671,.815557,186088e-9,0,.239454,.797323,19054e-8,0,.263332,.778124,191765e-9,0,.288336,.758929,192535e-9,0,.314451,.738979,192688e-9,0,.341658,.718213,191522e-9,0,.369924,.696947,190491e-9,0,.399202,.675807,187913e-9,0,.429416,.654147,184451e-9,0,.460447,.63229,181442e-9,0,.492064,.610499,177139e-9,0,.523809,.588747,172596e-9,0,.555555,.566783,167457e-9,0,.587301,.545359,162518e-9,0,.619048,.523984,156818e-9,0,.650794,.502917,151884e-9,0,.68254,.482294,145514e-9,0,.714286,.461945,140199e-9,0,.746032,.442133,134101e-9,0,.777778,.422705,128374e-9,0,.809524,.403916,122996e-9,0,.84127,.38554,116808e-9,0,.873016,.367909,111973e-9,0,.904762,.350651,105938e-9,0,.936508,.334208,101355e-9,0,.968254,.318123,957629e-10,0,1,1,111633e-11,0,0,1,111639e-11,0,0,1,111725e-11,0,0,1,112096e-11,0,0,.999999,11311e-10,0,0,.999997,115315e-11,0,0,.999995,11956e-10,0,0,.999989,127239e-11,0,0,.999981,140772e-11,0,0,.999969,164541e-11,0,0,.999952,206607e-11,0,0,.999928,281783e-11,0,0,.999895,416835e-11,0,0,.999848,658728e-11,0,0,.999781,108648e-10,0,0,.999682,182579e-10,0,0,.999523,306003e-10,0,159122e-10,.999205,499862e-10,0,391184e-9,.998131,73306e-9,0,.00147534,.993334,513229e-10,0,.0034227,.99016,467783e-10,0,.00632232,.987321,523413e-10,0,.0102295,.984099,64267e-9,0,.0151794,.980432,843042e-10,0,.0211947,.974976,102819e-9,0,.0282899,.966429,996234e-10,0,.0364739,.957633,111074e-9,0,.0457522,.949422,128644e-9,0,.0561278,.943045,140076e-9,0,.0676023,.935448,146349e-9,0,.0801762,.927225,161854e-9,0,.0938499,.917033,169135e-9,0,.108623,.905762,179987e-9,0,.124496,.892879,189832e-9,0,.141469,.878435,195881e-9,0,.159541,.863114,20466e-8,0,.178713,.84776,209473e-9,0,.198985,.832084,214861e-9,0,.220355,.814915,217695e-9,0,.242823,.796711,220313e-9,0,.266385,.777603,22313e-8,0,.291036,.757991,222471e-9,0,.316767,.738371,222869e-9,0,.343563,.717872,221243e-9,0,.371402,.696619,218089e-9,0,.400248,.675379,21562e-8,0,.430047,.65411,21169e-8,0,.460709,.63241,206947e-9,0,.492079,.61046,201709e-9,0,.52381,.58903,196753e-9,0,.555556,.567267,189637e-9,0,.587302,.545886,184735e-9,0,.619048,.524714,177257e-9,0,.650794,.503789,171424e-9,0,.68254,.483204,164688e-9,0,.714286,.462976,157172e-9,0,.746032,.443294,151341e-9,0,.777778,.423988,143737e-9,0,.809524,.405325,138098e-9,0,.84127,.386981,130698e-9,0,.873016,.369436,125276e-9,0,.904762,.35219,118349e-9,0,.936508,.335804,11312e-8,0,.968254,.319749,106687e-9,0,1,1,204685e-11,0,0,1,204694e-11,0,0,1,204831e-11,0,0,.999999,205428e-11,0,0,.999999,207056e-11,0,0,.999997,210581e-11,0,0,.999993,21732e-10,0,0,.999987,229365e-11,0,0,.999979,250243e-11,0,0,.999965,286127e-11,0,0,.999947,348028e-11,0,0,.999918,455588e-11,0,0,.999881,643303e-11,0,0,.999828,970064e-11,0,0,.999753,153233e-10,0,0,.999642,24793e-9,0,0,.999464,402032e-10,0,122947e-9,.999089,635852e-10,0,807414e-9,.997567,857026e-10,0,.00227206,.992903,594912e-10,0,.00462812,.990011,578515e-10,0,.00794162,.987192,65399e-9,0,.0122534,.98418,819675e-10,0,.0175888,.980491,105514e-9,0,.0239635,.974779,121532e-9,0,.031387,.96675,119144e-9,0,.0398644,.958248,136125e-9,0,.0493982,.948884,155408e-9,0,.0599896,.941673,162281e-9,0,.0716382,.934521,176754e-9,0,.0843437,.926205,192873e-9,0,.0981056,.916089,200038e-9,0,.112923,.904963,213624e-9,0,.128796,.892089,221834e-9,0,.145725,.878028,232619e-9,0,.163709,.86249,238632e-9,0,.182749,.846587,247002e-9,0,.202847,.830988,250702e-9,0,.224001,.814165,255562e-9,0,.246214,.796135,257505e-9,0,.269482,.777052,258625e-9,0,.293805,.757201,258398e-9,0,.319176,.737655,256714e-9,0,.345587,.717477,255187e-9,0,.373021,.696433,251792e-9,0,.401454,.675084,247223e-9,0,.430844,.653907,242213e-9,0,.461125,.632561,237397e-9,0,.492187,.610658,229313e-9,0,.52381,.589322,224402e-9,0,.555556,.567857,216116e-9,0,.587302,.54652,209124e-9,0,.619048,.525433,201601e-9,0,.650794,.504679,192957e-9,0,.68254,.484203,186052e-9,0,.714286,.464203,177672e-9,0,.746032,.444549,170005e-9,0,.777778,.425346,162401e-9,0,.809524,.406706,1544e-7,0,.84127,.388576,147437e-9,0,.873016,.37094,139493e-9,0,.904762,.353996,133219e-9,0,.936508,.337391,125573e-9,0,.968254,.321648,119867e-9,0,1,1,362511e-11,0,0,1,362525e-11,0,0,1,362739e-11,0,0,.999999,363673e-11,0,0,.999998,366214e-11,0,0,.999996,371698e-11,0,0,.999992,382116e-11,0,0,.999986,400554e-11,0,0,.999976,432058e-11,0,0,.999961,485194e-11,0,0,.999938,574808e-11,0,0,.999908,726643e-11,0,0,.999865,984707e-11,0,0,.999807,142217e-10,0,0,.999723,215581e-10,0,0,.999602,336114e-10,0,119113e-10,.999398,527353e-10,0,355813e-9,.998946,805809e-10,0,.00137768,.996647,942908e-10,0,.00322469,.992298,668733e-10,0,.00597897,.989802,716564e-10,0,.00968903,.987019,821355e-10,0,.0143845,.984219,104555e-9,0,.0200831,.980425,131245e-9,0,.0267948,.974241,139613e-9,0,.034525,.967006,145931e-9,0,.0432757,.95893,167153e-9,0,.0530471,.949157,188146e-9,0,.0638386,.94062,194625e-9,0,.0756487,.933509,213721e-9,0,.0884762,.925088,229616e-9,0,.10232,.915178,239638e-9,0,.117178,.904093,254814e-9,0,.133051,.891337,263685e-9,0,.149939,.877326,274789e-9,0,.167841,.861794,280534e-9,0,.18676,.845758,289534e-9,0,.206696,.829792,294446e-9,0,.22765,.813037,296877e-9,0,.249625,.795285,300217e-9,0,.27262,.776323,299826e-9,0,.296636,.756673,299787e-9,0,.321671,.736856,297867e-9,0,.347718,.716883,294052e-9,0,.374768,.696089,289462e-9,0,.402804,.67505,285212e-9,0,.431796,.653509,27653e-8,0,.461695,.63258,271759e-9,0,.49242,.61104,262811e-9,0,.523822,.589567,255151e-9,0,.555556,.568322,246434e-9,0,.587302,.547235,237061e-9,0,.619048,.52616,228343e-9,0,.650794,.505716,219236e-9,0,.68254,.485274,209595e-9,0,.714286,.465411,201011e-9,0,.746032,.445854,19109e-8,0,.777778,.426911,182897e-9,0,.809524,.408222,173569e-9,0,.84127,.390307,165496e-9,0,.873016,.372624,156799e-9,0,.904762,.355804,14917e-8,0,.936508,.33924,140907e-9,0,.968254,.323534,134062e-9,0,1,1,622487e-11,0,0,1,62251e-10,0,0,1,622837e-11,0,0,.999999,624259e-11,0,0,.999998,628127e-11,0,0,.999996,636451e-11,0,0,.999991,65218e-10,0,0,.999984,679782e-11,0,0,.999973,726361e-11,0,0,.999955,803644e-11,0,0,.999931,931397e-11,0,0,.999896,114299e-10,0,0,.999847,149402e-10,0,0,.999784,207461e-10,0,0,.999692,302493e-10,0,0,.999554,454957e-10,0,997275e-10,.999326,690762e-10,0,724813e-9,.998757,101605e-9,0,.0020972,.995367,958745e-10,0,.00432324,.99209,832808e-10,0,.00746347,.989517,887601e-10,0,.0115534,.987008,10564e-8,0,.0166134,.98421,133179e-9,0,.0226552,.98021,161746e-9,0,.0296838,.973676,161821e-9,0,.0377016,.967052,178635e-9,0,.0467079,.959385,206765e-9,0,.0567013,.949461,22476e-8,0,.0676796,.939578,23574e-8,0,.0796403,.932416,25893e-8,0,.0925812,.923759,271228e-9,0,.106501,.914223,289165e-9,0,.121397,.902942,301156e-9,0,.13727,.890419,313852e-9,0,.15412,.876639,324408e-9,0,.171946,.861316,33249e-8,0,.190751,.84496,338497e-9,0,.210537,.828427,345861e-9,0,.231305,.811871,347863e-9,0,.253057,.794397,350225e-9,0,.275797,.775726,349915e-9,0,.299525,.75617,347297e-9,0,.324242,.736091,344232e-9,0,.349947,.716213,340835e-9,0,.376633,.695736,332369e-9,0,.404289,.674961,327943e-9,0,.432895,.653518,318533e-9,0,.462415,.632574,310391e-9,0,.492788,.61134,300755e-9,0,.523909,.590017,290506e-9,0,.555556,.568752,280446e-9,0,.587302,.548061,269902e-9,0,.619048,.52711,258815e-9,0,.650794,.506682,248481e-9,0,.68254,.486524,237141e-9,0,.714286,.466812,226872e-9,0,.746032,.44732,216037e-9,0,.777778,.428473,205629e-9,0,.809524,.409921,195691e-9,0,.84127,.392028,185457e-9,0,.873016,.374606,176436e-9,0,.904762,.357601,166508e-9,0,.936508,.341348,158385e-9,0,.968254,.32542,149203e-9,0,1,1,103967e-10,0,0,1,10397e-9,0,0,1,104019e-10,0,0,.999999,104231e-10,0,0,.999998,104806e-10,0,0,.999995,106042e-10,0,0,.999991,108366e-10,0,0,.999982,112415e-10,0,0,.999968,119174e-10,0,0,.99995,130227e-10,0,0,.999922,148176e-10,0,0,.999884,177303e-10,0,0,.99983,224564e-10,0,0,.999758,300966e-10,0,0,.999654,423193e-10,0,549083e-11,.999503,614848e-10,0,296087e-9,.999237,903576e-10,0,.00123144,.998491,1271e-7,0,.00295954,.994594,107754e-9,0,.00555829,.99178,103025e-9,0,.00907209,.989265,11154e-8,0,.0135257,.986998,136296e-9,0,.0189327,.984137,169154e-9,0,.0252993,.979798,196671e-9,0,.0326272,.97337,196678e-9,0,.0409157,.967239,223121e-9,0,.0501623,.959543,253809e-9,0,.0603638,.949466,265972e-9,0,.0715171,.939074,288372e-9,0,.0836187,.931118,310983e-9,0,.0966657,.922525,325561e-9,0,.110656,.912983,345725e-9,0,.125588,.901617,3556e-7,0,.141461,.889487,374012e-9,0,.158275,.875787,383445e-9,0,.176031,.860654,393972e-9,0,.19473,.844417,400311e-9,0,.214374,.82741,405004e-9,0,.234967,.810545,407378e-9,0,.256512,.793312,407351e-9,0,.279011,.774847,406563e-9,0,.302468,.755621,404903e-9,0,.326887,.735511,397486e-9,0,.352266,.715435,39357e-8,0,.378605,.695403,384739e-9,0,.405897,.674681,376108e-9,0,.43413,.65359,365997e-9,0,.463277,.632471,354957e-9,0,.493295,.61151,343593e-9,0,.524106,.59064,331841e-9,0,.555561,.569386,318891e-9,0,.587302,.548785,3072e-7,0,.619048,.528146,29361e-8,0,.650794,.507872,281709e-9,0,.68254,.487805,268627e-9,0,.714286,.468196,255887e-9,0,.746032,.448922,243997e-9,0,.777778,.430093,231662e-9,0,.809524,.411845,220339e-9,0,.84127,.393808,208694e-9,0,.873016,.376615,198045e-9,0,.904762,.359655,187375e-9,0,.936508,.343452,177371e-9,0,.968254,.32765,167525e-9,0,1,1,169351e-10,0,0,1,169356e-10,0,0,1,169427e-10,0,0,.999999,169736e-10,0,0,.999998,170575e-10,0,0,.999995,172372e-10,0,0,.99999,175739e-10,0,0,.999979,181568e-10,0,0,.999966,191206e-10,0,0,.999944,20677e-9,0,0,.999912,231644e-10,0,0,.999869,271268e-10,0,0,.999811,334272e-10,0,0,.99973,433979e-10,0,0,.999617,590083e-10,0,680315e-10,.999445,829497e-10,0,612796e-9,.999138,118019e-9,0,.00187408,.998095,156712e-9,0,.00395791,.993919,125054e-9,0,.00692144,.991333,126091e-9,0,.0107962,.989226,144912e-9,0,.0155986,.986954,175737e-9,0,.0213364,.983982,213883e-9,0,.0280114,.979128,234526e-9,0,.0356226,.973327,243725e-9,0,.0441668,.967416,2773e-7,0,.0536399,.959729,308799e-9,0,.0640376,.949758,322447e-9,0,.0753554,.939173,350021e-9,0,.0875893,.9296,370089e-9,0,.100736,.921181,391365e-9,0,.114793,.91164,413636e-9,0,.129759,.900435,427068e-9,0,.145632,.888183,441046e-9,0,.162412,.874772,454968e-9,0,.180101,.859566,461882e-9,0,.1987,.843579,471556e-9,0,.218213,.826453,474335e-9,0,.238641,.809164,477078e-9,0,.259989,.792179,47755e-8,0,.282262,.773866,472573e-9,0,.305464,.754944,469765e-9,0,.329599,.735133,462371e-9,0,.35467,.714858,453674e-9,0,.380678,.694829,443888e-9,0,.407622,.674453,432052e-9,0,.435493,.653685,420315e-9,0,.464275,.632666,406829e-9,0,.493938,.611676,392234e-9,0,.524422,.591193,379208e-9,0,.555624,.570145,36319e-8,0,.587302,.549566,349111e-9,0,.619048,.529278,334166e-9,0,.650794,.509026,318456e-9,0,.68254,.489186,30449e-8,0,.714286,.469662,289051e-9,0,.746032,.450691,275494e-9,0,.777778,.431841,261437e-9,0,.809524,.413752,247846e-9,0,.84127,.395951,235085e-9,0,.873016,.378633,222245e-9,0,.904762,.36194,210533e-9,0,.936508,.345599,198494e-9,0,.968254,.329999,188133e-9,0,1,1,269663e-10,0,0,1,26967e-9,0,0,1,269772e-10,0,0,.999999,270214e-10,0,0,.999998,271415e-10,0,0,.999994,27398e-9,0,0,.999988,278771e-10,0,0,.999977,287019e-10,0,0,.999961,300544e-10,0,0,.999937,322138e-10,0,0,.999904,356163e-10,0,0,.999854,409465e-10,0,0,.99979,492651e-10,0,0,.999699,621722e-10,0,88288e-11,.999572,819715e-10,0,223369e-9,.999381,111689e-9,0,.00105414,.999016,153862e-9,0,.0026493,.997437,187667e-9,0,.00508608,.993545,155672e-9,0,.00840554,.991135,161455e-9,0,.012629,.989157,188241e-9,0,.0177661,.986874,226229e-9,0,.0238198,.983714,268668e-9,0,.0307887,.978301,277109e-9,0,.0386688,.973227,303446e-9,0,.0474554,.967317,341851e-9,0,.0571428,.959477,370885e-9,0,.0677256,.950012,392753e-9,0,.0791988,.939484,42781e-8,0,.0915576,.928135,443866e-9,0,.104798,.919819,472959e-9,0,.118918,.910049,491551e-9,0,.133915,.899181,512616e-9,0,.149788,.886881,523563e-9,0,.166537,.87359,540183e-9,0,.184164,.858613,547386e-9,0,.202669,.842809,554809e-9,0,.222056,.825727,558316e-9,0,.242329,.808086,557824e-9,0,.263492,.790728,556346e-9,0,.285551,.772987,552672e-9,0,.30851,.7541,543738e-9,0,.332376,.734669,536107e-9,0,.357153,.714411,523342e-9,0,.382845,.694196,512238e-9,0,.409454,.674252,497465e-9,0,.436977,.65357,481096e-9,0,.465404,.632999,467054e-9,0,.494713,.611994,448771e-9,0,.524864,.591604,431889e-9,0,.555779,.571134,415238e-9,0,.587302,.550528,396369e-9,0,.619048,.530292,379477e-9,0,.650794,.510364,361488e-9,0,.68254,.490749,343787e-9,0,.714286,.471266,327822e-9,0,.746032,.452462,310626e-9,0,.777778,.433907,295352e-9,0,.809524,.415659,279179e-9,0,.84127,.398138,264685e-9,0,.873016,.380833,249905e-9,0,.904762,.364247,236282e-9,0,.936508,.348041,222905e-9,0,.968254,.332389,210522e-9,0,1,1,420604e-10,0,0,1,420614e-10,0,0,1,420757e-10,0,0,.999999,42138e-9,0,0,.999997,423067e-10,0,0,.999993,426668e-10,0,0,.999986,433372e-10,0,0,.999974,444857e-10,0,0,.999956,463554e-10,0,0,.99993,493105e-10,0,0,.999892,539077e-10,0,0,.999838,610005e-10,0,0,.999767,718822e-10,0,0,.999666,884581e-10,0,365471e-10,.999525,113398e-9,0,485623e-9,.999311,150043e-9,0,.00162096,.998865,200063e-9,0,.00355319,.996278,211014e-9,0,.00633818,.992956,189672e-9,0,.0100043,.991017,210262e-9,0,.0145648,.989055,244292e-9,0,.0200237,.986741,290481e-9,0,.0263798,.983288,334303e-9,0,.033629,.977784,340307e-9,0,.0417652,.973037,377864e-9,0,.0507821,.967181,4239e-7,0,.060673,.958971,443854e-9,0,.0714314,.950093,483039e-9,0,.0830518,.939552,517934e-9,0,.0955288,.927678,539449e-9,0,.108859,.918278,568604e-9,0,.123038,.908449,588505e-9,0,.138065,.897713,612473e-9,0,.153938,.885533,625575e-9,0,.170657,.872131,63854e-8,0,.188224,.857517,647034e-9,0,.20664,.841796,65209e-8,0,.225909,.824726,6544e-7,0,.246035,.807297,655744e-9,0,.267022,.789058,646716e-9,0,.288878,.77189,643898e-9,0,.311607,.753082,629973e-9,0,.335216,.7341,621564e-9,0,.359713,.714094,605171e-9,0,.385103,.693839,588752e-9,0,.41139,.673891,573294e-9,0,.438576,.653565,552682e-9,0,.466656,.633326,533446e-9,0,.495617,.612582,514635e-9,0,.525431,.59205,49303e-8,0,.556041,.571918,471842e-9,0,.587338,.551572,451713e-9,0,.619048,.531553,430049e-9,0,.650794,.51175,410445e-9,0,.68254,.49238,390098e-9,0,.714286,.473143,370033e-9,0,.746032,.45423,351205e-9,0,.777778,.435963,332049e-9,0,.809524,.41787,315021e-9,0,.84127,.400387,297315e-9,0,.873016,.383332,281385e-9,0,.904762,.366665,265397e-9,0,.936508,.350633,250601e-9,0,.968254,.334964,23589e-8,0,1,1,643736e-10,0,0,1,64375e-9,0,0,1,643947e-10,0,0,.999999,64481e-9,0,0,.999997,647143e-10,0,0,.999994,652119e-10,0,0,.999985,661359e-10,0,0,.999972,677116e-10,0,0,.999952,702599e-10,0,0,.999922,742517e-10,0,0,.99988,803906e-10,0,0,.99982,897315e-10,0,0,.999741,103838e-9,0,0,.999629,12496e-8,0,149024e-9,.999474,156161e-9,0,861027e-9,.999229,201034e-9,0,.00231198,.998662,259069e-9,0,.00458147,.995299,245439e-9,0,.00770895,.992732,24498e-8,0,.0117126,.990847,273211e-9,0,.0165989,.988911,316492e-9,0,.0223674,.98654,37161e-8,0,.0290135,.982636,410352e-9,0,.0365309,.977346,421756e-9,0,.0449117,.972909,475578e-9,0,.0541481,.966821,522482e-9,0,.0642326,.958686,545008e-9,0,.075158,.949754,589286e-9,0,.0869181,.939184,619995e-9,0,.0995074,.927505,654266e-9,0,.112922,.916606,682362e-9,0,.127157,.906707,704286e-9,0,.142212,.895937,725909e-9,0,.158085,.883913,743939e-9,0,.174776,.870642,755157e-9,0,.192287,.856241,764387e-9,0,.210619,.84069,771032e-9,0,.229775,.823728,765906e-9,0,.249761,.806481,767604e-9,0,.270582,.787924,754385e-9,0,.292243,.770588,749668e-9,0,.314753,.751991,731613e-9,0,.338118,.733407,717655e-9,0,.362347,.713688,700604e-9,0,.387447,.693595,678765e-9,0,.413424,.673426,657042e-9,0,.440284,.65359,635892e-9,0,.468027,.633576,611569e-9,0,.496645,.613144,586011e-9,0,.526122,.592711,563111e-9,0,.556417,.572722,537699e-9,0,.587451,.552762,512556e-9,0,.619048,.532985,489757e-9,0,.650794,.513219,464139e-9,0,.68254,.493992,442193e-9,0,.714286,.47509,418629e-9,0,.746032,.456287,397045e-9,0,.777778,.438152,375504e-9,0,.809524,.420294,35492e-8,0,.84127,.402749,335327e-9,0,.873016,.385879,316422e-9,0,.904762,.369352,298333e-9,0,.936508,.353301,281417e-9,0,.968254,.337781,265203e-9,0,1,1,968267e-10,0,0,1,968284e-10,0,0,1,968556e-10,0,0,.999999,969733e-10,0,0,.999997,972913e-10,0,0,.999993,979688e-10,0,0,.999984,992239e-10,0,0,.999969,101356e-9,0,0,.999946,104784e-9,0,0,.999913,110111e-9,0,0,.999868,118217e-9,0,0,.999801,130396e-9,0,0,.999712,148523e-9,0,124907e-10,.999589,175233e-9,0,355405e-9,.999416,213999e-9,0,.0013528,.999136,268529e-9,0,.00312557,.998367,333088e-9,0,.00573045,.994701,304757e-9,0,.00919397,.992497,318031e-9,0,.0135261,.990608,353863e-9,0,.0187278,.988715,409044e-9,0,.0247947,.986241,472967e-9,0,.0317196,.981696,495104e-9,0,.039494,.977097,532873e-9,0,.0481087,.972583,594447e-9,0,.0575549,.966142,636867e-9,0,.0678242,.95823,669899e-9,0,.0789089,.949677,719499e-9,0,.0908023,.939226,750584e-9,0,.103499,.927501,793183e-9,0,.116993,.915199,81995e-8,0,.131282,.90498,847654e-9,0,.146364,.894243,868929e-9,0,.162237,.882154,884278e-9,0,.178902,.869161,898108e-9,0,.196358,.854751,901254e-9,0,.21461,.839368,90679e-8,0,.23366,.822874,901541e-9,0,.253512,.805514,897297e-9,0,.274174,.78716,881856e-9,0,.29565,.769061,870032e-9,0,.31795,.751,851719e-9,0,.341081,.732614,830671e-9,0,.365053,.713171,806569e-9,0,.389874,.693472,78338e-8,0,.415553,.673528,756404e-9,0,.442098,.653397,726872e-9,0,.469512,.633781,700494e-9,0,.497794,.613877,67105e-8,0,.526935,.593506,640361e-9,0,.556908,.573667,613502e-9,0,.587657,.553932,583177e-9,0,.61906,.534345,554375e-9,0,.650794,.515042,527811e-9,0,.68254,.495674,499367e-9,0,.714286,.477132,47429e-8,0,.746032,.458609,447726e-9,0,.777778,.440354,424205e-9,0,.809524,.422765,399549e-9,0,.84127,.405472,378315e-9,0,.873016,.388482,355327e-9,0,.904762,.372191,336122e-9,0,.936508,.356099,315247e-9,0,.968254,.340737,29794e-8,0,1,1,143327e-9,0,0,1,14333e-8,0,0,1,143366e-9,0,0,.999999,143524e-9,0,0,.999996,143952e-9,0,0,.999991,144862e-9,0,0,.999981,146544e-9,0,0,.999966,149391e-9,0,0,.999941,153946e-9,0,0,.999905,160971e-9,0,0,.999852,171562e-9,0,0,.99978,18729e-8,0,0,.999681,210386e-9,0,826239e-10,.999546,243906e-9,0,664807e-9,.999352,291739e-9,0,.00196192,.999027,357419e-9,0,.00405941,.997886,422349e-9,0,.00699664,.99419,385008e-9,0,.0107896,.99214,409775e-9,0,.0154415,.990274,456418e-9,0,.0209488,.988455,527008e-9,0,.0273037,.985804,597685e-9,0,.0344969,.98103,613124e-9,0,.0425183,.976674,668321e-9,0,.0513575,.972021,736985e-9,0,.0610046,.965274,773789e-9,0,.0714508,.958046,830852e-9,0,.0826877,.949333,875766e-9,0,.0947085,.939135,917088e-9,0,.107507,.927119,952244e-9,0,.121078,.91469,990626e-9,0,.135419,.903006,.00101304,0,.150526,.892368,.00103834,0,.166399,.880231,.00105002,0,.183038,.867432,.00106331,0,.200443,.853208,.00106783,0,.218618,.837956,.00106458,0,.237566,.821772,.00105945,0,.257291,.804328,.00104685,0,.2778,.786465,.00103178,0,.2991,.768004,.00101077,0,.321199,.74972,985504e-9,0,.344106,.731682,962893e-9,0,.36783,.712813,932146e-9,0,.392383,.693139,89871e-8,0,.417774,.673566,869678e-9,0,.444013,.653483,835525e-9,0,.471107,.633891,799853e-9,0,.49906,.614433,766838e-9,0,.527869,.594586,732227e-9,0,.557517,.574769,696442e-9,0,.587966,.555149,663935e-9,0,.61913,.535898,629826e-9,0,.650794,.516753,596486e-9,0,.68254,.497816,567078e-9,0,.714286,.479034,534399e-9,0,.746032,.460975,507013e-9,0,.777778,.442935,477421e-9,0,.809524,.425263,451101e-9,0,.84127,.408248,424964e-9,0,.873016,.391339,39993e-8,0,.904762,.37513,377619e-9,0,.936508,.359172,354418e-9,0,.968254,.343876,334823e-9,0,1,1,209042e-9,0,0,1,209045e-9,0,0,1,209093e-9,0,0,.999999,209304e-9,0,0,.999996,209871e-9,0,0,.999991,211078e-9,0,0,.999979,213304e-9,0,0,.999963,217061e-9,0,0,.999933,223042e-9,0,0,.999894,232206e-9,0,0,.999837,245901e-9,0,0,.999756,266023e-9,0,102927e-11,.999648,295204e-9,0,233468e-9,.999499,336958e-9,0,.00108237,.999283,395563e-9,0,.00268832,.998896,473785e-9,0,.00511138,.997006,520008e-9,0,.00837705,.993819,497261e-9,0,.0124928,.991632,523722e-9,0,.0174561,.989875,587258e-9,0,.0232596,.988109,676329e-9,0,.0298932,.985155,747701e-9,0,.0373453,.980479,768803e-9,0,.0456045,.976271,841054e-9,0,.0546593,.971347,911469e-9,0,.0644994,.964528,953057e-9,0,.0751152,.957632,.00102221,0,.0864981,.948681,.00106122,0,.0986407,.938716,.00111857,0,.111537,.926629,.00114762,0,.125182,.914025,.00118995,0,.139571,.901026,.00121228,0,.154703,.890358,.00123946,0,.170576,.878283,.0012527,0,.18719,.865459,.00125536,0,.204547,.851407,.00126134,0,.222648,.836276,.00124759,0,.241498,.820436,.00124443,0,.261101,.803253,.00122071,0,.281465,.785562,.00120107,0,.302595,.76718,.00117762,0,.324501,.748551,.00114289,0,.347192,.730564,.00110872,0,.370679,.712253,.00107636,0,.394973,.692867,.00103646,0,.420085,.673695,996793e-9,0,.446027,.653912,95675e-8,0,.47281,.634129,916739e-9,0,.500441,.615004,874401e-9,0,.528921,.595587,833411e-9,0,.558244,.575965,794556e-9,0,.588384,.5566,75196e-8,0,.619281,.537428,716381e-9,0,.650795,.518623,676558e-9,0,.68254,.499964,64074e-8,0,.714286,.481356,605984e-9,0,.746032,.463279,570256e-9,0,.777778,.445673,540138e-9,0,.809524,.428032,507299e-9,0,.84127,.411112,479553e-9,0,.873016,.394444,450737e-9,0,.904762,.378247,424269e-9,0,.936508,.362415,399111e-9,0,.968254,.347103,375274e-9,0,1,1,300729e-9,0,0,1,300733e-9,0,0,1,300797e-9,0,0,.999998,301072e-9,0,0,.999996,301817e-9,0,0,.999989,303398e-9,0,0,.999977,306309e-9,0,0,.999958,311209e-9,0,0,.999927,318975e-9,0,0,.999884,330804e-9,0,0,.99982,34834e-8,0,0,.999733,373854e-9,0,326995e-10,.999613,410424e-9,0,477174e-9,.999447,462047e-9,0,.00161099,.999204,533322e-9,0,.00353153,.998725,624964e-9,0,.00627965,.995871,631786e-9,0,.0098693,.993194,632017e-9,0,.0143011,.991541,68923e-8,0,.019568,.989773,766892e-9,0,.0256593,.987647,863668e-9,0,.0325625,.984193,922089e-9,0,.0402647,.980016,970749e-9,0,.0487532,.975859,.00106027,0,.058016,.970514,.00112239,0,.0680419,.963625,.00117212,0,.0788208,.956959,.00125211,0,.0903439,.947956,.00129411,0,.102604,.93809,.00135879,0,.115594,.92659,.00139309,0,.129309,.913829,.00143253,0,.143745,.90005,.00145809,0,.158901,.888129,.0014748,0,.174774,.87607,.00148756,0,.191365,.863461,.00148714,0,.208674,.849594,.00148892,0,.226705,.834531,.00146496,0,.245461,.81903,.0014579,0,.264947,.802122,.00143039,0,.28517,.78445,.00139717,0,.306137,.766434,.00136312,0,.327857,.747816,.00132597,0,.350341,.729519,.00128323,0,.373598,.711454,.00123803,0,.397642,.692699,.00119097,0,.422485,.673723,.00114565,0,.448139,.654386,.00109552,0,.474619,.634673,.00104553,0,.501933,.615554,99985e-8,0,.530089,.596462,948207e-9,0,.559087,.577385,902299e-9,0,.588913,.558257,856448e-9,0,.619525,.5392,810395e-9,0,.650826,.520543,768558e-9,0,.68254,.502206,7239e-7,0,.714286,.48402,685794e-9,0,.746032,.465779,64471e-8,0,.777778,.448455,609583e-9,0,.809524,.431091,57227e-8,0,.84127,.414147,54042e-8,0,.873016,.39765,506545e-9,0,.904762,.381576,477635e-9,0,.936508,.365881,448446e-9,0,.968254,.350582,421424e-9,0,1,1,427144e-9,0,0,1,427151e-9,0,0,1,427232e-9,0,0,.999998,42759e-8,0,0,.999995,428555e-9,0,0,.999988,430603e-9,0,0,.999976,434368e-9,0,0,.999952,440688e-9,0,0,.999919,450667e-9,0,0,.999871,46578e-8,0,0,.999801,488024e-9,0,0,.999704,520092e-9,0,129791e-9,.999572,565553e-9,0,821056e-9,.999389,628906e-9,0,.00225241,.999114,714911e-9,0,.00449109,.998488,819218e-9,0,.00756249,.995234,80415e-8,0,.0114716,.993021,830181e-9,0,.0162131,.991407,902645e-9,0,.021776,.989625,996934e-9,0,.0281471,.987064,.00109707,0,.0353118,.983265,.00114353,0,.0432562,.979535,.0012272,0,.0519665,.975224,.00132642,0,.0614298,.969574,.00138092,0,.0716348,.963021,.00145896,0,.0825709,.956046,.00152834,0,.094229,.947136,.00158217,0,.106602,.937313,.0016347,0,.119682,.926073,.00168383,0,.133465,.913121,.00171627,0,.147947,.899165,.00174229,0,.163125,.885891,.00176137,0,.178998,.873783,.00176406,0,.195566,.861331,.00176156,0,.21283,.847569,.00175346,0,.230793,.832785,.00172753,0,.249459,.817442,.00170204,0,.268832,.800613,.00166576,0,.28892,.783597,.00162909,0,.30973,.76571,.0015826,0,.331271,.747021,.00153106,0,.353554,.728593,.00148036,0,.37659,.710661,.00142808,0,.400391,.692426,.00136906,0,.424973,.673623,.00131066,0,.450347,.65494,.00125569,0,.476531,.635448,.00119517,0,.503535,.616221,.00113828,0,.531372,.597531,.0010816,0,.560047,.578795,.00102673,0,.589554,.559892,970985e-9,0,.619869,.541307,919773e-9,0,.650923,.522608,868479e-9,0,.68254,.504484,82137e-8,0,.714286,.486603,772916e-9,0,.746032,.468802,730353e-9,0,.777778,.451172,684955e-9,0,.809524,.434348,647565e-9,0,.84127,.417445,605863e-9,0,.873016,.401077,571885e-9,0,.904762,.385039,536034e-9,0,.936508,.369483,504227e-9,0,.968254,.354272,473165e-9,0,1,1,599525e-9,0,0,1,599533e-9,0,0,1,599639e-9,0,0,.999998,600097e-9,0,0,.999994,601336e-9,0,0,.999987,603958e-9,0,0,.999972,608775e-9,0,0,.999949,616842e-9,0,0,.999912,629534e-9,0,0,.999857,648658e-9,0,0,.999781,676615e-9,0,538873e-11,.999674,716574e-9,0,308602e-9,.999528,772641e-9,0,.00127003,.999326,849806e-9,0,.00300783,.999009,952682e-9,0,.00556637,.998112,.00106394,0,.00895889,.994496,.00102228,0,.0131827,.992806,.00108586,0,.0182277,.991211,.0011759,0,.0240795,.989415,.00128955,0,.030723,.986499,.00139038,0,.0381418,.982679,.00144539,0,.046321,.978839,.00153954,0,.0552459,.974295,.00164417,0,.0649034,.968784,.00171517,0,.0752814,.962324,.00180282,0,.0863693,.954956,.00186387,0,.0981578,.94624,.00193817,0,.110639,.936517,.00198156,0,.123806,.925186,.00203042,0,.137655,.91252,.0020664,0,.15218,.898441,.00207822,0,.16738,.884394,.0020992,0,.183253,.871273,.00208748,0,.199799,.859057,.00208686,0,.21702,.845243,.00205519,0,.234918,.830723,.00202868,0,.253496,.815801,.00199501,0,.272761,.79914,.00194193,0,.292719,.782372,.00188824,0,.313377,.76482,.00183695,0,.334745,.746586,.00177418,0,.356833,.7281,.00170628,0,.379654,.709842,.00164063,0,.403221,.692019,.00157355,0,.427548,.67364,.00150262,0,.452651,.655277,.00143473,0,.478545,.636438,.00136371,0,.505246,.617364,.00129911,0,.532768,.598603,.00123014,0,.561122,.580195,.00116587,0,.590309,.561786,.00110398,0,.620318,.543377,.00104148,0,.651102,.525093,983984e-9,0,.682545,.506791,92667e-8,0,.714286,.489291,874326e-9,0,.746032,.471811,821734e-9,0,.777778,.454435,774698e-9,0,.809524,.437493,727302e-9,0,.84127,.420977,684039e-9,0,.873016,.404729,64373e-8,0,.904762,.388756,60285e-8,0,.936508,.373344,56765e-8,0,.968254,.358191,531929e-9,0,1,1,832169e-9,0,0,1,832178e-9,0,0,1,83231e-8,0,0,.999998,832893e-9,0,0,.999995,834465e-9,0,0,.999985,837791e-9,0,0,.999969,843893e-9,0,0,.999944,854086e-9,0,0,.999903,870071e-9,0,0,.999843,894042e-9,0,0,.999759,928865e-9,0,531805e-10,.999643,978242e-9,0,579365e-9,.99948,.00104684,0,.00182774,.999255,.00114012,0,.00387804,.998885,.00126188,0,.00675709,.997405,.00135888,0,.010468,.99424,.00133626,0,.0150018,.992458,.00140905,0,.0203443,.990929,.00152305,0,.0264786,.989116,.00165882,0,.0333875,.985624,.00174128,0,.0410536,.982003,.00182108,0,.0494609,.978336,.00194498,0,.0585941,.973184,.00202708,0,.0684396,.9678,.00212166,0,.0789851,.961348,.00221366,0,.0902199,.953841,.00228219,0,.102134,.94534,.00235662,0,.114721,.935552,.00240572,0,.127972,.924064,.00244405,0,.141884,.911827,.00247557,0,.156451,.897731,.00248374,0,.171672,.883409,.00249863,0,.187545,.868625,.00246688,0,.20407,.856529,.00246523,0,.221249,.842999,.00242368,0,.239083,.828505,.00237354,0,.257578,.813825,.00232588,0,.276738,.797813,.00226731,0,.296569,.781097,.00219704,0,.31708,.764038,.00212394,0,.338281,.746067,.00204786,0,.360181,.727687,.00196728,0,.382794,.709571,.00188779,0,.406133,.691503,.00180532,0,.430213,.673673,.00171849,0,.45505,.655732,.00164147,0,.480662,.637399,.00155858,0,.507065,.618616,.00147641,0,.534278,.60005,.00140125,0,.562313,.581713,.00132441,0,.59118,.563546,.00125014,0,.620875,.545605,.00118249,0,.651373,.527559,.0011116,0,.682593,.509764,.00104979,0,.714286,.49193,985977e-9,0,.746032,.475011,928592e-9,0,.777778,.457878,873466e-9,0,.809524,.440979,819585e-9,0,.84127,.424613,772365e-9,0,.873016,.408549,722195e-9,0,.904762,.392771,680014e-9,0,.936508,.377317,636797e-9,0,.968254,.362352,598318e-9,0,1,1,.00114313,0,0,1,.00114314,0,0,.999999,.00114331,0,0,.999998,.00114404,0,0,.999994,.00114601,0,0,.999984,.00115019,0,0,.999967,.00115784,0,0,.999937,.0011706,0,0,.999894,.00119054,0,0,.999828,.00122031,0,0,.999735,.00126331,0,169263e-9,.999606,.00132382,0,949167e-9,.999426,.0014071,0,.00249668,.999173,.00151895,0,.00486392,.99873,.00166102,0,.00806323,.996243,.0017023,0,.0120895,.993779,.00172782,0,.0169288,.9919,.0018108,0,.0225633,.990524,.00196028,0,.028974,.98868,.00212014,0,.036142,.984663,.00217598,0,.044049,.981457,.00230563,0,.0526781,.977608,.00243966,0,.0620137,.972215,.00251336,0,.0720418,.966798,.0026285,0,.0827499,.960241,.00271409,0,.0941271,.952489,.00278381,0,.106164,.944127,.00285399,0,.118852,.934282,.00290994,0,.132185,.923271,.00294558,0,.146157,.910803,.00296269,0,.160766,.896705,.00296803,0,.176007,.88238,.00296637,0,.19188,.867116,.00293163,0,.208385,.853636,.00289418,0,.225523,.840469,.00284663,0,.243296,.82639,.00278594,0,.261709,.811759,.00271618,0,.280767,.796113,.00263187,0,.300476,.779518,.00254589,0,.320845,.763142,.00246003,0,.341883,.745464,.00236529,0,.363601,.727491,.00226536,0,.386011,.709414,.00216375,0,.409128,.691396,.00207127,0,.432967,.67368,.00197106,0,.457545,.656049,.00187022,0,.482881,.638188,.00177605,0,.508992,.620177,.00168482,0,.535899,.601506,.00158909,0,.563619,.58362,.00150583,0,.592165,.565496,.00141791,0,.621544,.54789,.00133693,0,.651743,.530323,.00126038,0,.682709,.512795,.00118556,0,.714286,.495199,.00111527,0,.746032,.478101,.0010489,0,.777778,.461511,984264e-9,0,.809524,.444879,92591e-8,0,.84127,.428424,866582e-9,0,.873016,.412495,814463e-9,0,.904762,.396975,764498e-9,0,.936508,.381614,715967e-9,0,.968254,.366732,672483e-9,0,1,1,.00155501,0,0,1,.00155503,0,0,1,.00155524,0,0,.999998,.00155615,0,0,.999994,.0015586,0,0,.999983,.00156379,0,0,.999963,.0015733,0,0,.999932,.00158911,0,0,.999882,.00161376,0,0,.99981,.00165041,0,100875e-10,.999708,.00170304,0,367658e-9,.999565,.00177658,0,.0014234,.999368,.00187688,0,.00327939,.999081,.00200989,0,.00596629,.99852,.00217177,0,.0094852,.99549,.0021745,0,.013824,.993252,.00222357,0,.0189642,.991727,.00235022,0,.0248856,.989951,.00250561,0,.0315669,.988029,.00268829,0,.0389882,.984029,.0027496,0,.0471302,.980683,.00289793,0,.0559754,.976554,.00303315,0,.0655081,.97139,.00313257,0,.0757138,.965544,.00323656,0,.08658,.95912,.00333432,0,.0980954,.951183,.0034039,0,.110251,.942974,.00347515,0,.123038,.932642,.00350381,0,.13645,.922158,.00354519,0,.150482,.909404,.00353851,0,.165129,.896071,.0035435,0,.18039,.881206,.00349936,0,.196263,.866077,.00347256,0,.212748,.85093,.003415,0,.229847,.837703,.00333367,0,.247561,.823878,.003249,0,.265895,.809449,.00316347,0,.284854,.794379,.00306351,0,.304445,.778138,.0029499,0,.324675,.761997,.00284099,0,.345555,.744938,.00272104,0,.367095,.727212,.00260715,0,.389309,.709549,.00248855,0,.41221,.691704,.00236783,0,.435814,.673689,.00225178,0,.460138,.656453,.00213765,0,.485203,.639128,.00202178,0,.511028,.621512,.00191443,0,.537634,.603598,.00180977,0,.565041,.58559,.00170456,0,.593268,.567852,.00160927,0,.622327,.5503,.00151395,0,.652217,.533033,.00142499,0,.682907,.515942,.00133955,0,.714296,.498814,.0012602,0,.746032,.481595,.00118188,0,.777778,.465117,.00111171,0,.809524,.448865,.00104091,0,.84127,.432711,976618e-9,0,.873016,.416822,91859e-8,0,.904762,.401272,857704e-9,0,.936508,.386226,807172e-9,0,.968254,.371321,75464e-8,0,1,1,.00209596,0,0,1,.00209598,0,0,1,.00209624,0,0,.999997,.00209736,0,0,.999991,.00210039,0,0,.999979,.00210678,0,0,.999959,.00211847,0,0,.999925,.0021379,0,0,.99987,.00216809,0,0,.999791,.00221281,0,681487e-10,.999677,.00227669,0,658161e-9,.999521,.00236533,0,.00200635,.999301,.00248514,0,.0041779,.998977,.00264185,0,.00718648,.998191,.00281695,0,.0110239,.994801,.00278518,0,.015672,.993091,.00288774,0,.0211091,.991571,.00303931,0,.0273123,.9897,.00321643,0,.034259,.987023,.00337332,0,.0419282,.983289,.00346146,0,.0502998,.979892,.00363704,0,.0593562,.975111,.00373601,0,.069081,.970351,.0038842,0,.0794598,.964131,.00397053,0,.0904798,.957747,.00408078,0,.10213,.949536,.00413533,0,.1144,.941372,.00420305,0,.127284,.931049,.00422815,0,.140772,.920647,.00425048,0,.154862,.908033,.0042281,0,.169548,.895028,.00422026,0,.184828,.879968,.00415042,0,.200701,.864875,.00408821,0,.217167,.84918,.00400909,0,.234227,.834934,.00391178,0,.251884,.821397,.00380066,0,.270141,.807135,.00367974,0,.289004,.792363,.00355172,0,.308479,.776661,.003411,0,.328575,.760705,.00328123,0,.349301,.744408,.00314003,0,.370668,.726994,.0029906,0,.392689,.709598,.00285034,0,.415379,.692112,.00271179,0,.438754,.674435,.00257185,0,.46283,.65676,.00243425,0,.48763,.639982,.00230351,0,.513173,.622983,.0021777,0,.539482,.605471,.00204991,0,.566579,.58796,.00193759,0,.594488,.570463,.00181976,0,.623226,.553058,.00171497,0,.6528,.535894,.00161109,0,.683198,.519089,.00151394,0,.714354,.502454,.00142122,0,.746032,.485681,.00133488,0,.777778,.468935,.00124975,0,.809524,.452951,.00117309,0,.84127,.437139,.00110155,0,.873016,.421446,.00103124,0,.904762,.405951,966387e-9,0,.936508,.391003,908119e-9,0,.968254,.376198,848057e-9,0,1,1,.00280076,0,0,1,.00280078,0,0,.999999,.00280109,0,0,.999997,.00280246,0,0,.999992,.00280616,0,0,.999979,.00281396,0,0,.999956,.00282822,0,0,.999916,.00285186,0,0,.999857,.0028885,0,0,.999768,.00294259,0,196026e-9,.999645,.00301946,0,.00104842,.99947,.00312541,0,.00270199,.999229,.00326733,0,.00519449,.998852,.00344992,0,.00852602,.997558,.00361052,0,.0126804,.994417,.0035898,0,.017635,.992824,.00372393,0,.023365,.991344,.00390695,0,.0298456,.989337,.00410392,0,.0370529,.985811,.00420987,0,.0449651,.982772,.00437488,0,.0535615,.979001,.00455069,0,.0628243,.974102,.00464462,0,.0727368,.969197,.00480577,0,.0832844,.962759,.00487818,0,.0944545,.956207,.00498176,0,.106236,.947909,.00503392,0,.118619,.939596,.00507474,0,.131595,.929642,.00509798,0,.145159,.918807,.00508476,0,.159305,.906921,.00505634,0,.174028,.893312,.00498845,0,.189327,.878933,.0049133,0,.2052,.863986,.0048259,0,.221647,.847936,.00470848,0,.23867,.832253,.00456889,0,.25627,.818619,.00442726,0,.274453,.804788,.00427677,0,.293222,.790241,.00411906,0,.312585,.775162,.00394833,0,.33255,.759463,.00377366,0,.353126,.743598,.00361026,0,.374324,.72697,.00343627,0,.396158,.709646,.00326422,0,.418641,.69277,.00309717,0,.44179,.675371,.0029356,0,.465624,.657863,.00277712,0,.490163,.640772,.00261738,0,.515429,.624441,.0024737,0,.541445,.607497,.00233125,0,.568236,.590438,.00218994,0,.595828,.573224,.0020664,0,.624242,.556168,.00193526,0,.653496,.539232,.00182463,0,.683588,.522352,.00170735,0,.714482,.506172,.00160555,0,.746032,.489842,.00150451,0,.777778,.473463,.00140938,0,.809524,.457266,.00132568,0,.84127,.441609,.0012376,0,.873016,.426348,.00116265,0,.904762,.411002,.00108935,0,.936508,.396045,.00101946,0,.968254,.381448,955665e-9,0,1,1,.0037121,0,0,1,.00371213,0,0,1,.00371251,0,0,.999997,.00371417,0,0,.99999,.00371863,0,0,.999977,.00372807,0,0,.99995,.00374529,0,0,.999908,.0037738,0,0,.999843,.00381789,0,123596e-10,.999745,.00388273,0,407442e-9,.999608,.00397443,0,.0015447,.999415,.00409998,0,.00351385,.999143,.00426662,0,.0063316,.9987,.00447625,0,.00998679,.996363,.00455323,0,.0144569,.994021,.00461052,0,.0197151,.992372,.00476359,0,.0257344,.991007,.00499101,0,.0324882,.988767,.0051972,0,.0399517,.984872,.00528407,0,.0481022,.982004,.00548926,0,.0569191,.977714,.00564385,0,.0663839,.973076,.0057693,0,.0764801,.967565,.0058924,0,.0871928,.961384,.00599629,0,.0985095,.954435,.00605998,0,.110419,.946303,.0061133,0,.122912,.937662,.00612028,0,.13598,.927867,.00612209,0,.149617,.916475,.00604813,0,.163817,.90541,.00603088,0,.178577,.891591,.00592218,0,.193894,.877573,.00578854,0,.209767,.862511,.00566648,0,.226196,.846861,.00551481,0,.243182,.83068,.00533754,0,.260728,.815725,.00515487,0,.278837,.802321,.0049655,0,.297515,.787826,.00475421,0,.316768,.773454,.00456002,0,.336605,.758224,.00434727,0,.357034,.74265,.00414444,0,.378067,.726729,.00393738,0,.399717,.710155,.00373575,0,.421998,.693312,.00353736,0,.444928,.67653,.00334368,0,.468523,.659444,.00315981,0,.492806,.642051,.00297809,0,.517798,.625758,.00280592,0,.543525,.609615,.00264254,0,.570012,.592919,.00248459,0,.597288,.576298,.00233327,0,.625379,.559489,.00219519,0,.654307,.542891,.00205441,0,.684084,.526255,.00193385,0,.714693,.509853,.00180745,0,.746044,.494131,.00169817,0,.777778,.478114,.0015913,0,.809524,.462274,.00148981,0,.84127,.446412,.00139537,0,.873016,.431274,.00130984,0,.904762,.41635,.00122403,0,.936508,.401476,.00114809,0,.968254,.386993,.00107563,0,1,1,.00488216,0,0,1,.0048822,0,0,1,.00488265,0,0,.999997,.00488463,0,0,.999988,.00488999,0,0,.999974,.00490129,0,0,.999946,.00492191,0,0,.999897,.00495598,0,0,.999825,.00500855,0,744791e-10,.999718,.00508559,0,712744e-9,.999565,.005194,0,.00215249,.999352,.00534147,0,.00444576,.999046,.00553523,0,.00759218,.998492,.00577016,0,.0115714,.995564,.00578487,0,.0163557,.993339,.00586414,0,.021915,.991834,.00606002,0,.0282201,.990496,.00633312,0,.0352433,.987826,.00651941,0,.042959,.98383,.00660842,0,.0513439,.98109,.00685523,0,.0603772,.976131,.00695778,0,.0700402,.971922,.00714236,0,.0803163,.965901,.00721437,0,.0911908,.959606,.00732017,0,.102651,.952504,.00735788,0,.114686,.944365,.00738493,0,.127286,.935652,.00737969,0,.140443,.925813,.00733612,0,.154151,.914397,.00723094,0,.168405,.903257,.00714002,0,.183201,.890015,.00700149,0,.198536,.876014,.00682813,0,.214409,.861436,.00665567,0,.23082,.845752,.00644526,0,.24777,.829169,.00621635,0,.265263,.813435,.00597789,0,.283301,.799701,.00575694,0,.301889,.785726,.00549866,0,.321035,.77152,.0052503,0,.340746,.75683,.00499619,0,.361032,.741951,.0047543,0,.381904,.726367,.0045084,0,.403374,.710537,.00426784,0,.425457,.693965,.00403487,0,.448169,.677724,.0038075,0,.47153,.66117,.00359431,0,.495561,.644274,.00338354,0,.520284,.627449,.00318163,0,.545725,.611645,.00299672,0,.571911,.595614,.00281016,0,.598873,.579426,.00264252,0,.62664,.563016,.00247509,0,.655239,.546728,.00232647,0,.684692,.530539,.00217803,0,.714999,.514164,.00204216,0,.746106,.498344,.00191403,0,.777778,.482957,.00179203,0,.809524,.467336,.00167695,0,.84127,.451994,.00157567,0,.873016,.436514,.00147113,0,.904762,.42178,.00138034,0,.936508,.407271,.00129219,0,.968254,.392822,.0012098,0,1,1,.00637427,0,0,1,.00637431,0,0,.999999,.00637485,0,0,.999996,.00637721,0,0,.999987,.00638357,0,0,.999971,.006397,0,0,.999939,.00642142,0,0,.999888,.00646177,0,0,.999807,.00652387,0,207916e-9,.999689,.00661454,0,.00112051,.99952,.00674155,0,.00287719,.999283,.00691313,0,.00550145,.998936,.00713598,0,.00897928,.998165,.00738501,0,.0132829,.994847,.00734388,0,.01838,.993182,.00749991,0,.0242381,.991665,.0077246,0,.030826,.989708,.00797579,0,.0381152,.986663,.00813011,0,.0460794,.983288,.00830365,0,.0546951,.980104,.00853496,0,.0639411,.974855,.00861045,0,.0737988,.97045,.00879133,0,.0842516,.964509,.00886377,0,.0952848,.957594,.00890346,0,.106886,.950546,.00893289,0,.119044,.942225,.00890074,0,.131749,.933365,.00886826,0,.144994,.923202,.0087316,0,.158772,.912605,.00863082,0,.173078,.901099,.00847403,0,.187908,.888177,.00825838,0,.203261,.873955,.00801834,0,.219134,.860091,.00779026,0,.235527,.84434,.00752478,0,.252443,.828517,.00724074,0,.269883,.81239,.00693769,0,.287851,.79721,.00664817,0,.306352,.783489,.00634763,0,.325393,.769514,.00604221,0,.344981,.755419,.00573568,0,.365126,.741083,.00544359,0,.385839,.726059,.00515515,0,.407132,.710809,.00487139,0,.42902,.695052,.00459846,0,.45152,.678886,.00433412,0,.474651,.663042,.00407981,0,.498433,.646634,.00384264,0,.52289,.630117,.00360897,0,.548048,.613804,.00338863,0,.573936,.598338,.00318486,0,.600584,.582687,.00298377,0,.628027,.566809,.00280082,0,.656295,.550817,.00262255,0,.685417,.534937,.00245835,0,.715406,.519151,.00230574,0,.74624,.503118,.0021549,0,.777778,.487723,.00202008,0,.809524,.472725,.00189355,0,.84127,.457599,.00177108,0,.873016,.442558,.00165843,0,.904762,.427624,.00155494,0,.936508,.413171,.00145273,0,.968254,.399122,.00136454,0,1,1,.00826496,0,0,1,.00826499,0,0,1,.00826564,0,0,.999996,.00826842,0,0,.999987,.00827589,0,0,.999967,.00829167,0,0,.999933,.00832037,0,0,.999876,.00836768,0,109338e-10,.999786,.00844031,0,427145e-9,.999655,.00854603,0,.0016384,.999468,.00869337,0,.00372392,.999203,.008891,0,.00668513,.998803,.00914387,0,.0104968,.99748,.00935838,0,.015125,.994446,.00933309,0,.0205338,.99292,.00953084,0,.0266884,.991414,.0097893,0,.0335565,.989049,.0100228,0,.0411086,.98582,.0101664,0,.0493181,.982441,.0103582,0,.0581613,.978595,.0105292,0,.0676169,.973495,.0106274,0,.0776661,.968405,.0107261,0,.0882926,.962717,.0108234,0,.0994817,.955478,.0108102,0,.111221,.948275,.0107914,0,.123499,.940006,.0107161,0,.136308,.930831,.0106309,0,.149639,.920648,.0104083,0,.163485,.910205,.0102312,0,.177843,.898445,.0100051,0,.192707,.885986,.00971928,0,.208077,.872204,.00940747,0,.22395,.858436,.0091085,0,.240326,.843454,.00876595,0,.257208,.827437,.00839794,0,.274596,.811488,.00803692,0,.292496,.796039,.00767352,0,.310911,.781083,.0073097,0,.329849,.767642,.00694032,0,.349316,.753901,.00657476,0,.369323,.740131,.00622699,0,.38988,.725845,.0058838,0,.410999,.710991,.00555586,0,.432696,.696002,.00523089,0,.454987,.680461,.00492494,0,.47789,.664875,.00463464,0,.501426,.649273,.00435422,0,.52562,.63302,.0040875,0,.550498,.61705,.00384075,0,.576089,.601154,.00359557,0,.602427,.586008,.00337636,0,.629544,.570699,.00316019,0,.657479,.555166,.00296033,0,.686264,.539645,.00277552,0,.715924,.524159,.00259499,0,.746459,.508682,.00243257,0,.777789,.493163,.00227851,0,.809524,.478004,.00213083,0,.84127,.46347,.00199502,0,.873016,.448778,.00186967,0,.904762,.434105,.00174732,0,.936508,.419576,.00163861,0,.968254,.405541,.00153341,0,1,1,.0106462,0,0,1,.0106462,0,0,.999999,.010647,0,0,.999995,.0106502,0,0,.999985,.0106589,0,0,.999964,.0106773,0,0,.999925,.0107106,0,0,.999861,.0107655,0,712986e-10,.999763,.0108497,0,743959e-9,.999616,.0109716,0,.00227361,.999408,.0111408,0,.0046983,.999112,.0113659,0,.00800158,.998637,.0116475,0,.0121493,.996223,.0117231,0,.0171023,.994006,.0118064,0,.0228218,.992444,.0120254,0,.0292711,.991028,.0123314,0,.036417,.98803,.0124954,0,.0442295,.984816,.0126538,0,.0526815,.981399,.0128537,0,.0617492,.977085,.0129694,0,.0714114,.972154,.013091,0,.0816495,.966617,.0131166,0,.0924472,.960628,.0131583,0,.10379,.953295,.0131094,0,.115665,.94575,.0129966,0,.128062,.937654,.0128796,0,.140972,.927716,.0126477,0,.154387,.917932,.0123889,0,.168301,.907719,.012131,0,.182709,.89584,.0118013,0,.197608,.883526,.0114145,0,.212994,.870301,.0110075,0,.228867,.856272,.0106019,0,.245227,.842251,.0101938,0,.262074,.826466,.00973254,0,.279412,.810859,.0092846,0,.297244,.795051,.00883304,0,.315575,.780053,.00840272,0,.334412,.76575,.00796438,0,.35376,.752298,.00752526,0,.373631,.739153,.00711486,0,.394034,.725514,.00670361,0,.414983,.711473,.00632656,0,.436491,.696936,.00595206,0,.458575,.682126,.00559191,0,.481253,.667027,.00525362,0,.504547,.651875,.00493805,0,.528481,.636463,.00462848,0,.553081,.620641,.00433936,0,.578377,.604931,.00407,0,.604404,.589549,.00380864,0,.631197,.574712,.00357049,0,.658795,.559775,.00334466,0,.687238,.544514,.00312505,0,.716559,.529555,.00293199,0,.746776,.514402,.00274204,0,.777849,.499302,.00256647,0,.809524,.484114,.00239901,0,.84127,.469308,.00225148,0,.873016,.455133,.00210178,0,.904762,.440939,.0019727,0,.936508,.426627,.00184382,0,.968254,.412509,.00172548,0,1,1,.013628,0,0,1,.0136281,0,0,.999999,.0136289,0,0,.999995,.0136327,0,0,.999983,.0136427,0,0,.99996,.0136638,0,0,.999917,.0137022,0,0,.999846,.0137652,0,204597e-9,.999736,.0138615,0,.00116837,.999573,.0140007,0,.00303325,.99934,.0141927,0,.00580613,.999004,.0144457,0,.00945626,.998407,.0147489,0,.0139421,.995464,.014731,0,.0192202,.993328,.0148283,0,.0252495,.991799,.0150797,0,.0319921,.990397,.0154316,0,.0394138,.986835,.0155005,0,.0474843,.983938,.0157308,0,.0561763,.980154,.0158753,0,.0654661,.975659,.0159581,0,.0753326,.970171,.0159832,0,.0857571,.964803,.0160084,0,.0967236,.958366,.0159484,0,.108218,.950613,.0158001,0,.120227,.942874,.0155845,0,.132741,.935005,.0154292,0,.145751,.924991,.0150742,0,.159249,.914814,.0146757,0,.17323,.904743,.0143097,0,.187687,.893216,.0138695,0,.202619,.880769,.0133706,0,.218021,.868136,.0128606,0,.233894,.85469,.0123403,0,.250238,.840593,.0118091,0,.267052,.825808,.011253,0,.284341,.81009,.0107099,0,.302106,.79504,.0101636,0,.320354,.779757,.00964041,0,.33909,.764697,.00911896,0,.358322,.750913,.00859533,0,.378059,.738175,.00811592,0,.398311,.725242,.00764504,0,.41909,.711864,.00718885,0,.440412,.698009,.00675843,0,.462292,.683841,.00634984,0,.484748,.669391,.00595502,0,.507802,.654731,.00558671,0,.531477,.639805,.00523578,0,.555802,.624789,.00490834,0,.580805,.609325,.00459448,0,.606522,.593975,.00430342,0,.63299,.578983,.00403019,0,.66025,.564442,.0037707,0,.688346,.549835,.0035316,0,.717319,.535039,.00330255,0,.7472,.520403,.00308932,0,.777982,.505687,.00289335,0,.809524,.490939,.00270818,0,.84127,.476233,.0025343,0,.873016,.461624,.00237097,0,.904762,.447833,.00222065,0,.936508,.433992,.00207561,0,.968254,.420147,.00194955,0,1,1,.0173415,0,0,1,.0173416,0,0,.999999,.0173426,0,0,.999995,.0173468,0,0,.999983,.0173582,0,0,.999954,.0173822,0,0,.999908,.0174258,0,669501e-11,.999828,.0174973,0,427399e-9,.999705,.0176063,0,.00171019,.999524,.0177631,0,.0039248,.999263,.0179781,0,.00705382,.998878,.018258,0,.0110552,.998012,.0185551,0,.0158812,.994614,.0184264,0,.0214852,.993132,.0186385,0,.0278239,.991563,.0189067,0,.0348585,.989298,.0191577,0,.0425544,.986036,.0192522,0,.050881,.982558,.0194063,0,.059811,.978531,.019486,0,.0693209,.974198,.0195847,0,.0793895,.968148,.0194749,0,.0899984,.962565,.0194277,0,.101132,.956041,.0192991,0,.112775,.947749,.0189893,0,.124917,.94018,.018704,0,.137547,.93165,.0183458,0,.150655,.921798,.0178775,0,.164236,.911573,.0173618,0,.178281,.901569,.0168482,0,.192788,.890341,.016265,0,.207752,.877835,.0156199,0,.223171,.865472,.0149516,0,.239044,.852905,.0143274,0,.255371,.838906,.0136643,0,.272153,.824888,.0129903,0,.289393,.809977,.0123218,0,.307093,.794697,.0116572,0,.325259,.780028,.0110307,0,.343896,.765124,.0104236,0,.363012,.750411,.0098219,0,.382617,.737264,.00924397,0,.402719,.724799,.00868719,0,.423332,.712253,.00816476,0,.444469,.699267,.00767262,0,.466146,.685618,.00719746,0,.488383,.671736,.00673916,0,.511199,.657777,.00631937,0,.534618,.643497,.00592411,0,.558668,.62889,.00553928,0,.58338,.614299,.0051934,0,.608787,.599197,.00485985,0,.634929,.584175,.00454357,0,.661849,.569541,.00425787,0,.689594,.555193,.00397905,0,.718211,.540947,.00372364,0,.747742,.526593,.00348599,0,.778205,.512335,.00326103,0,.80953,.498017,.00305137,0,.84127,.483609,.00285485,0,.873016,.469368,.00267472,0,.904762,.455037,.00249945,0,.936508,.441493,.00234792,0,.968254,.428147,.00219936,0,1,1,.0219422,0,0,1,.0219423,0,0,.999998,.0219434,0,0,.999993,.0219481,0,0,.999981,.021961,0,0,.999949,.0219879,0,0,.999896,.0220367,0,593194e-10,.999808,.0221167,0,75364e-8,.99967,.0222383,0,.00237884,.999466,.0224125,0,.00495612,.999174,.0226495,0,.00844887,.998725,.0229525,0,.0128058,.996979,.0231123,0,.0179742,.994317,.0230742,0,.0239047,.992781,.0232895,0,.0305526,.991191,.0235734,0,.0378786,.987787,.0236152,0,.0458475,.985092,.0237994,0,.0544287,.981121,.0238553,0,.0635952,.976924,.0238706,0,.0733233,.97218,.0238704,0,.0835922,.965956,.0236598,0,.0943839,.959998,.0234735,0,.105682,.953245,.0232277,0,.117474,.944445,.0226973,0,.129747,.937087,.0223527,0,.142491,.928341,.0218144,0,.155697,.9184,.0211516,0,.169358,.907959,.0204553,0,.183469,.89808,.0197673,0,.198024,.887047,.0189915,0,.21302,.875221,.0182082,0,.228455,.86269,.0173584,0,.244329,.850735,.0165718,0,.260639,.837545,.0157524,0,.277389,.823639,.0149482,0,.29458,.809699,.0141431,0,.312216,.794797,.0133527,0,.3303,.780578,.0126193,0,.34884,.766019,.0118914,0,.367842,.751447,.0111839,0,.387315,.737275,.010514,0,.40727,.724545,.00987277,0,.427717,.712644,.00926569,0,.448671,.700432,.00869029,0,.470149,.687664,.00814691,0,.492167,.674288,.00763012,0,.514746,.660966,.00714437,0,.537911,.647264,.00668457,0,.561688,.633431,.00626581,0,.586108,.619133,.00585593,0,.611206,.604935,.00548188,0,.637022,.590236,.00513288,0,.663599,.575473,.0047906,0,.690989,.561228,.00448895,0,.719242,.547054,.00420233,0,.748411,.533175,.00392869,0,.778531,.519163,.00367445,0,.809583,.505328,.00344097,0,.84127,.491446,.00322003,0,.873016,.477356,.00301283,0,.904762,.46356,.00282592,0,.936508,.449623,.00264956,0,.968254,.436068,.00246956,0,1,1,.0276135,0,0,1,.0276136,0,0,.999998,.0276148,0,0,.999993,.0276201,0,0,.999976,.0276342,0,0,.999945,.027664,0,0,.999884,.0277179,0,18679e-8,.999784,.027806,0,.00119607,.99963,.0279394,0,.00318407,.999401,.0281295,0,.00613601,.999066,.0283858,0,.00999963,.998524,.0287027,0,.0147164,.995702,.0286256,0,.0202295,.993593,.0286733,0,.0264876,.992067,.0288989,0,.0334452,.990548,.0292135,0,.0410621,.986775,.0291296,0,.0493032,.984054,.0293099,0,.0581381,.979481,.0291881,0,.0675397,.975297,.0291598,0,.0774848,.96981,.028954,0,.0879528,.963524,.028628,0,.0989258,.957398,.0283135,0,.110388,.950088,.0278469,0,.122327,.941538,.0271798,0,.134729,.933332,.0265388,0,.147587,.924392,.0257776,0,.160889,.914581,.024916,0,.174631,.904347,.0240242,0,.188806,.894324,.0231229,0,.203409,.883724,.022153,0,.218437,.872207,.0211355,0,.233888,.859927,.0201048,0,.249761,.848373,.0191263,0,.266056,.836023,.0181306,0,.282774,.82289,.0171718,0,.299917,.809324,.0162196,0,.317488,.795361,.0152622,0,.335493,.781253,.01439,0,.353936,.767338,.013533,0,.372825,.753156,.0127244,0,.392168,.739122,.0119454,0,.411976,.725358,.0112054,0,.432259,.712949,.010487,0,.453032,.701621,.00984032,0,.47431,.689703,.00921495,0,.496111,.677216,.00862492,0,.518456,.664217,.00806882,0,.541367,.65137,.00755922,0,.564872,.638,.00705705,0,.589001,.62453,.00661266,0,.613789,.610601,.00618432,0,.639277,.59676,.00578033,0,.66551,.582433,.00540927,0,.692539,.568026,.00506104,0,.720422,.55414,.0047353,0,.749216,.540178,.00442889,0,.778974,.526513,.00414363,0,.809711,.512954,.00388237,0,.84127,.499403,.00362875,0,.873016,.486026,.00340827,0,.904762,.472345,.00318598,0,.936508,.458828,.00297635,0,.968254,.445379,.00279447,0,1,1,.0345716,0,0,1,.0345717,0,0,.999999,.034573,0,0,.999991,.0345787,0,0,.999974,.0345941,0,0,.999937,.0346263,0,188589e-11,.999869,.0346847,0,409238e-9,.999757,.0347798,0,.0017674,.999582,.0349233,0,.00413658,.999322,.0351265,0,.00747408,.998939,.0353967,0,.0117157,.998219,.0357018,0,.0167966,.994974,.0354726,0,.0226572,.993201,.0355621,0,.0292445,.991573,.0357641,0,.0365123,.989301,.0359252,0,.0444203,.985712,.0358017,0,.0529334,.982411,.0358353,0,.0620214,.977827,.035617,0,.0716574,.973278,.0354398,0,.0818186,.967397,.0350483,0,.0924846,.960696,.0344795,0,.103638,.954349,.0339861,0,.115263,.946066,.0331323,0,.127348,.938012,.032359,0,.13988,.929413,.0314413,0,.152849,.920355,.0304103,0,.166248,.910586,.0292785,0,.18007,.900609,.0281391,0,.194308,.890093,.0269103,0,.208958,.880013,.0257269,0,.224018,.869001,.0244671,0,.239485,.85751,.0232252,0,.255359,.84582,.0220117,0,.271638,.834383,.0208274,0,.288324,.822158,.0196628,0,.305419,.809056,.0185306,0,.322927,.795832,.0174174,0,.340851,.782547,.0163758,0,.359199,.7689,.015391,0,.377975,.755526,.0144488,0,.397189,.741681,.0135372,0,.416851,.728178,.0126957,0,.436971,.714642,.0118812,0,.457564,.702756,.0111165,0,.478644,.69175,.0104145,0,.500229,.680159,.00974439,0,.522339,.668073,.00911926,0,.544997,.655405,.00851393,0,.56823,.642921,.00797637,0,.592068,.629993,.00745119,0,.616546,.616828,.00696972,0,.641705,.603305,.00652425,0,.66759,.589833,.00610188,0,.694255,.575945,.00570834,0,.72176,.561745,.00533384,0,.750168,.548277,.00500001,0,.779545,.534467,.00467582,0,.809933,.521032,.00438092,0,.841272,.507877,.00410348,0,.873016,.494654,.00383618,0,.904762,.481592,.00358699,0,.936508,.468509,.00337281,0,.968254,.455293,.00316196,0,1,1,.0430698,0,0,1,.0430699,0,0,.999998,.0430713,0,0,.999991,.0430773,0,0,.99997,.0430936,0,0,.999928,.0431277,0,406396e-10,.999852,.0431893,0,744376e-9,.999724,.0432895,0,.0024806,.999527,.0434397,0,.00524779,.99923,.0436507,0,.00898164,.998783,.0439255,0,.0136083,.997507,.0441104,0,.0190582,.994418,.0438225,0,.0252694,.992864,.0439396,0,.0321879,.991127,.0440962,0,.039767,.987331,.0438408,0,.0479667,.984819,.0438991,0,.056752,.980384,.0435906,0,.0660929,.975846,.0432543,0,.075963,.970748,.0428293,0,.0863398,.964303,.042153,0,.0972035,.95772,.0414111,0,.108537,.950747,.0405893,0,.120325,.942533,.0394887,0,.132554,.934045,.0383544,0,.145215,.924942,.037057,0,.158296,.915811,.0356993,0,.17179,.90612,.0342401,0,.185691,.896434,.0328078,0,.199993,.886021,.031288,0,.214691,.876081,.0297776,0,.229782,.865608,.0282334,0,.245265,.854924,.026749,0,.261138,.843607,.02526,0,.277401,.832456,.0238214,0,.294056,.821342,.0224682,0,.311104,.809303,.0211297,0,.328548,.796468,.0198387,0,.346394,.784046,.0186227,0,.364645,.771262,.0174561,0,.38331,.758118,.0163806,0,.402396,.745075,.0153287,0,.421912,.731926,.0143647,0,.44187,.71863,.0134363,0,.462283,.705414,.0125603,0,.483165,.693792,.0117508,0,.504535,.683108,.0110016,0,.52641,.67183,.0102757,0,.548816,.66015,.00962044,0,.571776,.647907,.00898031,0,.595323,.635734,.00840811,0,.619489,.623208,.00786211,0,.644317,.610438,.00734953,0,.669852,.597345,.00687688,0,.696148,.584138,.00643469,0,.723267,.5707,.00602236,0,.75128,.556966,.0056324,0,.780258,.543607,.00528277,0,.810268,.530213,.00493999,0,.841311,.516912,.00462265,0,.873016,.503916,.0043307,0,.904762,.491146,.00406858,0,.936508,.478439,.00381436,0,.968254,.465834,.00358003,0,1,1,.0534039,0,0,1,.053404,0,0,.999998,.0534055,0,0,.999989,.0534116,0,0,.999968,.0534283,0,0,.999918,.0534633,0,155895e-9,.99983,.0535262,0,.00120914,.999685,.0536281,0,.00334944,.999461,.0537799,0,.00653077,.999119,.0539902,0,.0106718,.998582,.0542524,0,.0156907,.995919,.0540318,0,.0215147,.993735,.0538914,0,.0280801,.992126,.0539557,0,.0353323,.990266,.0540401,0,.0432247,.986317,.0536064,0,.0517172,.983213,.0534425,0,.0607754,.978303,.0528622,0,.0703698,.973665,.0523363,0,.0804742,.968091,.0516165,0,.0910667,.961026,.0505434,0,.102128,.954333,.049523,0,.113641,.946372,.0481698,0,.125591,.938254,.0467674,0,.137965,.929516,.0452341,0,.150754,.920106,.0435083,0,.163947,.910899,.0417399,0,.177537,.901532,.0399389,0,.191516,.891919,.0380901,0,.205881,.882006,.0362341,0,.220626,.871965,.0343444,0,.235749,.862145,.0324832,0,.251248,.852058,.0306681,0,.267121,.84161,.0289097,0,.283368,.830806,.0272079,0,.299992,.820476,.0256089,0,.316992,.809514,.0240394,0,.334374,.797865,.0225379,0,.35214,.785621,.0211235,0,.370296,.773765,.0197908,0,.388849,.761629,.0185235,0,.407807,.748891,.0173358,0,.427178,.736437,.0162305,0,.446974,.723707,.0151778,0,.467207,.710606,.0141791,0,.487892,.698019,.0132592,0,.509046,.686203,.0123887,0,.530687,.675692,.0115976,0,.552839,.664826,.0108325,0,.575527,.65349,.0101348,0,.59878,.641774,.00947756,0,.622634,.629794,.00886058,0,.647128,.617647,.00828526,0,.672308,.60534,.00775312,0,.698231,.592718,.00726033,0,.724958,.579746,.00679731,0,.752563,.566763,.00636111,0,.781127,.553515,.00595228,0,.810733,.540118,.00556876,0,.841426,.527325,.00523051,0,.873016,.514265,.00490712,0,.904762,.501406,.00460297,0,.936508,.488922,.00431247,0,.968254,.476541,.0040472,0,1,1,.0659184,0,0,1,.0659185,0,0,.999998,.06592,0,0,.999988,.0659259,0,0,.999963,.0659423,0,0,.999907,.0659764,0,374198e-9,.999806,.0660376,0,.00182071,.999639,.0661361,0,.0043894,.999378,.0662814,0,.00800055,.998985,.0664779,0,.0125594,.998285,.0666914,0,.0179786,.995071,.0661989,0,.0241822,.993172,.0660454,0,.031106,.991438,.0660105,0,.0386952,.988428,.0656875,0,.0469032,.985218,.0652913,0,.0556905,.981128,.0647107,0,.065023,.976015,.0638491,0,.0748717,.97097,.062993,0,.0852112,.964582,.0617927,0,.0960199,.957383,.0603626,0,.107279,.949969,.0588128,0,.118971,.941843,.0570274,0,.131084,.933624,.0551885,0,.143604,.924543,.053122,0,.156521,.914919,.0508897,0,.169825,.905773,.0486418,0,.18351,.896434,.0463364,0,.197569,.887195,.0440623,0,.211997,.877706,.0417799,0,.226789,.867719,.03945,0,.241944,.858587,.037243,0,.257458,.849317,.0350956,0,.273331,.839585,.0329852,0,.289563,.829856,.0310028,0,.306154,.819589,.0290953,0,.323108,.809714,.0272738,0,.340426,.79934,.0255631,0,.358113,.788224,.0239175,0,.376175,.776619,.0223831,0,.394616,.76521,.0209298,0,.413445,.753716,.0195786,0,.432671,.741564,.0183001,0,.452305,.729413,.0171259,0,.472358,.717146,.0159933,0,.492845,.70436,.0149495,0,.513783,.69219,.0139681,0,.535189,.680289,.0130577,0,.557087,.669611,.0122198,0,.5795,.659113,.0114174,0,.602459,.648148,.0106729,0,.625997,.636905,.00998997,0,.650154,.625154,.00934313,0,.674976,.613481,.00874839,0,.700518,.60154,.00818265,0,.726845,.58943,.00766889,0,.754032,.576828,.00717153,0,.782167,.564194,.00672696,0,.811344,.551501,.00630863,0,.841644,.538635,.00592177,0,.873016,.525724,.00554888,0,.904762,.513209,.00520225,0,.936508,.500457,.00488231,0,.968254,.48799,.00457153,0,1,1,.0810131,0,0,1,.0810133,0,0,.999997,.0810145,0,0,.999985,.08102,0,0,.999956,.0810347,0,195026e-10,.999893,.0810656,0,719316e-9,.999777,.0811205,0,.00259774,.999583,.081208,0,.00561807,.999281,.0813343,0,.00967472,.998813,.0814969,0,.0146627,.997597,.0815217,0,.0204902,.994379,.0808502,0,.0270802,.992744,.0806792,0,.0343674,.990745,.0804589,0,.0422974,.986646,.0796107,0,.0508242,.983611,.0790913,0,.0599087,.978869,.0780746,0,.0695175,.973475,.0768218,0,.0796223,.967845,.0754926,0,.0901983,.960778,.0737063,0,.101224,.953333,.0718052,0,.112682,.945274,.0695946,0,.124555,.936955,.0672492,0,.136831,.928319,.0647732,0,.149496,.919075,.0620947,0,.162542,.909114,.0591816,0,.175958,.900137,.0563917,0,.189739,.891069,.0535392,0,.203877,.882262,.0507642,0,.218368,.873232,.0479793,0,.233208,.864042,.045226,0,.248393,.855002,.0425413,0,.263923,.846569,.0400126,0,.279796,.837714,.0375269,0,.296012,.828918,.0352027,0,.312573,.819783,.0330011,0,.329479,.810129,.0308908,0,.346734,.800866,.0289112,0,.364342,.79093,.0270255,0,.382307,.780593,.0252758,0,.400637,.769511,.0236178,0,.419337,.758558,.0220652,0,.438418,.747632,.0206289,0,.457889,.736146,.0192873,0,.477761,.724093,.0180333,0,.49805,.71234,.0168264,0,.51877,.700201,.015746,0,.53994,.687949,.0147027,0,.561581,.676163,.0137512,0,.583718,.665001,.0128655,0,.60638,.65472,.0120366,0,.629599,.644213,.0112604,0,.653415,.633382,.0105413,0,.677874,.62212,.00986498,0,.70303,.610631,.00923308,0,.728948,.599078,.00864206,0,.755706,.587519,.00811784,0,.783396,.575505,.00761237,0,.812121,.563148,.00713949,0,.841989,.550828,.00668379,0,.873035,.538458,.00627715,0,.904762,.525905,.00588336,0,.936508,.513517,.00552687,0,.968254,.501395,.00519681,0,1,1,.0991506,0,0,1,.0991504,0,0,.999996,.0991515,0,0,.999984,.0991558,0,0,.999947,.0991672,0,114389e-9,.999874,.0991912,0,.00121503,.999739,.0992331,0,.00356108,.999514,.0992983,0,.00705578,.999159,.0993877,0,.011574,.998586,.0994837,0,.017003,.995731,.0988425,0,.0232484,.993384,.098276,0,.0302318,.991615,.0979269,0,.0378884,.989029,.0973432,0,.0461641,.985373,.0963539,0,.0550136,.981278,.0952306,0,.0643988,.975777,.0936233,0,.0742868,.970526,.0920219,0,.0846501,.963755,.0898912,0,.0954644,.956676,.0876064,0,.106709,.948099,.0847751,0,.118367,.939718,.0818638,0,.130423,.931305,.078857,0,.142862,.922342,.0756127,0,.155674,.912842,.0721473,0,.168849,.903304,.0686195,0,.182378,.89411,.0650589,0,.196255,.885512,.0616022,0,.210473,.877193,.0582434,0,.225027,.86877,.0548979,0,.239915,.860267,.0516095,0,.255132,.851915,.048468,0,.270678,.843912,.0454447,0,.286551,.83604,.0425612,0,.302751,.828245,.0398752,0,.31928,.820159,.0373198,0,.336138,.81167,.034916,0,.35333,.802659,.0326402,0,.370858,.793921,.0304901,0,.388728,.784713,.0284857,0,.406944,.774946,.0266186,0,.425515,.76448,.0248593,0,.444449,.753793,.0232114,0,.463756,.743506,.0217039,0,.483447,.732555,.0202841,0,.503535,.720965,.0189648,0,.524036,.709422,.0177189,0,.544968,.697756,.0165626,0,.56635,.685565,.015483,0,.588208,.673987,.0144892,0,.610569,.66244,.0135607,0,.633466,.651675,.0126956,0,.656936,.641598,.0118788,0,.681025,.63121,.0111261,0,.705788,.620514,.010437,0,.731289,.609366,.00978747,0,.757606,.598137,.00917257,0,.784834,.586966,.00859778,0,.813085,.575549,.00806803,0,.842485,.563797,.00757294,0,.87313,.551758,.00710592,0,.904762,.539894,.0066841,0,.936508,.527901,.00627901,0,.968254,.515819,.00590506,0,1,1,.120864,0,0,1,.120864,0,0,.999996,.120864,0,0,.99998,.120867,0,0,.99994,.120872,0,323781e-9,.999852,.120884,0,.00188693,.999693,.120903,0,.00473489,.999426,.120929,0,.00872704,.999002,.120955,0,.0137237,.998235,.120918,0,.0196068,.994608,.119764,0,.0262803,.992997,.119265,0,.0336657,.990968,.11863,0,.0416987,.987002,.117261,0,.0503261,.983524,.116009,0,.0595035,.97875,.114252,0,.0691935,.972652,.11193,0,.0793645,.966613,.109555,0,.0899894,.959275,.106612,0,.101045,.951272,.103375,0,.112512,.942323,.0996594,0,.124372,.933679,.0958841,0,.136611,.924822,.0919265,0,.149216,.915742,.0878061,0,.162176,.906348,.0834894,0,.175482,.896883,.079085,0,.189125,.88774,.0746745,0,.203098,.87986,.0705773,0,.217396,.871998,.0665005,0,.232015,.864325,.0625413,0,.24695,.856685,.0586781,0,.2622,.84925,.0550063,0,.277761,.841719,.0514727,0,.293634,.834755,.0481398,0,.309819,.827853,.0450172,0,.326315,.820888,.0420969,0,.343126,.813616,.0393702,0,.360254,.805767,.0367771,0,.377701,.797338,.0343274,0,.395474,.789122,.0320529,0,.413577,.780601,.0299485,0,.432018,.771424,.0279812,0,.450804,.761502,.0261054,0,.469944,.751166,.0243942,0,.489451,.741276,.0228087,0,.509337,.730898,.0213265,0,.529617,.719878,.0199307,0,.550307,.708379,.0186574,0,.571428,.697165,.0174446,0,.593003,.685554,.0163144,0,.615059,.673631,.015276,0,.637628,.662385,.0143003,0,.660746,.651059,.0134112,0,.68446,.640451,.0125794,0,.70882,.630536,.011793,0,.733893,.620316,.0110547,0,.759756,.609722,.0103668,0,.786505,.598804,.00973009,0,.814259,.587871,.00912812,0,.843157,.577121,.00858916,0,.87334,.566019,.00807333,0,.904762,.554664,.00759687,0,.936508,.543101,.00714759,0,.968254,.531558,.00673418,0,1,1,.146767,0,0,1,.146767,0,0,.999997,.146767,0,0,.999977,.146765,0,320658e-11,.999929,.146762,0,682576e-9,.999823,.146753,0,.00276402,.999633,.146735,0,.00614771,.999314,.146699,0,.0106613,.998796,.14662,0,.0161546,.997124,.146107,0,.0225063,.994062,.144857,0,.0296198,.992154,.144011,0,.037417,.989186,.142712,0,.0458348,.985279,.140926,0,.0548211,.980826,.13885,0,.0643326,.975056,.136168,0,.074333,.969005,.133217,0,.0847917,.961554,.12959,0,.0956828,.954206,.125886,0,.106984,.945046,.121335,0,.118675,.935678,.116492,0,.130741,.926748,.111635,0,.143166,.917764,.106625,0,.155939,.908358,.101325,0,.169049,.899219,.0960249,0,.182487,.890089,.0906527,0,.196245,.881488,.0853905,0,.210317,.874031,.0804177,0,.224697,.866932,.0756005,0,.23938,.859976,.0709019,0,.254364,.853375,.0664391,0,.269646,.846971,.0622012,0,.285223,.840483,.058129,0,.301096,.833969,.0542762,0,.317265,.82806,.0507042,0,.333729,.822128,.047368,0,.350491,.815989,.044272,0,.367554,.809336,.0413444,0,.38492,.802177,.038601,0,.402594,.79441,.0360227,0,.420582,.786573,.0336383,0,.438891,.778619,.0314321,0,.457527,.77,.029362,0,.476499,.760698,.0274102,0,.49582,.750932,.0256146,0,.5155,.740993,.023974,0,.535555,.731159,.0224182,0,.556,.720836,.0209889,0,.576855,.709913,.0196411,0,.598143,.698415,.0183824,0,.619888,.68745,.0172222,0,.642123,.676154,.0161509,0,.664883,.664383,.0151397,0,.688211,.6533,.0141873,0,.71216,.642072,.0133105,0,.736792,.631412,.0124932,0,.762186,.621622,.0117408,0,.788439,.611681,.0110358,0,.815672,.60142,.0103775,0,.844034,.59083,.00975623,0,.873699,.580254,.00918084,0,.904765,.569841,.00864721,0,.936508,.559224,.00815731,0,.968254,.548315,.00767924,0,1,1,.177563,0,0,1,.177563,0,0,.999994,.177562,0,0,.999972,.177555,0,664171e-10,.999914,.177536,0,.0012276,.999787,.177496,0,.00388025,.999556,.17742,0,.00783463,.999165,.177285,0,.0128953,.9985,.177037,0,.0189053,.995388,.175634,0,.025742,.993102,.174375,0,.033309,.990992,.173121,0,.0415298,.986932,.170896,0,.0503425,.982786,.16847,0,.0596964,.977592,.165455,0,.0695498,.971075,.161676,0,.0798676,.963967,.157458,0,.0906201,.956397,.152836,0,.101783,.947489,.147467,0,.113333,.937564,.14145,0,.125254,.928182,.135383,0,.137529,.919027,.129212,0,.150144,.909618,.12276,0,.163088,.900492,.116273,0,.176351,.891671,.1098,0,.189924,.883146,.103362,0,.203799,.875151,.0970799,0,.21797,.868338,.0911732,0,.232433,.862033,.0854966,0,.247182,.856107,.0800691,0,.262216,.850644,.0749618,0,.27753,.845261,.070079,0,.293124,.839885,.0654321,0,.308997,.834609,.0610975,0,.325149,.829083,.0569741,0,.341581,.82404,.0531736,0,.358294,.818968,.049665,0,.37529,.813496,.0463856,0,.392573,.807533,.0433217,0,.410148,.80099,.0404402,0,.428019,.793891,.0377578,0,.446192,.786281,.0352616,0,.464676,.778773,.0329577,0,.483478,.770737,.030808,0,.502608,.762094,.0287964,0,.522079,.752898,.0269254,0,.541905,.743306,.0251926,0,.5621,.733416,.023595,0,.582684,.723742,.0221155,0,.603677,.713542,.0207435,0,.625106,.702755,.019434,0,.646998,.691484,.0182046,0,.66939,.680531,.0170771,0,.692324,.66953,.0160339,0,.715849,.658126,.0150677,0,.740028,.646933,.0141551,0,.764937,.636107,.0133179,0,.790673,.625271,.0125284,0,.817358,.615225,.0117937,0,.84515,.605678,.0111181,0,.874244,.59583,.0104759,0,.904828,.585704,.00986672,0,.936508,.575413,.00929712,0,.968254,.565373,.00876713,0,1,1,.214058,0,0,.999999,.214058,0,0,.999994,.214055,0,0,.999966,.214039,0,259642e-9,.999893,.213998,0,.00200075,.999737,.21391,0,.00527775,.999449,.213745,0,.00983959,.99896,.213458,0,.0154755,.9979,.212855,0,.0220249,.994278,.210779,0,.0293654,.992254,.20926,0,.0374021,.98881,.206908,0,.0460604,.984715,.204009,0,.0552802,.979738,.200471,0,.0650127,.972884,.195813,0,.0752175,.965996,.190856,0,.0858612,.957974,.185077,0,.0969155,.949155,.17868,0,.108356,.939288,.171513,0,.120163,.928996,.163838,0,.132319,.919563,.156246,0,.144808,.910004,.148359,0,.157618,.900791,.140417,0,.170737,.892135,.132569,0,.184155,.883803,.124741,0,.197866,.876034,.117091,0,.211861,.869219,.109835,0,.226134,.863062,.102859,0,.240682,.857795,.0962928,0,.255499,.853009,.0900725,0,.270583,.848603,.0842101,0,.285931,.844335,.0786527,0,.301542,.840208,.0734397,0,.317415,.836035,.0685334,0,.33355,.83172,.0639275,0,.349948,.827135,.0595909,0,.36661,.822797,.0556204,0,.383539,.818387,.0519394,0,.400738,.813565,.0485317,0,.41821,.808142,.0453138,0,.435961,.802212,.0423354,0,.453997,.79573,.0395553,0,.472324,.788741,.036988,0,.490951,.781093,.0345688,0,.509887,.773597,.0323297,0,.529144,.765622,.0302719,0,.548735,.757083,.0283477,0,.568674,.747992,.0265562,0,.588979,.738591,.0248844,0,.609671,.728719,.0233342,0,.630773,.719146,.0219081,0,.652314,.709165,.0205711,0,.674328,.69875,.0193248,0,.696854,.687884,.0181582,0,.719942,.676818,.0170746,0,.743651,.666247,.0160718,0,.768057,.655284,.0151262,0,.793253,.64401,.0142561,0,.819363,.633353,.0134327,0,.846547,.622674,.012653,0,.875017,.612265,.0119354,0,.905021,.602455,.0112533,0,.936508,.593147,.0106234,0,.968254,.583592,.0100213,0,1,1,.25717,0,0,1,.25717,0,0,.999992,.257164,0,0,.999958,.257135,0,641715e-9,.999864,.25706,0,.00305314,.999666,.256897,0,.00700975,.999302,.256596,0,.0122194,.998663,.25607,0,.0184622,.995607,.254123,0,.0255773,.993094,.252081,0,.0334439,.9907,.249867,0,.0419696,.98594,.246118,0,.0510823,.981214,.242049,0,.0607242,.974966,.236869,0,.0708486,.967589,.230724,0,.081417,.95915,.223635,0,.0923974,.950257,.21596,0,.103763,.940165,.207296,0,.115491,.929396,.197901,0,.127562,.919288,.188437,0,.13996,.909428,.178762,0,.15267,.900105,.169072,0,.165679,.891418,.159478,0,.178979,.883347,.15002,0,.192558,.875992,.140813,0,.20641,.869466,.13196,0,.220529,.863699,.123501,0,.234907,.858553,.115436,0,.249542,.854379,.107901,0,.264428,.850894,.10088,0,.279564,.847632,.0942296,0,.294947,.844571,.0879861,0,.310575,.84163,.0821534,0,.326448,.838542,.0766409,0,.342566,.835412,.0715322,0,.358929,.831899,.0666883,0,.37554,.828177,.0622175,0,.392399,.82416,.0580452,0,.409511,.820393,.054267,0,.426878,.816068,.0507172,0,.444506,.811201,.0474041,0,.4624,.805785,.0443174,0,.480566,.799878,.0414562,0,.499013,.793469,.0388147,0,.517749,.786473,.0363453,0,.536785,.778874,.0340225,0,.556134,.771277,.0318599,0,.575809,.763426,.0298859,0,.595827,.755044,.0280357,0,.616207,.746161,.0262979,0,.636973,.737124,.0247295,0,.65815,.72761,.0232514,0,.679772,.717822,.0218755,0,.701876,.708279,.0205942,0,.724509,.698333,.0193947,0,.74773,.68802,.0182717,0,.771609,.677321,.0172044,0,.79624,.666504,.0162122,0,.821743,.656184,.0152924,0,.84828,.64556,.0144326,0,.876069,.634636,.0136157,0,.905404,.624124,.0128612,0,.936508,.613914,.0121435,0,.968254,.603589,.0114887,0,1,1,.307946,0,0,.999999,.307945,0,0,.999988,.307934,0,204479e-10,.999944,.307886,0,.00127833,.999824,.307756,0,.00445047,.999565,.30748,0,.00914673,.999085,.306966,0,.0150498,.998103,.306004,0,.0219367,.994249,.303028,0,.0296485,.991807,.300435,0,.038068,.987773,.296554,0,.0471062,.982673,.2916,0,.0566942,.976623,.285641,0,.0667768,.968757,.27815,0,.0773099,.959849,.269529,0,.088257,.950663,.260248,0,.0995879,.940129,.249704,0,.111277,.92895,.238291,0,.123304,.917996,.226501,0,.13565,.907813,.214669,0,.148299,.898305,.202835,0,.161237,.889626,.191158,0,.174455,.88175,.179695,0,.187941,.874715,.168548,0,.201687,.868746,.15792,0,.215687,.863703,.147807,0,.229933,.859315,.138149,0,.24442,.855538,.128993,0,.259145,.852428,.120414,0,.274103,.850168,.112498,0,.289293,.848132,.105054,0,.304711,.846291,.0981087,0,.320357,.844431,.0915942,0,.33623,.842493,.0855056,0,.35233,.840368,.0798204,0,.368658,.83798,.0745097,0,.385214,.83523,.0695424,0,.402002,.832091,.0649092,0,.419023,.828667,.0606291,0,.436282,.824805,.0566523,0,.453782,.820988,.0530229,0,.471529,.816635,.0496364,0,.489528,.811725,.0464658,0,.507788,.806316,.0435082,0,.526317,.800469,.0407873,0,.545124,.794107,.038255,0,.564221,.787218,.0358825,0,.583621,.779872,.0336785,0,.603341,.772097,.0316379,0,.623397,.764484,.0297379,0,.643812,.756428,.0279581,0,.664611,.748022,.0263153,0,.685824,.739268,.0247799,0,.707488,.73024,.0233385,0,.729646,.720893,.0220035,0,.752354,.71119,.0207555,0,.77568,.701791,.0195843,0,.799715,.692184,.0184891,0,.824574,.682258,.0174541,0,.850417,.67206,.0164873,0,.877466,.661717,.0155959,0,.90604,.651462,.0147519,0,.936528,.641467,.0139727,0,.968254,.631229,.0132363,0,1,1,.367573,0,0,.999999,.367571,0,0,.999984,.367553,0,183382e-9,.999925,.367473,0,.00225254,.999759,.367259,0,.00628165,.99941,.366801,0,.0117858,.998739,.365946,0,.0184359,.995529,.363191,0,.0260114,.992875,.360171,0,.0343581,.989135,.355981,0,.0433637,.984166,.350401,0,.0529438,.977871,.343348,0,.0630334,.96951,.334341,0,.0735805,.959964,.323862,0,.0845437,.950162,.312521,0,.095889,.938882,.299577,0,.107588,.926992,.285573,0,.119617,.915589,.271212,0,.131957,.904791,.256611,0,.144591,.895177,.242224,0,.157503,.886403,.227952,0,.170682,.878957,.214192,0,.184117,.872418,.200795,0,.197799,.867029,.188015,0,.21172,.862835,.175975,0,.225873,.859411,.164526,0,.240253,.856655,.153693,0,.254854,.854519,.14352,0,.269673,.852828,.13397,0,.284707,.851412,.124984,0,.299953,.850609,.116748,0,.315408,.849855,.10905,0,.331073,.849017,.101839,0,.346946,.848079,.0951359,0,.363028,.846911,.0888774,0,.379318,.845445,.0830375,0,.395818,.84362,.0775844,0,.41253,.841411,.0725054,0,.429457,.838768,.0677691,0,.446602,.835801,.0634016,0,.463968,.832341,.0593095,0,.481561,.828424,.0555121,0,.499386,.824312,.052024,0,.51745,.819918,.0487865,0,.535761,.815072,.0457801,0,.554328,.809863,.0430184,0,.573162,.804164,.0404245,0,.592275,.798034,.0380146,0,.611681,.791436,.0357436,0,.631398,.784498,.0336475,0,.651445,.777125,.0316666,0,.671845,.769365,.0298122,0,.692628,.761579,.0281001,0,.713827,.753746,.0265049,0,.735484,.745573,.0250067,0,.75765,.737083,.0236026,0,.78039,.728545,.0223302,0,.803789,.719691,.0211243,0,.82796,.710569,.0199983,0,.853056,.701216,.0189569,0,.879298,.692094,.0179702,0,.907014,.682909,.0170418,0,.936691,.673509,.0161732,0,.968254,.663863,.0153406,0,1,1,.437395,0,0,.999998,.437394,0,0,.99998,.437363,0,616704e-9,.999891,.437232,0,.00367925,.999656,.436877,0,.00867446,.999148,.436121,0,.0150679,.997959,.434564,0,.022531,.993464,.430134,0,.0308507,.990606,.426077,0,.0398805,.985027,.419397,0,.0495148,.978491,.41118,0,.0596749,.969643,.40048,0,.0703001,.959189,.38769,0,.0813427,.948223,.373575,0,.0927641,.935955,.357622,0,.104533,.923237,.34043,0,.116624,.911074,.322735,0,.129015,.899724,.30479,0,.141687,.890189,.287392,0,.154626,.881796,.270248,0,.167818,.874781,.253659,0,.181252,.869166,.237786,0,.194918,.864725,.222618,0,.208807,.861565,.208356,0,.222913,.859284,.194867,0,.237229,.857677,.18212,0,.25175,.856714,.17018,0,.266473,.856155,.158969,0,.281392,.8558,.148413,0,.296505,.855672,.138578,0,.311811,.855538,.129345,0,.327306,.855689,.120861,0,.342991,.855767,.112969,0,.358864,.855618,.105593,0,.374925,.85525,.0987451,0,.391176,.854583,.0923727,0,.407616,.853534,.0864143,0,.424249,.852061,.0808338,0,.441076,.850253,.0756771,0,.4581,.848004,.0708612,0,.475324,.845333,.0663784,0,.492754,.842376,.0622631,0,.510394,.838956,.0584112,0,.528251,.835121,.0548328,0,.546331,.830842,.0514838,0,.564644,.826212,.048355,0,.583198,.821522,.0454714,0,.602005,.816551,.0428263,0,.621078,.811211,.0403612,0,.640434,.805479,.038039,0,.660089,.799409,.0358739,0,.680066,.79306,.0338727,0,.70039,.786395,.0319985,0,.721094,.779416,.030241,0,.742215,.77214,.0285951,0,.7638,.764636,.0270747,0,.785912,.756836,.0256354,0,.808628,.749315,.0243027,0,.832055,.741561,.0230497,0,.856338,.733589,.0218801,0,.88169,.725479,.020784,0,.908441,.717255,.0197702,0,.937125,.708829,.0188168,0,.968254,.700191,.0179113,0,1,1,.518937,0,0,.999998,.518933,0,0,.999967,.518883,0,.00147741,.999832,.51866,0,.00573221,.999466,.518057,0,.011826,.998644,.516752,0,.0192116,.994458,.512347,0,.027573,.991223,.507675,0,.0367099,.985515,.500188,0,.046487,.978308,.490408,0,.0568071,.968359,.477357,0,.0675984,.95682,.461752,0,.0788059,.943929,.443796,0,.090386,.930224,.423893,0,.102304,.916514,.402682,0,.114532,.903653,.380914,0,.127047,.892315,.359212,0,.139828,.882942,.338102,0,.152861,.875438,.31773,0,.16613,.869642,.298186,0,.179624,.865304,.279491,0,.193332,.862382,.261804,0,.207247,.860666,.245146,0,.22136,.859788,.229406,0,.235666,.859608,.214605,0,.250158,.859912,.200691,0,.264832,.86053,.187623,0,.279684,.861368,.17539,0,.294711,.862237,.163901,0,.309911,.863127,.153175,0,.32528,.863923,.143147,0,.340819,.864567,.133781,0,.356524,.865013,.125042,0,.372397,.86539,.116952,0,.388438,.865591,.109476,0,.404645,.865517,.102542,0,.421022,.865084,.0960688,0,.437569,.864309,.0900499,0,.454287,.863151,.0844328,0,.471181,.861649,.0792218,0,.488253,.859742,.0743482,0,.505507,.857446,.0697963,0,.522947,.854757,.0655364,0,.54058,.851783,.061608,0,.558412,.848516,.0579701,0,.576449,.844897,.0545742,0,.594701,.840956,.0514167,0,.613178,.836676,.0484598,0,.631892,.832075,.0456934,0,.650856,.827191,.0431178,0,.670088,.822295,.0407718,0,.689606,.817294,.0386032,0,.709434,.812013,.0365675,0,.7296,.806465,.0346547,0,.750138,.800691,.0328717,0,.771093,.794709,.031211,0,.792519,.788493,.0296504,0,.814488,.782049,.0281782,0,.837097,.775403,.0267965,0,.860481,.76857,.0255002,0,.884842,.761536,.0242759,0,.910494,.754303,.0231142,0,.937985,.74692,.0220305,0,.968254,.739745,.0210192,0,1,1,.613914,0,0,.999996,.613907,0,963597e-10,.999942,.613814,0,.00301247,.999704,.613407,0,.00870385,.999046,.612302,0,.0160714,.995516,.608266,0,.0245899,.991726,.602863,0,.0339681,.985157,.593956,0,.0440254,.97642,.581748,0,.0546409,.964404,.565183,0,.0657284,.950601,.545273,0,.0772246,.935158,.522129,0,.0890812,.919364,.496782,0,.10126,.904754,.470571,0,.113731,.89176,.444037,0,.126469,.881492,.418322,0,.139454,.873656,.393522,0,.15267,.868053,.369795,0,.166101,.864336,.347171,0,.179736,.862259,.325737,0,.193565,.861556,.305532,0,.207578,.861776,.286416,0,.221769,.862661,.268355,0,.23613,.864015,.251334,0,.250656,.865711,.235352,0,.265343,.867519,.220302,0,.280187,.869351,.206161,0,.295183,.871144,.192908,0,.31033,.872839,.180505,0,.325624,.874307,.168848,0,.341065,.875667,.158021,0,.35665,.876758,.147877,0,.37238,.87764,.138441,0,.388253,.878237,.129627,0,.404269,.878563,.121415,0,.42043,.878572,.113741,0,.436735,.87842,.106652,0,.453187,.878057,.100097,0,.469786,.877413,.0940128,0,.486536,.87646,.0883462,0,.503439,.875233,.0830924,0,.520498,.8737,.0781975,0,.537717,.871873,.07364,0,.555102,.86978,.0694103,0,.572657,.867405,.0654696,0,.59039,.864751,.0617914,0,.608307,.861818,.0583491,0,.626419,.858645,.0551443,0,.644733,.855307,.0521894,0,.663264,.851736,.0494334,0,.682025,.847927,.0468504,0,.701032,.843888,.0444261,0,.720308,.839629,.0421497,0,.739875,.835158,.0400082,0,.759764,.830509,.0380076,0,.780014,.825714,.0361488,0,.800673,.820729,.0343956,0,.821803,.815751,.0327781,0,.843492,.810752,.031275,0,.86586,.805587,.0298542,0,.889087,.800317,.0285397,0,.913466,.79489,.0272948,0,.93952,.789314,.0261139,0,.96835,.783593,.0249938,0,1,1,.724258,0,0,.999992,.724243,0,726889e-9,.99987,.724044,0,.00569574,.999336,.72317,0,.0131702,.996271,.719432,0,.0220738,.991159,.712576,0,.0319405,.982465,.700927,0,.0425202,.97049,.684297,0,.0536599,.953973,.661244,0,.065258,.935546,.633804,0,.0772427,.916596,.603071,0,.0895616,.899353,.57105,0,.102175,.885216,.539206,0,.11505,.875076,.508714,0,.128164,.868334,.479571,0,.141495,.864414,.451796,0,.155026,.862678,.425328,0,.168745,.862835,.400352,0,.182639,.864067,.376532,0,.196699,.866086,.35391,0,.210915,.868557,.332424,0,.225282,.871271,.312053,0,.239792,.874058,.292764,0,.25444,.8768,.27453,0,.269223,.87939,.257297,0,.284135,.8819,.24114,0,.299174,.884187,.225934,0,.314337,.886262,.211669,0,.329622,.888119,.198311,0,.345026,.889709,.185783,0,.360549,.891054,.174063,0,.376189,.892196,.163143,0,.391946,.893101,.152952,0,.407819,.893803,.143475,0,.423808,.894277,.134647,0,.439914,.894532,.126434,0,.456137,.894576,.1188,0,.472479,.894393,.111694,0,.48894,.893976,.105069,0,.505523,.893346,.0989077,0,.52223,.892502,.0931724,0,.539064,.891441,.0878276,0,.556028,.890276,.082903,0,.573125,.888972,.0783505,0,.590361,.887469,.0741083,0,.607741,.885785,.0701633,0,.62527,.883914,.0664835,0,.642957,.881872,.0630567,0,.660809,.879651,.0598527,0,.678836,.877267,.0568615,0,.69705,.874717,.05406,0,.715465,.872012,.0514378,0,.734098,.869157,.0489805,0,.752968,.866155,.0466727,0,.772101,.863014,.0445056,0,.791529,.859748,.0424733,0,.81129,.856416,.0405957,0,.831438,.852958,.0388273,0,.852044,.849382,.0371619,0,.87321,.845694,.0355959,0,.89509,.841893,.0341155,0,.917932,.837981,.0327141,0,.942204,.833963,.0313856,0,.968981,.829847,.0301275,0,1,1,.85214,0,0,.999969,.852095,0,.00279627,.999483,.851408,0,.0107635,.994545,.84579,0,.0206454,.986188,.835231,0,.0315756,.969847,.814687,0,.0432021,.945951,.783735,0,.0553396,.91917,.746074,0,.0678766,.895488,.706938,0,.0807395,.878232,.669534,0,.0938767,.868252,.635168,0,.10725,.863873,.603069,0,.120832,.863369,.572514,0,.134598,.86545,.543169,0,.148533,.868803,.514578,0,.16262,.872794,.486762,0,.176849,.87702,.459811,0,.19121,.881054,.433654,0,.205694,.884974,.408574,0,.220294,.888587,.384525,0,.235005,.891877,.36156,0,.24982,.894793,.339661,0,.264737,.89743,.318913,0,.279751,.899796,.299302,0,.294859,.901943,.280843,0,.310058,.903858,.263481,0,.325346,.905574,.247197,0,.340721,.907069,.231915,0,.356181,.908379,.217614,0,.371725,.90952,.20425,0,.387353,.910483,.191758,0,.403063,.91128,.180092,0,.418854,.911936,.169222,0,.434727,.912454,.159098,0,.450682,.912835,.149668,0,.466718,.913078,.140884,0,.482837,.913192,.132709,0,.499038,.913175,.125095,0,.515324,.91304,.118012,0,.531695,.912781,.111417,0,.548153,.91241,.105281,0,.5647,.911924,.0995691,0,.581338,.911331,.0942531,0,.59807,.910637,.0893076,0,.6149,.90984,.0846998,0,.63183,.908941,.0804044,0,.648865,.907944,.0763984,0,.666011,.906857,.0726638,0,.683273,.90568,.0691783,0,.700659,.904416,.0659222,0,.718176,.903067,.0628782,0,.735834,.901637,.0600307,0,.753646,.900128,.0573647,0,.771625,.898544,.0548668,0,.78979,.89689,.052527,0,.808162,.895165,.0503306,0,.826771,.893371,.0482668,0,.845654,.891572,.0463605,0,.864863,.889763,.0445998,0,.884472,.887894,.0429451,0,.904592,.885967,.0413884,0,.925407,.883984,.0399225,0,.947271,.881945,.0385405,0,.97105,.879854,.0372362,0,1,.999804,.995833,0,0,.938155,.933611,0,.0158731,.864755,.854311,0,.0317461,.888594,.865264,0,.0476191,.905575,.863922,0,.0634921,.915125,.850558,0,.0793651,.920665,.829254,0,.0952381,.924073,.802578,0,.111111,.926304,.772211,0,.126984,.927829,.739366,0,.142857,.928924,.705033,0,.15873,.92973,.670019,0,.174603,.930339,.634993,0,.190476,.930811,.600485,0,.206349,.931191,.566897,0,.222222,.93149,.534485,0,.238095,.931737,.503429,0,.253968,.931939,.473811,0,.269841,.932108,.445668,0,.285714,.93225,.418993,0,.301587,.932371,.393762,0,.31746,.932474,.369939,0,.333333,.932562,.347479,0,.349206,.932638,.326336,0,.365079,.932703,.306462,0,.380952,.93276,.287805,0,.396825,.932809,.270313,0,.412698,.932851,.253933,0,.428571,.932887,.23861,0,.444444,.932917,.224289,0,.460317,.932943,.210917,0,.47619,.932965,.19844,0,.492063,.932982,.186807,0,.507937,.932995,.175966,0,.52381,.933005,.165869,0,.539683,.933011,.156468,0,.555556,.933013,.147719,0,.571429,.933013,.139579,0,.587302,.93301,.132007,0,.603175,.933004,.124965,0,.619048,.932994,.118416,0,.634921,.932982,.112326,0,.650794,.932968,.106663,0,.666667,.93295,.101397,0,.68254,.932931,.0964993,0,.698413,.932908,.0919438,0,.714286,.932883,.0877057,0,.730159,.932856,.0837623,0,.746032,.932827,.0800921,0,.761905,.932796,.0766754,0,.777778,.932762,.0734936,0,.793651,.932727,.0705296,0,.809524,.932689,.0677676,0,.825397,.93265,.0651929,0,.84127,.932609,.0627917,0,.857143,.932565,.0605515,0,.873016,.932521,.0584606,0,.888889,.932474,.0565082,0,.904762,.932427,.0546841,0,.920635,.932377,.0529793,0,.936508,.932326,.0513851,0,.952381,.932274,.0498936,0,.968254,.93222,.0484975,0,.984127,.932164,.0471899,0,1],i=new Float32Array(e),a=new Float32Array(t),r=new L.DataTexture(i,64,64,L.RGBAFormat,L.FloatType,L.UVMapping,L.ClampToEdgeWrapping,L.ClampToEdgeWrapping,L.LinearFilter,L.NearestFilter,1),o=new L.DataTexture(a,64,64,L.RGBAFormat,L.FloatType,L.UVMapping,L.ClampToEdgeWrapping,L.ClampToEdgeWrapping,L.LinearFilter,L.NearestFilter,1);r.needsUpdate=!0,o.needsUpdate=!0;let s=new Uint16Array(e.length);e.forEach(function(e,t){s[t]=L.DataUtils.toHalfFloat(e)});let n=new Uint16Array(t.length);t.forEach(function(e,t){n[t]=L.DataUtils.toHalfFloat(e)});let l=new L.DataTexture(s,64,64,L.RGBAFormat,L.HalfFloatType,L.UVMapping,L.ClampToEdgeWrapping,L.ClampToEdgeWrapping,L.LinearFilter,L.NearestFilter,1),h=new L.DataTexture(n,64,64,L.RGBAFormat,L.HalfFloatType,L.UVMapping,L.ClampToEdgeWrapping,L.ClampToEdgeWrapping,L.LinearFilter,L.NearestFilter,1);return l.needsUpdate=!0,h.needsUpdate=!0,this.LTC_HALF_1=l,this.LTC_HALF_2=h,this.LTC_FLOAT_1=r,this.LTC_FLOAT_2=o,this}}tU.LTC_HALF_1=null,tU.LTC_HALF_2=null,tU.LTC_FLOAT_1=null,tU.LTC_FLOAT_2=null;class tN{static init(){tU.init();let{LTC_FLOAT_1:e,LTC_FLOAT_2:t,LTC_HALF_1:i,LTC_HALF_2:a}=tU;R.UniformsLib.LTC_FLOAT_1=e,R.UniformsLib.LTC_FLOAT_2=t,R.UniformsLib.LTC_HALF_1=i,R.UniformsLib.LTC_HALF_2=a}}var tB=L;class tV extends tB.Loader{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(e){return new tX(e)}),this.register(function(e){return new tK(e)}),this.register(function(e){return new t9(e)}),this.register(function(e){return new t3(e)}),this.register(function(e){return new t5(e)}),this.register(function(e){return new tZ(e)}),this.register(function(e){return new t$(e)}),this.register(function(e){return new tQ(e)}),this.register(function(e){return new tJ(e)}),this.register(function(e){return new tq(e)}),this.register(function(e){return new t0(e)}),this.register(function(e){return new tY(e)}),this.register(function(e){return new t2(e)}),this.register(function(e){return new t1(e)}),this.register(function(e){return new tH(e)}),this.register(function(e){return new t4(e,tj.EXT_MESHOPT_COMPRESSION)}),this.register(function(e){return new t4(e,tj.KHR_MESHOPT_COMPRESSION)}),this.register(function(e){return new t8(e)})}load(e,t,i,a){let r,o=this;if(""!==this.resourcePath)r=this.resourcePath;else if(""!==this.path){let t=tB.LoaderUtils.extractUrlBase(e);r=tB.LoaderUtils.resolveURL(t,this.path)}else r=tB.LoaderUtils.extractUrlBase(e);this.manager.itemStart(e);let s=function(t){a?a(t):console.error(t),o.manager.itemError(e),o.manager.itemEnd(e)},n=new tB.FileLoader(this.manager);n.setPath(this.path),n.setResponseType("arraybuffer"),n.setRequestHeader(this.requestHeader),n.setWithCredentials(this.withCredentials),n.load(e,function(i){try{o.parse(i,r,function(i){t(i),o.manager.itemEnd(e)},s)}catch(e){s(e)}},i,s)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return -1===this.pluginCallbacks.indexOf(e)&&this.pluginCallbacks.push(e),this}unregister(e){return -1!==this.pluginCallbacks.indexOf(e)&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,i,a){let r,o={},s={},n=new TextDecoder;if("string"==typeof e)r=JSON.parse(e);else if(e instanceof ArrayBuffer)if(n.decode(new Uint8Array(e,0,4))===t6){try{o[tj.KHR_BINARY_GLTF]=new t7(e)}catch(e){a&&a(e);return}r=JSON.parse(o[tj.KHR_BINARY_GLTF].content)}else r=JSON.parse(n.decode(e));else r=e;if(void 0===r.asset||r.asset.version[0]<2){a&&a(Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}let l=new ix(r,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});l.fileLoader.setRequestHeader(this.requestHeader);for(let e=0;e<this.pluginCallbacks.length;e++){let t=this.pluginCallbacks[e](l);t.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),s[t.name]=t,o[t.name]=!0}if(r.extensionsUsed)for(let e=0;e<r.extensionsUsed.length;++e){let t=r.extensionsUsed[e],i=r.extensionsRequired||[];switch(t){case tj.KHR_MATERIALS_UNLIT:o[t]=new tW;break;case tj.KHR_DRACO_MESH_COMPRESSION:o[t]=new ie(r,this.dracoLoader);break;case tj.KHR_TEXTURE_TRANSFORM:o[t]=new it;break;case tj.KHR_MESH_QUANTIZATION:o[t]=new ii;break;default:i.indexOf(t)>=0&&void 0===s[t]&&console.warn('THREE.GLTFLoader: Unknown extension "'+t+'".')}}l.setExtensions(o),l.setPlugins(s),l.parse(i,a)}parseAsync(e,t){let i=this;return new Promise(function(a,r){i.parse(e,t,a,r)})}}function tO(){let e={};return{get:function(t){return e[t]},add:function(t,i){e[t]=i},remove:function(t){delete e[t]},removeAll:function(){e={}}}}function tG(e,t,i){let a=e.json.materials[t];return a.extensions&&a.extensions[i]?a.extensions[i]:null}let tj={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",KHR_MESHOPT_COMPRESSION:"KHR_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"};class tH{constructor(e){this.parser=e,this.name=tj.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){let e=this.parser,t=this.parser.json.nodes||[];for(let i=0,a=t.length;i<a;i++){let a=t[i];a.extensions&&a.extensions[this.name]&&void 0!==a.extensions[this.name].light&&e._addNodeRef(this.cache,a.extensions[this.name].light)}}_loadLight(e){let t,i=this.parser,a="light:"+e,r=i.cache.get(a);if(r)return r;let o=i.json,s=((o.extensions&&o.extensions[this.name]||{}).lights||[])[e],n=new tB.Color(0xffffff);void 0!==s.color&&n.setRGB(s.color[0],s.color[1],s.color[2],tB.LinearSRGBColorSpace);let l=void 0!==s.range?s.range:0;switch(s.type){case"directional":(t=new tB.DirectionalLight(n)).target.position.set(0,0,-1),t.add(t.target);break;case"point":(t=new tB.PointLight(n)).distance=l;break;case"spot":(t=new tB.SpotLight(n)).distance=l,s.spot=s.spot||{},s.spot.innerConeAngle=void 0!==s.spot.innerConeAngle?s.spot.innerConeAngle:0,s.spot.outerConeAngle=void 0!==s.spot.outerConeAngle?s.spot.outerConeAngle:Math.PI/4,t.angle=s.spot.outerConeAngle,t.penumbra=1-s.spot.innerConeAngle/s.spot.outerConeAngle,t.target.position.set(0,0,-1),t.add(t.target);break;default:throw Error("THREE.GLTFLoader: Unexpected light type: "+s.type)}return t.position.set(0,0,0),iv(t,s),void 0!==s.intensity&&(t.intensity=s.intensity),t.name=i.createUniqueName(s.name||"light_"+e),r=Promise.resolve(t),i.cache.add(a,r),r}getDependency(e,t){if("light"===e)return this._loadLight(t)}createNodeAttachment(e){let t=this,i=this.parser,a=i.json.nodes[e],r=(a.extensions&&a.extensions[this.name]||{}).light;return void 0===r?null:this._loadLight(r).then(function(e){return i._getNodeRef(t.cache,r,e)})}}class tW{constructor(){this.name=tj.KHR_MATERIALS_UNLIT}getMaterialType(){return tB.MeshBasicMaterial}extendParams(e,t,i){let a=[];e.color=new tB.Color(1,1,1),e.opacity=1;let r=t.pbrMetallicRoughness;if(r){if(Array.isArray(r.baseColorFactor)){let t=r.baseColorFactor;e.color.setRGB(t[0],t[1],t[2],tB.LinearSRGBColorSpace),e.opacity=t[3]}void 0!==r.baseColorTexture&&a.push(i.assignTexture(e,"map",r.baseColorTexture,tB.SRGBColorSpace))}return Promise.all(a)}}class tq{constructor(e){this.parser=e,this.name=tj.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);return null===i||void 0!==i.emissiveStrength&&(t.emissiveIntensity=i.emissiveStrength),Promise.resolve()}}class tX{constructor(e){this.parser=e,this.name=tj.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){return null!==tG(this.parser,e,this.name)?tB.MeshPhysicalMaterial:null}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);if(null===i)return Promise.resolve();let a=[];if(void 0!==i.clearcoatFactor&&(t.clearcoat=i.clearcoatFactor),void 0!==i.clearcoatTexture&&a.push(this.parser.assignTexture(t,"clearcoatMap",i.clearcoatTexture)),void 0!==i.clearcoatRoughnessFactor&&(t.clearcoatRoughness=i.clearcoatRoughnessFactor),void 0!==i.clearcoatRoughnessTexture&&a.push(this.parser.assignTexture(t,"clearcoatRoughnessMap",i.clearcoatRoughnessTexture)),void 0!==i.clearcoatNormalTexture&&(a.push(this.parser.assignTexture(t,"clearcoatNormalMap",i.clearcoatNormalTexture)),void 0!==i.clearcoatNormalTexture.scale)){let e=i.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new tB.Vector2(e,e)}return Promise.all(a)}}class tK{constructor(e){this.parser=e,this.name=tj.KHR_MATERIALS_DISPERSION}getMaterialType(e){return null!==tG(this.parser,e,this.name)?tB.MeshPhysicalMaterial:null}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);return null===i||(t.dispersion=void 0!==i.dispersion?i.dispersion:0),Promise.resolve()}}class tY{constructor(e){this.parser=e,this.name=tj.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){return null!==tG(this.parser,e,this.name)?tB.MeshPhysicalMaterial:null}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);if(null===i)return Promise.resolve();let a=[];return void 0!==i.iridescenceFactor&&(t.iridescence=i.iridescenceFactor),void 0!==i.iridescenceTexture&&a.push(this.parser.assignTexture(t,"iridescenceMap",i.iridescenceTexture)),void 0!==i.iridescenceIor&&(t.iridescenceIOR=i.iridescenceIor),void 0===t.iridescenceThicknessRange&&(t.iridescenceThicknessRange=[100,400]),void 0!==i.iridescenceThicknessMinimum&&(t.iridescenceThicknessRange[0]=i.iridescenceThicknessMinimum),void 0!==i.iridescenceThicknessMaximum&&(t.iridescenceThicknessRange[1]=i.iridescenceThicknessMaximum),void 0!==i.iridescenceThicknessTexture&&a.push(this.parser.assignTexture(t,"iridescenceThicknessMap",i.iridescenceThicknessTexture)),Promise.all(a)}}class tZ{constructor(e){this.parser=e,this.name=tj.KHR_MATERIALS_SHEEN}getMaterialType(e){return null!==tG(this.parser,e,this.name)?tB.MeshPhysicalMaterial:null}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);if(null===i)return Promise.resolve();let a=[];if(t.sheenColor=new tB.Color(0,0,0),t.sheenRoughness=0,t.sheen=1,void 0!==i.sheenColorFactor){let e=i.sheenColorFactor;t.sheenColor.setRGB(e[0],e[1],e[2],tB.LinearSRGBColorSpace)}return void 0!==i.sheenRoughnessFactor&&(t.sheenRoughness=i.sheenRoughnessFactor),void 0!==i.sheenColorTexture&&a.push(this.parser.assignTexture(t,"sheenColorMap",i.sheenColorTexture,tB.SRGBColorSpace)),void 0!==i.sheenRoughnessTexture&&a.push(this.parser.assignTexture(t,"sheenRoughnessMap",i.sheenRoughnessTexture)),Promise.all(a)}}class t${constructor(e){this.parser=e,this.name=tj.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){return null!==tG(this.parser,e,this.name)?tB.MeshPhysicalMaterial:null}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);if(null===i)return Promise.resolve();let a=[];return void 0!==i.transmissionFactor&&(t.transmission=i.transmissionFactor),void 0!==i.transmissionTexture&&a.push(this.parser.assignTexture(t,"transmissionMap",i.transmissionTexture)),Promise.all(a)}}class tQ{constructor(e){this.parser=e,this.name=tj.KHR_MATERIALS_VOLUME}getMaterialType(e){return null!==tG(this.parser,e,this.name)?tB.MeshPhysicalMaterial:null}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);if(null===i)return Promise.resolve();let a=[];t.thickness=void 0!==i.thicknessFactor?i.thicknessFactor:0,void 0!==i.thicknessTexture&&a.push(this.parser.assignTexture(t,"thicknessMap",i.thicknessTexture)),t.attenuationDistance=i.attenuationDistance||1/0;let r=i.attenuationColor||[1,1,1];return t.attenuationColor=new tB.Color().setRGB(r[0],r[1],r[2],tB.LinearSRGBColorSpace),Promise.all(a)}}class tJ{constructor(e){this.parser=e,this.name=tj.KHR_MATERIALS_IOR}getMaterialType(e){return null!==tG(this.parser,e,this.name)?tB.MeshPhysicalMaterial:null}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);return null===i||(t.ior=void 0!==i.ior?i.ior:1.5),Promise.resolve()}}class t0{constructor(e){this.parser=e,this.name=tj.KHR_MATERIALS_SPECULAR}getMaterialType(e){return null!==tG(this.parser,e,this.name)?tB.MeshPhysicalMaterial:null}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);if(null===i)return Promise.resolve();let a=[];t.specularIntensity=void 0!==i.specularFactor?i.specularFactor:1,void 0!==i.specularTexture&&a.push(this.parser.assignTexture(t,"specularIntensityMap",i.specularTexture));let r=i.specularColorFactor||[1,1,1];return t.specularColor=new tB.Color().setRGB(r[0],r[1],r[2],tB.LinearSRGBColorSpace),void 0!==i.specularColorTexture&&a.push(this.parser.assignTexture(t,"specularColorMap",i.specularColorTexture,tB.SRGBColorSpace)),Promise.all(a)}}class t1{constructor(e){this.parser=e,this.name=tj.EXT_MATERIALS_BUMP}getMaterialType(e){return null!==tG(this.parser,e,this.name)?tB.MeshPhysicalMaterial:null}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);if(null===i)return Promise.resolve();let a=[];return t.bumpScale=void 0!==i.bumpFactor?i.bumpFactor:1,void 0!==i.bumpTexture&&a.push(this.parser.assignTexture(t,"bumpMap",i.bumpTexture)),Promise.all(a)}}class t2{constructor(e){this.parser=e,this.name=tj.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){return null!==tG(this.parser,e,this.name)?tB.MeshPhysicalMaterial:null}extendMaterialParams(e,t){let i=tG(this.parser,e,this.name);if(null===i)return Promise.resolve();let a=[];return void 0!==i.anisotropyStrength&&(t.anisotropy=i.anisotropyStrength),void 0!==i.anisotropyRotation&&(t.anisotropyRotation=i.anisotropyRotation),void 0!==i.anisotropyTexture&&a.push(this.parser.assignTexture(t,"anisotropyMap",i.anisotropyTexture)),Promise.all(a)}}class t9{constructor(e){this.parser=e,this.name=tj.KHR_TEXTURE_BASISU}loadTexture(e){let t=this.parser,i=t.json,a=i.textures[e];if(!a.extensions||!a.extensions[this.name])return null;let r=a.extensions[this.name],o=t.options.ktx2Loader;if(!o)if(!(i.extensionsRequired&&i.extensionsRequired.indexOf(this.name)>=0))return null;else throw Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return t.loadTextureImage(e,r.source,o)}}class t3{constructor(e){this.parser=e,this.name=tj.EXT_TEXTURE_WEBP}loadTexture(e){let t=this.name,i=this.parser,a=i.json,r=a.textures[e];if(!r.extensions||!r.extensions[t])return null;let o=r.extensions[t],s=a.images[o.source],n=i.textureLoader;if(s.uri){let e=i.options.manager.getHandler(s.uri);null!==e&&(n=e)}return i.loadTextureImage(e,o.source,n)}}class t5{constructor(e){this.parser=e,this.name=tj.EXT_TEXTURE_AVIF}loadTexture(e){let t=this.name,i=this.parser,a=i.json,r=a.textures[e];if(!r.extensions||!r.extensions[t])return null;let o=r.extensions[t],s=a.images[o.source],n=i.textureLoader;if(s.uri){let e=i.options.manager.getHandler(s.uri);null!==e&&(n=e)}return i.loadTextureImage(e,o.source,n)}}class t4{constructor(e,t){this.name=t,this.parser=e}loadBufferView(e){let t=this.parser.json,i=t.bufferViews[e];if(!i.extensions||!i.extensions[this.name])return null;{let e=i.extensions[this.name],a=this.parser.getDependency("buffer",e.buffer),r=this.parser.options.meshoptDecoder;if(!r||!r.supported)if(!(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0))return null;else throw Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return a.then(function(t){let i=e.byteOffset||0,a=e.byteLength||0,o=e.count,s=e.byteStride,n=new Uint8Array(t,i,a);return r.decodeGltfBufferAsync?r.decodeGltfBufferAsync(o,s,n,e.mode,e.filter).then(function(e){return e.buffer}):r.ready.then(function(){let t=new ArrayBuffer(o*s);return r.decodeGltfBuffer(new Uint8Array(t),o,s,n,e.mode,e.filter),t})})}}}class t8{constructor(e){this.name=tj.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){let t=this.parser.json,i=t.nodes[e];if(!i.extensions||!i.extensions[this.name]||void 0===i.mesh)return null;for(let e of t.meshes[i.mesh].primitives)if(e.mode!==is.TRIANGLES&&e.mode!==is.TRIANGLE_STRIP&&e.mode!==is.TRIANGLE_FAN&&void 0!==e.mode)return null;let a=i.extensions[this.name].attributes,r=[],o={};for(let e in a)r.push(this.parser.getDependency("accessor",a[e]).then(t=>(o[e]=t,o[e])));return r.length<1?null:(r.push(this.parser.createNodeMesh(e)),Promise.all(r).then(e=>{let t=e.pop(),i=t.isGroup?t.children:[t],a=e[0].count,r=[];for(let e of i){let t=new tB.Matrix4,i=new tB.Vector3,s=new tB.Quaternion,n=new tB.Vector3(1,1,1),l=new tB.InstancedMesh(e.geometry,e.material,a);for(let e=0;e<a;e++)o.TRANSLATION&&i.fromBufferAttribute(o.TRANSLATION,e),o.ROTATION&&s.fromBufferAttribute(o.ROTATION,e),o.SCALE&&n.fromBufferAttribute(o.SCALE,e),l.setMatrixAt(e,t.compose(i,s,n));for(let t in o)if("_COLOR_0"===t){let e=o[t];l.instanceColor=new tB.InstancedBufferAttribute(e.array,e.itemSize,e.normalized)}else"TRANSLATION"!==t&&"ROTATION"!==t&&"SCALE"!==t&&e.geometry.setAttribute(t,o[t]);tB.Object3D.prototype.copy.call(l,e),this.parser.assignFinalMaterial(l),r.push(l)}return t.isGroup?(t.clear(),t.add(...r),t):r[0]}))}}let t6="glTF";class t7{constructor(e){this.name=tj.KHR_BINARY_GLTF,this.content=null,this.body=null;const t=new DataView(e,0,12),i=new TextDecoder;if(this.header={magic:i.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==t6)throw Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw Error("THREE.GLTFLoader: Legacy binary file detected.");const a=this.header.length-12,r=new DataView(e,12);let o=0;for(;o<a;){const t=r.getUint32(o,!0);o+=4;const a=r.getUint32(o,!0);if(o+=4,0x4e4f534a===a){const a=new Uint8Array(e,12+o,t);this.content=i.decode(a)}else if(5130562===a){const i=12+o;this.body=e.slice(i,i+t)}o+=t}if(null===this.content)throw Error("THREE.GLTFLoader: JSON content not found.")}}class ie{constructor(e,t){if(!t)throw Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=tj.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){let i=this.json,a=this.dracoLoader,r=e.extensions[this.name].bufferView,o=e.extensions[this.name].attributes,s={},n={},l={};for(let e in o)s[iu[e]||e.toLowerCase()]=o[e];for(let t in e.attributes){let a=iu[t]||t.toLowerCase();if(void 0!==o[t]){let r=i.accessors[e.attributes[t]],o=il[r.componentType];l[a]=o.name,n[a]=!0===r.normalized}}return t.getDependency("bufferView",r).then(function(e){return new Promise(function(t,i){a.decodeDracoFile(e,function(e){for(let t in e.attributes){let i=e.attributes[t],a=n[t];void 0!==a&&(i.normalized=a)}t(e)},s,l,tB.LinearSRGBColorSpace,i)})})}}class it{constructor(){this.name=tj.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(void 0===t.texCoord||t.texCoord===e.channel)&&void 0===t.offset&&void 0===t.rotation&&void 0===t.scale||(e=e.clone(),void 0!==t.texCoord&&(e.channel=t.texCoord),void 0!==t.offset&&e.offset.fromArray(t.offset),void 0!==t.rotation&&(e.rotation=t.rotation),void 0!==t.scale&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}}class ii{constructor(){this.name=tj.KHR_MESH_QUANTIZATION}}class ia extends tB.Interpolant{constructor(e,t,i,a){super(e,t,i,a)}copySampleValue_(e){let t=this.resultBuffer,i=this.sampleValues,a=this.valueSize,r=e*a*3+a;for(let e=0;e!==a;e++)t[e]=i[r+e];return t}interpolate_(e,t,i,a){let r=this.resultBuffer,o=this.sampleValues,s=this.valueSize,n=2*s,l=3*s,h=a-t,c=(i-t)/h,d=c*c,u=d*c,m=e*l,p=m-l,f=-2*u+3*d,g=u-d,v=1-f,b=g-d+c;for(let e=0;e!==s;e++){let t=o[p+e+s],i=o[p+e+n]*h,a=o[m+e+s],l=o[m+e]*h;r[e]=v*t+b*i+f*a+g*l}return r}}let ir=new tB.Quaternion;class io extends ia{interpolate_(e,t,i,a){let r=super.interpolate_(e,t,i,a);return ir.fromArray(r).normalize().toArray(r),r}}let is={POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6},il={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},ih={9728:tB.NearestFilter,9729:tB.LinearFilter,9984:tB.NearestMipmapNearestFilter,9985:tB.LinearMipmapNearestFilter,9986:tB.NearestMipmapLinearFilter,9987:tB.LinearMipmapLinearFilter},ic={33071:tB.ClampToEdgeWrapping,33648:tB.MirroredRepeatWrapping,10497:tB.RepeatWrapping},id={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},iu={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},im={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},ip={CUBICSPLINE:void 0,LINEAR:tB.InterpolateLinear,STEP:tB.InterpolateDiscrete};function ig(e,t,i){for(let a in i.extensions)void 0===e[a]&&(t.userData.gltfExtensions=t.userData.gltfExtensions||{},t.userData.gltfExtensions[a]=i.extensions[a])}function iv(e,t){void 0!==t.extras&&("object"==typeof t.extras?Object.assign(e.userData,t.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+t.extras))}function ib(e){let t="",i=Object.keys(e).sort();for(let a=0,r=i.length;a<r;a++)t+=i[a]+":"+e[i[a]]+";";return t}function iw(e){switch(e){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}let iy=new tB.Matrix4;class ix{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new tO,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let i=!1,a=-1,r=!1,o=-1;if("u">typeof navigator&&void 0!==navigator.userAgent){const e=navigator.userAgent;i=!0===/^((?!chrome|android).)*safari/i.test(e);const t=e.match(/Version\/(\d+)/);a=i&&t?parseInt(t[1],10):-1,o=(r=e.indexOf("Firefox")>-1)?e.match(/Firefox\/([0-9]+)\./)[1]:-1}"u"<typeof createImageBitmap||i&&a<17||r&&o<98?this.textureLoader=new tB.TextureLoader(this.options.manager):this.textureLoader=new tB.ImageBitmapLoader(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new tB.FileLoader(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),"use-credentials"===this.options.crossOrigin&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){let i=this,a=this.json,r=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(e){return e._markDefs&&e._markDefs()}),Promise.all(this._invokeAll(function(e){return e.beforeRoot&&e.beforeRoot()})).then(function(){return Promise.all([i.getDependencies("scene"),i.getDependencies("animation"),i.getDependencies("camera")])}).then(function(t){let o={scene:t[0][a.scene||0],scenes:t[0],animations:t[1],cameras:t[2],asset:a.asset,parser:i,userData:{}};return ig(r,o,a),iv(o,a),Promise.all(i._invokeAll(function(e){return e.afterRoot&&e.afterRoot(o)})).then(function(){for(let e of o.scenes)e.updateMatrixWorld();e(o)})}).catch(t)}_markDefs(){let e=this.json.nodes||[],t=this.json.skins||[],i=this.json.meshes||[];for(let i=0,a=t.length;i<a;i++){let a=t[i].joints;for(let t=0,i=a.length;t<i;t++)e[a[t]].isBone=!0}for(let t=0,a=e.length;t<a;t++){let a=e[t];void 0!==a.mesh&&(this._addNodeRef(this.meshCache,a.mesh),void 0!==a.skin&&(i[a.mesh].isSkinnedMesh=!0)),void 0!==a.camera&&this._addNodeRef(this.cameraCache,a.camera)}}_addNodeRef(e,t){void 0!==t&&(void 0===e.refs[t]&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,i){if(e.refs[t]<=1)return i;let a=i.clone(),r=(e,t)=>{let i=this.associations.get(e);for(let[a,o]of(null!=i&&this.associations.set(t,i),e.children.entries()))r(o,t.children[a])};return r(i,a),a.name+="_instance_"+e.uses[t]++,a}_invokeOne(e){let t=Object.values(this.plugins);t.push(this);for(let i=0;i<t.length;i++){let a=e(t[i]);if(a)return a}return null}_invokeAll(e){let t=Object.values(this.plugins);t.unshift(this);let i=[];for(let a=0;a<t.length;a++){let r=e(t[a]);r&&i.push(r)}return i}getDependency(e,t){let i=e+":"+t,a=this.cache.get(i);if(!a){switch(e){case"scene":a=this.loadScene(t);break;case"node":a=this._invokeOne(function(e){return e.loadNode&&e.loadNode(t)});break;case"mesh":a=this._invokeOne(function(e){return e.loadMesh&&e.loadMesh(t)});break;case"accessor":a=this.loadAccessor(t);break;case"bufferView":a=this._invokeOne(function(e){return e.loadBufferView&&e.loadBufferView(t)});break;case"buffer":a=this.loadBuffer(t);break;case"material":a=this._invokeOne(function(e){return e.loadMaterial&&e.loadMaterial(t)});break;case"texture":a=this._invokeOne(function(e){return e.loadTexture&&e.loadTexture(t)});break;case"skin":a=this.loadSkin(t);break;case"animation":a=this._invokeOne(function(e){return e.loadAnimation&&e.loadAnimation(t)});break;case"camera":a=this.loadCamera(t);break;default:if(!(a=this._invokeOne(function(i){return i!=this&&i.getDependency&&i.getDependency(e,t)})))throw Error("Unknown type: "+e)}this.cache.add(i,a)}return a}getDependencies(e){let t=this.cache.get(e);if(!t){let i=this;t=Promise.all((this.json[e+("mesh"===e?"es":"s")]||[]).map(function(t,a){return i.getDependency(e,a)})),this.cache.add(e,t)}return t}loadBuffer(e){let t=this.json.buffers[e],i=this.fileLoader;if(t.type&&"arraybuffer"!==t.type)throw Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(void 0===t.uri&&0===e)return Promise.resolve(this.extensions[tj.KHR_BINARY_GLTF].body);let a=this.options;return new Promise(function(e,r){i.load(tB.LoaderUtils.resolveURL(t.uri,a.path),e,void 0,function(){r(Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){let t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(e){let i=t.byteLength||0,a=t.byteOffset||0;return e.slice(a,a+i)})}loadAccessor(e){let t=this,i=this.json,a=this.json.accessors[e];if(void 0===a.bufferView&&void 0===a.sparse){let e=id[a.type],t=il[a.componentType],i=!0===a.normalized,r=new t(a.count*e);return Promise.resolve(new tB.BufferAttribute(r,e,i))}let r=[];return void 0!==a.bufferView?r.push(this.getDependency("bufferView",a.bufferView)):r.push(null),void 0!==a.sparse&&(r.push(this.getDependency("bufferView",a.sparse.indices.bufferView)),r.push(this.getDependency("bufferView",a.sparse.values.bufferView))),Promise.all(r).then(function(e){let r,o,s=e[0],n=id[a.type],l=il[a.componentType],h=l.BYTES_PER_ELEMENT,c=h*n,d=a.byteOffset||0,u=void 0!==a.bufferView?i.bufferViews[a.bufferView].byteStride:void 0,m=!0===a.normalized;if(u&&u!==c){let e=Math.floor(d/u),i="InterleavedBuffer:"+a.bufferView+":"+a.componentType+":"+e+":"+a.count,c=t.cache.get(i);c||(r=new l(s,e*u,a.count*u/h),c=new tB.InterleavedBuffer(r,u/h),t.cache.add(i,c)),o=new tB.InterleavedBufferAttribute(c,n,d%u/h,m)}else r=null===s?new l(a.count*n):new l(s,d,a.count*n),o=new tB.BufferAttribute(r,n,m);if(void 0!==a.sparse){let t=id.SCALAR,i=il[a.sparse.indices.componentType],r=a.sparse.indices.byteOffset||0,h=a.sparse.values.byteOffset||0,c=new i(e[1],r,a.sparse.count*t),d=new l(e[2],h,a.sparse.count*n);null!==s&&(o=new tB.BufferAttribute(o.array.slice(),o.itemSize,o.normalized)),o.normalized=!1;for(let e=0,t=c.length;e<t;e++){let t=c[e];if(o.setX(t,d[e*n]),n>=2&&o.setY(t,d[e*n+1]),n>=3&&o.setZ(t,d[e*n+2]),n>=4&&o.setW(t,d[e*n+3]),n>=5)throw Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}o.normalized=m}return o})}loadTexture(e){let t=this.json,i=this.options,a=t.textures[e].source,r=t.images[a],o=this.textureLoader;if(r.uri){let e=i.manager.getHandler(r.uri);null!==e&&(o=e)}return this.loadTextureImage(e,a,o)}loadTextureImage(e,t,i){let a=this,r=this.json,o=r.textures[e],s=r.images[t],n=(s.uri||s.bufferView)+":"+o.sampler;if(this.textureCache[n])return this.textureCache[n];let l=this.loadImageSource(t,i).then(function(t){t.flipY=!1,t.name=o.name||s.name||"",""===t.name&&"string"==typeof s.uri&&!1===s.uri.startsWith("data:image/")&&(t.name=s.uri);let i=(r.samplers||{})[o.sampler]||{};return t.magFilter=ih[i.magFilter]||tB.LinearFilter,t.minFilter=ih[i.minFilter]||tB.LinearMipmapLinearFilter,t.wrapS=ic[i.wrapS]||tB.RepeatWrapping,t.wrapT=ic[i.wrapT]||tB.RepeatWrapping,t.generateMipmaps=!t.isCompressedTexture&&t.minFilter!==tB.NearestFilter&&t.minFilter!==tB.LinearFilter,a.associations.set(t,{textures:e}),t}).catch(function(){return null});return this.textureCache[n]=l,l}loadImageSource(e,t){let i=this.json,a=this.options;if(void 0!==this.sourceCache[e])return this.sourceCache[e].then(e=>e.clone());let r=i.images[e],o=self.URL||self.webkitURL,s=r.uri||"",n=!1;if(void 0!==r.bufferView)s=this.getDependency("bufferView",r.bufferView).then(function(e){n=!0;let t=new Blob([e],{type:r.mimeType});return s=o.createObjectURL(t)});else if(void 0===r.uri)throw Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");let l=Promise.resolve(s).then(function(e){return new Promise(function(i,r){let o=i;!0===t.isImageBitmapLoader&&(o=function(e){let t=new tB.Texture(e);t.needsUpdate=!0,i(t)}),t.load(tB.LoaderUtils.resolveURL(e,a.path),o,void 0,r)})}).then(function(e){var t;return!0===n&&o.revokeObjectURL(s),iv(e,r),e.userData.mimeType=r.mimeType||((t=r.uri).search(/\.jpe?g($|\?)/i)>0||0===t.search(/^data\:image\/jpeg/)?"image/jpeg":t.search(/\.webp($|\?)/i)>0||0===t.search(/^data\:image\/webp/)?"image/webp":t.search(/\.ktx2($|\?)/i)>0||0===t.search(/^data\:image\/ktx2/)?"image/ktx2":"image/png"),e}).catch(function(e){throw console.error("THREE.GLTFLoader: Couldn't load texture",s),e});return this.sourceCache[e]=l,l}assignTexture(e,t,i,a){let r=this;return this.getDependency("texture",i.index).then(function(o){if(!o)return null;if(void 0!==i.texCoord&&i.texCoord>0&&((o=o.clone()).channel=i.texCoord),r.extensions[tj.KHR_TEXTURE_TRANSFORM]){let e=void 0!==i.extensions?i.extensions[tj.KHR_TEXTURE_TRANSFORM]:void 0;if(e){let t=r.associations.get(o);o=r.extensions[tj.KHR_TEXTURE_TRANSFORM].extendTexture(o,e),r.associations.set(o,t)}}return void 0!==a&&(o.colorSpace=a),e[t]=o,o})}assignFinalMaterial(e){let t=e.geometry,i=e.material,a=void 0===t.attributes.tangent,r=void 0!==t.attributes.color,o=void 0===t.attributes.normal;if(e.isPoints){let e="PointsMaterial:"+i.uuid,t=this.cache.get(e);t||(t=new tB.PointsMaterial,tB.Material.prototype.copy.call(t,i),t.color.copy(i.color),t.map=i.map,t.sizeAttenuation=!1,this.cache.add(e,t)),i=t}else if(e.isLine){let e="LineBasicMaterial:"+i.uuid,t=this.cache.get(e);t||(t=new tB.LineBasicMaterial,tB.Material.prototype.copy.call(t,i),t.color.copy(i.color),t.map=i.map,this.cache.add(e,t)),i=t}if(a||r||o){let e="ClonedMaterial:"+i.uuid+":";a&&(e+="derivative-tangents:"),r&&(e+="vertex-colors:"),o&&(e+="flat-shading:");let t=this.cache.get(e);t||(t=i.clone(),r&&(t.vertexColors=!0),o&&(t.flatShading=!0),a&&(t.normalScale&&(t.normalScale.y*=-1),t.clearcoatNormalScale&&(t.clearcoatNormalScale.y*=-1)),this.cache.add(e,t),this.associations.set(t,this.associations.get(i))),i=t}e.material=i}getMaterialType(){return tB.MeshStandardMaterial}loadMaterial(e){let t,i=this,a=this.json,r=this.extensions,o=a.materials[e],s={},n=o.extensions||{},l=[];if(n[tj.KHR_MATERIALS_UNLIT]){let e=r[tj.KHR_MATERIALS_UNLIT];t=e.getMaterialType(),l.push(e.extendParams(s,o,i))}else{let a=o.pbrMetallicRoughness||{};if(s.color=new tB.Color(1,1,1),s.opacity=1,Array.isArray(a.baseColorFactor)){let e=a.baseColorFactor;s.color.setRGB(e[0],e[1],e[2],tB.LinearSRGBColorSpace),s.opacity=e[3]}void 0!==a.baseColorTexture&&l.push(i.assignTexture(s,"map",a.baseColorTexture,tB.SRGBColorSpace)),s.metalness=void 0!==a.metallicFactor?a.metallicFactor:1,s.roughness=void 0!==a.roughnessFactor?a.roughnessFactor:1,void 0!==a.metallicRoughnessTexture&&(l.push(i.assignTexture(s,"metalnessMap",a.metallicRoughnessTexture)),l.push(i.assignTexture(s,"roughnessMap",a.metallicRoughnessTexture))),t=this._invokeOne(function(t){return t.getMaterialType&&t.getMaterialType(e)}),l.push(Promise.all(this._invokeAll(function(t){return t.extendMaterialParams&&t.extendMaterialParams(e,s)})))}!0===o.doubleSided&&(s.side=tB.DoubleSide);let h=o.alphaMode||"OPAQUE";if("BLEND"===h?(s.transparent=!0,s.depthWrite=!1):(s.transparent=!1,"MASK"===h&&(s.alphaTest=void 0!==o.alphaCutoff?o.alphaCutoff:.5)),void 0!==o.normalTexture&&t!==tB.MeshBasicMaterial&&(l.push(i.assignTexture(s,"normalMap",o.normalTexture)),s.normalScale=new tB.Vector2(1,1),void 0!==o.normalTexture.scale)){let e=o.normalTexture.scale;s.normalScale.set(e,e)}if(void 0!==o.occlusionTexture&&t!==tB.MeshBasicMaterial&&(l.push(i.assignTexture(s,"aoMap",o.occlusionTexture)),void 0!==o.occlusionTexture.strength&&(s.aoMapIntensity=o.occlusionTexture.strength)),void 0!==o.emissiveFactor&&t!==tB.MeshBasicMaterial){let e=o.emissiveFactor;s.emissive=new tB.Color().setRGB(e[0],e[1],e[2],tB.LinearSRGBColorSpace)}return void 0!==o.emissiveTexture&&t!==tB.MeshBasicMaterial&&l.push(i.assignTexture(s,"emissiveMap",o.emissiveTexture,tB.SRGBColorSpace)),Promise.all(l).then(function(){let a=new t(s);return o.name&&(a.name=o.name),iv(a,o),i.associations.set(a,{materials:e}),o.extensions&&ig(r,a,o),a})}createUniqueName(e){let t=tB.PropertyBinding.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){let t=this,i=this.extensions,a=this.primitiveCache,r=[];for(let o=0,s=e.length;o<s;o++){let s=e[o],n=function(e){let t,i=e.extensions&&e.extensions[tj.KHR_DRACO_MESH_COMPRESSION];if(t=i?"draco:"+i.bufferView+":"+i.indices+":"+ib(i.attributes):e.indices+":"+ib(e.attributes)+":"+e.mode,void 0!==e.targets)for(let i=0,a=e.targets.length;i<a;i++)t+=":"+ib(e.targets[i]);return t}(s),l=a[n];if(l)r.push(l.promise);else{let e;e=s.extensions&&s.extensions[tj.KHR_DRACO_MESH_COMPRESSION]?function(e){return i[tj.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(e,t).then(function(i){return iM(i,e,t)})}(s):iM(new tB.BufferGeometry,s,t),a[n]={primitive:s,promise:e},r.push(e)}}return Promise.all(r)}loadMesh(e){let t=this,i=this.json,a=this.extensions,r=i.meshes[e],o=r.primitives,s=[];for(let e=0,t=o.length;e<t;e++){var n;let t=void 0===o[e].material?(void 0===(n=this.cache).DefaultMaterial&&(n.DefaultMaterial=new tB.MeshStandardMaterial({color:0xffffff,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:tB.FrontSide})),n.DefaultMaterial):this.getDependency("material",o[e].material);s.push(t)}return s.push(t.loadGeometries(o)),Promise.all(s).then(function(i){let s=i.slice(0,i.length-1),n=i[i.length-1],l=[];for(let i=0,h=n.length;i<h;i++){let h,c=n[i],d=o[i],u=s[i];if(d.mode===is.TRIANGLES||d.mode===is.TRIANGLE_STRIP||d.mode===is.TRIANGLE_FAN||void 0===d.mode)!0===(h=!0===r.isSkinnedMesh?new tB.SkinnedMesh(c,u):new tB.Mesh(c,u)).isSkinnedMesh&&h.normalizeSkinWeights(),d.mode===is.TRIANGLE_STRIP?h.geometry=(0,tR.toTrianglesDrawMode)(h.geometry,tB.TriangleStripDrawMode):d.mode===is.TRIANGLE_FAN&&(h.geometry=(0,tR.toTrianglesDrawMode)(h.geometry,tB.TriangleFanDrawMode));else if(d.mode===is.LINES)h=new tB.LineSegments(c,u);else if(d.mode===is.LINE_STRIP)h=new tB.Line(c,u);else if(d.mode===is.LINE_LOOP)h=new tB.LineLoop(c,u);else if(d.mode===is.POINTS)h=new tB.Points(c,u);else throw Error("THREE.GLTFLoader: Primitive mode unsupported: "+d.mode);Object.keys(h.geometry.morphAttributes).length>0&&function(e,t){if(e.updateMorphTargets(),void 0!==t.weights)for(let i=0,a=t.weights.length;i<a;i++)e.morphTargetInfluences[i]=t.weights[i];if(t.extras&&Array.isArray(t.extras.targetNames)){let i=t.extras.targetNames;if(e.morphTargetInfluences.length===i.length){e.morphTargetDictionary={};for(let t=0,a=i.length;t<a;t++)e.morphTargetDictionary[i[t]]=t}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}(h,r),h.name=t.createUniqueName(r.name||"mesh_"+e),iv(h,r),d.extensions&&ig(a,h,d),t.assignFinalMaterial(h),l.push(h)}for(let i=0,a=l.length;i<a;i++)t.associations.set(l[i],{meshes:e,primitives:i});if(1===l.length)return r.extensions&&ig(a,l[0],r),l[0];let h=new tB.Group;r.extensions&&ig(a,h,r),t.associations.set(h,{meshes:e});for(let e=0,t=l.length;e<t;e++)h.add(l[e]);return h})}loadCamera(e){let t,i=this.json.cameras[e],a=i[i.type];return a?("perspective"===i.type?t=new tB.PerspectiveCamera(tB.MathUtils.radToDeg(a.yfov),a.aspectRatio||1,a.znear||1,a.zfar||2e6):"orthographic"===i.type&&(t=new tB.OrthographicCamera(-a.xmag,a.xmag,a.ymag,-a.ymag,a.znear,a.zfar)),i.name&&(t.name=this.createUniqueName(i.name)),iv(t,i),Promise.resolve(t)):void console.warn("THREE.GLTFLoader: Missing camera parameters.")}loadSkin(e){let t=this.json.skins[e],i=[];for(let e=0,a=t.joints.length;e<a;e++)i.push(this._loadNodeShallow(t.joints[e]));return void 0!==t.inverseBindMatrices?i.push(this.getDependency("accessor",t.inverseBindMatrices)):i.push(null),Promise.all(i).then(function(e){let i=e.pop(),a=[],r=[];for(let o=0,s=e.length;o<s;o++){let s=e[o];if(s){a.push(s);let e=new tB.Matrix4;null!==i&&e.fromArray(i.array,16*o),r.push(e)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[o])}return new tB.Skeleton(a,r)})}loadAnimation(e){let t=this.json,i=this,a=t.animations[e],r=a.name?a.name:"animation_"+e,o=[],s=[],n=[],l=[],h=[];for(let e=0,t=a.channels.length;e<t;e++){let t=a.channels[e],i=a.samplers[t.sampler],r=t.target,c=r.node,d=void 0!==a.parameters?a.parameters[i.input]:i.input,u=void 0!==a.parameters?a.parameters[i.output]:i.output;void 0!==r.node&&(o.push(this.getDependency("node",c)),s.push(this.getDependency("accessor",d)),n.push(this.getDependency("accessor",u)),l.push(i),h.push(r))}return Promise.all([Promise.all(o),Promise.all(s),Promise.all(n),Promise.all(l),Promise.all(h)]).then(function(e){let t=e[0],o=e[1],s=e[2],n=e[3],l=e[4],h=[];for(let e=0,a=t.length;e<a;e++){let a=t[e],r=o[e],c=s[e],d=n[e],u=l[e];if(void 0===a)continue;a.updateMatrix&&a.updateMatrix();let m=i._createAnimationTracks(a,r,c,d,u);if(m)for(let e=0;e<m.length;e++)h.push(m[e])}let c=new tB.AnimationClip(r,void 0,h);return iv(c,a),c})}createNodeMesh(e){let t=this.json,i=this,a=t.nodes[e];return void 0===a.mesh?null:i.getDependency("mesh",a.mesh).then(function(e){let t=i._getNodeRef(i.meshCache,a.mesh,e);return void 0!==a.weights&&t.traverse(function(e){if(e.isMesh)for(let t=0,i=a.weights.length;t<i;t++)e.morphTargetInfluences[t]=a.weights[t]}),t})}loadNode(e){let t=this.json.nodes[e],i=this._loadNodeShallow(e),a=[],r=t.children||[];for(let e=0,t=r.length;e<t;e++)a.push(this.getDependency("node",r[e]));let o=void 0===t.skin?Promise.resolve(null):this.getDependency("skin",t.skin);return Promise.all([i,Promise.all(a),o]).then(function(e){let t=e[0],i=e[1],a=e[2];null!==a&&t.traverse(function(e){e.isSkinnedMesh&&e.bind(a,iy)});for(let e=0,a=i.length;e<a;e++)t.add(i[e]);if(void 0!==t.userData.pivot&&i.length>0){let e=t.userData.pivot,a=i[0];t.pivot=new tB.Vector3().fromArray(e),t.position.x-=e[0],t.position.y-=e[1],t.position.z-=e[2],a.position.set(0,0,0),delete t.userData.pivot}return t})}_loadNodeShallow(e){let t=this.json,i=this.extensions,a=this;if(void 0!==this.nodeCache[e])return this.nodeCache[e];let r=t.nodes[e],o=r.name?a.createUniqueName(r.name):"",s=[],n=a._invokeOne(function(t){return t.createNodeMesh&&t.createNodeMesh(e)});return n&&s.push(n),void 0!==r.camera&&s.push(a.getDependency("camera",r.camera).then(function(e){return a._getNodeRef(a.cameraCache,r.camera,e)})),a._invokeAll(function(t){return t.createNodeAttachment&&t.createNodeAttachment(e)}).forEach(function(e){s.push(e)}),this.nodeCache[e]=Promise.all(s).then(function(t){let s;if((s=!0===r.isBone?new tB.Bone:t.length>1?new tB.Group:1===t.length?t[0]:new tB.Object3D)!==t[0])for(let e=0,i=t.length;e<i;e++)s.add(t[e]);if(r.name&&(s.userData.name=r.name,s.name=o),iv(s,r),r.extensions&&ig(i,s,r),void 0!==r.matrix){let e=new tB.Matrix4;e.fromArray(r.matrix),s.applyMatrix4(e)}else void 0!==r.translation&&s.position.fromArray(r.translation),void 0!==r.rotation&&s.quaternion.fromArray(r.rotation),void 0!==r.scale&&s.scale.fromArray(r.scale);if(a.associations.has(s)){if(void 0!==r.mesh&&a.meshCache.refs[r.mesh]>1){let e=a.associations.get(s);a.associations.set(s,{...e})}}else a.associations.set(s,{});return a.associations.get(s).nodes=e,s}),this.nodeCache[e]}loadScene(e){let t=this.extensions,i=this.json.scenes[e],a=this,r=new tB.Group;i.name&&(r.name=a.createUniqueName(i.name)),iv(r,i),i.extensions&&ig(t,r,i);let o=i.nodes||[],s=[];for(let e=0,t=o.length;e<t;e++)s.push(a.getDependency("node",o[e]));return Promise.all(s).then(function(e){for(let t=0,i=e.length;t<i;t++){let i=e[t];null!==i.parent?r.add(function(e){let t=new Map,i=new Map,a=e.clone();return function e(t,i,a){a(t,i);for(let r=0;r<t.children.length;r++)e(t.children[r],i.children[r],a)}(e,a,function(e,a){t.set(a,e),i.set(e,a)}),a.traverse(function(e){if(!e.isSkinnedMesh)return;let a=t.get(e),r=a.skeleton.bones;e.skeleton=a.skeleton.clone(),e.bindMatrix.copy(a.bindMatrix),e.skeleton.bones=r.map(function(e){return i.get(e)}),e.bind(e.skeleton,e.bindMatrix)}),a}(i)):r.add(i)}return a.associations=(e=>{let t=new Map;for(let[e,i]of a.associations)(e instanceof tB.Material||e instanceof tB.Texture)&&t.set(e,i);return e.traverse(e=>{let i=a.associations.get(e);null!=i&&t.set(e,i)}),t})(r),r})}_createAnimationTracks(e,t,i,a,r){let o,s=[],n=e.name?e.name:e.uuid,l=[];switch(im[r.path]===im.weights?e.traverse(function(e){e.morphTargetInfluences&&l.push(e.name?e.name:e.uuid)}):l.push(n),im[r.path]){case im.weights:o=tB.NumberKeyframeTrack;break;case im.rotation:o=tB.QuaternionKeyframeTrack;break;case im.translation:case im.scale:o=tB.VectorKeyframeTrack;break;default:o=1===i.itemSize?tB.NumberKeyframeTrack:tB.VectorKeyframeTrack}let h=void 0!==a.interpolation?ip[a.interpolation]:tB.InterpolateLinear,c=this._getArrayFromAccessor(i);for(let e=0,i=l.length;e<i;e++){let i=new o(l[e]+"."+im[r.path],t.array,c,h);"CUBICSPLINE"===a.interpolation&&this._createCubicSplineTrackInterpolant(i),s.push(i)}return s}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){let e=iw(t.constructor),i=new Float32Array(t.length);for(let a=0,r=t.length;a<r;a++)i[a]=t[a]*e;t=i}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(e){return new(this instanceof tB.QuaternionKeyframeTrack?io:ia)(this.times,this.values,this.getValueSize()/3,e)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}function iM(e,t,i){let a=t.attributes,r=[];for(let t in a){let o=iu[t]||t.toLowerCase();o in e.attributes||r.push(function(t,a){return i.getDependency("accessor",t).then(function(t){e.setAttribute(a,t)})}(a[t],o))}if(void 0!==t.indices&&!e.index){let a=i.getDependency("accessor",t.indices).then(function(t){e.setIndex(t)});r.push(a)}return tB.ColorManagement.workingColorSpace!==tB.LinearSRGBColorSpace&&"COLOR_0"in a&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${tB.ColorManagement.workingColorSpace}" not supported.`),iv(e,t),!function(e,t,i){let a=t.attributes,r=new tB.Box3;if(void 0===a.POSITION)return;{let e=i.json.accessors[a.POSITION],t=e.min,o=e.max;if(void 0===t||void 0===o)return console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");if(r.set(new tB.Vector3(t[0],t[1],t[2]),new tB.Vector3(o[0],o[1],o[2])),e.normalized){let t=iw(il[e.componentType]);r.min.multiplyScalar(t),r.max.multiplyScalar(t)}}let o=t.targets;if(void 0!==o){let e=new tB.Vector3,t=new tB.Vector3;for(let a=0,r=o.length;a<r;a++){let r=o[a];if(void 0!==r.POSITION){let a=i.json.accessors[r.POSITION],o=a.min,s=a.max;if(void 0!==o&&void 0!==s){if(t.setX(Math.max(Math.abs(o[0]),Math.abs(s[0]))),t.setY(Math.max(Math.abs(o[1]),Math.abs(s[1]))),t.setZ(Math.max(Math.abs(o[2]),Math.abs(s[2]))),a.normalized){let e=iw(il[a.componentType]);t.multiplyScalar(e)}e.max(t)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}r.expandByVector(e)}e.boundingBox=r;let s=new tB.Sphere;r.getCenter(s.center),s.radius=r.min.distanceTo(r.max)/2,e.boundingSphere=s}(e,t,i),Promise.all(r).then(function(){return void 0!==t.targets?function(e,t,i){let a=!1,r=!1,o=!1;for(let e=0,i=t.length;e<i;e++){let i=t[e];if(void 0!==i.POSITION&&(a=!0),void 0!==i.NORMAL&&(r=!0),void 0!==i.COLOR_0&&(o=!0),a&&r&&o)break}if(!a&&!r&&!o)return Promise.resolve(e);let s=[],n=[],l=[];for(let h=0,c=t.length;h<c;h++){let c=t[h];if(a){let t=void 0!==c.POSITION?i.getDependency("accessor",c.POSITION):e.attributes.position;s.push(t)}if(r){let t=void 0!==c.NORMAL?i.getDependency("accessor",c.NORMAL):e.attributes.normal;n.push(t)}if(o){let t=void 0!==c.COLOR_0?i.getDependency("accessor",c.COLOR_0):e.attributes.color;l.push(t)}}return Promise.all([Promise.all(s),Promise.all(n),Promise.all(l)]).then(function(t){let i=t[0],s=t[1],n=t[2];return a&&(e.morphAttributes.position=i),r&&(e.morphAttributes.normal=s),o&&(e.morphAttributes.color=n),e.morphTargetsRelative=!0,e})}(e,t.targets,i):e})}let iS="1"!==e.i(872293).default.env.NEXT_PUBLIC_SPACE_BLENDER?"bootstrap":"blender";async function iT(e){if(!/^(shanghai|(minimal|modern|cyberpunk|vintage|italian|penthouse|japanese|company)-(original|island|shanghai))$/.test(e))throw Error("Unknown Blender asset");let t=`/assets/space/blender-v1/${e}`,i=await fetch(`${t}.json`,{cache:"no-store"});if(!i.ok)throw Error(`Blender asset manifest HTTP ${i.status}: ${e}`);let a=await i.json();if(a.asset!==e||2!==a.schemaVersion||!/^[a-f0-9]{64}$/.test(a.sha256))throw Error(`Invalid Blender manifest: ${e}`);return new tV().loadAsync(`${t}.glb?v=${a.sha256}`)}let iC=(e,t,i)=>L.MathUtils.smoothstep(i,e,t);function iP(e,t){let i=(e- -6)/79,a=(t-3)/65,r=Math.atan2(a,i),o=Math.hypot(i,a)/(1+.055*Math.sin(3*r)+.035*Math.cos(7*r));return -.65-4.05*iC(.64,.9,o)-1.8*iC(.9,1.02,o)-20*iC(1.02,1.5,o)}let iA=`
float islandHeight(vec2 p) {
  vec2 q = (p - vec2(-6.0, 3.0)) / vec2(79.0, 65.0);
  float angle = atan(q.y, q.x);
  float r = length(q) / (1. + .055 * sin(angle * 3.) + .035 * cos(angle * 7.));
  return -.65 - 4.05 * smoothstep(.64, .9, r) - 1.8 * smoothstep(.9, 1.02, r) - 20. * smoothstep(1.02, 1.5, r);
}`,ik=`
float shorePhase(vec2 p, float depth) {
  return depth * 1.75 + uTime * 1.25 + sin(p.x * .11 + p.y * .08) * 1.1
       + sin(p.x * .23 - p.y * .17) * .45;
}
float shoreBreakup(vec2 p) {
  return .45 + .55 * smoothstep(-.6, .65, sin(p.x * .19 + sin(p.y * .13) * 2.) * cos(p.y * .21));
}
float shoreHeight(vec2 p) {
  float depth = uSeaLevel - islandHeight(p);
  float phase = shorePhase(p, depth);
  float envelope = smoothstep(0., 1., depth) * (1. - smoothstep(1.5, 8., depth));
  return (sin(phase) * .82 - cos(phase * 2.) * .18) * envelope * min(1.25, .16 + uWindSpeed * .035) * shoreBreakup(p);
}
`;function iD(e){e.onBeforeCompile=e=>{e.vertexShader="varying vec3 vCoast;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\nvCoast = (modelMatrix * vec4(position,1.)).xyz;"),e.fragmentShader="varying vec3 vCoast;\n"+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
      float grain = fract(sin(dot(floor(vCoast.xz * 24.),vec2(127.1,311.7))) * 43758.5453);
      float patches = sin(vCoast.x*.31 + sin(vCoast.z*.18)*2.) * cos(vCoast.z*.27);
      float grass = smoothstep(-3.7,-1.1,vCoast.y + patches*.35);
      vec3 sand = mix(vec3(.30,.23,.13),vec3(.67,.56,.37),smoothstep(-5.65,-4.3,vCoast.y));
      diffuseColor.rgb *= mix(sand,vec3(.15,.20,.075)*(1.+patches*.20),grass) * (.94+grain*.12);
    `),e.fragmentShader=e.fragmentShader.replace("#include <roughnessmap_fragment>","#include <roughnessmap_fragment>\nroughnessFactor = mix(.34,.9,smoothstep(-5.8,-4.4,vCoast.y));")},e.customProgramCacheKey=()=>"space-island-terrain"}let iz={minimal:{sky:0x9aadb9,ground:8292742,stone:0xbcbdb8,frame:0xc9d0d2,wall:0xe7e5de,wood:8681320,fabric:0xd6d5cd,mirror:7502199,glow:0xffedce,secondary:0xe1eeff},cyberpunk:{sky:396311,ground:527895,stone:2107181,frame:5661035,wall:1252392,wood:1581610,fabric:1648432,mirror:1187369,glow:6546431,secondary:0xff518b},modern:{sky:9149349,ground:4475968,stone:0xc7c1b3,frame:4933953,wall:0xd4d0c5,wood:6443335,fabric:0xc9c4b9,mirror:6185563,glow:0xffd099,secondary:0xffe0b9}},i_={vintage:{...iz.modern,wood:3613981,fabric:7628363,frame:9465924,wall:0xb7aa8f},italian:{...iz.modern,stone:0xd5c7ac,wall:0xe4d5bd,wood:8610885,fabric:0xd8c4a4},penthouse:{...iz.minimal,sky:5531511,frame:3225659,wood:5259319,fabric:0xc4bcae},japanese:{...iz.modern,wood:0xa0845c,stone:0xb5b3a2,wall:0xe0dac8,fabric:0xc5bda6},company:{...iz.minimal,wood:0xc5ad86,wall:0xe5e4dc,frame:3816766,fabric:7961980}},iL=(e,t,i,a,r,o)=>{o.alphaTest||o.alphaHash||(o.map=null,o.alphaMap=null)};class iR{style;helpers;invalidate;environment;root;palette;ready;floor;surfaces;obstacles;solids;lights;lightSlots;roof;back;mirrors;textures;models;carsLoaded;disposed;glass;stone;wall;wood;fabric;metal;dark;ceramic;led;constructor(e,t,i=()=>{},a="original",r=iS){this.style=e,this.helpers=t,this.invalidate=i,this.environment=a,this.root=new L.Group,this.surfaces=[],this.obstacles=[],this.solids=[],this.lights=[],this.lightSlots=Array.from({length:4},()=>new L.RectAreaLight),this.roof=new L.Group,this.back=new L.Group,this.mirrors=[],this.textures=new Map,this.models=new Map,this.carsLoaded=!1,this.disposed=!1,this.glass=new L.MeshPhysicalMaterial({color:0xd7e6e5,roughness:.07,metalness:.15,transparent:!0,opacity:.1,depthWrite:!1,side:L.DoubleSide}),this.dark=new L.MeshStandardMaterial({color:2370091,roughness:.5}),this.ceramic=new L.MeshPhysicalMaterial({color:0xf0efdf,roughness:.12,clearcoat:1}),this.palette=e in iz?iz[e]:i_[e];const o=this.palette;if("LTC_FLOAT_1"in R.UniformsLib||tN.init(),"blender"===r){this.carsLoaded=!0,this.ready=this.loadBlender().catch(e=>{throw this.dispose(),e});return}for(const t of(this.ready=Promise.resolve(),this.stone=this.material(o.stone,"marble",.25),this.wall=new L.MeshStandardMaterial({color:o.wall,roughness:.9}),this.wood=this.material(o.wood,"wood",.48),this.fabric=this.material(o.fabric,"fabric",.95),this.metal=new L.MeshStandardMaterial({color:o.frame,metalness:.85,roughness:.25}),this.led=new L.MeshBasicMaterial({color:new L.Color(o.glow).multiplyScalar(2.2)}),this.root.add(this.roof,this.back),this.floor=this.mirror(20,18,[0,.014,0]),this.floor.rotation.x=-Math.PI/2,this.surfaces.push(this.floor),"company"===e?(this.floor.visible=!1,this.company()):this.villa(),this.landscape(),this.root.updateWorldMatrix(!0,!0),this.solids)){const e=new L.Box3().setFromObject(t);this.obstacles.push({minX:e.min.x,maxX:e.max.x,minY:e.min.y,maxY:e.max.y,minZ:e.min.z,maxZ:e.max.z})}for(const e of this.lights)e.getWorldPosition(e.position),e.getWorldQuaternion(e.quaternion),e.removeFromParent();for(const e of(this.root.add(...this.lightSlots),this.root.children))e instanceof L.Group&&e!==this.roof&&this.batch(e);for(const e of this.roof.children)e instanceof L.Group&&this.batch(e);this.batch(this.root),this.batch(this.roof),this.root.traverse(e=>{e instanceof L.Mesh&&(e.onBeforeShadow=iL)})}async loadBlender(){let{scene:e}=await iT(`${this.style}-${this.environment}`);if(this.disposed)return void this.disposeModel(e);let t=e;if(e.traverse(e=>{"root"===e.userData.spaceId&&(t=e)}),2!==e.userData.space_contract)throw this.disposeModel(e),Error("Space Blender asset needs contract 2 export");this.root.add(e),this.root.userData.spaceSource="blender";let i=[];e.traverse(e=>i.push(e));let a=new Set;for(let e of i){let t=e.userData;if("boolean"==typeof t.spaceVisible&&(e.visible=t.spaceVisible),"number"==typeof t.spaceRenderOrder&&(e.renderOrder=t.spaceRenderOrder),"roof"===t.spaceRole&&(this.roof=e),"back"===t.spaceRole&&(this.back=e),!(e instanceof L.Mesh))continue;if("reflection"===t.spaceRuntime){let i=this.mirror(1,"floor"===t.spaceRole?18:1,[0,+("floor"!==t.spaceRole),0]);for(let a of(i.geometry.dispose(),i.geometry=e.geometry,i.position.copy(e.position),i.quaternion.copy(e.quaternion),i.scale.copy(e.scale),i.userData=t,i.renderOrder=e.renderOrder,e.parent.add(i),e.removeFromParent(),Array.isArray(e.material)?e.material:[e.material]))a.dispose();e=i,"floor"===t.spaceRole&&(this.floor=i)}else if("shadow"===t.spaceRuntime){for(let t of Array.isArray(e.material)?e.material:[e.material])t.dispose();e.material=new L.ShadowMaterial({opacity:.3,depthWrite:!1})}let i=e;for(let e of(i.castShadow=!0===t.spaceCastShadow,i.receiveShadow=!0===t.spaceReceiveShadow,i.onBeforeShadow=iL,t.spaceSurface&&this.surfaces.push(i),Array.isArray(i.material)?i.material:[i.material]))a.add(e)}for(let e of a){"boolean"==typeof e.userData.spaceDepthWrite&&(e.depthWrite=e.userData.spaceDepthWrite),e.userData.spaceGlass&&(this.glass=e);let t=String(e.userData.spaceShaderKey??""),i=/^space-world-texture-(wood|marble|fabric|carpet|parquet)/.exec(t)?.[1];if(i&&e instanceof L.MeshStandardMaterial&&this.configureMaterial(e,i),e instanceof L.MeshStandardMaterial){("space-island-terrain"===t||t.includes("vCoast"))&&iD(e);let i=/^space-city-facade-([0-3])/.exec(t);i&&this.configureCityFacade(e,Number(i[1]))}}let r=t.userData;for(let e of(Array.isArray(r.spaceObstacles)&&this.obstacles.push(...r.spaceObstacles),r.spaceLights??[])){let t=new L.RectAreaLight;t.position.fromArray(e.position),t.quaternion.fromArray(e.quaternion),t.color.fromArray(e.color),t.intensity=e.intensity,t.width=e.width,t.height=e.height,this.lights.push(t)}this.root.add(...this.lightSlots),this.root.updateWorldMatrix(!0,!0),this.invalidate()}material(e,t,i){let a=new L.MeshStandardMaterial({color:e,roughness:i}),r=new L.TextureLoader;for(let e of["map","normalMap"]){let i="fabric"===t||"carpet"===t||"parquet"===t?"v2/"+({fabric:"rough_linen",carpet:"dirty_carpet",parquet:"herringbone_parquet"})[t]+"-"+("map"===e?"Diffuse":"nor_gl")+".jpg":"v1/"+("wood"===t?"wood_floor":"marble_01")+("map"===e?"-Diffuse.jpg":"-nor_gl.jpg"),o=this.textures.get(i)??r.load("/assets/space/"+i,()=>{this.disposed?o.dispose():this.invalidate()});o.wrapS=o.wrapT=L.RepeatWrapping,o.repeat.setScalar("fabric"===t?5:.25),"map"===e&&(o.colorSpace=L.SRGBColorSpace),o.anisotropy=4,a[e]=o,this.textures.set(i,o)}return a.normalScale.setScalar("fabric"===t?.25:.3),this.configureMaterial(a,t),a}configureMaterial(e,t){e.onBeforeCompile=e=>{if(("fabric"===t||"carpet"===t)&&(e.fragmentShader=e.fragmentShader.replace("#include <map_fragment>",R.ShaderChunk.map_fragment.replace("diffuseColor *= sampledDiffuseColor;",`sampledDiffuseColor.rgb = vec3(clamp(dot(sampledDiffuseColor.rgb, vec3(0.2126, 0.7152, 0.0722)) * ${"carpet"===t?"3.5":"1.8"}, 0.0, 1.0)); diffuseColor *= sampledDiffuseColor;`))),"company"===this.style&&("wood"===t||"parquet"===t)&&(e.fragmentShader=e.fragmentShader.replace("#include <map_fragment>",R.ShaderChunk.map_fragment.replace("diffuseColor *= sampledDiffuseColor;","sampledDiffuseColor.rgb = mix(sampledDiffuseColor.rgb, vec3(dot(sampledDiffuseColor.rgb, vec3(0.2126, 0.7152, 0.0722))), 0.25) * 1.6; diffuseColor *= sampledDiffuseColor;"))),"fabric"!==t){let i="carpet"===t?"1.8":"0.25";e.vertexShader=e.vertexShader.replace("#include <uv_vertex>",`#include <uv_vertex>
vec3 wp = (modelMatrix * vec4(position, 1.0)).xyz; vec3 wn = abs(mat3(modelMatrix) * normal); vec2 surfaceUv = wn.y > max(wn.x,wn.z) ? wp.xz : wn.x > wn.z ? wp.zy : wp.xy;
#ifdef USE_MAP
vMapUv = surfaceUv * ${i};
#endif
#ifdef USE_NORMALMAP
vNormalMapUv = surfaceUv * ${i};
#endif`)}},e.customProgramCacheKey=()=>"space-world-texture-"+t+("company"===this.style?"-company":"")}box(e,t,i,a,r,o,s,n=this.root,l=.025){let h=new L.Mesh(new eO.RoundedBoxGeometry(e,t,i,l>.06?3:1,Math.min(l,e/3,t/3,i/3)),s);return h.position.set(a,r,o),h.castShadow=s!==this.glass,h.receiveShadow=!0,t>=.6&&n!==this.roof&&this.solids.push(h),n.add(h),h}cylinder(e,t,i,a,r,o,s,n=this.root){let l=new L.Mesh(new L.CylinderGeometry(e,t,i,32),s);return l.position.set(a,r,o),l.castShadow=l.receiveShadow=!0,n.add(l),l}sphere(e,t,i,a,r,o=this.root){let s=new L.Mesh(new L.SphereGeometry(1,24,16),r);return s.position.set(e,t,i),s.scale.set(...a),s.castShadow=s.receiveShadow=!0,o.add(s),s}line(e,t,i,a=this.root){let r=new L.CatmullRomCurve3(e.map(e=>new L.Vector3(...e))),o=new L.Mesh(new L.TubeGeometry(r,24,t,8,!1),i);return o.castShadow=!0,a.add(o),o}area(e,t,i,a,r=4,o=this.palette.glow){let s=new L.RectAreaLight(o,r*("company"===this.style?.12:.2),i,a);s.position.set(...e),s.lookAt(...t),this.root.add(s),this.lights.push(s)}model(e,t,i,a,r,o=0,s=!1){let n=new L.Group;return n.position.set(t,i,a),n.rotation.y=o,n.name=e,this.root.add(n),this.models.has(e)||this.models.set(e,new tV().loadAsync("car-concept"===e?"/assets/space/v3/car-concept.glb":`/assets/space/v2/${e}/model.gltf`).then(({scene:t})=>this.disposed?(this.disposeModel(t),null):(t.traverse(t=>{if(t instanceof L.Mesh){if(t.castShadow=t.receiveShadow=!0,"car-concept"===e)for(let e of Array.isArray(t.material)?t.material:[t.material])e instanceof L.MeshPhysicalMaterial&&e.transmission>0&&(e.transmission=0,e.transparent=!0,e.opacity=.35,e.depthWrite=!1);if("throw_pillows_01"===e&&"vintage"!==this.style)for(let e of Array.isArray(t.material)?t.material:[t.material])e instanceof L.MeshStandardMaterial&&(e.map?.dispose(),e.map=null,e.color.setHex(this.palette.fabric),e.roughness=1)}}),t)).catch(t=>(console.warn(`Space asset could not load: ${e}`,t),null))),this.models.get(e).then(e=>{if(!e||this.disposed)return;let t=e.clone(!0),i=new L.Box3().setFromObject(t),a=i.getSize(new L.Vector3);if(s&&t.traverse(e=>{(e.name.endsWith("_pot")||e.name.endsWith("_pebbles"))&&(e.visible=!1)}),!Number.isFinite(a.y)||a.y<=0)return;let o=r/a.y,l=i.getCenter(new L.Vector3);t.scale.multiplyScalar(o),t.position.set(-l.x*o,-i.min.y*o,-l.z*o),t.traverse(e=>{e instanceof L.Mesh&&(e.onBeforeShadow=iL)}),n.add(t),this.invalidate()}),n}disposeModel(e){let t=new Set;e.traverse(e=>{if(e instanceof L.Mesh)for(let i of(e.geometry.dispose(),Array.isArray(e.material)?e.material:[e.material])){for(let e of Object.values(i))e instanceof L.Texture&&t.add(e);i.dispose()}}),t.forEach(e=>e.dispose())}platform(e,t,i,a,r,o){let s=this.box(e,.16,t,i,a-.08,r,o);return this.surfaces.push(s),s}books(e,t,i,a=7){let r=[0xa99d87,4738641,8673861,0xd2c8b5,7766649].map(e=>new L.MeshStandardMaterial({color:e,roughness:.85}));for(let o=0;o<a;o++){let a=.38+7*o%5*.055;this.box(.11,a,.31,e+.14*o,t+a/2,i,r[o%r.length]),this.box(.09,.018,.004,e+.14*o,t+.7*a,i+.157,this.ceramic)}}plant(e,t,i,a=1){this.model(a<.6?"potted_plant_02":"potted_plant_01",e,t,i,2.5*a,.7*e)}tree(e,t,i,a=1){this.model("island_tree_02",e,t,i,3.2*a,.7*e)}sofa(e,t,i,a,r=this.fabric){if("vintage"===this.style&&a>2){for(let r of a>4?[-(.26*a),.26*a]:[0])this.model("sofa_03",e+r,t,i,1.1);return}for(let o of(this.box(a,.17,1.16,e,t+.21,i,r,this.root,.08),[-1,1]))for(let r of[-1,1])this.box(.045,.14,.045,e+o*(a/2-.18),t+.07,i+.43*r,this.metal);let o=Math.max(1,Math.round(a/1.05)),s=r.clone();s.color.multiplyScalar(.7),s.onBeforeCompile=r.onBeforeCompile,s.customProgramCacheKey=r.customProgramCacheKey;for(let n=0;n<o;n++){let l=e-a/2+(n+.5)*a/o;this.box(a/o-.022,.24,.95,l,t+.42,i+.08,r,this.root,.11);let h=a/o/2-.075;this.line([[l-h,t+.48,i-.33],[l,t+.52,i-.37],[l+h,t+.48,i-.33],[l+h,t+.48,i+.48],[l,t+.52,i+.51],[l-h,t+.48,i+.48],[l-h,t+.48,i-.33]],.004,s),this.box(a/o-.025,.6,.25,l,t+.69,i-.43,r,this.root,.115).rotation.x=-.13,(0===n||n===o-1)&&this.model("throw_pillows_01",l,t+.52,i-.13,.44,n?-.25:.35)}for(let o of[-1,1])this.box(.2,.36,1.12,e+o*(a/2-.04),t+.46,i,r,this.root,.1)}table(e,t,i,a,r,o=this.wood){let s=this.box(a,.1,r,e,t,i,o,this.root,.07);for(let o of(this.surfaces.push(s),[-1,1]))for(let s of[-1,1])this.box(.06,t,.06,e+o*(a/2-.18),t/2,i+s*(r/2-.15),this.dark)}bowl(e,t,i,a,r,o){let s=[[.001,.03],[.72,.03],[.86,.12],[.98,.8],[1,.96],[.96,1],[.91,.95],[.79,.25],[.62,.17],[.001,.17]].map(([e,t])=>new L.Vector2(e,t*o)),n=new L.SplineCurve(s).getPoints(64),l=new L.Mesh(new L.LatheGeometry(n,96),this.ceramic);l.position.set(e,t,i),l.scale.set(a,1,r),l.castShadow=l.receiveShadow=!0,this.root.add(l),this.cylinder(.045,.045,.01,e,t+.18*o,i,this.metal)}villa(){let{stone:e,wall:t,wood:i,fabric:a,metal:r,led:o}=this;for(let a of(this.box(43,.5,31,-9,-.26,-2.5,e),Object.values(tw))){for(let o of(this.platform(a.width,a.depth,a.x,5*a.level,a.z,a===tw.bathroom||a===tw.interior?e:i),this.box(a.width+.3,.23,a.depth+.3,a.x,a.ceiling+.1,a.z,t,this.roof),[-1,1]))this.box(a.width+.6,.18,.14,a.x,a.ceiling+.27,a.z+o*(a.depth/2+.18),e,this.roof),this.box(.14,.18,a.depth+.6,a.x+o*(a.width/2+.18),a.ceiling+.27,a.z,e,this.roof),this.box(a.width+.4,.07,.12,a.x,a.ceiling-.1,a.z+o*(a.depth/2+.12),r,this.roof);for(let e of(this.box(a.width-.8,.026,.045,a.x,a.ceiling-.055,a.z+a.depth/2-.32,o,this.roof),[-1,1]))this.box(a.width-.6,.14,.3,a.x,a.ceiling-.15,a.z+e*(a.depth/2-.18),t,this.roof),this.box(.3,.14,a.depth-.6,a.x+e*(a.width/2-.18),a.ceiling-.15,a.z,t,this.roof),this.box(.025,.025,a.depth-1,a.x+e*(a.width/2-.36),a.ceiling-.07,a.z,o,this.roof);for(let e of[-1,1])for(let t of[-1,0,1])this.cylinder(.105,.105,.04,a.x+e*a.width*.32,a.ceiling-.04,a.z+t*a.depth*.31,this.dark,this.roof),this.cylinder(.068,.068,.008,a.x+e*a.width*.32,a.ceiling-.064,a.z+t*a.depth*.31,o,this.roof);this.area([a.x,a.ceiling-.1,a.z],[a.x,5*a.level,a.z],.7*a.width,.55*a.depth,3)}this.floor.position.y=.018;let s=e.clone();s.onBeforeCompile=e.onBeforeCompile,s.customProgramCacheKey=e.customProgramCacheKey,s.transparent=!0,s.opacity="minimal"===this.style?.16:.55,s.depthWrite=!1;let n=new L.Mesh(new L.PlaneGeometry(20,18),s);n.rotation.x=-Math.PI/2,n.position.y=.022,n.receiveShadow=!0,this.root.add(n);let l=new L.Mesh(new L.PlaneGeometry(20,18),new L.ShadowMaterial({opacity:.3,depthWrite:!1}));for(let e of(l.rotation.x=-Math.PI/2,l.position.y=.026,l.receiveShadow=!0,this.root.add(l),this.box(39,9.5,.3,-9.5,4.75,-16.1,t),this.box(.3,7.8,13.5,10.15,3.9,-2.25,t),this.box(.3,7.8,2.5,10.15,3.9,7.75,t),this.box(.3,5,2,10.15,5.3,5.5,t),[4.45,6.55]))this.box(.35,2.85,.06,10.15,1.425,e,r);for(let[e,a,o,s,n]of(this.box(12,4.7,.25,-23,2.35,-6.1,i),this.box(8.8,4.4,.22,-24.6,7.2,-4.1,i),this.box(.25,4.5,22,-29.15,7.25,-5,t),[[0,3.9,9,20,7.8],[-23,2.4,10,12,4.8],[-23,7.2,10,12,4.4]])){if(0===e){for(let e of[-5.6,5.6])this.box(8.8,n,.03,e,a,o,this.glass);this.box(2.4,n-2.8,.03,0,a+1.4,o,this.glass)}else this.box(s,n,.03,e,a,o,this.glass);for(let t=0;t<=s;t+=3)(0!==e||Math.abs(e-s/2+t)>1.2)&&this.box(.045,n,.075,e-s/2+t,a,o,r);for(let t of[-1,1])this.box(s,.07,.1,e,a+t*n/2,o,r)}for(let t of[-29,-17,-10,10])this.box(.26,t<-10?9.4:7.8,.26,t,t<-10?4.7:3.9,9,e);this.box(.035,4.5,16,-29,2.4,2,this.glass),this.box(.035,4.4,2.3,-17,7.2,-14.85,this.glass),this.box(.035,4.4,21.3,-17,7.2,-.65,this.glass),this.box(.035,1.6,2.4,-17,8.6,-12.5,this.glass);for(let e=-15;e<=9;e+=3)Math.abs(e+12.5)>1.25&&this.box(.055,4.4,.06,-17,7.2,e,r);for(let e=0;e<25;e++)this.box(.5,.14,2.9,9-.44*e,.2+.2*e,-12.35,i);for(let e of[-13.85,-10.85]){this.line([[9.2,1.2,e],[-1.6,6.1,e]],.035,r);for(let t=0;t<6;t++)this.box(.03,1,.03,9-2.1*t,.65+.955*t,e,r)}for(let[t,s,n,l]of(this.box(15,1.1,.025,-9.5,5.65,-9,this.glass),this.box(15,.04,.05,-9.5,6.2,-9,r),this.box(13,7.8,.22,-3.5,3.9,-9.1,i),this.box(12,3.6,.08,-3.4,3.4,-8.96,r),this.mirror(11.8,3.4,[-3.4,3.4,-8.9]),this.box(12,.025,.03,-3.4,5.18,-8.88,o),this.sofa(-4.7,0,-6.6,4.8),this.model("modern_arm_chair_01",-8,0,-4.1,.95,.9),this.model("modern_arm_chair_01",-7.5,0,-2.5,.95,1.2),this.box(7.2,.025,5,-4.8,.045,-4.5,a,this.root,.1),[[-4.8,-4.2,1,.51],[-3.3,-3.7,.65,.38]]))this.surfaces.push(this.cylinder(n,n,.09,t,l,s,e)),this.cylinder(.6*n,.6*n,l,t,l/2,s,r);this.box(.7,.06,.5,-4.8,.59,-4.2,i),this.cylinder(.15,.21,.42,-5.3,.75,-4.3,this.ceramic),this.plant(8.2,0,-6.3);for(let e=-9.8;e<3;e+=.16)this.box(.075,2.3,.1,e,6.62,-8.91,i);this.box(2.8,7.8,.45,8.35,3.9,-8.85,e),this.box(2.4,.8,.08,8.35,.8,-8.59,this.dark),this.box(2.15,.015,.07,8.35,.48,-8.52,o),this.box(3.2,.17,.85,8.35,.16,-8.52,e),this.area([-4,4.7,-8.4],[-4,1,-5.5],8,1.5,9),this.area([-9.7,3.8,-2],[-3,1.3,-5],7,4,8,0xcad8e5);for(let e=0;e<3;e++){let t=new L.Mesh(new L.TorusGeometry(1.15+.22*e,.025,8,80),o);t.rotation.x=Math.PI/2+.16*e,t.position.set(-3,6.1+.3*e,-3.4),this.root.add(t),this.line([[-3,7.8,-3.4],[-3,6.2,-3.4]],.008,r)}this.box(.1,4.5,13.6,-28.93,2.25,2,i);let h=[3491147,7758659,0xbeb29a,7755594,8882809].map(e=>new L.MeshStandardMaterial({color:e,roughness:.9}));for(let e=-4.4;e<8;e+=2.25){this.box(.5,4.5,.065,-28.6,2.25,e,i);for(let t=.35;t<4.1;t+=.77){this.box(.7,.065,2.1,-28.5,t,e+1.08,i),this.box(.022,.015,2,-28.2,t-.04,e+1.08,o);for(let i=0;i<9;i++){let a=.31+(7*i+Math.round(10*t))%5*.045,r=e+.22+.17*i;for(let e of(this.box(.32,a,.115,-28.4,t+.04+a/2,r,h[(i+Math.round(4*t))%h.length]),[.11,a-.07]))this.box(.004,.012,.075,-28.238,t+.04+e,r,this.ceramic)}}}this.area([-28.05,2.9,1],[-24,1.4,1],.5,8,7),this.box(5.1,.024,4.1,-23.8,.022,.45,a,this.root,.1),this.table(-23.5,.76,0,2.6,1.15),this.box(1.15,.008,.65,-23.35,.806,.08,this.dark,this.root,.04),this.box(.76,.44,.045,-23.3,1.14,-.3,this.dark),this.box(.04,.2,.04,-23.3,.88,-.3,r),this.box(.42,.018,.15,-23.3,.825,.26,this.dark);for(let e=0;e<4;e++)for(let t=0;t<12;t++)this.box(.026,.004,.024,-23.48+.032*t,.837,.21+.032*e,this.metal,this.root,.001);this.cylinder(.06,.045,.11,-22.95,.87,.37,this.ceramic);let c=new L.Mesh(new L.TorusGeometry(.035,.008,8,20),this.ceramic);for(let e of(c.position.set(-22.887,.88,.37),this.root.add(c),this.books(-24.6,.82,-.3,4),this.cylinder(.12,.12,.025,-22.5,.82,-.32,r),this.line([[-22.5,.84,-.32],[-22.5,1.45,-.32],[-22.83,1.52,-.22]],.014,r),this.cylinder(.12,.21,.11,-22.83,1.48,-.22,r),this.cylinder(.19,.19,.008,-22.83,1.422,-.22,o),[-25.4,-21.8])){this.box(2.5,2.8,.075,e,2.45,-5.91,r),this.box(2.4,2.7,.08,e,2.45,-5.85,a);for(let t=0;t<8;t++){let i=new L.Mesh(new L.TorusGeometry(.35+.07*t,.023,6,64,1.5*Math.PI),this.ceramic);i.position.set(e,2.45,-5.785),i.rotation.z=e<-24?.4:2.4,i.castShadow=i.receiveShadow=!0,this.root.add(i)}this.box(2.4,.025,.05,e,4.16,-5.7,o),this.area([e,4.05,-5.4],[e,2.2,-5.9],2.2,.15,5)}this.model("modern_arm_chair_01",-23.5,0,1.1,.94,Math.PI),this.sofa(-23.5,0,7,3.6),this.plant(-18.5,0,-3.5,.65),this.bedroom(),this.bathroom(),this.box(6,.4,18,-13.5,-.22,0,this.dark),this.mirror(5.7,17.7,[-13.5,-.015,0]).rotation.x=-Math.PI/2,this.box(2.2,.3,2.2,-13.5,.08,-3.5,e),this.plant(-13.5,.22,-3.5,1.4);for(let t=0;t<5;t++)this.platform(1.1,1.6,-15.8+1.15*t,.07,5,e);this.details(),this.leisureWing()}leisureWing(){let{wood:e,metal:t,led:i,stone:a,dark:r,fabric:o}=this,s=this.material(3619901,"fabric",1);for(let t of(this.box(20.4,.5,40.5,20.1,-.26,4,a),this.box(20.3,4.2,.25,20,2.1,-16.1,a),this.box(.25,4.2,40,30.1,2.1,4,a),[-4,10]))this.box(18,4.2,.22,21,2.1,t,e);for(let[i,a]of[[-10,12],[3,14],[17,14]]){let r=(a-1.8)/2;for(let t of[-1,1])this.box(.22,4.2,r,12,2.1,i+t*(.9+r/2),e);for(let a of(this.box(.22,1.4,1.8,12,3.5,i,e),[-1,1]))this.box(.3,2.85,.06,12,1.425,i+.94*a,t)}this.box(18,4.2,.025,21,2.1,24,this.glass);for(let e=12;e<=30;e+=3)this.box(.055,4.2,.08,e,2.1,24,t);for(let e of(this.platform(17.5,11.5,21,.035,-10,r),[16.3,25.5])){for(let t of[-2,2])this.box(.045,.008,7,e+t,.045,-10,i);this.box(.5,.75,.12,e,1.15,-15.85,t,this.root,.1),this.line([[e+.15,1.15,-15.75],[e+.32,.55,-15.5],[e-.15,.45,-15.5],[e-.12,.9,-15.7]],.019,r),this.obstacles.push({minX:e-1.1,maxX:e+1.1,minY:0,maxY:1.5,minZ:-12.6,maxZ:-7.4})}for(let i=14;i<29;i+=1.2)this.box(1.17,2.2,.65,i,1.1,-15.7,e),this.box(.025,.45,.03,i+.43,1.12,-15.34,t);this.platform(17.6,13.6,21,.04,3,s),this.box(.14,2.9,8.8,29.9,2.1,3,r);let n=new L.MeshBasicMaterial({color:0xa9bbbf});for(let e of(this.box(.045,2.5,8.2,29.8,2.1,3,n),[-3.84,9.84]))for(let t=12.6;t<29.5;t+=.32)this.box(.14,3.9,.12,t,2,e,s);for(let i of[17,21.5])for(let a of[-.1,3,6.1]){let r=this.root.children.length;this.sofa(i,0,a,1.7,s),this.table(i+1.2,.52,a,.5,.65,e),this.cylinder(.09,.08,.19,i+1.2,.68,a,t);let o=new L.Group;for(let e of(o.position.set(i,0,a),this.root.add(o),o.updateMatrixWorld(),this.root.children.slice(r,-1)))o.attach(e);o.rotation.y=Math.PI/2}for(let e of[-3.7,9.7])this.box(17,.02,.025,21,.12,e,i);for(let i of(this.box(.8,.3,.6,15,3.7,3,r,this.roof),this.area([29.6,2.3,3],[20,1,3],2.4,8,2.4,0xb5d9eb),this.platform(17.6,13.6,21,.025,17,e),this.mirror(15.5,2.9,[21,1.9,10.16]),[17,21,25])){for(let e of(this.box(1.05,.13,2.3,i,.16,20.8,r,this.root,.1),this.box(.72,.015,1.7,i,.24,21,s),[-.5,.5]))this.line([[i+e,.2,20],[i+e,1.35,19.75],[i+e,1.35,20.4]],.035,t);this.box(.8,.22,.3,i,1.35,19.75,r,this.root,.06).rotation.x=-.3}for(let e of(this.table(22,.48,14.4,.65,1.8,s),[14,15.8]))this.box(.1,2.4,.1,e,1.2,12.1,t);for(let e of(this.box(2,.1,.8,14.9,2.4,12.1,t),[14.05,15.75])){this.line([[e,.25,12.1],[e,2.25,12.1],[e,1.6,12.7]],.008,r);for(let t=.2;t<.85;t+=.065)this.box(.35,.05,.28,e,t,12.1,r)}this.table(26,.65,12,4,.7,t);for(let e=0;e<7;e++){let i=24.5+.5*e,a=.11+.014*e;for(let e of(this.cylinder(.025,.025,.43,i,.83,12,t).rotation.x=Math.PI/2,[11.8,12.2]))this.cylinder(a,a,.12,i,.83,e,r).rotation.x=Math.PI/2}for(let e of(this.box(.8,.015,2,16,.045,17,o,this.root,.05),this.sphere(27,.62,17,[.6,.6,.6],s),[13.3,28.5]))this.plant(e,0,22.6,.6);this.area([21,3.5,23.6],[21,.8,16],15,3,7,0xd5e4e9)}bedroom(){let e=this.root.children.length;this.box(5.5,1.9,.15,-24.3,6,-3.7,this.fabric,this.root,.15),this.box(5,.35,6.6,-24.3,5.25,0,this.wood,this.root,.1),this.box(4.7,.42,6.2,-24.3,5.63,0,this.ceramic,this.root,.2);let t=this.material(0xe2d9c7,"fabric",1),i=new L.PlaneGeometry(6.3,5.4,110,90);i.rotateX(-Math.PI/2);let a=i.attributes.position;for(let e=0;e<a.count;e++){let t=a.getX(e),i=a.getZ(e),r=Math.max(0,Math.abs(t)-2.24);a.setX(e,Math.sign(t)*(Math.min(Math.abs(t),2.24)+.14*Math.sin(Math.min(r,.3)/.3*Math.PI/2))),a.setY(e,-(.9*r)+.025*Math.sin(4.1*t+2.7*i)+.015*Math.sin(6.3*i-t)+.065*Math.exp(-Math.pow((i+2.4)*5,2)))}i.computeVertexNormals(),t.side=L.DoubleSide;let r=new L.Mesh(i,t);r.position.set(-24.3,5.98,.5),r.castShadow=r.receiveShadow=!0,this.root.add(r);let o=new L.PlaneGeometry(6.2,1.5,110,30);o.rotateX(-Math.PI/2);let s=o.attributes.position;for(let e=0;e<s.count;e++){let t=s.getX(e),i=s.getZ(e),a=Math.max(0,Math.abs(t)-2.28);s.setX(e,Math.sign(t)*(Math.min(Math.abs(t),2.28)+.14*Math.sin(Math.min(a,.3)/.3*Math.PI/2))),s.setY(e,.022*Math.sin(3.8*t+2*i)+.008*Math.sin(9*i-5*t)-.9*a)}o.computeVertexNormals();let n=new L.Mesh(o,this.fabric);for(let e of(n.position.set(-24.3,6.08,1.9),n.castShadow=!0,this.root.add(n),[-25.5,-23.1]))this.box(1.8,.28,.98,e,6,-2.05,t,this.root,.13),this.model("throw_pillows_01",e,6.08,-1.7,.55,e<-24?.15:-.12);for(let e of[-27.6,-21]){let i=this.box(1.1,.65,1.05,e,5.43,-2.7,this.wood,this.root,.08);this.surfaces.push(i),this.box(.9,.012,.025,e,5.42,-2.163,this.metal),this.cylinder(.12,.16,.35,e,5.95,-2.7,this.metal),this.cylinder(.25,.37,.4,e,6.3,-2.7,t)}for(let e of(this.box(4.5,.36,1.1,-24.3,5.6,4.2,this.fabric,this.root,.12),[-26,-22.6]))this.box(.09,.5,.65,e,5.25,4.2,this.metal);let l=new L.Group;for(let t of(l.position.set(-24.3,5,-.5),this.root.add(l),l.updateMatrixWorld(),this.root.children.slice(e,-1)))l.attach(t);l.scale.set(.5,.8,.48),this.box(6.3,.024,5.2,-24.3,5.03,.4,this.fabric);for(let e=-27.5;e<-20.8;e+=.24)this.box(.09,2.9,.06,e,6.6,-3.88,this.wood);this.box(6.8,.022,.03,-24.3,7.92,-3.84,this.led),this.area([-24.3,7.6,-3.7],[-24.3,5.7,0],5,1,7);for(let e=0;e<8;e+=1.2)this.box(.72,3.7,1.15,-28.45,7.05,e,this.wood),this.box(.05,.8,.035,-28.05,6.95,e+.38,this.metal);for(let e of(this.sofa(-19.4,5,7.7,2),this.area([-23,8.4,9.2],[-24,5.8,0],10,2,4.5,0xd6e4ff),[-28.1,-17.9])){let t=new L.PlaneGeometry(1.25,4.1,48,1),i=t.attributes.position;for(let e=0;e<i.count;e++)i.setZ(e,.065*Math.sin(27*i.getX(e)));t.computeVertexNormals();let a=new L.Mesh(t,this.material(0xe2ddcf,"fabric",1));a.material.side=L.DoubleSide,a.position.set(e,7.1,9.76),a.castShadow=!0,this.root.add(a)}}bathroom(){this.box(12,4.4,.13,-23,7.2,-15.86,this.stone);for(let e=-11.2;e<=-4.4;e+=1.7)this.box(.065,4.1,1.68,-28.93,7.1,e,this.stone);this.box(.08,.65,2.8,-28.83,6.9,-8.1,this.dark),this.box(.055,.025,2.8,-28.77,7.19,-8.1,this.led),this.box(.45,.08,2.8,-28.61,6.59,-8.1,this.wood);for(let e=0;e<4;e++)this.cylinder(.055,.07,.2+e%2*.08,-28.48,6.74,-9+.3*e,e%2?this.ceramic:this.metal);this.box(5.8,.55,1.2,-23.1,5.75,-14.8,this.wood,this.root,.05),this.surfaces.push(this.box(6,.11,1.3,-23.1,6.08,-14.8,this.stone));for(let e=-25.8;e<-20.4;e+=.95)this.box(.015,.43,.025,e,5.75,-14.187,this.dark);for(let e of(this.box(5.7,.02,.03,-23.1,5.44,-14.2,this.led),[-24.55,-21.75]))this.bowl(e,6.15,-14.65,.58,.43,.25),this.line([[e,6.1,-15.28],[e,6.68,-15.28],[e,6.72,-14.99]],.035,this.metal),this.box(2.16,2.12,.07,e,7.68,-15.67,this.led,this.root,.12),this.mirror(2.04,1.98,[e,7.68,-15.61]),this.cylinder(.055,.065,.19,e+.85,6.34,-14.55,this.ceramic),this.box(.06,.025,.025,e+.85,6.46,-14.55,this.metal);this.bowl(-25.3,5.04,-7.8,1.24,.63,.64),this.line([[-25.7,5.1,-8.95],[-25.7,6.25,-8.95],[-25.7,6.35,-8.58]],.046,this.metal),this.box(.42,.04,1.4,-25.1,5.7,-7.8,this.wood);for(let e=0;e<3;e++)this.cylinder(.095,.095,.32,-24.97,5.81+.008*e,-7.57-.21*e,this.fabric).rotation.z=Math.PI/2;this.platform(3,3.5,-27.35,5.05,-13.65,this.stone),this.box(.025,3.6,3.5,-25.8,6.85,-13.65,this.glass),this.box(1.5,3.6,.025,-28,6.85,-11.9,this.glass),this.box(.04,3.6,.04,-25.8,6.85,-11.9,this.metal),this.box(.035,.55,.035,-27.1,6.5,-11.9,this.metal),this.line([[-28.6,6.1,-14],[-28.6,8.65,-14],[-27.6,8.65,-14]],.035,this.metal),this.cylinder(.32,.32,.055,-27.6,8.63,-14,this.metal),this.box(.02,.65,.25,-28.8,6.55,-13.9,this.metal),this.box(.025,.5,.9,-28.81,6.9,-12.9,this.dark),this.box(.65,.008,.045,-27.5,5.145,-13.8,this.metal),this.box(.15,2.6,3.3,-20.05,6.3,-12,this.wood),this.box(2.9,2.6,.15,-18.5,6.3,-13.7,this.wood),this.box(.32,.25,.34,-18.65,5.35,-13.5,this.ceramic,this.root,.1),this.bowl(-18.65,5.26,-13.22,.28,.41,.28);let e=new L.Mesh(new L.TorusGeometry(.26,.025,12,64),this.ceramic);e.rotation.x=Math.PI/2,e.scale.y=1.43,e.position.set(-18.65,5.55,-13.22),this.root.add(e),this.box(.53,.56,.04,-18.65,5.86,-13.6,this.ceramic,this.root,.13).rotation.x=-.09,this.box(.25,.14,.015,-18.65,6.3,-13.61,this.metal),this.cylinder(.1,.1,.22,-19.9,5.8,-12.75,this.ceramic).rotation.x=Math.PI/2,this.box(2.7,.022,1.1,-23.1,5.1,-13.15,this.fabric,this.root,.07),this.plant(-28.3,5,-5.3,.5),this.area([-23,8.8,-13],[-23,5.2,-9],5,2,5,0xffefd7),this.mirror(12,12,[-23,5.018,-10]).rotation.x=-Math.PI/2;let t=this.stone.clone();t.onBeforeCompile=this.stone.onBeforeCompile,t.customProgramCacheKey=this.stone.customProgramCacheKey,t.transparent=!0,t.opacity=.65,t.depthWrite=!1;let i=new L.Mesh(new L.PlaneGeometry(12,12),t);i.rotation.x=-Math.PI/2,i.position.set(-23,5.022,-10),i.receiveShadow=!0,this.root.add(i)}details(){if("italian"===this.style){for(let e of[-7.5,-2.5,2.5,7.5]){let t=new L.Shape;t.moveTo(-2.5,0),t.lineTo(-2.5,7.8),t.lineTo(2.5,7.8),t.lineTo(2.5,0),t.lineTo(2.1,0),t.lineTo(2.1,4.8),t.absarc(0,4.8,2.1,0,Math.PI,!1),t.lineTo(-2.1,0),t.closePath();let i=new L.Mesh(new L.ExtrudeGeometry(t,{depth:.5,bevelEnabled:!1,curveSegments:40}),this.wall);i.position.set(e,0,8.8),i.castShadow=!0,this.root.add(i)}for(let e=-29;e<10;e+=.4)this.box(.2,.16,7.5,e,9.65,-12.5,this.wood,this.roof,.06);for(let e of[-7.5,-2.5,2.5,7.5]){let t=new L.Mesh(new L.TorusGeometry(2.16,.045,8,64,Math.PI),this.stone);for(let i of(t.position.set(e,4.8,9.34),this.root.add(t),[-1,1]))this.box(.09,4.8,.12,e+2.16*i,2.4,9.3,this.stone),this.box(.38,.16,.68,e+2.3*i,4.77,9.05,this.stone),this.box(.4,.18,.7,e+2.3*i,.1,9.05,this.stone)}for(let e of[-8.5,8.5])this.cylinder(.48,.33,1.2,e,.6,12,this.stone),this.plant(e,.4,12,.8)}if("vintage"===this.style){this.cylinder(.26,.28,.035,-1.55,.04,-6.55,this.metal),this.cylinder(.025,.025,1.65,-1.55,.87,-6.55,this.metal),this.cylinder(.22,.38,.4,-1.55,1.7,-6.55,new L.MeshStandardMaterial({color:0xefe1c7,roughness:.95,emissive:0xc68b43,emissiveIntensity:.4}));for(let e=-9;e<9;e+=3)for(let t of[.3,2.8,5.8,7.5])this.box(2.75,.055,.055,e+1.4,t,-8.92,this.metal);for(let e=-9;e<9;e+=3)this.box(.055,7.3,.06,e,3.9,-8.91,this.metal);for(let e of[-5.8,9.7])for(let t=-28;t<-18;t+=2.2){for(let i of[-1,1])this.box(.04,2.4,.07,t+.9*i,1.65,e,this.metal);for(let i of[.45,2.85])this.box(1.8,.04,.07,t,i,e,this.metal)}for(let e=0;e<16;e++){let t=e*Math.PI/8;this.line([[-3,6.6,-3.4],[-3+2*Math.cos(t),5.8,-3.4+2*Math.sin(t)]],.035,this.metal),this.sphere(-3+2*Math.cos(t),5.8,-3.4+2*Math.sin(t),[.12,.25,.12],this.led)}for(let e=0;e<23;e++)this.sphere(-7.8+.28*e,.95,-7.01,[.04,.04,.02],this.metal)}if("japanese"===this.style){for(let e=-29;e<=10;e+=1.1)this.box(.13,.27,29,e,9.6,-3,this.wood,this.roof);for(let e=-8;e<=9;e+=.33)this.box(.13,7.8,.08,9.9,3.9,e,this.wood);for(let e=-28;e<-17;e+=.5)this.box(.06,4.1,.09,e,7.15,9.85,this.wood);for(let e=0;e<6;e++)this.sphere(-14+1.5*Math.sin(e),.12,-5+1.4*e,[.55,.28,.36],this.stone)}if("cyberpunk"===this.style){let e=new L.MeshBasicMaterial({color:new L.Color(this.palette.secondary).multiplyScalar(2)});for(let t of[-29,-17,-10,10])this.box(.055,9.4,.055,t,4.7,9.1,e);for(let e of[.15,5,7.8])this.box(20,.035,.08,0,e,9.15,this.led);this.area([-9,4,-8],[0,1,0],6,3,8,this.palette.secondary);for(let t=0;t<12;t++)this.box(.025,1+t%4,.03,-9+.35*t,3,-8.85,e)}if("minimal"===this.style){for(let e of[-8,8])this.cylinder(.2,.2,7.8,e,3.9,8.8,this.metal);this.sphere(6.6,1.25,-5,[.8,1.2,.8],new L.MeshStandardMaterial({color:0xbac5c8,metalness:1,roughness:.1}))}}company(){let e=this.material(0xb9bdbb,"carpet",1),t=this.material(9212563,"fabric",1),i=this.material(0xf1dfbe,"parquet",.48),a=this.material(0xc4a168,"fabric",1),r=new L.MeshStandardMaterial({color:0xe0e2dc,roughness:.6}),o=this.material(0xb3693b,"fabric",1),s=this.material(0xa7ac6b,"fabric",1);for(let t of(this.platform(26.6,18.4,-12.65,-.025,3.6,i),this.platform(5.4,6.6,-23,0,2,e),[-25.95,.65]))this.box(.15,3.7,18.4,t,1.85,3.6,r);for(let e of[-5.65,12.85])this.box(26.6,3.7,.15,-12.65,1.85,e,r);this.box(26.6,.1,18.4,-12.65,3.75,3.6,this.dark,this.roof),this.box(.12,2.75,6.6,-25.75,1.375,2,r),this.box(.12,2.75,6.6,-20.25,1.375,2,r),this.box(.06,.12,6.6,-20.33,.06,2,this.dark),this.box(.06,.12,6.6,-25.67,.06,2,this.dark);let n=new L.MeshStandardMaterial({color:1055011,metalness:.5,roughness:.16});this.box(5.4,2.7,.04,-23,1.35,-1.3,n);let l=this.mirror(5.3,2.6,[-23,1.35,-1.265]);l.material.uniforms.uPolish.value=.32,l.material.uniforms.color.value.setHex(527376);let h=new L.MeshStandardMaterial({color:0xb4b9b6,metalness:.65,roughness:.33});for(let e of[-25.7,-24,-22.3,-20.3])this.box(.055,2.7,.07,e,1.35,-1.2,h);for(let e of[.28,.78,1.28,1.78,2.3])this.box(5.4,.055,.075,-23,e,-1.2,h);for(let[e,t]of[[-24.8,.6],[-23.1,.72],[-21.2,1.12]])this.box(1.6,t,.025,e,2.7-t/2,-1.16,r),this.line([[e+.76,2.68,-1.08],[e+.76,1.5,-1.08]],.004,this.dark);this.cylinder(.28,.28,2.75,-20.55,1.375,-.85,r),this.box(5.4,.1,6.6,-23,2.8,2,r,this.roof);for(let e=-25.7;e<-20.2;e+=.6)this.box(.012,.018,6.6,e,2.738,2,h,this.roof);for(let e=-1.3;e<5.4;e+=.6)this.box(5.4,.018,.012,-23,2.738,e,h,this.roof);for(let e of[0,2.4,4.2])this.box(.56,.02,.56,-23,2.72,e,this.led,this.roof),this.area([-23,2.65,e],[-23,0,e],2.4,1.8,14,0xf0f3ee);this.area([-23,.1,2],[-23,2.7,2],4,5,3,0xffffff);for(let e=0;e<5;e++){let t=.5-.085*e;for(let i of[-1,1])this.box(t,.018,.014,-24.5,2.72-.008*e,1.2+i*t/2,h,this.roof),this.box(.014,.018,t,-24.5+i*t/2,2.72-.008*e,1.2,h,this.roof)}let c=new Uint8Array(16384);for(let e=0;e<4096;e++)c.fill(255*(e%4==0||Math.floor(e/64)%4==0),4*e,4*e+4);let d=new L.DataTexture(c,64,64);d.wrapS=d.wrapT=L.RepeatWrapping,d.repeat.set(2,3),d.generateMipmaps=!0,d.minFilter=L.LinearMipmapLinearFilter,d.needsUpdate=!0,this.textures.set("chair-mesh",d);let u=new L.MeshStandardMaterial({color:2106405,roughness:.9,alphaMap:d,transparent:!0,opacity:.85,depthWrite:!1,side:L.DoubleSide}),m=(e,t,i=this.dark,a=0,o=!0)=>{let s=new L.Group;if(s.position.set(e,0,t),s.rotation.y=a,this.root.add(s),this.box(.5,.085,.48,0,.48,0,i,s,.09),!o){let e=i.clone();e.side=L.DoubleSide,e.onBeforeCompile=i.onBeforeCompile,e.customProgramCacheKey=i.customProgramCacheKey;let t=new L.CylinderGeometry(.28,.25,.3,48,4,!0,-Math.PI/2,Math.PI),a=t.attributes.position;for(let e=0;e<a.count;e++)a.setY(e,a.getY(e)+.71-.2*(a.getY(e)/.3+.5)*Math.abs(a.getX(e)/.28)**3);t.computeVertexNormals();let r=new L.Mesh(t,e);r.castShadow=r.receiveShadow=!0,s.add(r);let o=Array.from({length:25},(e,t)=>{let i=-Math.PI/2+t*Math.PI/24;return[.28*Math.sin(i),.86-.2*Math.abs(Math.sin(i))**3,.28*Math.cos(i)]});this.line(o,.018,i,s)}if(o){let e=new L.PlaneGeometry(.43,.52,24,24),t=e.attributes.position;for(let e=0;e<t.count;e++)t.setZ(e,.02*Math.cos(10*t.getY(e))-.25*t.getX(e)**2);e.computeVertexNormals();let i=new L.Mesh(e,u);i.position.set(0,.81,.25),i.rotation.x=.14,i.castShadow=i.receiveShadow=!0,s.add(i),this.line([[-.19,.54,.21],[-.235,.64,.22],[-.22,1.02,.28],[-.16,1.08,.29],[.16,1.08,.29],[.22,1.02,.28],[.235,.64,.22],[.19,.54,.21],[-.19,.54,.21]],.025,this.dark,s),this.box(.42,.085,.025,0,.63,.29,this.dark,s),this.cylinder(.027,.04,.42,0,.23,0,h,s);for(let e=0;e<5;e++){let t=e*Math.PI*.4;this.line([[0,.12,0],[.3*Math.cos(t),.08,.3*Math.sin(t)]],.022,this.dark,s),this.sphere(.3*Math.cos(t),.045,.3*Math.sin(t),[.045,.045,.035],this.dark,s)}for(let e of[-.29,.29])this.box(.035,.2,.035,e,.6,.05,this.dark,s),this.box(.06,.035,.3,e,.71,0,this.dark,s)}else for(let e of[-1,1])for(let t of[-1,1])this.line([[.17*e,.44,.16*t],[.27*e,.035,.26*t]],.025,r,s);this.batch(s)};for(let e of(this.table(-23.7,.74,2.1,1.48,3.95,r),this.table(-21.5,.74,-.25,2.35,1.15,r),[-1,1]))for(let i=0;i<3;i++){let a=-23.7+.39*e,n=.7+1.3*i;m(-23.7+1.07*e,n,this.dark,-e*Math.PI/2);let l=this.root.children.length;this.box(.52,.32,.027,a+.13,1.04,n-.22,this.dark),this.box(.018,.2,.018,a+.13,.86,n-.22,this.metal),this.box(.3,.018,.12,a+.1,.81,n+.1,this.dark),this.box(.28,.015,.2,a-.4,.8,n+.05,r),this.box(.3,.22,.012,a-.35,.94,n-.21,this.metal).rotation.x=-.25,this.cylinder(.036,.036,.18,a+.51,.87,n-.23,i%2?o:s),this.cylinder(.035,.045,.07,a-.45,.825,n+.24,r),this.box(.14,.012,.075,a+.34,.81,n+.23,this.dark).rotation.y=.17*i,this.box(.17,.08,.09,a-.17,.84,n-.26,i%2?r:o),this.box(.12,.02,.055,a-.17,.889,n-.26,r);for(let o=0;o<=i;o++)this.box(.21,.018,.28,a-.45,.81+.022*o,n+.26,o%2?r:t).rotation.y=.12*e;this.cylinder(.045,.047,.22,a+.32,.9,n-.35,0===i?s:r),this.cylinder(.045,.045,.02,a+.32,1.02,n-.35,o),this.line([[a+.1,.8,n-.3],[a+.5,.7,n-.36],[a+.45,.15,n-.4]],.006,this.dark);let h=new L.Group;for(let e of(h.position.set(a,0,n),this.root.add(h),h.updateMatrixWorld(),this.root.children.slice(l,-1)))h.attach(e);if(h.rotation.y=-e*Math.PI/2,this.batch(h),1===i){let i=new L.PlaneGeometry(.55,.85,24,30),a=i.attributes.position;for(let e=0;e<a.count;e++)a.setZ(e,.025*Math.sin(30*a.getX(e))+.06*Math.sin(6*a.getY(e)));i.computeVertexNormals();let r=new L.Mesh(i,t);r.material.side=L.DoubleSide,r.position.set(-23.7+1.32*e,.75,n),r.rotation.y=Math.PI/2,r.castShadow=!0,this.root.add(r)}this.box(.16,.42,.36,a,.23,n+.44,this.dark);for(let e=0;e<3;e++)this.box(.21,.004,.28,a+.12,.81+.005*e,n+.22,r).rotation.y=.09*e}for(let e of(m(-21.3,.8),m(-21.3,-1.02,this.dark,Math.PI),this.box(.06,2.7,2.7,-20.34,1.35,.6,n),[-.7,.6,1.9]))this.box(.34,2.7,.035,-20.5,1.35,e,h);for(let e of[.15,.68,1.21,1.74,2.27]){this.box(.42,.035,2.7,-20.53,e,.6,h);for(let t=0;t<4;t++)this.box(.27,.28+t%2*.08,.15,-20.52,e+.17,-.45+.28*t,t%2?o:a)}this.box(5.4,.04,.05,-23,2.7,5.3,this.dark),this.box(3.8,2.7,.025,-23.8,1.35,5.3,this.glass);let p=new L.MeshStandardMaterial({color:0xd3d7d3,transparent:!0,opacity:.74,roughness:1});this.box(3.8,1.65,.03,-23.8,.88,5.29,p);for(let e=-25.4;e<-22;e+=.26)this.box(.07,.07,.008,e,1.82,5.32,r);this.box(.065,2.7,.08,-21.9,1.35,5.3,this.dark);let f=new L.Group;f.position.set(-20.3,0,5.3),f.rotation.y=-1.18,this.root.add(f),this.box(1.4,2.6,.055,-.7,1.3,0,this.wood,f),this.box(.16,.025,.06,-1.22,1.05,.06,this.dark,f),this.box(.38,.63,.3,-20.65,.32,4.4,r,this.root,.06),this.cylinder(.11,.11,.025,-20.65,.42,4.57,this.dark).rotation.x=Math.PI/2;let g=this.root.children.length,v=this.roof.children.length;this.box(11,3.5,.15,-5,1.75,-5.55,this.wood);for(let e=-10.4;e<.4;e+=.1)this.box(.035,3.4,.045,e,1.75,-5.44,this.wood);for(let e of[-8,-2])for(let t of[-2.8,1,4])this.box(3.6,.15,2,e,3.35,t,r,this.roof,.2),this.cylinder(.07,.07,.22,e,3.14,t,this.ceramic,this.roof),this.area([e,3.1,t],[e,0,t],2,1.2,4,0xffe0b7);for(let e of(this.box(10.7,.04,.055,-5,3.25,-5.42,this.led),[-9.6,0]))this.cylinder(.32,.32,3.7,e,1.85,1,r);for(let e of(this.box(.62,1.8,.6,-9.2,.9,-5,r),this.box(.53,.65,.025,-9.2,1.15,-4.69,this.dark),[-9.33,-9.07]))this.cylinder(.025,.025,.09,e,1.18,-4.65,h);for(let e of(this.box(.44,.045,.16,-9.2,.9,-4.62,this.dark),[-8.1,-6.95])){this.box(.94,1.94,.7,e,.97,-5,e<-7.5?r:this.dark,this.root,.04),this.box(.79,1.6,.04,e,.96,-4.635,n),this.box(.028,.5,.045,e+.35,1.04,-4.59,h);for(let t=.35;t<1.7;t+=.32){this.box(.74,.018,.025,e,t-.1,-4.59,h);for(let i=0;i<5;i++)this.cylinder(.035,.035,.16,e-.28+.14*i,t,-4.61,i%2?o:s)}}for(let e of(this.box(4.9,1.2,.25,-3.5,1.65,-5.28,this.dark),this.box(4.9,.035,.03,-3.5,2.23,-5.12,this.led),this.box(4.9,.06,.55,-3.5,1.07,-5.05,this.wood),[-8,-2]))for(let t of(this.box(.035,.05,9,e,3.6,-.4,this.dark,this.roof),[-4,-.5,3.4]))this.cylinder(.06,.06,.16,e,3.49,t,this.dark,this.roof);this.cylinder(.18,.18,10.2,-5,3.48,-4.2,h,this.roof).rotation.z=Math.PI/2,this.box(7,.025,3.5,-5.1,.018,-1.8,this.dark),this.box(6.92,.008,3.42,-5.1,.034,-1.8,a);let b=new L.Shape;b.moveTo(-1.31,-.64),b.lineTo(1.31,-.64),b.absarc(1.31,0,.64,-Math.PI/2,Math.PI/2,!1),b.lineTo(-1.31,.64),b.absarc(-1.31,0,.64,Math.PI/2,1.5*Math.PI,!1);let w=new L.Mesh(new L.ExtrudeGeometry(b,{depth:.055,bevelEnabled:!0,bevelThickness:.009,bevelSize:.009,bevelSegments:2,steps:1,curveSegments:64}),this.wood);for(let e of(w.rotation.x=-Math.PI/2,w.position.set(-5.2,.74,-1.8),w.castShadow=w.receiveShadow=!0,this.root.add(w),this.surfaces.push(w),[-6.5,-3.9]))this.box(.08,.73,.62,e,.365,-1.8,this.dark).rotation.z=e<-5?-.15:.15,this.box(.14,.01,.075,e,.805,-1.8,this.metal);for(let e=0;e<3;e++)m(-6.3+1.1*e,-2.9,e%2?s:t,Math.PI,!1);for(let e of(this.box(2.9,.14,.46,-5.2,.47,-.75,t,this.root,.06),[-6.35,-4.05]))this.box(.035,.41,.32,e,.205,-.75,this.dark);this.cylinder(.085,.11,.17,-3.7,.89,-1.8,o),this.line([[-3.79,.96,-1.8],[-3.7,1.11,-1.8],[-3.61,.96,-1.8]],.009,this.dark),this.sofa(-7.4,0,2.5,3.8,t),this.sofa(-4.9,0,2.5,1.3,o),this.surfaces.push(this.cylinder(.65,.65,.055,-6.5,.46,3.9,this.dark)),this.cylinder(.15,.3,.42,-6.5,.21,3.9,this.dark),this.cylinder(.42,.42,.4,-4.8,.2,4.3,s),this.cylinder(.38,.38,.37,-8,.19,4.5,o);let y=r.clone();y.side=L.DoubleSide;let x=o.clone();for(let[e,t]of(x.onBeforeCompile=o.onBeforeCompile,x.customProgramCacheKey=o.customProgramCacheKey,x.side=L.DoubleSide,[[1,y],[.97,x]])){let i=new L.PlaneGeometry(1.35*Math.PI,1,48,36),a=i.attributes.position;for(let e=0;e<a.count;e++){let t=a.getX(e),i=a.getY(e)+.5,r=.33+.23*Math.pow(1.75*Math.abs(i-.42),.7)+.1*Math.sin(i*Math.PI);a.setXYZ(e,Math.sin(t)*r,1.26*i-.3*i**3*(Math.abs(t)/(.675*Math.PI))**2,-Math.cos(t)*(.35+.07*i)-.12*i)}i.computeVertexNormals();let r=new L.Mesh(i,t);r.position.set(-1.8,.43,1),r.scale.set(e,e,e),r.castShadow=r.receiveShadow=!0,this.root.add(r)}for(let e of(this.box(.78,.18,.68,-1.8,.55,1.08,o,this.root,.14),this.box(.72,.64,.2,-1.8,1.03,.66,o,this.root,.18).rotation.x=-.14,[-.4,.4]))this.box(.14,.18,.48,-1.8+e,.7,1.06,o,this.root,.1).rotation.z=-(.45*e);for(let e of[-1,1])for(let t of[-1,1])this.line([[-1.8+.2*e,.5,1+.18*t],[-1.8+.33*e,.04,1+.32*t]],.023,this.dark);for(let t of(this.table(-1.9,.6,-.65,1.2,.55),this.box(.55,.08,.4,-1.9,.68,-.65,this.dark),this.cylinder(.17,.17,.013,-1.9,.73,-.65,this.dark),this.box(1.3,.76,.06,-.1,1.2,-2.8,this.dark),this.box(.05,.9,.05,-.1,.45,-2.8,this.metal),[-3,-1.2]))for(let i of(this.box(1.3,1.6,.25,t,.8,5,e,this.root,.13),this.box(1.05,.3,.8,t,.5,4.5,s,this.root,.12),[-.6,.6]))this.box(.15,1.5,.9,t+i,.8,4.6,e,this.root,.1);this.plant(-9,0,4.6,.65),this.plant(-.4,0,-4.8,.65);let M=new L.Group;M.add(...this.root.children.slice(g)),M.position.x=-7,this.root.add(M);let S=new L.Group;S.add(...this.roof.children.slice(v)),S.position.x=-7,this.roof.add(S),this.box(8,3.7,.1,-17,1.85,7.8,this.wood),this.box(7,.12,3.2,-17,3.35,10,r,this.roof,.12),this.area([-17,3.2,11],[-17,0,9],5,2,4,0xffe8d1);for(let i=0;i<3;i++){let a=-18+1.5*i;for(let t of(this.platform(1.3,1.4,a,.06,8.7,e),this.box(1.3,2.25,.14,a,1.18,8.7-.7,r,this.root,.1),[-.6,.6]))this.box(.12,2.3,1.5,a+t,1.2,8.7,r,this.root,.08);for(let e of(this.box(1.3,.15,1.5,a,2.35,8.7,r,this.root,.06),this.box(1.02,2.05,.025,a,1.18,8.7-.615,t),[-.525,.525]))this.box(.025,2.05,1.24,a+e,1.18,8.7,t),this.box(.025,.025,1.1,a+e,2.25,8.7,this.led);for(let e of(this.box(1.04,.025,.045,a,2.25,9.25,this.led),this.surfaces.push(this.box(.38,.05,1,a-.32,1.05,8.7,r,this.root,.025)),[-.32,.32]))this.cylinder(.028,.028,.008,a-.38,1.079,8.7+e,this.dark);for(let e=0;e<9;e++)this.box(.025,.06,.012,a-.2+.05*e,2.36,8.7+.758,this.dark);this.cylinder(.2,.2,.075,a,.7,8.7,t),this.cylinder(.028,.028,.59,a,.37,8.7,this.metal),this.cylinder(.24,.24,.035,a,.09,8.7,this.metal),this.box(.045,.25,.34,a+.18,.89,8.7,t,this.root,.045);let o=new L.Mesh(new L.TorusGeometry(.17,.013,8,32),h);o.rotation.x=Math.PI/2,o.position.set(a,.33,8.7),this.root.add(o);let s=new L.Group;for(let e of(s.position.set(a-.52,0,9.42),s.rotation.y=2===i?-1:0,this.root.add(s),this.box(1.04,2.1,.02,.52,1.2,0,this.glass,s),this.box(.15,.025,.035,.85,1.15,.06,h,s),[.4,1.95]))this.box(.065,.09,.04,.04,e,.02,h,s);this.box(.22,.055,.055,.23,2.19,.025,h,s),this.area([a,2.2,8.7],[a,0,8.7],.9,.9,2===i?6:1,0xf1f0e7)}}configureCityFacade(e,t){e.onBeforeCompile=e=>{e.vertexShader="varying vec3 vFacadePosition; varying vec3 vFacadeNormal;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\nvFacadePosition = (modelMatrix * vec4(position, 1.0)).xyz; vFacadeNormal = abs(mat3(modelMatrix) * normal);"),e.fragmentShader="varying vec3 vFacadePosition; varying vec3 vFacadeNormal;\n"+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <map_fragment>",`#include <map_fragment>
        vec2 facadeUv = vec2(vFacadeNormal.x > vFacadeNormal.z ? vFacadePosition.z : vFacadePosition.x, vFacadePosition.y) / vec2(${t%2?"2.4, 3.5":"1.5, 3.2"});
        vec2 cell = fract(facadeUv), edge = max(fwidth(facadeUv), vec2(0.006));
        vec2 margin = vec2(${t%2?"0.2, 0.16":"0.035, 0.09"});
        vec2 opening = smoothstep(margin, margin + edge, cell) * (1.0 - smoothstep(1.0 - margin - edge, 1.0 - margin, cell));
        float windowMask = opening.x * opening.y * (1.0 - step(0.5, vFacadeNormal.y));
        float suite = fract(sin(dot(floor(facadeUv), vec2(127.1,311.7))) * 43758.5453);
        float occupied = step(${"cyberpunk"===this.style?"0.58":"0.84"}, suite);
        diffuseColor.rgb = mix(diffuseColor.rgb * 0.8, vec3(0.11, 0.16, 0.19) * (0.7 + suite * 0.5), windowMask);
      `),e.fragmentShader=e.fragmentShader.replace("#include <roughnessmap_fragment>","#include <roughnessmap_fragment>\nroughnessFactor = mix(0.78, 0.2, windowMask);"),e.fragmentShader=e.fragmentShader.replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
totalEmissiveRadiance += vec3(${t%2?"0.8, 0.53, 0.29":"0.5, 0.64, 0.75"}) * windowMask * occupied * (0.1 + suite * 0.3);`)},e.customProgramCacheKey=()=>"space-city-facade-"+t+this.style}landscape(){if("shanghai"===this.environment)return;let e="island"===this.environment;if(e&&this.root.add(function(){let e=new L.Group;e.name="island",e.userData.spaceBackdrop=!0;let t=new L.PlaneGeometry(270,240,200,180);t.rotateX(-Math.PI/2);let i=t.attributes.position;for(let e=0;e<i.count;e++)i.setY(e,iP(i.getX(e),i.getZ(e)));t.computeVertexNormals();let a=new L.MeshStandardMaterial({roughness:.88});iD(a);let r=new L.Mesh(t,a);r.receiveShadow=!0,e.add(r);let o=new L.InstancedMesh(new L.IcosahedronGeometry(1,2),new L.MeshStandardMaterial({color:7630688,roughness:.82}),54),s=new L.Object3D;for(let e=0;e<o.count;e++){let t=1.39*Math.floor(e/9)+.105*Math.sin(2.39*e),i=.86+e%7*.021,a=-6+79*Math.cos(t)*i,r=3+65*Math.sin(t)*i;s.position.set(a,iP(a,r)+.15,r),s.rotation.set(.73*e,1.19*e,.31*e),s.scale.set(1.2+e%3*.55,.5+e%5*.27,.9+e%4*.42),s.updateMatrix(),o.setMatrixAt(e,s.matrix)}return o.castShadow=o.receiveShadow=!0,e.add(o),e}()),"company"!==this.style)if(e||"penthouse"!==this.style&&"cyberpunk"!==this.style){for(let[e,t,i]of[[-39,-20,2.7],[-28,-30,3.2],[-12,-28,2.5],[6,-27,3],[25,-26,2.6],[39,3,2.8],[-41,14,3],[-31,31,2.4]])this.tree(e,-.6,t,i);if(!e){let e=new L.MeshStandardMaterial({color:5398600,roughness:1,vertexColors:!0}),t=new L.PlaneGeometry(800,800,96,96);t.rotateX(-Math.PI/2);let i=t.getAttribute("position"),a=new Float32Array(3*i.count),r=new L.Color;for(let e=0;e<i.count;e++){let t=i.getX(e),o=i.getZ(e),s=Math.min(1,Math.max(0,(Math.hypot(t+9,o+3)-65)/100));i.setY(e,-.65+s*(13+11*Math.sin(t/43)*Math.cos(o/59)+5*Math.sin(t/17+o/31))),r.setHSL(.22,.15,.48+.08*Math.sin(.37*t)*Math.cos(.23*o)),r.toArray(a,3*e)}t.setAttribute("color",new L.BufferAttribute(a,3)),t.computeVertexNormals();let o=new L.Mesh(t,e);o.receiveShadow=!0,this.root.add(o)}for(let e=0;e<5;e++)for(let t=0;t<8;t++)this.box(4.95,.15,2.45,-26.5+5*t,-.42,14.5+2.5*e,this.stone,this.root,0);for(let e=0;e<3;e++)this.platform(8,.75,0,-.04-.12*e,13.4+.8*e,this.stone);for(let e of[-31.8,32.2]){this.box(2.2,.5,36,e,-.34,5,this.stone),this.box(1.9,.02,35.7,e,-.08,5,this.dark);for(let t=-11;t<23;t+=2.5)this.model("potted_plant_01",e+.3*Math.sin(t),-.7,t,2.1+(t+11)%3*.15,t,!0)}let t=[];for(let e=0;e<9;e++){let i=new L.PlaneGeometry(.018,.55,1,5),a=i.attributes.position;for(let t=0;t<a.count;t++){let i=a.getY(t)/.55+.5;a.setXYZ(t,a.getX(t)*(1-i),i*(.28+e%4*.06),i*i*(.16+e%3*.06))}i.rotateY(2.4*e),i.computeVertexNormals(),t.push(i)}let i=(0,tR.mergeGeometries)(t);t.forEach(e=>e.dispose());let a=new L.InstancedMesh(i,new L.MeshStandardMaterial({color:6187344,roughness:1,side:L.DoubleSide}),700),r=new L.Object3D;for(let e=0;e<700;e++)r.position.set(e%2?-33.8-e%17*.14:34.2+e%17*.14,-.62,-13+31*e%380*.1),r.rotation.set(0,2.4*e,0),r.scale.setScalar(.65+e%11*.075),r.updateMatrix(),a.setMatrixAt(e,r.matrix);a.castShadow=a.receiveShadow=!0,this.root.add(a)}else{let e=[5465977,9142644,4015694,8151634].map((e,t)=>{let i=new L.MeshStandardMaterial({color:e,metalness:t%2?.2:.7,roughness:.45});return this.configureCityFacade(i,t),i});this.box(60.5,119,42.5,0,-60,3,e[0],this.root,0);for(let e=-118;e<0;e+=3.2)this.box(60.8,.16,42.8,0,e,3,this.metal,this.root,0);for(let e=-28;e<11;e+=1.8)this.box(.07,118,.07,e,-60,12.1,this.metal);for(let t=-5;t<=5;t++)for(let i=-5;i<=5;i++){if(1>=Math.abs(t)&&1>=Math.abs(i))continue;let a=(t+5)*11+i+5,r=31*t-9,o=35*i,s=25+(43758.5453*Math.sin(127.1*a)%1+1)%1*112,n=13+a%8,l=16+a%9,h=e[a%4],c=a%3==0;this.box(n,s*(c?.72:1),l,r,-120+s*(c?.36:.5),o,h,this.root,0),c&&(this.box(.76*n,.28*s,.72*l,r,-120+.86*s,o,h,this.root,0),this.box(n+.5,.4,l+.5,r,-120+.72*s,o,this.metal,this.root,0)),a%5==0&&(this.box(.55*n,5,.55*l,r,-117.5+s,o,h,this.root,0),this.box(.3*n,4,.3*l,r,-113+s,o,h,this.root,0)),this.box(.36*n,1.8,.26*l,r,-119.1+s,o,this.dark,this.root,0),a%4==0&&(this.cylinder(1,1,2,r+3,-117.5+s,o-3,this.dark),this.cylinder(.08,.08,7,r,-115.5+s,o,this.metal)),this.box(n+3,.16,l+3,r,-119.9,o,this.stone,this.root,0)}this.box(600,.5,600,0,-120,0,this.dark,this.root,0);for(let e=-5;e<5;e++)this.box(.12,.01,390,31*e+6.5,-119.73,0,this.ceramic,this.root,0),this.box(355,.01,.12,-9,-119.73,35*e+17.5,this.ceramic,this.root,0);for(let e of[-18.1,13.1])this.box(43,1.15,.025,-9,.65,e,this.glass);for(let e of[-28,-20,-12,-4,4])this.box(3.8,.5,1.3,e,.18,11.6,this.stone),this.model("potted_plant_01",e,.12,11.6,1.9,e,!0)}}batch(e){let t=new Map;for(let i of[...e.children])if(i instanceof L.Mesh&&!(i instanceof L.InstancedMesh)&&"Reflector"!==i.type&&!this.surfaces.includes(i)&&!i.userData.spaceBackdrop&&!Array.isArray(i.material)&&!i.material.transparent){let e=t.get(i.material)??[];e.push(i),t.set(i.material,e)}for(let[i,a]of t){if(a.length<2)continue;let t=a.map(e=>{e.updateMatrix();let t=e.geometry.index?e.geometry.toNonIndexed():e.geometry.clone();return t.applyMatrix4(e.matrix),t}),r=(0,tR.mergeGeometries)(t);if(t.forEach(e=>e.dispose()),!r)continue;for(let e of a)e.removeFromParent(),e.geometry.dispose();let o=new L.Mesh(r,i);o.castShadow=!0,o.receiveShadow=!0,e.add(o)}}mirror(e,t,i,a=this.root){let r=t>=10||i[1]<.1,o=new tL(new L.PlaneGeometry(e,t),{color:r?this.palette.mirror:0xffffff,textureWidth:512,textureHeight:512,clipBias:.001,multisample:0}),s=o.material;s.uniforms.uTexel={value:new L.Vector2(1/1024,1/1024)},s.uniforms.uPolish={value:r?.58:.94},s.vertexShader=s.vertexShader.replace("varying vec4 vUv;","varying vec4 vUv; varying vec3 vMirrorWorld;").replace("vUv =","vMirrorWorld = (modelMatrix * vec4(position,1.0)).xyz; vUv ="),s.fragmentShader=s.fragmentShader.replace("varying vec4 vUv;","varying vec4 vUv; varying vec3 vMirrorWorld; uniform vec2 uTexel; uniform float uPolish;").replace("vec4 base = texture2DProj( tDiffuse, vUv );",`
        vec2 uv = vUv.xy / vUv.w;
        vec2 stepUv = uTexel * ${r?"1.25":"0.45"};
        vec4 base = texture2D(tDiffuse,uv) * 0.5;
        base += (texture2D(tDiffuse,uv+vec2(stepUv.x,0)) + texture2D(tDiffuse,uv-vec2(stepUv.x,0)) + texture2D(tDiffuse,uv+vec2(0,stepUv.y)) + texture2D(tDiffuse,uv-vec2(0,stepUv.y))) * 0.125;
      `).replace("vec4( blendOverlay( base.rgb, color ), 1.0 )",r?"vec4(mix(color * (0.45 + 0.08 * sin(vMirrorWorld.x * 1.6 + sin(vMirrorWorld.z * 0.7) * 3.0)), base.rgb, uPolish + 0.25 * pow(1.0 - abs(normalize(cameraPosition-vMirrorWorld).y), 3.0)), 1.0)":"vec4(mix(color * 0.28, base.rgb, uPolish), 1.0)"),o.position.set(...i);let n=o.onBeforeRender;return o.onBeforeRender=(...e)=>{let t=[...this.mirrors,...this.helpers],i=t.map(e=>e.visible);t.forEach(e=>{e.visible=!1});try{n.apply(o,e)}finally{t.forEach((e,t)=>{e.visible=i[t]})}},tF(o),a.add(o),this.mirrors.push(o),o}resize(e){let t=e<600?384:768;for(let e of this.mirrors)e.getRenderTarget().setSize(t,t),e.material.uniforms.uTexel.value.set(1/t,1/t)}update(e,t){let i=576>e.position.distanceToSquared(new L.Vector3(21,1,-10));if("company"!==this.style&&!this.carsLoaded&&i)for(let e of(this.carsLoaded=!0,[16.3,25.5]))this.model("car-concept",e,.04,-10,1.35,0);this.root.traverse(e=>{e.name.startsWith("car-concept")&&(e.visible=i||t)});let a=[...this.lights].sort((t,i)=>i.intensity*i.width*i.height/(4+i.position.distanceToSquared(e.position))-t.intensity*t.width*t.height/(4+t.position.distanceToSquared(e.position))).slice(0,this.lightSlots.length);for(let i of(this.lightSlots.forEach((e,t)=>{let i=a[t];i?(e.copy(i),e.intensity=i.intensity):e.intensity=0}),this.roof.visible=!t,this.back.visible=!0,this.mirrors)){let t=i.getWorldPosition(new L.Vector3),a=e.position.distanceTo(t);i.visible="company"===this.style?i!==this.floor&&a<14:i===this.floor?a<85:t.y>5?a<23:a<85}this.glass.opacity=t?.035:.075}dispose(){this.disposed=!0,this.textures.forEach(e=>e.dispose()),this.root.removeFromParent();let e=new Set,t=new Set;for(let i of(this.root.traverse(i=>{if(i instanceof L.InstancedMesh&&i.dispose(),i instanceof L.Mesh||i instanceof L.LineSegments)for(let a of(e.add(i.geometry),Array.isArray(i.material)?i.material:[i.material]))t.add(a)}),this.mirrors)){for(let e of Array.isArray(i.material)?i.material:[i.material])t.delete(e);i.dispose()}e.forEach(e=>e.dispose()),t.forEach(e=>{for(let t of Object.values(e))t instanceof L.Texture&&t.dispose();e.dispose()})}}var iE=e.i(692212),iF=e.i(154303),iI=e.i(761438),iU=e.i(590831),iN=e.i(685701),iB=e.i(424776),iV=e.i(501958),iO=e.i(233118),iG=e.i(179780),ij=e.i(433627);let iH=e=>e instanceof ta.default?e.busy:e.twister.busy;function iW(e,t,i=!1){if(iH(e))return!1;if(e instanceof ta.default)return e.twister.twist(new iI.TwistAction(t),i,!1);if(e instanceof tn.default){let a=(0,tu.parseSq1Scramble)(t)[0];return!!a&&e.twister.twist(a,i,!1)}if(e instanceof tl.default){let a=(0,iU.parsePyraMoves)(t)[0];return!!a&&e.twister.twist(a,i,!1)}if(e instanceof th.default){let a=(0,iN.parseMegaMoves)(t)[0];return!!a&&e.twister.twist(a,i,!1)}let a=(0,iB.parseSkewbMoves)(t)[0];return!!a&&e.twister.twist(a,i,!1)}let iq=`
float hash(vec3 p) { return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453); }
float noise(vec3 p) {
  vec3 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
  return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),
    mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);
}`,iX=new L.BufferGeometry;iX.setAttribute("position",new L.BufferAttribute(new Float32Array([-1,-1,0,3,-1,0,-1,3,0]),3)),iX.setAttribute("uv",new L.BufferAttribute(new Float32Array([0,0,2,0,0,2]),2)),iX.boundingSphere=new L.Sphere(new L.Vector3,4);let iK=new L.OrthographicCamera(-1,1,1,-1,0,1),iY=`
out vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4( position.xy, 0.0, 1.0 );
}`;class iZ{constructor(e,t={},i={}){this.material=new L.RawShaderMaterial({name:i.name||"FullScreenPass",glslVersion:L.GLSL3,vertexShader:`precision highp float;
precision highp int;
in vec3 position;
in vec2 uv;
${iY}`,fragmentShader:`precision highp float;
precision highp int;
precision highp sampler2D;
precision highp sampler3D;
precision highp sampler2DArray;
${e}`,uniforms:t,defines:i.defines||{},depthTest:!1,depthWrite:!1,blending:void 0!==i.blending?i.blending:L.NoBlending,transparent:void 0!==i.blending&&i.blending!==L.NoBlending}),this.mesh=new L.Mesh(iX.clone(),this.material),this.mesh.frustumCulled=!1,this.scene=new L.Scene,this.scene.add(this.mesh)}get uniforms(){return this.material.uniforms}set(e,t){let i=this.material.uniforms[e];return i&&(i.value=t),this}define(e,t){return this.material.defines[e]!==t&&(this.material.defines[e]=t,this.material.needsUpdate=!0),this}render(e,t=null,i=!1){let a=e.getRenderTarget(),r=e.autoClear;e.autoClear=i,e.setRenderTarget(t),e.render(this.scene,iK),e.setRenderTarget(a),e.autoClear=r}dispose(){this.material.dispose(),this.mesh.geometry.dispose()}}function i$(e,t,i={}){let a=new L.WebGLRenderTarget(Math.max(1,0|e),Math.max(1,0|t),{type:i.type||L.HalfFloatType,format:i.format||L.RGBAFormat,minFilter:i.minFilter||L.LinearFilter,magFilter:i.magFilter||L.LinearFilter,wrapS:i.wrap||L.ClampToEdgeWrapping,wrapT:i.wrap||L.ClampToEdgeWrapping,depthBuffer:!!i.depthBuffer,stencilBuffer:!1,generateMipmaps:!!i.mipmaps,count:i.count||1});if(a.texture.name=i.name||"rt",i.anisotropy&&(a.texture.anisotropy=i.anisotropy),i.count>1)for(let e=0;e<i.count;e++)a.textures[e].name=`${i.name||"rt"}[${e}]`,a.textures[e].minFilter=i.minFilter||L.LinearFilter,a.textures[e].magFilter=i.magFilter||L.LinearFilter,a.textures[e].wrapS=i.wrap||L.ClampToEdgeWrapping,a.textures[e].wrapT=i.wrap||L.ClampToEdgeWrapping,a.textures[e].generateMipmaps=!!i.mipmaps,i.anisotropy&&(a.textures[e].anisotropy=i.anisotropy);return a}class iQ{constructor(e,t,i={}){this.a=i$(e,t,{...i,name:(i.name||"pp")+"A"}),this.b=i$(e,t,{...i,name:(i.name||"pp")+"B"})}swap(){let e=this.a;this.a=this.b,this.b=e}get read(){return this.a}get write(){return this.b}setSize(e,t){this.a.setSize(e,t),this.b.setSize(e,t)}dispose(){this.a.dispose(),this.b.dispose()}}let iJ=`
#ifndef NOISE_GLSL
#define NOISE_GLSL 1

float hash11(float p){ p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash12(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float hash13(vec3 p3){ p3 = fract(p3 * 0.1031); p3 += dot(p3, p3.zyx + 31.32); return fract((p3.x + p3.y) * p3.z); }
vec2 hash22(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973)); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.xx + p3.yz) * p3.zy); }
vec3 hash33(vec3 p3){ p3 = fract(p3 * vec3(0.1031, 0.1030, 0.0973)); p3 += dot(p3, p3.yxz + 33.33); return fract((p3.xxy + p3.yxx) * p3.zyx); }
vec3 hash32(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973)); p3 += dot(p3, p3.yxz + 33.33); return fract((p3.xxy + p3.yzz) * p3.zyx); }

// ------------------------------------------------------------- value noise
float vnoise2(vec2 x){
  vec2 i = floor(x), f = fract(x);
  vec2 u = f * f * (3.0 - 2.0 * f);
  float a = hash12(i), b = hash12(i + vec2(1,0)), c = hash12(i + vec2(0,1)), d = hash12(i + vec2(1,1));
  return mix(mix(a,b,u.x), mix(c,d,u.x), u.y);
}
float vnoise3(vec3 x){
  vec3 i = floor(x), f = fract(x);
  vec3 u = f * f * (3.0 - 2.0 * f);
  float n000 = hash13(i + vec3(0,0,0)), n100 = hash13(i + vec3(1,0,0));
  float n010 = hash13(i + vec3(0,1,0)), n110 = hash13(i + vec3(1,1,0));
  float n001 = hash13(i + vec3(0,0,1)), n101 = hash13(i + vec3(1,0,1));
  float n011 = hash13(i + vec3(0,1,1)), n111 = hash13(i + vec3(1,1,1));
  return mix(mix(mix(n000,n100,u.x), mix(n010,n110,u.x), u.y),
             mix(mix(n001,n101,u.x), mix(n011,n111,u.x), u.y), u.z);
}

// ----------------------------------------------------- tileable perlin 3D
vec3 tileHash33(vec3 p, float period){
  p = mod(p, vec3(period));
  return normalize(hash33(p) * 2.0 - 1.0);
}
float perlin3Tiled(vec3 x, float period){
  vec3 i = floor(x), f = fract(x);
  vec3 u = f*f*f*(f*(f*6.0-15.0)+10.0);
  float n = 0.0;
  for (int dz = 0; dz <= 1; dz++)
  for (int dy = 0; dy <= 1; dy++)
  for (int dx = 0; dx <= 1; dx++) {
    vec3 o = vec3(float(dx), float(dy), float(dz));
    vec3 g = tileHash33(i + o, period);
    float w = mix(1.0-u.x, u.x, o.x) * mix(1.0-u.y, u.y, o.y) * mix(1.0-u.z, u.z, o.z);
    n += w * dot(g, f - o);
  }
  return n;
}
float perlinFbm3(vec3 p, float period, int octaves){
  float f = 0.0, amp = 0.5, per = period;
  for (int i = 0; i < 8; i++) {
    if (i >= octaves) break;
    f += amp * perlin3Tiled(p, per);
    p *= 2.0; per *= 2.0; amp *= 0.5;
  }
  return f;
}

// ------------------------------------------------------ tileable worley 3D
float worley3Tiled(vec3 p, float cells){
  p *= cells;
  vec3 i = floor(p), f = fract(p);
  float minDist = 1e9;
  for (int z = -1; z <= 1; z++)
  for (int y = -1; y <= 1; y++)
  for (int x = -1; x <= 1; x++) {
    vec3 o = vec3(float(x), float(y), float(z));
    vec3 cell = mod(i + o, vec3(cells));
    vec3 pt = o + hash33(cell);
    minDist = min(minDist, dot(pt - f, pt - f));
  }
  return clamp(sqrt(minDist), 0.0, 1.0);
}
float worleyFbm3(vec3 p, float cells){
  return worley3Tiled(p, cells) * 0.625
       + worley3Tiled(p, cells * 2.0) * 0.25
       + worley3Tiled(p, cells * 4.0) * 0.125;
}

// -------------------------------------------------------- tileable worley 2D
float worley2Tiled(vec2 p, float cells){
  p *= cells;
  vec2 i = floor(p), f = fract(p);
  float minDist = 1e9;
  for (int y = -1; y <= 1; y++)
  for (int x = -1; x <= 1; x++) {
    vec2 o = vec2(float(x), float(y));
    vec2 cell = mod(i + o, vec2(cells));
    vec2 pt = o + hash22(cell);
    minDist = min(minDist, dot(pt - f, pt - f));
  }
  return clamp(sqrt(minDist), 0.0, 1.0);
}
float vnoise2Tiled(vec2 x, float period){
  vec2 i = floor(x), f = fract(x);
  vec2 u = f*f*(3.0-2.0*f);
  float a = hash12(mod(i, period));
  float b = hash12(mod(i + vec2(1,0), period));
  float c = hash12(mod(i + vec2(0,1), period));
  float d = hash12(mod(i + vec2(1,1), period));
  return mix(mix(a,b,u.x), mix(c,d,u.x), u.y);
}
float fbm2Tiled(vec2 p, float period, int octaves){
  float f = 0.0, amp = 0.5, per = period;
  for (int i = 0; i < 8; i++) {
    if (i >= octaves) break;
    f += amp * vnoise2Tiled(p * per / period, per);
    per *= 2.0; amp *= 0.5;
  }
  return f;
}

// Interleaved gradient noise — cheap per-pixel dithering
float ign(vec2 p){ return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }

// Ordered 4x4 dither. Every 4x4 tile carries the sixteen values of [0,1) once,
// so averaging a tile is a stratified estimate rather than a random one.
float bayer4(vec2 p){
  ivec2 i = ivec2(mod(floor(p), 4.0));
  int b = ((i.x & 1) << 3) | ((i.y & 1) << 2) | (i.x & 2) | ((i.y & 2) >> 1);
  return (float(b) + 0.5) / 16.0;
}
float ignTemporal(vec2 p, float frame){
  p += 5.588238 * fract(frame * 0.6180339887);
  return ign(p);
}

#endif
`,i0=`
${iJ}
in vec2 vUv;
layout(location = 0) out vec4 oCol;
void main(){
  vec2 p = vUv;
  // clustered bubble rafts
  float w1 = 1.0 - worley2Tiled(p, 6.0);
  float w2 = 1.0 - worley2Tiled(p, 14.0);
  float w3 = 1.0 - worley2Tiled(p, 32.0);
  float w4 = 1.0 - worley2Tiled(p, 72.0);

  float clusters = clamp(w1 * 0.55 + w2 * 0.3 + w3 * 0.18, 0.0, 1.0);
  clusters = pow(clusters, 1.35);

  float bubbles = clamp(w3 * 0.5 + w4 * 0.7, 0.0, 1.0);
  bubbles = smoothstep(0.32, 0.92, bubbles);

  // fbm2Tiled takes lattice coordinates, unlike worley2Tiled's unit UVs.
  // Cover whole periods on each texture axis so RepeatWrapping has no seam.
  float fbm = fbm2Tiled(p * 8.0, 8.0, 6);
  float streak = fbm2Tiled(p * vec2(8.0, 24.0), 8.0, 5);

  // dissolve mask drives foam erosion over time
  float dissolve = clamp(fbm * 0.6 + w2 * 0.4, 0.0, 1.0);

  oCol = vec4(clusters, bubbles, clamp(fbm * 1.15, 0.0, 1.0), dissolve * 0.75 + streak * 0.25);
}
`,i1=`
${iJ}
uniform float uRes;
uniform float uSlope;
in vec2 vUv;
layout(location = 0) out vec4 oCol;
float h(vec2 p){
  float a = fbm2Tiled(p * 11.0, 11.0, 5);
  float b = fbm2Tiled((p + vec2(3.71, 1.29)) * 26.0, 26.0, 4);
  // A trace of cellular structure for the dimpled look of a wind-ruffled
  // surface, rounded off hard so it contributes shape and not creases.
  float c = smoothstep(0.10, 0.95, 1.0 - worley2Tiled(p, 30.0));
  return a * 0.56 + b * 0.30 + c * 0.14;
}
void main(){
  vec2 p = vUv;
  float e = 1.5 / uRes;
  float gx = (h(p + vec2(e, 0.0)) - h(p - vec2(e, 0.0))) / (2.0 * e);
  float gy = (h(p + vec2(0.0, e)) - h(p - vec2(0.0, e))) / (2.0 * e);
  vec3 n = normalize(vec3(-gx * uSlope, 1.0, -gy * uSlope));
  oCol = vec4(n * 0.5 + 0.5, h(p));
}
`,i2=`
${iJ}
uniform float uRes;
uniform float uTilesX;
in vec2 vUv;
layout(location = 0) out vec4 oCol;
void main(){
  vec2 px = floor(vUv * vec2(uRes * uTilesX, uRes * uRes / uTilesX));
  float tileX = floor(px.x / uRes);
  float tileY = floor(px.y / uRes);
  float z = tileX + tileY * uTilesX;
  vec3 uvw = vec3((mod(px.x, uRes) + 0.5) / uRes, (mod(px.y, uRes) + 0.5) / uRes, (z + 0.5) / uRes);

  // Five octaves from 4 tops out at frequency 64, which is Nyquist for a 128^3
  // volume. Seven ran to 256: the last two octaves alias into per-texel grit,
  // and once the coverage threshold slices that field the grit becomes
  // single-voxel blobs — a sky of little cubes no erosion pass can smooth.
  float freq = 4.0;
  float perlin = clamp(perlinFbm3(uvw * freq, freq, 5) * 0.5 + 0.5, 0.0, 1.0);

  // billowy worley octaves (inverted so high == dense)
  float w0 = 1.0 - worleyFbm3(uvw, 4.0);
  float w1 = 1.0 - worleyFbm3(uvw, 8.0);
  float w2 = 1.0 - worleyFbm3(uvw, 14.0);
  float w3 = 1.0 - worleyFbm3(uvw, 22.0);

  // Schneider's perlin-worley: dilate the perlin field by the low worley so the
  // result keeps perlin's connectedness with worley's cauliflower edges.
  float perlinWorley = w0 + perlin * (1.0 - w0);

  oCol = vec4(clamp(perlinWorley, 0.0, 1.0), w1, w2, w3);
}
`,i9=`
${iJ}
uniform float uRes;
uniform float uTilesX;
in vec2 vUv;
layout(location = 0) out vec4 oCol;
void main(){
  vec2 px = floor(vUv * vec2(uRes * uTilesX, uRes * uRes / uTilesX));
  float tileX = floor(px.x / uRes);
  float tileY = floor(px.y / uRes);
  float z = tileX + tileY * uTilesX;
  vec3 uvw = vec3((mod(px.x, uRes) + 0.5) / uRes, (mod(px.y, uRes) + 0.5) / uRes, (z + 0.5) / uRes);
  float w0 = 1.0 - worleyFbm3(uvw, 3.0);
  float w1 = 1.0 - worleyFbm3(uvw, 6.0);
  float w2 = 1.0 - worleyFbm3(uvw, 11.0);
  oCol = vec4(w0, w1, w2, (w0 + w1 + w2) / 3.0);
}
`,i3=`
${iJ}
in vec2 vUv;
layout(location = 0) out vec4 oCol;

void main(){
  vec2 p = vUv;

  // Synoptic scale: broad fronts and clear lanes. Ridged noise gives the long
  // filamentary bands a satellite image actually shows, rather than the
  // isotropic blobs a plain fbm produces. The ridge is smoothed because a bare
  // absolute value has a crease along its zero set, and a crease in coverage
  // becomes a dead-straight edge to the cloud deck kilometres long.
  float f1 = fbm2Tiled(p * 4.0, 4.0, 5);
  float f2 = fbm2Tiled((p + vec2(3.7, 1.3)) * 6.0, 6.0, 5);
  float r = f2 * 2.0 - 1.0;
  float band = 1.0 - sqrt(r * r + 0.035);
  float synoptic = clamp(f1 * 0.62 + band * 0.55 - 0.10, 0.0, 1.0);

  // Mesoscale cells inside a system, with worley to give them discrete edges.
  float cells = 1.0 - worley2Tiled(p + vec2(0.41, 0.77), 9.0);
  float meso = clamp(fbm2Tiled((p + vec2(9.1, 4.4)) * 11.0, 11.0, 4) * 0.7 + cells * 0.5, 0.0, 1.0);

  // Type: the deepest, most persistent parts of a system grow towers.
  float type = clamp(smoothstep(0.42, 0.86, synoptic) * 0.8
                   + fbm2Tiled((p + vec2(6.3, 2.9)) * 7.0, 7.0, 3) * 0.5, 0.0, 1.0);

  // Convective cores: sparse, small, and only inside an active region.
  float core = smoothstep(0.55, 0.95, 1.0 - worley2Tiled(p + vec2(2.2, 8.8), 14.0));
  core *= smoothstep(0.35, 0.8, synoptic);

  oCol = vec4(synoptic, meso, type, core);
}
`,i5=`
${iJ}
in vec2 vUv;
layout(location = 0) out vec4 oCol;
void main(){
  float e = 1.0 / 256.0;
  float n1 = fbm2Tiled((vUv + vec2(0.0, e)) * 6.0, 6.0, 4);
  float n2 = fbm2Tiled((vUv - vec2(0.0, e)) * 6.0, 6.0, 4);
  float n3 = fbm2Tiled((vUv + vec2(e, 0.0)) * 6.0, 6.0, 4);
  float n4 = fbm2Tiled((vUv - vec2(e, 0.0)) * 6.0, 6.0, 4);
  vec2 curl = vec2(n1 - n2, n4 - n3) / (2.0 * e);
  curl = normalize(curl + 1e-6) * 0.5 + 0.5;
  oCol = vec4(curl, fbm2Tiled(vUv * 12.0, 12.0, 5), fbm2Tiled(vUv * 3.0, 3.0, 4));
}
`;function i4(e,t,i,a,r={},o=!1){let s=i$(i,a,{type:L.UnsignedByteType,wrap:L.RepeatWrapping,name:"bake",mipmaps:o,minFilter:o?L.LinearMipmapLinearFilter:L.LinearFilter,anisotropy:o?Math.min(8,e.capabilities.getMaxAnisotropy()):1}),n=new iZ(t,r,{name:"bake"});return n.render(e,s),n.dispose(),s}function i8(e,t,i,a,r){let o=i*a,s=i*r,n=new Uint8Array(o*s*4);e.readRenderTargetPixels(t,0,0,o,s,n);let l=function(e,t,i=.02){let a=[],r=[];for(let o=0;o<4;o++){let s=new Uint32Array(256);for(let i=0;i<t;i++)s[e[4*i+o]]++;let n=0,l=0,h=255;for(let e=0;e<256;e++)if((n+=s[e])>=t*i){l=e;break}n=0;for(let e=255;e>=0;e--)if((n+=s[e])>=t*i){h=e;break}h<=l&&(h=Math.min(255,l+1)),a.push(l/255),r.push(h/255)}return{lo:a,hi:r}}(n,o*s),h=new Uint8Array(i*i*i*4);for(let e=0;e<i;e++){let t=e%a,r=Math.floor(e/a);for(let a=0;a<i;a++){let s=((r*i+a)*o+t*i)*4,l=(e*i+a)*i*4;h.set(n.subarray(s,s+4*i),l)}}let c=new L.Data3DTexture(h,i,i,i);return c.format=L.RGBAFormat,c.type=L.UnsignedByteType,c.minFilter=L.LinearFilter,c.magFilter=L.LinearFilter,c.wrapS=c.wrapT=c.wrapR=L.RepeatWrapping,c.unpackAlignment=1,c.needsUpdate=!0,c.userData.percentiles=l,c}async function i6(e,t=()=>{},i){let a={};try{let r=()=>new Promise(e=>setTimeout(e,0));t("baking curl turbulence field"),await r(),i?.throwIfAborted();let o=i4(e,i5,256,256);o.texture.wrapS=o.texture.wrapT=L.RepeatWrapping,a.curl=o.texture,a._curlRT=o,t("baking synoptic weather map"),await r(),i?.throwIfAborted();let s=i4(e,i3,1024,1024,{},!0);a.weather=s.texture,a._weatherRT=s,t("baking volumetric cloud shape (128³)"),await r(),i?.throwIfAborted();let n=i4(e,i2,2048,1024,{uRes:{value:128},uTilesX:{value:16}});a.cloudShape=i8(e,n,128,16,8),n.dispose(),t("baking volumetric cloud detail (32³)"),await r(),i?.throwIfAborted();let l=i4(e,i9,256,128,{uRes:{value:32},uTilesX:{value:8}});return a.cloudDetail=i8(e,l,32,8,4),l.dispose(),a}catch(e){throw i7(a),e}}function i7(e){e._curlRT?.dispose(),e._weatherRT?.dispose(),e.cloudShape?.dispose(),e.cloudDetail?.dispose()}let ae=`
#ifndef ATMO_COMMON
#define ATMO_COMMON 1

#define PI_A 3.14159265358979323846

const float groundRadiusMM = 6.360;
const float atmosphereRadiusMM = 6.460;

// per-megametre coefficients
const vec3  rayleighScatteringBase = vec3(5.802, 13.558, 33.100);
const float rayleighAbsorptionBase = 0.0;
const float mieScatteringBase = 3.996;
const float mieAbsorptionBase = 4.40;
const vec3  ozoneAbsorptionBase = vec3(0.650, 1.881, 0.085);

uniform float uAtmoTurbidity;   // 1 = clear, up to ~12 in a storm
uniform float uAtmoMieG;
uniform vec3  uAtmoGroundAlbedo;

float rayIntersectSphere(vec3 ro, vec3 rd, float rad) {
  float b = dot(ro, rd);
  float c = dot(ro, ro) - rad * rad;
  if (c > 0.0 && b > 0.0) return -1.0;
  float disc = b * b - c;
  if (disc < 0.0) return -1.0;
  if (disc > b * b) return (-b + sqrt(disc));
  return -b - sqrt(disc);
}

void scatteringValues(vec3 pos, out vec3 rayleighScattering, out float mieScattering, out vec3 extinction) {
  float altitudeKM = (length(pos) - groundRadiusMM) * 1000.0;
  float rayleighDensity = exp(-altitudeKM / 8.0);
  float mieDensity = exp(-altitudeKM / 1.2);

  float turb = uAtmoTurbidity;
  rayleighScattering = rayleighScatteringBase * rayleighDensity;
  float rayleighAbsorption = rayleighAbsorptionBase * rayleighDensity;

  mieScattering = mieScatteringBase * turb * mieDensity;
  float mieAbsorption = mieAbsorptionBase * turb * mieDensity;

  vec3 ozoneAbsorption = ozoneAbsorptionBase * max(0.0, 1.0 - abs(altitudeKM - 25.0) / 15.0);

  extinction = rayleighScattering + rayleighAbsorption + mieScattering + mieAbsorption + ozoneAbsorption;
}

float miePhase(float cosTheta) {
  const float scale = 3.0 / (8.0 * PI_A);
  float g = uAtmoMieG;
  float g2 = g * g;
  float num = (1.0 - g2) * (1.0 + cosTheta * cosTheta);
  float denom = (2.0 + g2) * pow(max(1.0 + g2 - 2.0 * g * cosTheta, 1e-4), 1.5);
  return scale * num / denom;
}

float rayleighPhase(float cosTheta) {
  const float k = 3.0 / (16.0 * PI_A);
  return k * (1.0 + cosTheta * cosTheta);
}

// ------------------------------------------------- transmittance LUT lookup
vec3 getValFromTLUT(sampler2D tex, vec3 pos, vec3 sunDir) {
  float height = length(pos);
  vec3 up = pos / height;
  float sunCosZenithAngle = dot(sunDir, up);
  vec2 uv = vec2(
    clamp(0.5 + 0.5 * sunCosZenithAngle, 0.0, 1.0),
    clamp((height - groundRadiusMM) / (atmosphereRadiusMM - groundRadiusMM), 0.0, 1.0));
  return texture(tex, uv).rgb;
}

vec3 getValFromMultiScattLUT(sampler2D tex, vec3 pos, vec3 sunDir) {
  float height = length(pos);
  vec3 up = pos / height;
  float sunCosZenithAngle = dot(sunDir, up);
  vec2 uv = vec2(
    clamp(0.5 + 0.5 * sunCosZenithAngle, 0.0, 1.0),
    clamp((height - groundRadiusMM) / (atmosphereRadiusMM - groundRadiusMM), 0.0, 1.0));
  return texture(tex, uv).rgb;
}

// --------------------------------------------------- sky-view LUT mapping
// Non-linear in view zenith so the horizon keeps its detail.
vec2 skyViewUV(vec3 viewPos, vec3 rayDir, vec3 sunDir) {
  float height = length(viewPos);
  vec3 up = viewPos / height;
  float horizonAngle = acos(clamp(sqrt(max(height * height - groundRadiusMM * groundRadiusMM, 0.0)) / height, -1.0, 1.0)) - 0.5 * PI_A;
  float altitudeAngle = asin(clamp(dot(rayDir, up), -1.0, 1.0)) - horizonAngle;

  vec3 right = normalize(cross(sunDir, up));
  vec3 forward = normalize(cross(up, right));
  vec3 projected = normalize(rayDir - up * dot(rayDir, up));
  float sinTheta = dot(projected, right);
  float cosTheta = dot(projected, forward);
  float azimuth = atan(sinTheta, cosTheta) + PI_A;

  float v;
  if (altitudeAngle < 0.0) {
    v = 0.5 - 0.5 * sqrt(max(-altitudeAngle / (0.5 * PI_A + horizonAngle), 0.0));
  } else {
    v = 0.5 + 0.5 * sqrt(max(altitudeAngle / (0.5 * PI_A - horizonAngle), 0.0));
  }
  return vec2(azimuth / (2.0 * PI_A), clamp(v, 0.0, 1.0));
}

vec3 getValFromSkyLUT(sampler2D tex, vec3 viewPos, vec3 rayDir, vec3 sunDir) {
  // Explicit LOD, always. The azimuth coordinate wraps from 1 back to 0 in the
  // span of one pixel, so an implicit lookup sees a screen-space derivative of
  // ~1 there and jumps to the top of the mip chain — a hairline dark column
  // running from the zenith to the horizon on whichever bearing the wrap lands.
  return textureLod(tex, skyViewUV(viewPos, rayDir, sunDir), 0.0).rgb;
}
vec3 getValFromSkyLUTLod(sampler2D tex, vec3 viewPos, vec3 rayDir, vec3 sunDir, float lod) {
  return textureLod(tex, skyViewUV(viewPos, rayDir, sunDir), lod).rgb;
}

#endif
`,at=`
vec3 raymarchScattering(sampler2D tLUT, sampler2D msLUT, vec3 pos, vec3 rayDir, vec3 sunDir,
                        float tMax, float numSteps) {
  float cosTheta = dot(rayDir, sunDir);
  float miePhaseValue = miePhase(cosTheta);
  float rayleighPhaseValue = rayleighPhase(-cosTheta);

  vec3 lum = vec3(0.0);
  vec3 transmittance = vec3(1.0);
  float t = 0.0;
  for (float i = 0.0; i < numSteps; i += 1.0) {
    float newT = ((i + 0.3) / numSteps) * tMax;
    float dt = newT - t;
    t = newT;

    vec3 newPos = pos + t * rayDir;

    vec3 rayleighScattering, extinction;
    float mieScattering;
    scatteringValues(newPos, rayleighScattering, mieScattering, extinction);

    vec3 sampleTransmittance = exp(-dt * extinction);

    vec3 sunTransmittance = getValFromTLUT(tLUT, newPos, sunDir);
    vec3 psiMS = getValFromMultiScattLUT(msLUT, newPos, sunDir);

    vec3 rayleighInScattering = rayleighScattering * (rayleighPhaseValue * sunTransmittance + psiMS);
    vec3 mieInScattering = vec3(mieScattering) * (miePhaseValue * sunTransmittance + psiMS);
    vec3 inScattering = rayleighInScattering + mieInScattering;

    vec3 scatteringIntegral = (inScattering - inScattering * sampleTransmittance) / max(extinction, vec3(1e-7));

    lum += scatteringIntegral * transmittance;
    transmittance *= sampleTransmittance;
  }
  return lum;
}
`,ai=`
${ae}
in vec2 vUv;
layout(location = 0) out vec4 oCol;
const float sunTransmittanceSteps = 40.0;

vec3 getSunTransmittance(vec3 pos, vec3 sunDir) {
  if (rayIntersectSphere(pos, sunDir, groundRadiusMM) > 0.0) return vec3(0.0);
  float atmoDist = rayIntersectSphere(pos, sunDir, atmosphereRadiusMM);
  float t = 0.0;
  vec3 transmittance = vec3(1.0);
  for (float i = 0.0; i < sunTransmittanceSteps; i += 1.0) {
    float newT = ((i + 0.3) / sunTransmittanceSteps) * atmoDist;
    float dt = newT - t; t = newT;
    vec3 newPos = pos + t * sunDir;
    vec3 rs, ext; float ms;
    scatteringValues(newPos, rs, ms, ext);
    transmittance *= exp(-dt * ext);
  }
  return transmittance;
}

void main(){
  float u = vUv.x, v = vUv.y;
  float sunCosTheta = 2.0 * u - 1.0;
  float sunTheta = acos(clamp(sunCosTheta, -1.0, 1.0));
  float height = mix(groundRadiusMM, atmosphereRadiusMM, v);
  vec3 pos = vec3(0.0, height, 0.0);
  vec3 sunDir = normalize(vec3(0.0, sunCosTheta, -sin(sunTheta)));
  oCol = vec4(getSunTransmittance(pos, sunDir), 1.0);
}
`,aa=`
${ae}
uniform sampler2D uTransmittance;
in vec2 vUv;
layout(location = 0) out vec4 oCol;

const float mulScattSteps = 20.0;
const int sqrtSamples = 8;

vec3 getSphericalDir(float theta, float phi) {
  float cosPhi = cos(phi), sinPhi = sin(phi);
  float cosTheta = cos(theta), sinTheta = sin(theta);
  return vec3(sinPhi * sinTheta, cosPhi, sinPhi * cosTheta);
}

void getMulScattValues(vec3 pos, vec3 sunDir, out vec3 lumTotal, out vec3 fms) {
  lumTotal = vec3(0.0); fms = vec3(0.0);
  float invSamples = 1.0 / float(sqrtSamples * sqrtSamples);
  for (int i = 0; i < sqrtSamples; i++) {
    for (int j = 0; j < sqrtSamples; j++) {
      float theta = PI_A * (float(i) + 0.5) / float(sqrtSamples);
      float phi = acos(1.0 - 2.0 * (float(j) + 0.5) / float(sqrtSamples));
      vec3 rayDir = getSphericalDir(theta, phi);

      float atmoDist = rayIntersectSphere(pos, rayDir, atmosphereRadiusMM);
      float groundDist = rayIntersectSphere(pos, rayDir, groundRadiusMM);
      float tMax = atmoDist;
      if (groundDist > 0.0) tMax = groundDist;

      float cosTheta = dot(rayDir, sunDir);
      float miePhaseValue = miePhase(cosTheta);
      float rayleighPhaseValue = rayleighPhase(-cosTheta);

      vec3 lum = vec3(0.0), lumFactor = vec3(0.0), transmittance = vec3(1.0);
      float t = 0.0;
      for (float stepI = 0.0; stepI < mulScattSteps; stepI += 1.0) {
        float newT = ((stepI + 0.3) / mulScattSteps) * tMax;
        float dt = newT - t; t = newT;
        vec3 newPos = pos + t * rayDir;

        vec3 rayleighScattering, extinction; float mieScattering;
        scatteringValues(newPos, rayleighScattering, mieScattering, extinction);
        vec3 sampleTransmittance = exp(-dt * extinction);

        vec3 scatteringNoPhase = rayleighScattering + vec3(mieScattering);
        vec3 scatteringF = (scatteringNoPhase - scatteringNoPhase * sampleTransmittance) / max(extinction, vec3(1e-7));
        lumFactor += transmittance * scatteringF;

        vec3 sunTransmittance = getValFromTLUT(uTransmittance, newPos, sunDir);
        vec3 rayleighInScattering = rayleighScattering * rayleighPhaseValue;
        vec3 mieInScattering = vec3(mieScattering * miePhaseValue);
        vec3 inScattering = (rayleighInScattering + mieInScattering) * sunTransmittance;

        vec3 scatteringIntegral = (inScattering - inScattering * sampleTransmittance) / max(extinction, vec3(1e-7));
        lum += scatteringIntegral * transmittance;
        transmittance *= sampleTransmittance;
      }

      if (groundDist > 0.0) {
        vec3 hitPos = pos + groundDist * rayDir;
        if (dot(pos, sunDir) > 0.0) {
          hitPos = normalize(hitPos) * groundRadiusMM;
          lum += transmittance * uAtmoGroundAlbedo * getValFromTLUT(uTransmittance, hitPos, sunDir);
        }
      }
      fms += lumFactor * invSamples;
      lumTotal += lum * invSamples;
    }
  }
}

void main(){
  float sunCosTheta = 2.0 * vUv.x - 1.0;
  float sunTheta = acos(clamp(sunCosTheta, -1.0, 1.0));
  float height = mix(groundRadiusMM, atmosphereRadiusMM, vUv.y);
  vec3 pos = vec3(0.0, height, 0.0);
  vec3 sunDir = normalize(vec3(0.0, sunCosTheta, -sin(sunTheta)));
  vec3 lum, f_ms;
  getMulScattValues(pos, sunDir, lum, f_ms);
  vec3 psi = lum / max(1.0 - f_ms, vec3(1e-5));
  oCol = vec4(psi, 1.0);
}
`,ar=`
${ae}
${at}
uniform sampler2D uTransmittance;
uniform sampler2D uMultiScatter;
uniform vec3 uSunDir;
uniform float uViewHeightMM;
in vec2 vUv;
layout(location = 0) out vec4 oCol;

void main(){
  float u = vUv.x, v = vUv.y;
  vec3 viewPos = vec3(0.0, uViewHeightMM, 0.0);
  float azimuthAngle = (u - 0.5) * 2.0 * PI_A;
  float adjV;
  if (v < 0.5) { float c = 1.0 - 2.0 * v; adjV = -c * c; }
  else { float c = v * 2.0 - 1.0; adjV = c * c; }

  float height = length(viewPos);
  vec3 up = viewPos / height;
  float horizonAngle = acos(clamp(sqrt(max(height*height - groundRadiusMM*groundRadiusMM, 0.0)) / height, -1.0, 1.0)) - 0.5 * PI_A;
  float altitudeAngle = adjV * 0.5 * PI_A - horizonAngle;

  float cosAltitude = cos(altitudeAngle);
  vec3 rayDir = vec3(cosAltitude * sin(azimuthAngle), sin(altitudeAngle), -cosAltitude * cos(azimuthAngle));

  float sunAltitude = (0.5 * PI_A) - acos(clamp(dot(uSunDir, up), -1.0, 1.0));
  vec3 sunDir = vec3(0.0, sin(sunAltitude), -cos(sunAltitude));

  float atmoDist = rayIntersectSphere(viewPos, rayDir, atmosphereRadiusMM);
  float groundDist = rayIntersectSphere(viewPos, rayDir, groundRadiusMM);
  float tMax = (groundDist < 0.0) ? atmoDist : groundDist;

  vec3 lum = raymarchScattering(uTransmittance, uMultiScatter, viewPos, rayDir, sunDir, tMax, 32.0);
  oCol = vec4(lum, 1.0);
}
`,ao=`
${ae}
${at}
uniform sampler2D uTransmittance;
uniform sampler2D uMultiScatter;
uniform vec3 uSunDir;
uniform vec3 uCamPos;          // world metres
uniform mat4 uInvViewProj;
uniform float uMaxDistance;    // metres
uniform float uSlices;
uniform float uRes;
in vec2 vUv;
layout(location = 0) out vec4 oCol;

void main(){
  float sliceX = floor(vUv.x * uSlices * uRes) ;
  float slice = floor(sliceX / uRes);
  float localX = (mod(sliceX, uRes) + 0.5) / uRes;
  vec2 ndc = vec2(localX, vUv.y) * 2.0 - 1.0;

  vec4 p0 = uInvViewProj * vec4(ndc, -1.0, 1.0); p0 /= p0.w;
  vec4 p1 = uInvViewProj * vec4(ndc,  1.0, 1.0); p1 /= p1.w;
  vec3 rayDir = normalize(p1.xyz - p0.xyz);

  float dist = uMaxDistance * pow((slice + 1.0) / uSlices, 2.0);

  vec3 viewPos = vec3(0.0, groundRadiusMM + max(uCamPos.y, 0.5) * 1e-6, 0.0);
  float tMaxMM = dist * 1e-6;
  float atmoDist = rayIntersectSphere(viewPos, rayDir, atmosphereRadiusMM);
  tMaxMM = min(tMaxMM, atmoDist);

  vec3 lum = raymarchScattering(uTransmittance, uMultiScatter, viewPos, rayDir, uSunDir, tMaxMM, 12.0);

  // transmittance along the same segment
  vec3 transmittance = vec3(1.0);
  float t = 0.0;
  const float N = 8.0;
  for (float i = 0.0; i < N; i += 1.0) {
    float newT = ((i + 0.5) / N) * tMaxMM;
    float dt = newT - t; t = newT;
    vec3 rs, ext; float ms;
    scatteringValues(viewPos + rayDir * t, rs, ms, ext);
    transmittance *= exp(-dt * ext);
  }
  oCol = vec4(lum, dot(transmittance, vec3(0.3333)));
}
`;class as{constructor(e){this.renderer=e,this.sunDir=new L.Vector3(.3,.35,-.9).normalize(),this.turbidity=1,this.mieG=.8,this.groundAlbedo=new L.Color(.06,.09,.12),this.sunIntensity=22,this.viewHeightMM=6.36+2e-4;const t={type:L.HalfFloatType};this.transmittanceRT=i$(256,64,{...t,name:"tLUT"}),this.multiScatterRT=i$(32,32,{...t,name:"msLUT"}),this.skyViewRT=i$(200,128,{...t,name:"skyLUT",wrap:L.RepeatWrapping,minFilter:L.LinearMipmapLinearFilter,mipmaps:!0}),this.aerialRT=i$(1024,32,{...t,name:"apLUT"});const i=()=>({uAtmoTurbidity:{value:this.turbidity},uAtmoMieG:{value:this.mieG},uAtmoGroundAlbedo:{value:new L.Vector3(.06,.09,.12)}});this.tPass=new iZ(ai,i(),{name:"transmittanceLUT"}),this.msPass=new iZ(aa,{...i(),uTransmittance:{value:this.transmittanceRT.texture}},{name:"multiScatterLUT"}),this.skyPass=new iZ(ar,{...i(),uTransmittance:{value:this.transmittanceRT.texture},uMultiScatter:{value:this.multiScatterRT.texture},uSunDir:{value:this.sunDir},uViewHeightMM:{value:this.viewHeightMM}},{name:"skyViewLUT"}),this.apPass=new iZ(ao,{...i(),uTransmittance:{value:this.transmittanceRT.texture},uMultiScatter:{value:this.multiScatterRT.texture},uSunDir:{value:this.sunDir},uCamPos:{value:new L.Vector3},uInvViewProj:{value:new L.Matrix4},uMaxDistance:{value:9e4},uSlices:{value:32},uRes:{value:32}},{name:"aerialLUT"}),this._lutTurbidity=-1,this.sunColor=new L.Color(1,1,1),this.ambientColor=new L.Color(.1,.2,.35),this._readBuf=new Float32Array(4)}_syncCommon(e){e.uniforms.uAtmoTurbidity.value=this.turbidity,e.uniforms.uAtmoMieG.value=this.mieG,e.uniforms.uAtmoGroundAlbedo.value.set(this.groundAlbedo.r,this.groundAlbedo.g,this.groundAlbedo.b)}buildStaticLUTs(e=!1){!e&&.02>Math.abs(this.turbidity-this._lutTurbidity)||(this._lutTurbidity=this.turbidity,this._syncCommon(this.tPass),this._syncCommon(this.msPass),this.tPass.render(this.renderer,this.transmittanceRT),this.msPass.render(this.renderer,this.multiScatterRT))}update(e,t){this.buildStaticLUTs(),this._syncCommon(this.skyPass),this.skyPass.uniforms.uSunDir.value.copy(this.sunDir),this.skyPass.uniforms.uViewHeightMM.value=6.36+1e-6*Math.max(t.y,.4),this.skyPass.render(this.renderer,this.skyViewRT),this._syncCommon(this.apPass),this.apPass.uniforms.uSunDir.value.copy(this.sunDir),this.apPass.uniforms.uCamPos.value.copy(t),this.apPass.uniforms.uInvViewProj.value.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse).invert(),this.apPass.render(this.renderer,this.aerialRT),this._updateLightColors()}_updateLightColors(){let e=Math.max(Math.max(this.sunDir.y,-.12),0),t=1/(e+.15*Math.pow(Math.max(93.885-57.29578*Math.acos(Math.min(e,1)),1),-1.253)),i=this.turbidity,a=[.005802,.013558,.0331],r=.003996*i+.0044*i,o=[65e-5,.001881,85e-6],s=[0,0,0];for(let e=0;e<3;e++){let i=(8*a[e]+1.2*r+15*o[e])*t;s[e]=Math.exp(-i)}let n=L.MathUtils.smoothstep(this.sunDir.y,-.1,.12);this.sunColor.setRGB(s[0],s[1],s[2]).multiplyScalar(n);let l=.02+.5*Math.max(this.sunDir.y+.12,0);this.ambientColor.setRGB(.28*l,.42*l,.65*l)}bind(e){return e.uTransmittanceLUT={value:this.transmittanceRT.texture},e.uMultiScatterLUT={value:this.multiScatterRT.texture},e.uSkyViewLUT={value:this.skyViewRT.texture},e.uAerialLUT={value:this.aerialRT.texture},e.uAerialSlices={value:32},e.uAerialRes={value:32},e.uAerialMaxDist={value:9e4},e.uSunDir={value:this.sunDir},e.uSunColor={value:new L.Vector3(1,1,1)},e.uSunIntensity={value:this.sunIntensity},e.uAtmoTurbidity={value:this.turbidity},e.uAtmoMieG={value:this.mieG},e.uAtmoGroundAlbedo={value:new L.Vector3(.06,.09,.12)},e}syncUniforms(e){e.uSunDir&&e.uSunDir.value.copy(this.sunDir),e.uSunColor&&e.uSunColor.value.set(this.sunColor.r,this.sunColor.g,this.sunColor.b),e.uSunIntensity&&(e.uSunIntensity.value=this.sunIntensity),e.uAtmoTurbidity&&(e.uAtmoTurbidity.value=this.turbidity),e.uAtmoMieG&&(e.uAtmoMieG.value=this.mieG)}dispose(){for(let e of["transmittanceRT","multiScatterRT","skyViewRT","aerialRT","tPass","msPass","skyPass","apPass"])this[e].dispose()}}let an=`
uniform sampler2D uAerialLUT;
uniform float uAerialSlices;
uniform float uAerialRes;
uniform float uAerialMaxDist;

vec4 sampleAerial(vec2 screenUv, float distMeters) {
  float s = sqrt(clamp(distMeters / uAerialMaxDist, 0.0, 1.0)) * uAerialSlices - 1.0;
  float s0 = clamp(floor(s), 0.0, uAerialSlices - 1.0);
  float s1 = clamp(s0 + 1.0, 0.0, uAerialSlices - 1.0);
  float f = clamp(s - s0, 0.0, 1.0);
  vec2 uvIn = vec2(clamp(screenUv.x, 0.5 / uAerialRes, 1.0 - 0.5 / uAerialRes), screenUv.y);
  vec4 a = texture(uAerialLUT, vec2((s0 + uvIn.x) / uAerialSlices, uvIn.y));
  vec4 b = texture(uAerialLUT, vec2((s1 + uvIn.x) / uAerialSlices, uvIn.y));
  return mix(a, b, f);
}
`,al=`
#ifndef SHADING_GLSL
#define SHADING_GLSL 1

#define PI_S 3.14159265358979323846
#define TAU_S 6.28318530717958647692

vec2 dirToEquirect(vec3 d) {
  return vec2(atan(d.z, d.x) / TAU_S + 0.5, acos(clamp(d.y, -1.0, 1.0)) / PI_S);
}
vec3 equirectToDir(vec2 uv) {
  float phi = (uv.x - 0.5) * TAU_S;
  float theta = uv.y * PI_S;
  float st = sin(theta);
  return vec3(st * cos(phi), cos(theta), st * sin(phi));
}

/**
 * Mean cosine-weighted radiance of the upper hemisphere of an equirect probe.
 *
 * Nine taps on a heavily blurred mip: enough for an ambient term, and because
 * it reads the same probe the reflections use, an overcast deck darkens the
 * water and a break in the clouds brightens it with no extra bookkeeping.
 * Multiply by an albedo to get the diffuse response (the 1/pi and the pi in the
 * irradiance cancel).
 */
vec3 skyIrradiance(sampler2D env, float maxLod) {
  // Keep at least four latitude rows: a 2x1 mip mixes sky with the dark lower hemisphere.
  float lod = max(maxLod - 3.0, 0.0);
  vec3 sum = textureLod(env, vec2(0.5, 0.02), lod).rgb;
  float w = 1.0;
  for (int i = 0; i < 4; i++) {
    float a = (float(i) + 0.5) * 0.25;
    sum += textureLod(env, vec2(a, 0.25), lod).rgb * 0.7071;          // 45 deg
    sum += textureLod(env, vec2(a + 0.125, 0.40), lod).rgb * 0.3090;  // 18 deg
    w += 1.0161;
  }
  return sum / w;
}

float ggxD(float NoH, float a) {
  float a2 = a * a;
  float d = (NoH * a2 - NoH) * NoH + 1.0;
  return a2 / max(PI_S * d * d, 1e-8);
}

float smithGGXCorrelated(float NoV, float NoL, float a) {
  float a2 = a * a;
  float gv = NoL * sqrt(NoV * NoV * (1.0 - a2) + a2);
  float gl = NoV * sqrt(NoL * NoL * (1.0 - a2) + a2);
  return 0.5 / max(gv + gl, 1e-6);
}

float fresnelWater(float NoV, float roughness) {
  float f = 0.02 + 0.98 * pow(clamp(1.0 - NoV, 0.0, 1.0), 5.0);
  // rough surfaces lose the sharp grazing peak
  return mix(f, clamp(f * 0.72 + 0.06, 0.0, 1.0), clamp(roughness * 1.5, 0.0, 1.0));
}

float schlick(float cosTheta, float f0) {
  return f0 + (1.0 - f0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

float henyeyGreenstein(float cosT, float g) {
  float g2 = g * g;
  return (1.0 - g2) / (4.0 * PI_S * pow(max(1.0 + g2 - 2.0 * g * cosT, 1e-4), 1.5));
}
float dualHG(float cosT, float g0, float g1, float w) {
  return mix(henyeyGreenstein(cosT, g0), henyeyGreenstein(cosT, g1), w);
}

float luminance(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

// ---------------------------------------------------------------- lightning
// Two concurrent strokes, inverse-square with a soft core; used by every
// surface shader so a bolt lights the whole scene consistently.
vec3 lightningContribution(vec3 worldPos, vec3 N, vec3 V, vec4 l0, vec4 l1, vec3 tint) {
  vec3 sum = vec3(0.0);
  for (int i = 0; i < 2; i++) {
    vec4 l = (i == 0) ? l0 : l1;
    if (l.w <= 0.0001) continue;
    vec3 d = l.xyz - worldPos;
    float dist2 = dot(d, d);
    vec3 Ld = d * inversesqrt(max(dist2, 1e-4));
    float atten = l.w * 4.0e5 / max(dist2, 900.0);
    float ndl = clamp(dot(N, Ld) * 0.65 + 0.35, 0.0, 1.0);
    vec3 H = normalize(Ld + V);
    float spec = pow(max(dot(N, H), 0.0), 220.0) * 2.4;
    sum += tint * atten * (ndl + spec);
  }
  return sum;
}

// --------------------------------------------------------------- tonemapping
vec3 agxDefaultContrastApprox(vec3 x) {
  vec3 x2 = x * x;
  vec3 x4 = x2 * x2;
  return  15.5 * x4 * x2
        - 40.14 * x4 * x
        + 31.96 * x4
        - 6.868 * x2 * x
        + 0.4298 * x2
        + 0.1191 * x
        - 0.00232;
}

vec3 agx(vec3 val) {
  const mat3 agx_mat = mat3(
    0.842479062253094, 0.0423282422610123, 0.0423756549057051,
    0.0784335999999992, 0.878468636469772, 0.0784336,
    0.0792237451477643, 0.0791661274605434, 0.879142973793104);
  const float min_ev = -12.47393;
  const float max_ev = 4.026069;
  val = agx_mat * val;
  val = clamp(log2(max(val, 1e-10)), min_ev, max_ev);
  val = (val - min_ev) / (max_ev - min_ev);
  return agxDefaultContrastApprox(val);
}
vec3 agxEotf(vec3 val) {
  const mat3 agx_mat_inv = mat3(
     1.19687900512017, -0.0528968517574562, -0.0529716355144438,
    -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
    -0.0990297440797205, -0.0989611768448433, 1.15107367264116);
  return agx_mat_inv * val;
}
vec3 agxLook(vec3 val, float sat, vec3 slope, vec3 power, float offset) {
  float luma = luminance(val);
  val = pow(max(val * slope + offset, vec3(0.0)), power);
  return luma + sat * (val - luma);
}

vec3 acesFitted(vec3 x) {
  const mat3 ACESInputMat = mat3(
    0.59719, 0.07600, 0.02840,
    0.35458, 0.90834, 0.13383,
    0.04823, 0.01566, 0.83777);
  const mat3 ACESOutputMat = mat3(
     1.60475, -0.10208, -0.00327,
    -0.53108,  1.10813, -0.07276,
    -0.07367, -0.00605,  1.07602);
  x = ACESInputMat * x;
  vec3 a = x * (x + 0.0245786) - 0.000090537;
  vec3 b = x * (0.983729 * x + 0.4329510) + 0.238081;
  x = a / b;
  return clamp(ACESOutputMat * x, 0.0, 1.0);
}

vec3 linearToSrgb(vec3 c) {
  return mix(c * 12.92, 1.055 * pow(max(c, vec3(1e-5)), vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));
}

#endif
`,ah=`
uniform sampler3D uCloudShape;
uniform sampler3D uCloudDetail;
uniform sampler2D uCurlTex;
uniform sampler2D uWeatherMap;
uniform float uWeatherScaleM;   // metres per weather-map repeat
uniform vec4 uShapeLo;
uniform vec4 uShapeHi;
uniform vec4 uDetailLo;
uniform vec4 uDetailHi;

uniform float uCoverage;
uniform float uCloudDensity;
uniform float uCloudBottom;
uniform float uCloudTop;
uniform float uAnvil;
uniform float uStorm;
uniform vec2  uCloudWind;
uniform float uCloudTime;
uniform float uCloudScaleM;    // metres per shape-texture repeat
uniform float uCloudAspect;    // vertical squash: how many cells fit in the deck
uniform float uCloudContrast;  // how hard the weather map breaks the deck up
uniform float uSunIntensity;
uniform vec3  uSunDir;
uniform float uAmbientFlash;

// Skylight reaching the deck, in the same units as everything else in the
// frame. Written once per fragment from the sky LUT rather than carried as a
// uniform, because an ad-hoc ambient constant is impossible to keep in step
// with the sun's intensity and leaves storm cloud undersides pure black.
vec3 gAmbTop = vec3(0.0);
vec3 gAmbBottom = vec3(0.0);
uniform vec3  uLightningColor;
uniform vec4  uLightning0;
uniform vec4  uLightning1;

const float PLANET_R = 6360000.0;

float remap(float v, float a, float b, float c, float d) {
  return c + (v - a) * (d - c) / max(b - a, 1e-5);
}

// normalise a baked channel onto its measured 2..98 percentile range
vec4 shapeTex(vec3 uvw) {
  return clamp((textureLod(uCloudShape, uvw, 0.0) - uShapeLo) / (uShapeHi - uShapeLo), 0.0, 1.0);
}
vec4 detailTex(vec3 uvw) {
  return clamp((textureLod(uCloudDetail, uvw, 0.0) - uDetailLo) / (uDetailHi - uDetailLo), 0.0, 1.0);
}

/**
 * Vertical density profile. The type parameter runs 0 = flat stratus slab,
 * 0.5 = fair weather cumulus, 1 = full cumulonimbus tower with an anvil.
 */
float heightProfile(float h, float type) {
  // Blend where the profile rises and falls, not two already-evaluated curves.
  // Averaging a low stratus slab against a taller cumulus gives a curve that
  // never reaches 1 — above h=0.38 the old blend capped at 0.6, and since the
  // coverage threshold sits near 0.9 that made cloud *impossible* up there. The
  // deck collapsed into flat-lidded slabs all topping out at one altitude,
  // because the only thing still clearing the threshold was the narrow band
  // where both curves happened to overlap.
  float t = clamp(type * 2.0, 0.0, 1.0);
  float rise = mix(0.05, 0.13, t);       // stratus base is crisper than cumulus
  float fallFrom = mix(0.16, 0.48, t);   // where the shoulders start eroding
  float fallTo = mix(0.38, 0.95, t);     // and where nothing is left
  float lo = smoothstep(0.0, rise, h) * (1.0 - smoothstep(fallFrom, fallTo, h));

  // column that punches the whole deck and flares into an anvil
  float tower = smoothstep(0.0, 0.04, h) * (1.0 - smoothstep(0.88, 1.0, h));
  float anvil = smoothstep(0.58, 0.74, h) * (1.0 - smoothstep(0.90, 1.0, h));
  float cb = max(tower * 0.9, anvil);

  return mix(lo, cb, clamp(type * 2.0 - 1.0, 0.0, 1.0));
}

/**
 * Large-scale organisation. A real sky is never statistically uniform: cells
 * come in clusters and bands tens of kilometres across with clear lanes
 * between them, and that structure is most of what the eye uses to judge
 * whether a cloudscape is real. Returns (coverage, type, base lift).
 */
vec3 weatherAt(vec2 xz) {
  // The map drifts as a whole and the cells inside it drift again, so a system
  // evolves as it crosses the sky instead of sliding past rigidly.
  // Explicit level, always. Screen-space derivatives inside a raymarch loop are
  // meaningless — neighbouring fragments are at different steps, or have exited
  // entirely — and letting the hardware pick a mip from them tears the deck
  // along hard seams wherever the chosen level happens to change.
  vec2 w = xz + uCloudWind * uCloudTime * 0.6;
  vec4 m = textureLod(uWeatherMap, w / uWeatherScaleM, 0.0);
  vec4 n = textureLod(uWeatherMap, w / (uWeatherScaleM * 0.27)
                 + vec2(0.37, 0.11) - uCloudWind * uCloudTime * 0.00002, 0.0);

  float field = m.r * 0.62 + m.g * 0.22 + n.g * 0.16;
  // Contrast pivots about the requested coverage: uCoverage says how much sky
  // is cloud, the field says where. Narrowing that spread near the ends is
  // tempting but wrong — it starves exactly the light-coverage case, where each
  // surviving cell is already only a few shape voxels across and turns to
  // cubes. Instead only the zero itself is gated, because the pivot alone lets
  // an above-average field manufacture cloud out of a request for none, and
  // "clear sky" has to actually clear.
  float cover = clamp((field - 0.5) * uCloudContrast + uCoverage, 0.0, 1.0)
              * smoothstep(0.0, 0.05, uCoverage);
  // Cloud type: 0 is a flat stratus slab, 0.5 a fair-weather cumulus, 1 a
  // cumulonimbus tower. Fair weather is made of cumulus, so the floor sits
  // there and the storm control lifts the deepest cells into towers. Running
  // the whole range off uAnvil meant a clear day was drawn as a field of
  // stratus pancakes — the right density in entirely the wrong shape.
  float type = clamp(0.30 + 0.20 * m.b + uAnvil * (0.34 + 0.55 * m.b + 0.6 * m.a), 0.0, 1.0);
  // How far this column's whole profile rides above or below the nominal deck.
  // Without it the base is a geometric plane at a constant altitude, and once
  // coverage is high enough to close the gaps an observer underneath sees a
  // featureless grey ceiling — which is why an overcast storm can end up
  // reading as flat haze while the same cloud model looks fine at a distance.
  float lift = (n.r * 0.6 + m.g * 0.4 - 0.5) * 0.34;
  return vec3(cover, type, lift);
}

// diagnostics: last raw shape value / post-threshold base, read by the probe
float gShapeR = 0.0;
float gBase = 0.0;
// march internals, written unconditionally and only read when uCloudDebug asks
float gT0 = 0.0, gT1 = 0.0, gIters = 0.0, gSpent = 0.0, gCov = 0.0;

/**
 * @param detail how much erosion to apply, 0..2. Continuous on purpose: a hard
 *   LOD switch changes the density, not just its frequency content, and since
 *   the switch happens at a fixed distance it stamps a sharp arc across the sky
 *   wherever the deck crosses it.
 */
float cloudDensity(vec3 p, float h, float detail) {
  // Higher layers outrun the base: the shear is what tilts a tower downwind
  // and smears its anvil, and it costs nothing.
  vec3 q = p;
  q.xz += uCloudWind * uCloudTime * (0.6 + h * 1.5);

  vec3 wm = weatherAt(q.xz);
  float type = wm.y;
  // Anvils spread aloft, so the top of a mature cell covers far more sky — but
  // only a mature cell does. Keyed on plain cumulus this lays a translucent
  // sheet across the entire top of the deck and the sky hazes over.
  float anvilness = smoothstep(0.62, 1.0, type);
  float cov = mix(wm.x, min(wm.x * 1.8 + 0.24, 1.0), smoothstep(0.55, 0.88, h) * anvilness);
  gCov = max(gCov, cov);
  if (cov <= 0.01) return 0.0;

  // Ride the whole profile up or down with the system. heightProfile is zero
  // outside the unit interval, so this carves a ragged base and top rather than
  // merely fading the slab.
  float hs = h - wm.z;
  if (hs <= 0.0 || hs >= 1.0) return 0.0;

  vec3 uvw = q / uCloudScaleM;
  uvw.y *= uCloudAspect;
  // Scattered cloud slices the top few percent of the shape field, and the
  // maxima of a trilinearly interpolated 128^3 volume are its own voxel corners
  // — so at low coverage the sky came out as a field of axis-aligned bricks. A
  // domain warp finer than that lattice moves the isosurface off it without
  // touching the value distribution, so coverage still means what it says.
  vec3 warp = (detailTex(uvw * 11.0).rgb - 0.5) * 0.011;
  vec4 shape = shapeTex(uvw + warp);

  float fbmLow = shape.g * 0.625 + shape.b * 0.25 + shape.a * 0.125;
  // Schneider's dilation: widen the perlin-worley field by its own fbm so the
  // billows stay connected instead of breaking into popcorn
  float base = remap(shape.r, fbmLow * 0.92 - 1.0, 1.0, 0.0, 1.0);
  base *= heightProfile(hs, type);
  gShapeR = max(gShapeR, shape.r);
  gBase = max(gBase, base);

  // Coverage sweeps a threshold across the base distribution. The dilation
  // above lifts the mean of base well past 0.5, so the sweep still has to start
  // near 1.0 for zero coverage to mean a genuinely empty sky. What it must not
  // do is spend the low end of its travel up in the tail: sliced above ~0.85 a
  // cell is only three or four shape-texture voxels across, and a trilinear
  // blob that small is a rounded box that no amount of erosion can rescue. The
  // gamma keeps both endpoints exact and gets off the tail quickly, so light
  // coverage means a few real cumulus rather than a field of bricks.
  float d = remap(base, mix(0.99, 0.20, pow(cov, 0.67)), 1.0, 0.0, 1.0);
  if (d <= 0.0) return 0.0;

  // A cloud is not a soft blob: liquid water content ramps up fast just inside
  // the boundary. The smoothstep puts that hard edge back, which is most of
  // what separates "convincing cumulus" from "grey smudge".
  d = d * d * (3.0 - 2.0 * d);

  float w1 = clamp(detail, 0.0, 1.0);
  if (w1 > 0.001) {
    // Curl-distorted erosion: wispy tendrils at the base where the updraught
    // shears, cauliflower billows at the top where it punches through.
    vec2 curl = textureLod(uCurlTex, uvw.xz * 3.1, 0.0).rg * 2.0 - 1.0;
    vec3 dp = q / (uCloudScaleM * 0.2);
    dp.xz += curl * (1.0 - h) * 3.5;
    vec3 det = detailTex(dp).rgb;
    float detFbm = det.r * 0.625 + det.g * 0.25 + det.b * 0.125;
    float mod3 = mix(1.0 - detFbm, detFbm, clamp(h * 4.0, 0.0, 1.0));
    // Erosion bites hardest at the silhouette and barely at all in the core,
    // which is what turns a smooth blob into billows. It used to be capped low
    // so the boundary could not flicker between amortisation phases — but the
    // cure for that belongs in the resolve, and paying for it here meant never
    // carving a shape in the first place.
    float bite = mix(0.78, 0.14, smoothstep(0.20, 0.78, d));
    d = mix(d, remap(d, mod3 * bite, 1.0, 0.0, 1.0), w1);
    if (d <= 0.0) return 0.0;

    float w2 = clamp(detail - 1.0, 0.0, 1.0);
    if (w2 > 0.001) {
      // The octave that actually reads as cauliflower: tens of metres across,
      // on the lit shoulders. Warped by the curl again at a different rate so
      // it never sits in register with the octave above it.
      vec3 fp = dp * 3.1;
      fp.xz += curl * 0.9;
      vec3 fine = detailTex(fp).rgb;
      float f = fine.r * 0.62 + fine.g * 0.26 + fine.b * 0.12;
      float fbite = mix(0.46, 0.08, smoothstep(0.25, 0.85, d));
      d = mix(d, remap(d, f * fbite, 1.0, 0.0, 1.0), w2);
      if (d <= 0.0) return 0.0;
    }
  }

  return clamp(d, 0.0, 1.0) * uCloudDensity;
}

/** Intersect a ray with a sphere of radius r centred at the planet core. */
vec2 shellIntersect(vec3 ro, vec3 rd, float r) {
  float b = dot(ro, rd);
  float c = dot(ro, ro) - r * r;
  float disc = b * b - c;
  if (disc < 0.0) return vec2(-1.0);
  float s = sqrt(disc);
  return vec2(-b - s, -b + s);
}

/**
 * Folds atmospheric extinction between the eye and the cloud into the layer,
 * so distant cells wash out into the horizon haze exactly like the real thing.
 * Returns the premultiplied layer colour for "sky * a + rgb" compositing.
 */
vec3 applyAerial(vec3 scatter, float transmittance, float dist, vec3 hazeColor) {
  if (dist <= 0.0) return scatter;
  // sea-level extinction, thinned a little for the altitude of the deck
  vec3 beta = (vec3(5.802e-6, 13.558e-6, 33.1e-6)
             + vec3(3.996e-6) * uAtmoTurbidity) * 0.72;
  vec3 Ta = exp(-beta * dist);
  return scatter * Ta + hazeColor * (1.0 - Ta) * (1.0 - transmittance);
}

vec3 lightningGlow(vec3 p) {
  vec3 sum = vec3(0.0);
  for (int i = 0; i < 2; i++) {
    vec4 l = (i == 0) ? uLightning0 : uLightning1;
    if (l.w <= 0.0001) continue;
    float d2 = dot(l.xyz - p, l.xyz - p);
    sum += uLightningColor * l.w * 6.0e6 / max(d2, 4.0e4);
  }
  return sum;
}
`,ac=`
uniform int uSteps;
uniform int uLightSteps;
uniform sampler2D uSkyAmbLUT;
// Ranges over which the two erosion octaves fade out, in metres along the ray.
uniform vec3 uDetailFade;

/**
 * Skylight arriving at the deck, split into what reaches the tops and what
 * crawls in under the base. Both come straight out of the sky LUT so they
 * track sunset, overcast and night without any hand-tuned constants.
 */
void skyAmbient(vec3 viewPos, vec3 rd) {
  vec3 up = getValFromSkyLUT(uSkyAmbLUT, viewPos, vec3(0.0, 1.0, 0.0), uSunDir);
  // Under a deck the only light comes in sideways from the bright ring at the
  // horizon, then bounces once off the water on its way up.
  vec3 side = getValFromSkyLUT(uSkyAmbLUT, viewPos,
                normalize(vec3(rd.x, 0.07, rd.z)), uSunDir);
  // Skylight is blue and comes from everywhere, so it is also the term that
  // flattens a cloud. Too much of it and a sunlit cumulus reads as a pale blue
  // smudge with no lit side and no shaded side — which is not a lighting bug
  // you can tonemap your way out of, it is the shape disappearing.
  gAmbTop = up * uSunIntensity * 1.45;
  // Still generous. A deck kilometres thick is optically opaque, so a strictly
  // single-scattering base integrates to black and the overcast stops reading
  // as weather and starts reading as night. The light is really there: it
  // arrives sideways from the bright ring under the deck edge and is piped
  // through the cloud by high-order scattering the light march truncates.
  gAmbBottom = (side * 0.50 + up * 0.15) * uSunIntensity * vec3(0.80, 0.88, 1.0);
}

// Extinction per unit density per metre. Real cumulus sit around 0.05/m, which
// makes a 500 m cell optically thick enough to hide the sun completely; we run
// a little under that because the raymarch cannot afford steps short enough to
// resolve the ~20 m skin where all the visible shading actually happens.
const float SIGMA = 0.022;

/**
 * Energy-conserving multiple-scattering approximation (Wrenninge octaves).
 * Light taps grow exponentially so a handful of samples still cover the deck.
 */
vec3 sampleLight(vec3 p, float mu, vec3 sunColor, float selfDensity, float jitter, int steps) {
  vec3 ld = uSunDir;
  float thickness = uCloudTop - uCloudBottom;
  float stepLen = thickness * 0.045;
  float depth = 0.0;
  // Small: the shadow march is smooth, so jitter here buys almost no banding
  // relief and costs visible noise in the lighting.
  float travelled = stepLen * (0.25 + 0.3 * jitter);
  for (int i = 0; i < 8; i++) {
    if (i >= steps) break;
    travelled += stepLen;
    vec3 sp = p + ld * travelled;
    float sh = clamp((length(sp) - (PLANET_R + uCloudBottom)) / thickness, 0.0, 1.0);
    // base octave only: the shadow of a wisp is not worth a 3D texture fetch
    depth += cloudDensity(sp, sh, 0.0) * stepLen;
    stepLen *= 1.62;
  }

  vec3 lum = vec3(0.0);
  float a = 1.0, b = 1.0, c = 1.0;
  for (int o = 0; o < 3; o++) {
    float beer = exp(-depth * SIGMA * b);
    // Powder: light that scattered back out of a dense edge before it could be
    // absorbed. It is the thing that makes a sunlit cumulus edge read as solid
    // rather than translucent, and it must key off the LOCAL density, not the
    // path integral, or it darkens the whole cloud instead of its rim.
    float powder = 1.0 - exp(-selfDensity * 14.0);
    float phase = dualHG(mu, 0.82 * c, -0.32 * c, 0.55);
    lum += sunColor * a * phase * beer * mix(1.0, powder, 0.6);
    // Successive octaves stand for light that has already bounced: each one is
    // dimmer but penetrates much further, and it is that long tail that keeps
    // the inside of a thick cell luminous grey instead of black. The tail has
    // to keep decaying though — at b = 0.09 the third octave barely attenuates
    // at all, so it acts as a second flat ambient and erases the very gradient
    // between the lit shoulder and the shaded flank it exists to soften.
    a *= 0.5; b *= 0.42; c *= 0.68;
  }
  return lum;
}

/**
 * Two-speed raymarch: long cheap strides (no detail octave) hunt for the cloud
 * boundary, then we back up and integrate with short detailed steps. Leaving a
 * cell reverts to striding. This is what makes a 4 km deck affordable at
 * horizon distances where the ray can cover 200 km inside the shell.
 *
 * @return vec4(scattered radiance, transmittance)
 */
vec4 marchClouds(vec3 ro, vec3 rd, float rayJitter, vec3 sunColor, out vec4 diag) {
  // diag = (first-hit distance, peak raw shape, peak density, taps inside cloud)
  diag = vec4(-1.0, 0.0, 0.0, 0.0);
  float depthOut = -1.0;
  float peakDensity = 0.0;
  vec3 center = vec3(0.0, -PLANET_R, 0.0);
  vec3 o = ro - center;

  float thickness = uCloudTop - uCloudBottom;
  float rInner = PLANET_R + uCloudBottom;
  float rOuter = PLANET_R + uCloudTop;
  vec2 tOuter = shellIntersect(o, rd, rOuter);
  if (tOuter.y < 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
  vec2 tInner = shellIntersect(o, rd, rInner);

  float t0, t1;
  float ro_r = length(o);
  if (ro_r < rInner) {
    if (tInner.y < 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
    t0 = tInner.y; t1 = tOuter.y;
  } else if (ro_r < rOuter) {
    t0 = 0.0;
    t1 = (tInner.x > 0.0) ? tInner.x : tOuter.y;
  } else {
    t0 = max(tOuter.x, 0.0);
    t1 = (tInner.x > 0.0) ? tInner.x : tOuter.y;
  }
  if (t1 <= t0) return vec4(0.0, 0.0, 0.0, 1.0);

  // Beyond this the deck is a few pixels tall on the horizon and the aerial
  // perspective has already washed it into the haze, so marching further only
  // buys banding.
  float maxDist = 140000.0;
  t1 = min(t1, t0 + maxDist);
  float span = t1 - t0;
  gT0 = t0; gT1 = t1;

  // Fine steps resolve the cell; they have to stay short enough that a single
  // step cannot swallow the whole optical depth, or the visible skin of the
  // cloud collapses to one flat sample. Tying this to the deck thickness would
  // make a 12 km storm deck step in 250 m chunks, which is exactly the case
  // where the skin matters most. Distance relaxes it because a far cell is a
  // pixel wide anyway.
  float nearFine = clamp(thickness * 0.005, 22.0, 48.0);

  float mu = dot(rd, uSunDir);
  vec3 scatter = vec3(0.0);
  float transmittance = 1.0;

  float t = t0 + nearFine * rayJitter;
  bool inside = false;
  int emptyRun = 0;
  int spent = 0;

  for (int i = 0; i < 512; i++) {
    gIters = float(i);
    if (spent >= uSteps || t > t1 || transmittance < 0.004) break;
    // Sample spacing is a quality decision and must not be stretched to make
    // the ray reach the far shell: a 500 m step swallows the whole optical
    // depth of a storm cell in one go, which flattens its skin to a single
    // sample and turns the ray-start jitter into salt-and-pepper noise.
    // Instead the step only grows once the budget is nearly gone, smoothly,
    // so a ray that runs long fades out rather than cutting off.
    float budget = float(uSteps - spent) / float(uSteps);
    float fine = nearFine * clamp(1.0 + t / 9000.0, 1.0, 22.0)
               * (1.0 + 7.0 * (1.0 - smoothstep(0.0, 0.35, budget)));
    // The stride is what hunts for the cloud boundary, so it cannot be longer
    // than the features it is hunting for: stride past a wisp and the ray
    // reports empty, and whether it does depends on the jitter, which is
    // precisely how a cloud edge turns into salt-and-pepper. Distance growth
    // is compounding, so this still reaches 140 km in about 120 taps.
    float stride = fine * 3.0;
    vec3 p = o + rd * t;
    float h = clamp((length(p) - rInner) / thickness, 0.0, 1.0);

    if (!inside) {
      if (cloudDensity(p, h, 0.0) > 0.0) {
        // Rewind to just before the boundary. The rewind lands on a grid that
        // is nearly identical for neighbouring rays, so without re-jittering
        // here the sample phase correlates across the screen and prints a comb
        // of stripes across every cloud face. One fine step of jitter is enough
        // to break that up; a whole stride just turns the comb into noise.
        t = max(t - stride + fine * rayJitter, t0);
        inside = true;
        emptyRun = 0;
      } else {
        t += stride;
      }
      continue;
    }

    // Detail octaves retire when what they carve stops resolving. Retiring the
    // fine octave at a kilometre and a bit — nearer than the cloud base itself
    // — meant every cloud in the sky was drawn from the base shape alone, and a
    // 128-cell volume stretched over seven kilometres holds nothing smaller
    // than a three-hundred-metre blob. That, and not the march resolution, is
    // what made the deck read as cotton wool.
    float detail = 2.0 - smoothstep(uDetailFade.x, uDetailFade.y, t)
                       - smoothstep(uDetailFade.y, uDetailFade.z, t);
    float dens = cloudDensity(p, h, detail);
    peakDensity = max(peakDensity, dens);
    spent++;
    if (dens > 0.0005) {
      diag.w += 1.0;
      emptyRun = 0;
      if (depthOut < 0.0) depthOut = t;

      // Once the cloud in front has eaten most of the light, nothing behind it
      // is resolvable, so the light march can drop to a couple of taps.
      int ls = transmittance > 0.25 ? uLightSteps : 2;
      vec3 lum = sampleLight(p, mu, sunColor, dens, rayJitter, ls);
      // Ambient: sky from above, ocean-tinted bounce from below, attenuated by
      // how deep inside the deck we are — that vertical gradient is what gives
      // a cloud its dark base and bright shoulders.
      // Skylight has to fight its way down through whatever cloud stands above
      // this sample. Without this the ambient term is the same everywhere along
      // the base and an overcast deck integrates to a flat grey sheet: the
      // relief is all there in the geometry, but nothing shades it. Two coarse
      // taps are enough, because what matters is the difference between a
      // sample under two hundred metres of cloud and one under two kilometres.
      float above = 0.0;
      {
        float span = max(uCloudTop - uCloudBottom, 200.0);
        vec3 up = normalize(p);
        above += cloudDensity(p + up * span * 0.10, min(h + 0.10, 1.0), 0.0) * span * 0.22;
        above += cloudDensity(p + up * span * 0.34, min(h + 0.34, 1.0), 0.0) * span * 0.46;
      }
      float skyVis = exp(-above * SIGMA * 0.55);

      vec3 amb = mix(gAmbBottom, gAmbTop, h);
      lum += amb * mix(0.55, 1.0, h) * mix(0.16, 1.0, skyVis);
      lum += lightningGlow(p + center);
      lum += uAmbientFlash * uLightningColor * 0.25;

      float tr = exp(-dens * SIGMA * fine);
      // analytic slab integration keeps banding away at low step counts
      scatter += lum * transmittance * (1.0 - tr);
      transmittance *= tr;
    } else if (++emptyRun > 4) {
      inside = false;
    }
    t += fine;
  }

  diag.x = depthOut;
  diag.y = gShapeR;
  diag.z = max(gBase, peakDensity);
  gSpent = float(spent);
  return vec4(scatter, transmittance);
}
`,ad=`
precision highp float;
precision highp int;
precision highp sampler2D;
precision highp sampler3D;

uniform vec3 uCamPos;
uniform float uFrame;
uniform mat4 uInvViewProj;

${ae}
${al}
${iJ}
${ah}
${ac}

uniform sampler2D uTransmittanceLUT;
uniform sampler2D uSkyViewLUT;

in vec2 vUv;
layout(location = 0) out vec4 oColor;

void main(){
  #ifdef SCREEN_SPACE
  vec2 ndc = vUv * 2.0 - 1.0;
  vec4 p0 = uInvViewProj * vec4(ndc, -1.0, 1.0); p0 /= p0.w;
  vec4 p1 = uInvViewProj * vec4(ndc, 1.0, 1.0); p1 /= p1.w;
  vec3 rd = normalize(p1.xyz - p0.xyz);
  #else
  vec3 rd = equirectToDir(vUv);
  #endif
  if (rd.y < -0.02) { oColor = vec4(0.0, 0.0, 0.0, 1.0); return; }

  vec3 viewPos = vec3(0.0, groundRadiusMM + max(uCamPos.y, 0.2) * 1e-6, 0.0);
  vec3 sunColor = getValFromTLUT(uTransmittanceLUT, viewPos, uSunDir) * uSunIntensity;
  skyAmbient(viewPos, rd);

  vec4 diag;
  // Fixed spatial jitter breaks march bands without temporal sparkle.
  float jitter = fract(52.9829189 * fract(dot(floor(gl_FragCoord.xy), vec2(0.06711056, 0.00583715))));
  vec4 cl = marchClouds(uCamPos, rd, jitter, sunColor, diag);
  vec3 haze = getValFromSkyLUT(uSkyViewLUT, viewPos, rd, uSunDir) * uSunIntensity;
  cl.rgb = applyAerial(cl.rgb, cl.a, diag.x, haze);
  oColor = cl;
}
`;class au{constructor(e,t,i,a,r){this.U=r,this.renderer=e,this.atmosphere=t,this.enabled=!0,this.frame=0,this.reset=!0;const o=e=>{let t=e?.userData?.percentiles;return t?[new L.Vector4(...t.lo),new L.Vector4(...t.hi)]:[new L.Vector4(0,0,0,0),new L.Vector4(1,1,1,1)]},[s,n]=o(i.cloudShape),[l,h]=o(i.cloudDetail);this.shared={uCloudShape:{value:i.cloudShape},uCloudDetail:{value:i.cloudDetail},uShapeLo:{value:s},uShapeHi:{value:n},uDetailLo:{value:l},uDetailHi:{value:h},uCurlTex:this.U.uCurlTex,uWeatherMap:{value:i.weather},uWeatherScaleM:{value:58e3},uCoverage:{value:.4},uCloudDensity:{value:.6},uCloudBottom:{value:1200},uCloudTop:{value:5200},uAnvil:{value:0},uStorm:this.U.uStormFactor,uCloudWind:{value:new L.Vector2(6,2)},uCloudTime:{value:0},uCloudScaleM:{value:15e3},uCloudAspect:{value:2.6},uCloudContrast:{value:1.6},uSunIntensity:this.U.uSunIntensity,uSunDir:this.U.uSunDir,uSkyAmbLUT:{value:t.skyViewRT.texture},uAmbientFlash:this.U.uAmbientFlash,uLightningColor:this.U.uLightningColor,uLightning0:this.U.uLightning0,uLightning1:this.U.uLightning1,uTransmittanceLUT:{value:t.transmittanceRT.texture},uSkyViewLUT:{value:t.skyViewRT.texture},uAtmoTurbidity:this.U.uAtmoTurbidity,uAtmoMieG:this.U.uAtmoMieG,uAtmoGroundAlbedo:this.U.uAtmoGroundAlbedo,uSteps:{value:64},uLightSteps:{value:6}},this.envPass=new iZ(ad,{...this.shared,uCamPos:this.U.uCamPos,uFrame:this.U.uFrame,uSteps:{value:18},uLightSteps:{value:3},uDetailFade:{value:new L.Vector3(9e3,34e3,95e3)}},{name:"cloudEnv"}),this.screenPass=new iZ(ad,{...this.shared,uCamPos:this.U.uCamPos,uInvViewProj:this.U.uInvViewProj,uDetailFade:{value:new L.Vector3(9e3,34e3,95e3)}},{name:"cloudScreen",defines:{SCREEN_SPACE:1}}),this.screenRT=i$(1,1,{name:"cloudScreen"}),this.setQuality(a)}setQuality(e){this.screenPass.uniforms.uSteps.value=e.cloudSteps,this.screenPass.uniforms.uLightSteps.value=e.cloudLightSteps,this.envPass.uniforms.uSteps.value=160,this.envPass.uniforms.uLightSteps.value=3,this.envRT?.dispose(),this.envRT=i$(e.envSize,e.envSize/2,{name:"cloudEnv"}),this.envRT.texture.wrapS=L.RepeatWrapping}update(e,t,i,a){let r=this.shared;r.uCloudTime.value=e;let o=Math.max(r.uCloudTop.value-r.uCloudBottom.value,200);r.uCloudAspect.value=L.MathUtils.clamp(r.uCloudScaleM.value/(4.4*o),.8,1.7);let s=Math.min(.5,900/t);this.screenRT.setSize(Math.max(1,Math.round(t*s)),Math.max(1,Math.round(i*s))),r.uCoverage.value>0&&(this.screenPass.render(this.renderer,this.screenRT),a&&this.envPass.render(this.renderer,this.envRT))}get envTexture(){return this.envRT.texture}dispose(){this.envRT.dispose(),this.envPass.dispose(),this.screenRT.dispose(),this.screenPass.dispose()}}let am=`
uniform sampler2D uSkyViewLUT;
uniform sampler2D uTransmittanceLUT;
uniform vec3 uSunDir;
uniform vec3 uMoonDir;
uniform vec3 uSunColor;
uniform float uSunIntensity;
uniform float uStarIntensity;
uniform float uAmbientFlash;
uniform vec3 uLightningColor;
uniform vec4 uLightning0;
uniform vec4 uLightning1;
uniform vec3 uCamPos;
uniform vec3 uHorizonColor;
uniform float uCityHaze;

vec3 cityHaze(vec3 sky, vec3 dir) {
  // Same linear colour as Three's exponential fog. The horizon limit is exact;
  // blend upward through the low cloud deck instead of ending at a hard plane.
  float belt=exp(-abs(dir.y)*22.0);
  return mix(sky,uHorizonColor,belt*uCityHaze);
}

const float SUN_ANGULAR_RADIUS = 0.00465;

vec3 sunDisc(vec3 dir, vec3 sunDir, vec3 transmittance) {
  float cosT = dot(dir, sunDir);
  float ang = acos(clamp(cosT, -1.0, 1.0));
  if (ang > SUN_ANGULAR_RADIUS * 1.6) return vec3(0.0);
  float r = clamp(ang / SUN_ANGULAR_RADIUS, 0.0, 1.0);
  // Limb darkening (Hestroffer & Magnan coefficients)
  float mu = sqrt(max(1.0 - r * r, 0.0));
  vec3 u = vec3(1.0);
  vec3 a = vec3(0.397, 0.503, 0.652);
  vec3 factor = 1.0 - u * (1.0 - pow(vec3(mu), a));
  float edge = 1.0 - smoothstep(1.0, 1.35, ang / SUN_ANGULAR_RADIUS);
  return transmittance * factor * edge * 18000.0;
}

vec3 starField(vec3 dir, float intensity) {
  if (intensity < 0.001) return vec3(0.0);
  vec3 col = vec3(0.0);
  for (int oct = 0; oct < 2; oct++) {
    float scale = (oct == 0) ? 340.0 : 780.0;
    vec3 p = dir * scale;
    vec3 i = floor(p);
    vec3 f = fract(p) - 0.5;
    vec3 h = hash33(i);
    if (h.x > (oct == 0 ? 0.982 : 0.9955)) {
      vec3 off = (hash33(i + 7.31) - 0.5) * 0.7;
      float d = length(f - off);
      float mag = pow(h.y, 3.0);
      float twinkle = 0.75 + 0.25 * sin(h.z * 90.0 + uTimeStars * (1.2 + h.z * 2.5));
      float s = exp(-d * d * 900.0) * mag * twinkle;
      vec3 tint = mix(vec3(0.68, 0.78, 1.0), vec3(1.0, 0.82, 0.62), h.z);
      col += tint * s;
    }
  }
  // milky way band
  float band = exp(-pow(dot(normalize(dir), normalize(vec3(0.42, 0.28, -0.86))) * 2.6, 2.0));
  float mw = fbm2Tiled(dirToEquirect(dir) * 26.0, 26.0, 5);
  col += vec3(0.55, 0.62, 0.86) * band * mw * 0.055;
  return col * intensity * 8.0;
}
`,ap=`
vec3 renderSky(vec3 dir, vec3 camPos) {
  vec3 viewPos = vec3(0.0, groundRadiusMM + max(camPos.y, 0.2) * 1e-6, 0.0);
  vec3 lum = getValFromSkyLUT(uSkyViewLUT, viewPos, dir, uSunDir);

  vec3 tr = getValFromTLUT(uTransmittanceLUT, viewPos, dir);
  if (dir.y > -0.02) {
    lum += sunDisc(dir, uSunDir, tr) * 0.00025;
  }

  // night sky
  float night = clamp(1.0 - (uSunDir.y + 0.12) * 6.0, 0.0, 1.0);
  lum += starField(dir, uStarIntensity * night) * 0.0016;

  return lum;
}
`,af=`
precision highp float;
in vec3 position;
in vec2 uv;
out vec2 vUv;
void main(){ vUv = uv; gl_Position = vec4(position.xy, 1.0, 1.0); }
`,ag=`
precision highp float;
precision highp int;
precision highp sampler2D;

uniform mat4 uInvViewProj;
uniform mat4 uPrevViewProjNJ;
uniform mat4 uViewProjNJ;
uniform vec2 uResolution;
uniform sampler2D uCloudTex;
uniform sampler2D uCloudEnvTex;
uniform bool uScreenClouds;
uniform float uCloudEnabled;
uniform float uTimeStars;
uniform float uFogDensity;
uniform float uUrbanGlow;

${ae}
${al}
${iJ}
${am}
${ap}

in vec2 vUv;
layout(location = 0) out vec4 oColor;

void main(){
  vec2 ndc = vUv * 2.0 - 1.0;
  vec4 p0 = uInvViewProj * vec4(ndc, -1.0, 1.0); p0 /= p0.w;
  vec4 p1 = uInvViewProj * vec4(ndc,  1.0, 1.0); p1 /= p1.w;
  vec3 dir = normalize(p1.xyz - p0.xyz);

  // The LUTs store radiance per unit solar irradiance, so the sun's strength is
  // applied here. The cloud layer already carries it — folding it in before the
  // composite instead of after is the difference between a lit deck and one
  // that is a hundred times too bright.
  vec3 sky = renderSky(dir, uCamPos) * uSunIntensity;

  if (uCloudEnabled > 0.5) {
    vec4 cl = vec4(0.0);
    if (uScreenClouds) {
      vec2 texel = 1.0 / vec2(textureSize(uCloudTex, 0));
      // Spatial resolve for the fixed march jitter; no stale temporal history on orbit.
      for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) {
        float weight = (x == 0 ? 2.0 : 1.0) * (y == 0 ? 2.0 : 1.0);
        cl += texture(uCloudTex, vUv + vec2(float(x), float(y)) * texel) * weight / 16.0;
      }
    } else cl = texture(uCloudEnvTex, dirToEquirect(dir));
    sky = sky * cl.a + cl.rgb;
  }

  sky += uAmbientFlash * uLightningColor * 0.012 * max(0.0, 1.0 - abs(dir.y));
  sky += vec3(.012,.019,.04) * (.25 + .75 * exp(-max(dir.y,0.) * 5.)) * uUrbanGlow;
  sky = cityHaze(sky,dir);

  oColor = vec4(sky, 1.0);

  vec3 farPt = uCamPos + dir * 40000.0;
  vec4 cur = uViewProjNJ * vec4(farPt, 1.0);
  vec4 prv = uPrevViewProjNJ * vec4(farPt, 1.0);
  // z is the linear view distance the depth-of-field and fog passes read; the
  // sky is at infinity, and leaving it at zero makes the CoC solver treat the
  // whole dome as if it were pressed against the lens.

}
`,av=`
precision highp float;
precision highp int;
precision highp sampler2D;

uniform sampler2D uCloudEnvTex;
uniform float uCloudEnabled;
uniform float uTimeStars;
uniform float uUrbanGlow;

${ae}
${al}
${iJ}
${am}
${ap}

in vec2 vUv;
layout(location = 0) out vec4 oColor;

void main(){
  vec3 dir = equirectToDir(vUv);

  // Below the horizon the probe stands in for the sea itself. Leaving it black
  // would drain every rough reflection, so mirror the sky and tint it with the
  // water's own colour — that is very close to what a wave actually sees.
  float below = smoothstep(0.0, -0.22, dir.y);
  vec3 lookDir = mix(dir, vec3(dir.x, abs(dir.y) * 0.35 + 0.02, dir.z), below);

  vec3 sky = renderSky(normalize(lookDir), uCamPos) * uSunIntensity;
  if (uCloudEnabled > 0.5) {
    vec4 cl = texture(uCloudEnvTex, vUv);
    sky = sky * cl.a + cl.rgb;
  }
  sky += uAmbientFlash * uLightningColor * 0.012;
  sky += vec3(.012,.019,.04) * (.25 + .75 * exp(-max(lookDir.y,0.) * 5.)) * uUrbanGlow;
  sky = cityHaze(sky,lookDir);
  sky = mix(sky, sky * vec3(0.16, 0.30, 0.38), below);
  oColor = vec4(sky, 1.0);
}
`;class ab{constructor(e,t,i){this.U=i,this.renderer=e,this.atmosphere=t,this.starIntensity=1;const a={uSkyViewLUT:{value:t.skyViewRT.texture},uTransmittanceLUT:{value:t.transmittanceRT.texture},uSunDir:this.U.uSunDir,uMoonDir:this.U.uMoonDir,uSunColor:this.U.uSunColor,uSunIntensity:this.U.uSunIntensity,uCamPos:this.U.uCamPos,uStarIntensity:{value:1},uAmbientFlash:this.U.uAmbientFlash,uLightningColor:this.U.uLightningColor,uLightning0:this.U.uLightning0,uLightning1:this.U.uLightning1,uAtmoTurbidity:this.U.uAtmoTurbidity,uAtmoMieG:this.U.uAtmoMieG,uAtmoGroundAlbedo:this.U.uAtmoGroundAlbedo,uTimeStars:{value:0},uCloudEnabled:{value:0},uUrbanGlow:{value:0},uCityHaze:{value:0},uHorizonColor:{value:new L.Color}};this.shared=a;const r=new L.BufferGeometry;r.setAttribute("position",new L.BufferAttribute(new Float32Array([-1,-1,0,3,-1,0,-1,3,0]),3)),r.setAttribute("uv",new L.BufferAttribute(new Float32Array([0,0,2,0,0,2]),2)),r.boundingSphere=new L.Sphere(new L.Vector3,4),this.bgMaterial=new L.RawShaderMaterial({name:"SkyBackground",glslVersion:L.GLSL3,vertexShader:af,fragmentShader:ag,uniforms:{...a,uInvViewProj:{value:new L.Matrix4},uViewProjNJ:this.U.uViewProjNJ,uPrevViewProjNJ:this.U.uPrevViewProjNJ,uResolution:this.U.uResolution,uFogDensity:this.U.uFogDensity,uCloudTex:{value:null},uCloudEnvTex:{value:null},uScreenClouds:{value:!1}},depthTest:!1,depthWrite:!1}),this.mesh=new L.Mesh(r,this.bgMaterial),this.mesh.frustumCulled=!1,this.mesh.renderOrder=-1e3,this.bgMaterial.uniforms.uCamPos={value:new L.Vector3},this.mesh.onBeforeRender=(e,t,i)=>{this.bgMaterial.uniforms.uScreenClouds.value=i===this.mainCamera,this.bgMaterial.uniforms.uCamPos.value.setFromMatrixPosition(i.matrixWorld),this.bgMaterial.uniforms.uInvViewProj.value.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse).invert()},this.envRT=i$(256,128,{type:L.HalfFloatType,name:"envProbe",wrap:L.RepeatWrapping,minFilter:L.LinearMipmapLinearFilter,mipmaps:!0}),this.envRT.texture.wrapS=L.RepeatWrapping,this.envRT.texture.wrapT=L.ClampToEdgeWrapping,this.envPass=new iZ(av,{...a,uCloudEnvTex:{value:null}},{name:"envProbe"}),this.U.uEnvMap.value=this.envRT.texture,this.U.uEnvMaxLod.value=Math.log2(256),this.U.uEnvWidth.value=256}setCloudTextures(e,t){this.bgMaterial.uniforms.uCloudTex.value=e,this.bgMaterial.uniforms.uCloudEnvTex.value=t,this.envPass.uniforms.uCloudEnvTex.value=t;let i=+!!e;this.bgMaterial.uniforms.uCloudEnabled.value=i,this.envPass.uniforms.uCloudEnabled.value=i}update(e){this.shared.uTimeStars.value=e,this.bgMaterial.uniforms.uTimeStars.value=e,this.envPass.uniforms.uTimeStars.value=e,this.bgMaterial.uniforms.uStarIntensity.value=this.starIntensity,this.envPass.uniforms.uStarIntensity.value=this.starIntensity}renderEnv(){this.envPass.render(this.renderer,this.envRT)}dispose(){this.envRT.dispose(),this.envPass.dispose(),this.bgMaterial.dispose(),this.mesh.geometry.dispose(),this.mesh.removeFromParent()}}let aw=L.MathUtils.lerp,ay=(e,t,i,a)=>e+(t-e)*(1-Math.exp(-i*a)),ax=[[.3,"CALM"],[1.5,"LIGHT AIR"],[3.3,"LIGHT BREEZE"],[5.5,"GENTLE BREEZE"],[7.9,"MODERATE BREEZE"],[10.7,"FRESH BREEZE"],[13.8,"STRONG BREEZE"],[17.1,"NEAR GALE"],[20.7,"GALE"],[24.4,"STRONG GALE"],[28.4,"STORM"],[32.6,"VIOLENT STORM"],[1e9,"HURRICANE"]];class aM{constructor(e,t){this.U=t,this.app=e,this.state={windSpeed:7,windAngle:.6,gustiness:.25,swellHs:1.4,swellAngle:1.1,swellPeriod:11,spread:.7,amplitude:1,choppiness:1.3,rain:0,turbidity:1,mieG:.78,sunElevation:.22,sunAzimuth:2.1,cloudCoverage:.42,cloudDensity:.55,cloudBottom:900,cloudTop:5200,cloudAnvil:0,storm:0,fog:0,spray:0,lightningRate:0,seaLevel:0,waterScatter:new L.Vector3(.01,.045,.092),waterAbsorb:new L.Vector3(.003,.016,.036),foamStrength:1,sunIntensity:22,starIntensity:1,timeScale:1},this.target=JSON.parse(JSON.stringify({...this.state,waterScatter:void 0,waterAbsorb:void 0})),this.target.waterScatter=this.state.waterScatter.clone(),this.target.waterAbsorb=this.state.waterAbsorb.clone(),this.rates={windSpeed:.28,windAngle:.15,rain:.4,turbidity:.25,sunElevation:.1,sunAzimuth:.06,cloudCoverage:.22,cloudDensity:.25,storm:.3,spray:.5,fog:.3,amplitude:.3,swellHs:.16,swellPeriod:.14,choppiness:.3,cloudAnvil:.2,sunIntensity:.4,seaLevel:.5,_default:.35},this._sunDirTmp=new L.Vector3}set(e,t=!1){for(let i of Object.keys(e))"waterScatter"===i||"waterAbsorb"===i?(this.target[i].copy(e[i]),t&&this.state[i].copy(e[i])):(this.target[i]=e[i],t&&(this.state[i]=e[i]))}update(e){let t=this.U,i=this.state,a=this.target;for(let t of Object.keys(i)){if("waterScatter"===t||"waterAbsorb"===t){i[t].x=ay(i[t].x,a[t].x,.4,e),i[t].y=ay(i[t].y,a[t].y,.4,e),i[t].z=ay(i[t].z,a[t].z,.4,e);continue}if("number"!=typeof i[t])continue;let r=(this.rates[t]??this.rates._default)*4;i[t]=ay(i[t],a[t],r,e)}let r=i.windSpeed,o=.21*this.app.time,s=r*(1+i.gustiness*(.5*Math.sin(o)+.3*Math.sin(2.37*o+1.1)+.2*Math.sin(5.1*o)));if(this.app.ocean){let e=this.app.ocean.params;e.windSpeed=s,e.windDir=i.windAngle,e.swellHs=i.swellHs,e.swellDir=i.swellAngle,e.swellPeriod=i.swellPeriod,e.spread=i.spread,e.amplitude=i.amplitude,e.choppiness=i.choppiness;let a=L.MathUtils.clamp(384e-8*Math.pow(Math.max(s,.1),3.41),0,.16),o=L.MathUtils.clamp(r/30,0,1);e.foamBias=aw(.01,.16,o),e.steepBias=aw(.85,.52,o),e.foamMul=aw(.3,.95,o)*i.foamStrength,e.foamDecay=aw(.9,.28,o),e.bubbleDecay=aw(.35,.11,o),t.uWhitecapCoverage.value=a}t.uWindSpeed.value=s,this.U.uWindDir.value.set(Math.cos(i.windAngle),Math.sin(i.windAngle)),this.U.uGustiness.value=i.gustiness,this.U.uRain.value=i.rain,this.U.uFogDensity.value=i.fog,this.U.uSprayAmount.value=i.spray,this.U.uStormFactor.value=i.storm,this.U.uSeaLevel.value=i.seaLevel;let n=i.sunElevation,l=i.sunAzimuth;if(this._sunDirTmp.set(Math.cos(n)*Math.cos(l),Math.sin(n),Math.cos(n)*Math.sin(l)).normalize(),this.U.uSunDir.value.copy(this._sunDirTmp),this.app.atmosphere.sunDir.copy(this._sunDirTmp),this.app.atmosphere.turbidity=i.turbidity,this.app.atmosphere.mieG=i.mieG,this.app.atmosphere.sunIntensity=i.sunIntensity,this.U.uSunIntensity.value=i.sunIntensity,this.U.uAtmoTurbidity.value=i.turbidity,this.U.uAtmoMieG.value=i.mieG,this.U.uMoonDir.value.set(-Math.cos(.6*n)*Math.cos(l+2.6),Math.max(.25,-(.8*Math.sin(n))+.35),-Math.cos(.6*n)*Math.sin(l+2.6)).normalize(),this.app.sky.starIntensity=i.starIntensity,this.app.oceanMesh){let e=this.app.oceanMesh.uniforms;e.uWaterScatter.value.copy(i.waterScatter),e.uWaterAbsorb.value.copy(i.waterAbsorb),e.uFoamStrength.value=i.foamStrength}let h=this.app.clouds?.shared;if(h){h.uCoverage.value=i.cloudCoverage,h.uCloudDensity.value=i.cloudDensity,h.uCloudBottom.value=i.cloudBottom,h.uCloudTop.value=Math.max(i.cloudTop,i.cloudBottom+400),h.uAnvil.value=i.cloudAnvil;let e=i.windAngle+.35,t=2.5+.42*r;h.uCloudWind.value.set(Math.cos(e)*t,Math.sin(e)*t),h.uCloudScaleM.value=aw(7e3,2e4,L.MathUtils.clamp(i.storm,0,1))}this.beaufort=function(e){for(let t=0;t<ax.length;t++)if(e<ax[t][0])return[t,ax[t][1]];return[12,"HURRICANE"]}(s)}}let aS=`
#ifndef OCEAN_SAMPLE_GLSL
#define OCEAN_SAMPLE_GLSL 1

uniform sampler2D uOceanDisp0, uOceanDisp1, uOceanDisp2;
uniform sampler2D uOceanDeriv0, uOceanDeriv1, uOceanDeriv2;
uniform sampler2D uOceanTurb0, uOceanTurb1, uOceanTurb2;
uniform vec3 uOceanScales;
uniform float uOceanTexels;
uniform float uOceanAniso;
uniform vec3 uCascadeGain;
uniform sampler2D uCurlTex;

uniform vec4 uVortex0, uVortex1, uVortex2, uVortex3;
uniform vec4 uSoliton0, uSoliton0b, uSoliton1, uSoliton1b;
uniform vec4 uRogue, uRogueB;
uniform vec4 uHurricane;
uniform vec2 uWindDir;
uniform float uWindSpeed;
uniform float uGustiness;
uniform float uEarthCurvature;
uniform float uSeaLevel;

const float EARTH_R = 6371000.0;

// ------------------------------------------------------------ current field
// Slowly varying divergence-free-ish flow used to advect the small cascades.
vec2 currentAt(vec2 p, float t) {
  vec2 uv = p * 0.00022 + vec2(t * 0.0009, -t * 0.0006);
  vec4 c = texture(uCurlTex, uv);
  vec2 f = (c.xy * 2.0 - 1.0);
  vec2 uv2 = p * 0.0009 - vec2(t * 0.0021, t * 0.0013);
  vec4 c2 = texture(uCurlTex, uv2);
  f += (c2.xy * 2.0 - 1.0) * 0.45;
  return f;
}

// ------------------------------------------------------------------ vortex
// Returns swirl rotation angle at p and writes the funnel depression.
float vortexField(vec2 p, vec4 v, inout float depression, inout float shear) {
  if (v.w <= 0.0001) return 0.0;
  vec2 d = p - v.xy;
  float r = length(d) + 1e-3;
  float R = max(v.z, 1.0);
  float x = r / R;
  // Rankine-like vortex: solid body inside the core, 1/r outside
  float vt = (x < 1.0) ? x : 1.0 / (x * x * 0.65 + 0.35);
  float env = exp(-x * x * 0.55);
  depression -= v.w * (1.0 / (1.0 + x * x * 2.2)) * 1.0;
  // Foam from shear saturates rather than tracking strength linearly: past a
  // point the surface is already fully broken and cannot get whiter. Without
  // the ceiling a forty metre maelstrom asks for four times full coverage and
  // the spiral arms merge into one disc of white paint.
  shear += vt * env * min(v.w * 0.022, 0.62);
  return vt * env * v.w * 0.09;
}

// ---------------------------------------------------------------- soliton
/**
 * Crest profile of the travelling solitary wave, normalised to a peak of one.
 *
 * x runs along the direction of travel, measured from the crest, so x > 0 is
 * the water the wave has not reached yet and the flank facing that way is the
 * one that breaks.
 *
 * A deep-water soliton is a symmetric sech^2 mound. At the amplitude a tsunami
 * really carries offshore that is a 1-in-40 slope — invisible from any camera
 * you would want to put in the shot, which is exactly why ships ride them out
 * without noticing. What everybody pictures is the shoaling form: the front has
 * run out of depth and stood up while the back is still in deep water.
 * Compressing the leading half of the coordinate reproduces that asymmetry
 * while staying a single smooth function of x, so normals, foam and the CPU
 * mirror all follow from it for free.
 *
 * Keep this in step with Director.eventHeight(), which evaluates the same
 * profile on the CPU for the camera to ride.
 */
float solitonProfile(float x, float w, float steep) {
  float xf = x > 0.0 ? x * (1.0 + steep * 1.35) : x;
  float s = 1.0 / cosh(clamp(xf / w, -12.0, 12.0));
  // Drawdown ahead of the face. The volume standing up in the crest has to come
  // from somewhere, and it comes from the water immediately in front — which is
  // the sea running out before it lands.
  float d = 1.0 / cosh(clamp((x - w * 1.6) / (w * 1.1), -12.0, 12.0));
  return s * s - d * d * 0.16 * steep;
}

float solitonHeight(vec2 p, vec4 s, vec4 sb, out vec2 pushDir, out float crest) {
  pushDir = vec2(0.0); crest = 0.0;
  if (s.w <= 0.001) return 0.0;
  vec2 dir = normalize(s.xy);
  float x = dot(p, dir) - s.z;
  float w = max(sb.x, 1.0);
  // lateral extent so the wave is a finite front, not infinite
  float lateral = dot(p, vec2(-dir.y, dir.x));
  float latEnv = exp(-lateral * lateral / (sb.z * sb.z + 1.0));

  float steep = sb.y;
  float prof = solitonProfile(x, w, steep);
  float h = s.w * prof * latEnv;

  // Overhang. Water near the crest is thrown forward over the face, which is
  // what a wave about to break looks like and what stops the wall reading as a
  // smooth ramp. Concentrating it in the top of the crest — prof squared, which
  // falls to nothing within a wave length — is what keeps it from translating
  // the whole neighbourhood bodily and tearing a hole under the camera.
  float top = clamp(prof, 0.0, 1.0);
  pushDir = dir * (top * top * min(s.w, w * 0.4) * steep * 0.28 * latEnv);

  // Foam belongs on the breaking lip and in the wash running down the face —
  // not spread over the whole shoulder, which reads as a painted slab rather
  // than as water. Keep it to the top of the profile and bias it forward.
  float faceBias = mix(0.25, 1.0, smoothstep(-w * 0.35, w * 0.2, x));
  crest = smoothstep(0.80, 0.985, prof) * latEnv * faceBias;
  return h;
}

// -------------------------------------------------------------- rogue group
float rogueGroup(vec2 p, out vec2 push, out float crest) {
  push = vec2(0.0); crest = 0.0;
  if (uRogue.w <= 0.001) return 0.0;
  vec2 d = p - uRogue.xy;
  float R = max(uRogue.z, 1.0);
  float env = exp(-dot(d, d) / (R * R));
  vec2 dir = normalize(uRogueB.xy + 1e-6);
  float k = 6.28318530718 / max(uRogueB.z, 4.0);
  float phase = dot(d, dir) * k + uRogueB.w;
  float h = 0.0;
  // three-mode Gerstner group -> peaky crest, flat trough
  h += cos(phase) * 1.0;
  h += cos(phase * 1.87 + 1.1) * 0.42;
  h += cos(phase * 0.61 - 0.7) * 0.55;
  h = h / 1.97;
  float peaky = sign(h) * pow(abs(h), 0.72);
  push = dir * (-sin(phase) * env * uRogue.w * 0.45);
  crest = smoothstep(0.55, 1.0, peaky) * env;
  return peaky * env * uRogue.w;
}

// ------------------------------------------------------------- hurricane
// Large rotating swell plus an eye of glassy calm.
float hurricaneField(vec2 p, out vec2 swirl, out float calm) {
  swirl = vec2(0.0); calm = 0.0;
  if (uHurricane.w <= 0.001) return 0.0;
  vec2 d = p - uHurricane.xy;
  float r = length(d) + 1e-3;
  float eye = max(uHurricane.z, 50.0);
  float x = r / eye;
  calm = exp(-x * x * 1.6);
  vec2 tang = vec2(-d.y, d.x) / r;
  float vt = (x < 1.0) ? x * 1.05 : 1.0 / pow(x, 0.55);
  swirl = tang * vt * uHurricane.w;
  // eyewall swell ring
  float ring = exp(-pow((x - 1.25) * 1.4, 2.0));
  return ring * uHurricane.w * 3.0 - calm * uHurricane.w * 0.4;
}

/**
 * Vertical-only disaster displacement. Mirrors oceanModifiers().y, minus the
 * horizontal push and the crest/calm outputs.
 *
 * The projected grid places samples by intersecting view rays with a flat
 * plane. That is a fine approximation for wind waves, which are metres tall,
 * and a terrible one for events that lift the surface by tens of metres: the
 * band of rays that lands on a tsunami is then a fraction of a degree wide, so
 * the wall is drawn by a handful of vertex rows however dense the grid is.
 * Iterating the intersection against this height restores a uniform
 * screen-space distribution, so it needs to be cheap.
 */
float oceanEventHeight(vec2 p) {
  float h = 0.0;

  vec4 vs[4];
  vs[0] = uVortex0; vs[1] = uVortex1; vs[2] = uVortex2; vs[3] = uVortex3;
  for (int i = 0; i < 4; i++) {
    if (vs[i].w <= 0.0001) continue;
    float x = (length(p - vs[i].xy) + 1e-3) / max(vs[i].z, 1.0);
    h -= vs[i].w / (1.0 + x * x * 2.2);
  }

  vec4 ss[2]; vec4 sbs[2];
  ss[0] = uSoliton0; sbs[0] = uSoliton0b;
  ss[1] = uSoliton1; sbs[1] = uSoliton1b;
  for (int i = 0; i < 2; i++) {
    if (ss[i].w <= 0.001) continue;
    vec2 dir = normalize(ss[i].xy);
    float x = dot(p, dir) - ss[i].z;
    float w = max(sbs[i].x, 1.0);
    float lateral = dot(p, vec2(-dir.y, dir.x));
    float latEnv = exp(-lateral * lateral / (sbs[i].z * sbs[i].z + 1.0));
    h += ss[i].w * solitonProfile(x, w, sbs[i].y) * latEnv;
  }

  if (uRogue.w > 0.001) {
    vec2 d = p - uRogue.xy;
    float R = max(uRogue.z, 1.0);
    float env = exp(-dot(d, d) / (R * R));
    vec2 dir = normalize(uRogueB.xy + 1e-6);
    float phase = dot(d, dir) * (6.28318530718 / max(uRogueB.z, 4.0)) + uRogueB.w;
    float g = (cos(phase) + cos(phase * 1.87 + 1.1) * 0.42 + cos(phase * 0.61 - 0.7) * 0.55) / 1.97;
    h += sign(g) * pow(abs(g), 0.72) * env * uRogue.w;
  }

  if (uHurricane.w > 0.001) {
    vec2 d = p - uHurricane.xy;
    float x = (length(d) + 1e-3) / max(uHurricane.z, 50.0);
    float ring = exp(-pow((x - 1.25) * 1.4, 2.0));
    h += ring * uHurricane.w * 3.0 - exp(-x * x * 1.6) * uHurricane.w * 0.4;
  }

  return h;
}

// ------------------------------------------------------- cascade fetching
struct OceanSample {
  vec3 disp;
  float jacobian;
  vec4 turb;       // foam, bubbles, crest, spray
  vec4 deriv;      // dYdx, dYdz, lambdaDxDx, lambdaDzDz
};

vec2 warpCoord(vec2 p, float t, float amount) {
  vec2 flow = currentAt(p, t);
  return p + flow * amount;
}

/** Vertex-side displacement with explicit LOD. */
vec3 oceanDisplacementLod(vec2 p, vec3 lods, out float foamHint) {
  vec3 d = vec3(0.0);
  foamHint = 0.0;
  if (uCascadeGain.x > 0.001) {
    vec4 s = textureLod(uOceanDisp0, p / uOceanScales.x, lods.x);
    d += s.xyz * uCascadeGain.x;
  }
  if (uCascadeGain.y > 0.001 && lods.y < 7.5) {
    vec4 s = textureLod(uOceanDisp1, p / uOceanScales.y, lods.y);
    d += s.xyz * uCascadeGain.y;
  }
  if (uCascadeGain.z > 0.001 && lods.z < 7.5) {
    vec4 s = textureLod(uOceanDisp2, p / uOceanScales.z, lods.z);
    d += s.xyz * uCascadeGain.z;
  }
  return d;
}

/** Full analytic modifier stack, shared by vertex + CPU-side probes. */
vec3 oceanModifiers(vec2 p, float t, out float crestOut, out float calmOut) {
  vec3 d = vec3(0.0);
  crestOut = 0.0;
  calmOut = 0.0;

  float depression = 0.0, shear = 0.0;
  float a0 = vortexField(p, uVortex0, depression, shear);
  float a1 = vortexField(p, uVortex1, depression, shear);
  float a2 = vortexField(p, uVortex2, depression, shear);
  float a3 = vortexField(p, uVortex3, depression, shear);
  d.y += depression;
  crestOut += shear;

  vec2 push; float crest;
  d.y += solitonHeight(p, uSoliton0, uSoliton0b, push, crest);
  d.xz += push; crestOut = max(crestOut, crest);
  d.y += solitonHeight(p, uSoliton1, uSoliton1b, push, crest);
  d.xz += push; crestOut = max(crestOut, crest);

  d.y += rogueGroup(p, push, crest);
  d.xz += push; crestOut = max(crestOut, crest);

  vec2 swirl; float calm;
  d.y += hurricaneField(p, swirl, calm);
  calmOut = calm;

  return d;
}

/** Rotation applied to cascade lookups so vortices actually swirl the water. */
vec2 swirlCoords(vec2 p, float t) {
  vec2 q = p;
  vec4 vs[4];
  vs[0] = uVortex0; vs[1] = uVortex1; vs[2] = uVortex2; vs[3] = uVortex3;
  for (int i = 0; i < 4; i++) {
    vec4 v = vs[i];
    if (v.w <= 0.0001) continue;
    vec2 d = q - v.xy;
    float r = length(d) + 1e-3;
    float R = max(v.z, 1.0);
    float x = r / R;
    float vt = (x < 1.0) ? x : 1.0 / (x * x * 0.6 + 0.4);
    float ang = vt * exp(-x * x * 0.5) * v.w * 0.05 * t;
    float c = cos(ang), s = sin(ang);
    q = v.xy + mat2(c, -s, s, c) * d;
  }
  if (uHurricane.w > 0.001) {
    vec2 d = q - uHurricane.xy;
    float r = length(d) + 1e-3;
    float x = r / max(uHurricane.z, 50.0);
    float vt = (x < 1.0) ? x : 1.0 / pow(max(x, 1e-3), 0.6);
    float ang = vt * uHurricane.w * 0.0015 * t;
    float c = cos(ang), s = sin(ang);
    q = uHurricane.xy + mat2(c, -s, s, c) * d;
  }
  return q;
}

float earthDrop(vec2 p, vec3 camPos) {
  float r2 = dot(p - camPos.xz, p - camPos.xz);
  return uEarthCurvature * r2 / (2.0 * EARTH_R);
}

#endif
`,aT=`
precision highp float;
in vec3 position;
in vec2 uv;
in float aIndex;

uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform vec3 uCamPos;
uniform vec3 uCamFwd;
uniform float uTime;
uniform float uRain;
uniform vec2 uWindDir;
uniform float uWindSpeed;
uniform float uGustiness;
uniform vec2 uBox;          // (half extent, height)
uniform float uCount;
uniform float uStreak;      // shutter length in seconds
uniform float uSeaLevel;
uniform float uPixelScale;  // world units per pixel at one metre of depth
uniform float uDebug;

out vec2 vUv;
out float vFade;
out float vSeed;
out float vThin;
out vec3 vWorld;

${iJ}

void main(){
  float id = aIndex;
  vec3 h = hash33(vec3(id * 0.0013, id * 0.0071, id * 0.0037));
  vSeed = h.z;

  // Only a fraction of the slots are live at low rain rates. Fading a drop in
  // rather than popping it keeps the onset of a squall smooth.
  float live = step(h.x, clamp(uRain * 1.15, 0.0, 1.0));

  // Bias the field toward the camera's view direction: rain behind the lens is
  // wasted geometry, so the box is pushed forward along the look vector.
  vec3 anchor = uCamPos + uCamFwd * uBox.x * 0.45;
  anchor.y = uCamPos.y;

  // terminal velocity of a raindrop, 4 m/s for drizzle to 9 m/s for a downpour
  float size = mix(0.35, 1.0, h.y);
  float vy = mix(4.2, 9.4, size) * mix(0.85, 1.15, h.z);
  vec2 gust = uWindDir * uWindSpeed * (0.78 + uGustiness * 0.5 * sin(uTime * 0.7 + h.z * 6.28));

  // wrap the fall so the slot recycles without any state
  float fall = mod(h.z * uBox.y + uTime * vy, uBox.y);
  vec3 wp;
  wp.y = anchor.y + uBox.y * 0.55 - fall;

  // Uniform density in space wastes almost every drop: at 80 m a raindrop is
  // far under a pixel. Biasing the radius toward the camera gives roughly
  // uniform density on screen instead, which is what the eye reads as rain.
  float ang = h.x * 6.2831853;
  float rad = uBox.x * pow(h.y, 1.7);
  vec2 drift = gust * (fall / max(vy, 0.1));
  wp.xz = anchor.xz + vec2(cos(ang), sin(ang)) * rad + drift;
  // keep the slab centred on the camera as the drift carries it away
  wp.xz -= floor((wp.xz - anchor.xz) / (2.0 * uBox.x) + 0.5) * (2.0 * uBox.x);

  vec3 vel = vec3(gust.x, -vy, gust.y);
  float speed = length(vel);
  vec3 dir = vel / max(speed, 1e-4);

  vec3 toEye = uCamPos - wp;
  float dist = length(toEye);
  toEye /= max(dist, 1e-4);
  vec3 side = normalize(cross(dir, toEye));

  // The streak is what the shutter integrates: the drop's own length is
  // irrelevant, only how far it travels while the frame is open.
  float len = clamp(speed * uStreak, 0.30, 3.2) * mix(0.7, 1.3, size);

  // A raindrop is a few millimetres across, which is far under a pixel at any
  // useful distance. Rasterising that honestly gives a flickering dotted mess,
  // so the quad is held at a floor of about one pixel and the opacity is scaled
  // down by exactly the factor it was widened. That keeps the total light the
  // streak contributes correct, and it is what makes distant rain settle into a
  // grey veil instead of a swarm of confetti.
  float worldPerPx = uPixelScale * dist;
  float trueWide = mix(0.002, 0.006, size);
  float wide = max(trueWide, worldPerPx * 1.15);
  vThin = clamp(trueWide / wide, 0.0, 1.0);

  vec3 p = wp + dir * (position.y - 0.5) * len + side * position.x * wide;

  // Rain arrives in curtains, not as a uniform field. A slow noise sheet
  // drifting downwind gates whole swathes of the box, which is most of what
  // sells a squall — and it means the near field breathes as gusts pass.
  vec2 curtainUv = (wp.xz - uWindDir * uTime * 9.0) * 0.0055;
  float curtain = fbm2Tiled(curtainUv, 64.0, 3) * 0.5 + 0.55;
  curtain = smoothstep(0.30, 0.72, curtain + uRain * 0.35);

  // fade at the box edges and kill anything that has fallen into the sea
  float edge = 1.0 - smoothstep(uBox.x * 0.72, uBox.x, length(wp.xz - anchor.xz));
  float above = smoothstep(-0.5, 2.0, wp.y - uSeaLevel);
  vFade = live * edge * above * curtain * clamp(uRain * 1.6, 0.0, 1.0);

  vUv = vec2(position.x, position.y);
  vWorld = wp;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  if (vFade <= 0.001) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); }
}
`,aC=`
precision highp float;
precision highp sampler2D;
in vec2 vUv;
in float vFade;
in float vSeed;
in float vThin;
in vec3 vWorld;

uniform sampler2D uEnvMap;
uniform float uEnvMaxLod;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunIntensity;
uniform vec3 uCamPos;
uniform vec3 uLightningColor;
uniform float uAmbientFlash;
uniform float uDebug;

${al}

layout(location = 0) out vec4 oColor;

void main(){
  // cylindrical cross-section: bright core falling off to the edges
  float r = vUv.x * 2.0;
  float body = sqrt(max(1.0 - r * r, 0.0));
  float ends = smoothstep(0.0, 0.12, vUv.y) * (1.0 - smoothstep(0.88, 1.0, vUv.y));
  if (uDebug > 0.5) {
    float ad = vFade * body * ends;
    oColor = vec4(vec3(30.0, 0.0, 30.0) * ad, ad);

    return;
  }

  // A drop is a lens. It gathers light from a wide cone and concentrates it
  // toward the eye, which is why rain reads bright against a dark sea even
  // under a flat grey sky — the streak is far brighter than the sky behind it.
  vec3 up = vec3(0.0, 1.0, 0.0);
  vec3 look = normalize(vWorld - uCamPos);
  vec3 refr = normalize(mix(look, up, 0.55 + r * 0.25));
  vec3 lens = textureLod(uEnvMap, dirToEquirect(refr), uEnvMaxLod * 0.45).rgb;

  // total internal reflection puts a hard glint on the sun side of the drop
  float glint = pow(max(dot(refr, uSunDir), 0.0), 24.0);
  vec3 col = lens * (0.85 + body * 0.35) + uSunColor * uSunIntensity * glint * 0.9;
  col += uLightningColor * uAmbientFlash * 2.5;

  float a = vFade * body * ends * vThin * 0.7;
  oColor = vec4(col * a, a);
  // leave the velocity/depth buffer alone: these are transparent overlays and
  // should inherit the motion of whatever they are drawn over

}
`;class aP{constructor(e,t,i,a){this.U=t;const r=new L.InstancedBufferGeometry,o=new Float32Array([-.5,0,0,.5,0,0,.5,1,0,-.5,0,0,.5,1,0,-.5,1,0]),s=new Float32Array([0,0,1,0,1,1,0,0,1,1,0,1]);r.setAttribute("position",new L.BufferAttribute(o,3)),r.setAttribute("uv",new L.BufferAttribute(s,2)),this.max=e.rainCount??24e3;const n=new Float32Array(this.max);for(let e=0;e<this.max;e++)n[e]=e;r.setAttribute("aIndex",new L.InstancedBufferAttribute(n,1)),r.instanceCount=0,r.boundingSphere=new L.Sphere(new L.Vector3,1e6),this.material=new L.RawShaderMaterial({name:"Rain",glslVersion:L.GLSL3,vertexShader:aT.replace("void main(){",i+"\nvoid main(){").replace("vUv = vec2(position.x, position.y);","vFade *= step(roofAt(wp.xz) + len, wp.y); vUv = vec2(position.x, position.y);"),fragmentShader:aC,uniforms:{...a,uCamPos:this.U.uCamPos,uCamFwd:{value:new L.Vector3(0,0,-1)},uTime:this.U.uTime,uRain:this.U.uRain,uWindDir:this.U.uWindDir,uWindSpeed:this.U.uWindSpeed,uGustiness:this.U.uGustiness,uSeaLevel:this.U.uSeaLevel,uBox:{value:new L.Vector2(80,52)},uCount:{value:this.max},uStreak:{value:.022},uPixelScale:{value:.002},uEnvMap:this.U.uEnvMap,uEnvMaxLod:this.U.uEnvMaxLod,uSunDir:this.U.uSunDir,uSunColor:this.U.uSunColor,uSunIntensity:this.U.uSunIntensity,uLightningColor:this.U.uLightningColor,uAmbientFlash:this.U.uAmbientFlash,uDebug:{value:0}},transparent:!0,depthWrite:!1,depthTest:!0,side:L.DoubleSide,blending:L.CustomBlending,blendSrc:L.OneFactor,blendDst:L.OneMinusSrcAlphaFactor}),this.mesh=new L.Mesh(r,this.material),this.mesh.frustumCulled=!1,this.mesh.renderOrder=6,this.geom=r}setQuality(e){this.max=Math.min(this.max,e.rainCount??this.max),this.budget=e.rainCount??this.max}update(e,t,i){let a=Math.min(this.max,Math.ceil((this.budget??this.max)*Math.min(1.2*t,1)));if(this.geom.instanceCount=a,this.mesh.visible=a>0,0===a)return;e.getWorldDirection(this.material.uniforms.uCamFwd.value);let r=Math.max(i||720,16);this.material.uniforms.uPixelScale.value=2*Math.tan(.5*e.fov*Math.PI/180)/r}dispose(){this.geom.dispose(),this.material.dispose(),this.mesh.removeFromParent()}}let aA=`
precision highp float;
precision highp sampler2D;

uniform sampler2D uPos;      // xyz = world position, w = age
uniform sampler2D uVel;      // xyz = velocity, w = seed
uniform float uDt;
uniform float uTime;
uniform vec3 uCamPos;
uniform float uSprayAmount;
uniform float uRadius;
uniform float uFrame;
uniform float uDisplaceScale;
uniform float uCurrentStrength;

${iJ}
${aS}
${iA}
${ik}

in vec2 vUv;
layout(location = 0) out vec4 oPos;
layout(location = 1) out vec4 oVel;

/**
 * Sea surface height under a world xz, including the analytic modifiers.
 * Use level zero for collision against the full-resolution wave surface.
 */
float seaHeight(vec2 xz, out float breaking) {
  float foamHint;
  // Invert horizontal chop before sampling height: rendered crests are displaced
  // sideways, so sampling at world XZ otherwise emits below the visible surface.
  vec2 baseXZ = xz;
  for (int i = 0; i < 2; i++) {
    vec2 uv = warpCoord(swirlCoords(baseXZ, uTime), uTime, uCurrentStrength);
    vec3 offset = oceanDisplacementLod(uv, vec3(0.), foamHint);
    baseXZ = xz - offset.xz * smoothstep(0., 10., uSeaLevel - islandHeight(baseXZ)) * uDisplaceScale;
  }
  vec2 q = warpCoord(swirlCoords(baseXZ, uTime), uTime, uCurrentStrength);
  float depth = uSeaLevel - islandHeight(baseXZ);
  float shoal = smoothstep(0., 10., depth);
  vec3 d = oceanDisplacementLod(q, vec3(0.0), foamHint);
  float crest, calm;
  vec3 m = oceanModifiers(baseXZ, uTime, crest, calm);
  // spray is torn where the wind sea breaks; the swell cascade contributes the
  // big plunging crests and the capillary one is far too fine to matter
  vec4 t0 = texture(uOceanTurb0, q / uOceanScales.x);
  vec4 t1 = texture(uOceanTurb1, q / uOceanScales.y);
  float surf = smoothstep(.45, .94, sin(shorePhase(baseXZ, depth)))
             * smoothstep(.15, .7, depth) * (1. - smoothstep(2., 5., depth)) * shoreBreakup(baseXZ);
  breaking = max(max(t1.a, t0.a * .7) * shoal, surf * .65) * step(.1, depth);
  return (d.y * shoal * uDisplaceScale + shoreHeight(baseXZ)) * (1. - calm * .8) + m.y + uSeaLevel;
}

void main(){
  vec4 P = texture(uPos, vUv);
  vec4 V = texture(uVel, vUv);
  float age = P.w;
  float seed = V.w;

  // NaN never compares true, so a texel that started as uninitialised garbage
  // would stay "alive" forever with a position that never rasterises.
  bool dead = !(age > 0.0 && all(lessThan(abs(P.xyz), vec3(1e5))) && all(lessThan(abs(V.xyz), vec3(1e4))));
  if (!dead) {
    // drag toward the local wind, gravity, and a little turbulent jitter
    vec3 wind = vec3(uWindDir.x, 0.0, uWindDir.y) * uWindSpeed;
    vec3 rel = wind - V.xyz;
    // small droplets couple to the air much faster than large ones
    float drag = mix(0.35, 2.6, seed);
    V.xyz += (rel * drag - vec3(0.0, 9.81, 0.0)) * uDt;
    V.xyz += (hash33(P.xyz * 0.7 + uTime) - 0.5) * uWindSpeed * 0.35 * uDt;
    P.xyz += V.xyz * uDt;
    age -= uDt;

    float breaking;
    float sea = seaHeight(P.xz, breaking);
    if (P.y < max(sea - 0.15, islandHeight(P.xz))) age = 0.0;
    if (length(P.xz - uCamPos.xz) > uRadius * 1.35) age = 0.0;
    dead = age <= 0.0;
  }

  if (dead) {
    // Look for a breaking crest to be born on. Whitecaps cover a few percent of
    // the sea even in a gale, so a single blind candidate per frame would take
    // a hundred frames to fill the budget; three keeps the refill snappy while
    // the cost stays a fixed handful of taps.
    P = vec4(0.0, -1e6, 0.0, 0.0);
    V = vec4(0.0);
    for (int k = 0; k < 3; k++) {
      vec3 r = hash33(vec3(vUv * 512.0, uFrame * 0.017 + float(k) * 7.31));
      float ang = r.x * 6.2831853;
      // Uniform area sampling puts almost every droplet in the far ring where
      // it is sub-pixel. Bias the radius inward so screen density is even.
      float rad = uRadius * pow(r.y, 1.55) + 4.0;
      vec2 xz = uCamPos.xz + vec2(cos(ang), sin(ang)) * rad;
      float breaking;
      float sea = seaHeight(xz, breaking);

      if (r.z < breaking * uSprayAmount * 2.2) {
        vec3 wind = vec3(uWindDir.x, 0.0, uWindDir.y) * uWindSpeed;
        float dropletSeed = fract(r.x * 13.71 + r.y * 7.13);
        P = vec4(xz.x, sea + 0.3, xz.y, mix(1.1, 3.4, dropletSeed));
        // torn off the crest: mostly downwind, with an upward kick
        vec3 kick = wind * mix(0.45, 1.05, r.x)
                  + vec3(0.0, 1.0, 0.0) * (3.5 + breaking * 9.0) * mix(0.6, 1.5, r.y);
        // splash out sideways as well, so a crest reads as a bursting sheet
        vec2 lat = vec2(-uWindDir.y, uWindDir.x) * (r.x - 0.5) * uWindSpeed * 0.35;
        V = vec4(kick + vec3(lat.x, 0.0, lat.y), dropletSeed);
        break;
      }
    }
  } else {
    P.w = age;
  }

  oPos = P;
  oVel = V;
}
`,ak=`
precision highp float;
precision highp sampler2D;
in vec3 position;
in vec2 aTexel;

uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform sampler2D uPos;
uniform sampler2D uVel;
uniform vec3 uCamPos;
uniform float uSize;
uniform float uDebug;

out vec2 vUv;
out float vAlpha;
out float vSeed;
out vec3 vWorld;

void main(){
  // explicit level: a vertex stage has no derivatives to pick one from
  vec4 P = textureLod(uPos, aTexel, 0.0);
  vec4 V = textureLod(uVel, aTexel, 0.0);
  vUv = position.xy;

  if (uDebug > 1.5) {
    vAlpha = P.w > 0.0 ? 1.0 : 0.0; vSeed = 0.5;
    vec3 c = P.xyz;
    vWorld = c;
    vec3 te = normalize(uCamPos - c);
    vec3 sd = normalize(cross(vec3(0.0, 1.0, 0.0), te));
    vec3 upv = cross(te, sd);
    gl_Position = projectionMatrix * modelViewMatrix
                * vec4(c + sd * position.x * 2.0 + upv * position.y * 2.0, 1.0);
    return;
  }
  vSeed = V.w;

  if (P.w <= 0.0) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vAlpha = 0.0; return; }

  // fade in as it is torn off, fade out as the droplet evaporates or falls
  float life = clamp(P.w / mix(1.1, 3.4, V.w), 0.0, 1.0);
  vAlpha = smoothstep(0.0, 0.12, 1.0 - life) * smoothstep(0.0, 0.35, life);

  vec3 toEye = uCamPos - P.xyz;
  float dist = length(toEye);
  toEye /= max(dist, 1e-4);
  vec3 side = normalize(cross(vec3(0.0, 1.0, 0.0), toEye));
  vec3 up = cross(toEye, side);

  // stretch along the direction of travel: fast droplets read as streaks
  float speed = length(V.xyz);
  vec3 dir = V.xyz / max(speed, 1e-4);
  float stretch = 1.0 + clamp(speed * 0.05, 0.0, 2.2);
  vec3 axis = normalize(dir - toEye * dot(dir, toEye) + side * 1e-5);
  vec3 perp = cross(axis, toEye);

  // grow with distance so a far plume keeps a few pixels instead of aliasing
  // Fine droplets keep their physical size; only a minority become soft mist.
  float mist = smoothstep(.72, .95, vSeed);
  float s = uSize * mix(.3, 6., mist) * (1.0 + min(dist, 80.) * .004);
  vAlpha *= mix(.38, .095, mist) * smoothstep(2., 6., dist);
  vec3 wp = P.xyz + axis * (position.y * s * stretch) + perp * (position.x * s);

  vWorld = wp;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(wp, 1.0);
}
`,aD=`
precision highp float;
precision highp sampler2D;
in vec2 vUv;
in float vAlpha;
in float vSeed;
in vec3 vWorld;

uniform sampler2D uEnvMap;
uniform float uEnvMaxLod;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunIntensity;
uniform vec3 uCamPos;
uniform vec3 uLightningColor;
uniform float uAmbientFlash;
uniform float uDebug;
uniform float uStormFactor;

${al}
${iJ}

layout(location = 0) out vec4 oColor;

void main(){
  float d = length(vUv);
  if (d > 1.0) discard;
  // soft droplet cluster, denser in the middle
  float a = exp(-d * d * 5.0) * (1.0 - smoothstep(.7, 1., d)) * vAlpha;
  // Break up the mist sheet into wisps without swimming world-space noise.
  vec2 eddy = vUv * vec2(5., 8.) + vSeed * 91.;
  float wisps = vnoise2(eddy) * .65 + vnoise2(eddy * 2.7) * .35;
  a *= mix(1., smoothstep(.2, .72, wisps), smoothstep(.72, .95, vSeed));
  if (uDebug > 0.5) {
    oColor = vec4(vec3(0.0, 30.0, 10.0) * a, a);
    return;
  }

  vec3 look = normalize(vWorld - uCamPos);
  // A droplet cloud scatters mostly forward: it lights up when the sun is
  // behind it, which is what makes wind-torn spray glow off a wave crest.
  float mu = dot(look, uSunDir);
  float phase = 0.55 + 1.9 * pow(max(mu, 0.0), 6.0);

  vec3 sky = textureLod(uEnvMap, dirToEquirect(vec3(look.x, abs(look.y) * 0.5 + 0.2, look.z)), uEnvMaxLod * 0.6).rgb;
  vec3 col = sky * 2.8 + uSunColor * uSunIntensity * phase * mix(.12, .035, uStormFactor);
  col += uLightningColor * uAmbientFlash * 0.5;

  oColor = vec4(col * a, a * 0.85);
}
`;class az{constructor(e,t,i,a,r){this.renderer=e,this.size=0,this.oceanFFT=t,this.simUniforms={...a,uPos:{value:null},uVel:{value:null},uDt:{value:.016},uTime:r.uTime,uFrame:r.uFrame,uCamPos:r.uCamPos,uSprayAmount:r.uSprayAmount,uRadius:{value:160},...r},t.bind(this.simUniforms),this.simPass=new iZ(aA,this.simUniforms,{name:"spraySim"}),this.material=new L.RawShaderMaterial({name:"Spray",glslVersion:L.GLSL3,vertexShader:ak,fragmentShader:aD,uniforms:{uPos:{value:null},uVel:{value:null},uCamPos:r.uCamPos,uSize:{value:.12},uDebug:{value:0},uEnvMap:r.uEnvMap,uEnvMaxLod:r.uEnvMaxLod,uSunDir:r.uSunDir,uSunColor:r.uSunColor,uSunIntensity:r.uSunIntensity,uLightningColor:r.uLightningColor,uAmbientFlash:r.uAmbientFlash,uStormFactor:r.uStormFactor},transparent:!0,depthWrite:!1,depthTest:!0,blending:L.CustomBlending,blendSrc:L.OneFactor,blendDst:L.OneMinusSrcAlphaFactor});const o=new L.InstancedBufferGeometry;o.setAttribute("position",new L.BufferAttribute(new Float32Array([-1,-1,0,1,-1,0,1,1,0,-1,-1,0,1,1,0,-1,1,0]),3)),o.boundingSphere=new L.Sphere(new L.Vector3,1e6),this.geom=o,this.mesh=new L.Mesh(o,this.material),this.mesh.frustumCulled=!1,this.mesh.renderOrder=7,this.setQuality(i)}setQuality(e){let t=Math.max(8,Math.round(Math.sqrt(e.sprayCount??4096)));if(t===this.size)return;this.size=t,this.state?.dispose(),this.state=new iQ(t,t,{type:L.FloatType,minFilter:L.NearestFilter,magFilter:L.NearestFilter,count:2,name:"sprayState"});let i=new Float32Array(t*t*2);for(let e=0,a=0;e<t;e++)for(let r=0;r<t;r++,a+=2)i[a]=(r+.5)/t,i[a+1]=(e+.5)/t;this.geom.setAttribute("aTexel",new L.InstancedBufferAttribute(i,2)),this.geom.instanceCount=t*t,this.reset=!0}update(e,t){let i=t>.005;if(this.mesh.visible=i,!i)return;let a=this.state;if(this.reset){let e=this.renderer.getRenderTarget(),t=this.renderer.getClearColor(new L.Color),i=this.renderer.getClearAlpha();for(let e of(this.renderer.setClearColor(0,0),[a.read,a.write]))this.renderer.setRenderTarget(e),this.renderer.clear();this.renderer.setRenderTarget(e),this.renderer.setClearColor(t,i),this.material.uniforms.uPos.value=a.read.textures[0],this.material.uniforms.uVel.value=a.read.textures[1],this.reset=!1}e<=0||(this.simPass.set("uPos",a.read.textures[0]),this.simPass.set("uVel",a.read.textures[1]),this.simPass.uniforms.uDt.value=Math.min(e,.05),this.simPass.render(this.renderer,a.write),a.swap(),this.material.uniforms.uPos.value=a.read.textures[0],this.material.uniforms.uVel.value=a.read.textures[1])}dispose(){this.state?.dispose(),this.simPass.dispose(),this.geom.dispose(),this.material.dispose(),this.mesh.removeFromParent()}}let a_=`
precision highp float;
in vec3 position;
in vec3 aStart;
in vec3 aEnd;
in vec2 aWidth;       // (core width, glow width)
in vec2 aLife;        // (bolt index, branch fade)

uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform vec3 uCamPos;
uniform vec4 uBoltState[4];   // xyz unused, w = current intensity

out vec2 vUv;
out float vIntensity;
out float vGlow;

void main(){
  int bi = int(aLife.x + 0.5);
  float intensity = uBoltState[bi].w * aLife.y;
  vIntensity = intensity;

  vec3 seg = aEnd - aStart;
  vec3 mid = mix(aStart, aEnd, 0.5);
  vec3 toEye = normalize(uCamPos - mid);
  vec3 side = normalize(cross(normalize(seg), toEye));

  // widen with distance so a far bolt never falls below a pixel
  float dist = length(uCamPos - mid);
  float widen = 1.0 + dist * 0.0016;
  float w = mix(aWidth.x, aWidth.y, position.z) * widen * (intensity > 0.001 ? 1.0 : 0.0);
  vGlow = position.z;

  vec3 p = aStart + seg * position.y + side * (position.x * w);
  vUv = vec2(position.x, position.y);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
}
`,aL=`
precision highp float;
in vec2 vUv;
in float vIntensity;
in float vGlow;
uniform vec3 uColor;
layout(location = 0) out vec4 oColor;

void main(){
  float r = abs(vUv.x);
  // core is a hot near-white filament, glow is a wide soft halo
  float core = exp(-r * r * 26.0);
  float halo = exp(-r * r * 2.4);
  vec3 c = mix(uColor * halo * 0.025, vec3(1.0, 0.98, 0.95) * core, 1.0 - vGlow);
  float ends = smoothstep(0.0, 0.06, vUv.y) * (1.0 - smoothstep(0.94, 1.0, vUv.y));
  oColor = vec4(c * vIntensity * 16.0 * ends, 1.0);

}
`;class aR{constructor(e){this.U=e,this.bolts=[],this.time=0,this.ambientFlash=0,this._tmp=new L.Vector3;const t=new L.InstancedBufferGeometry,i=new Float32Array([-1,0,0,1,0,0,1,1,0,-1,0,0,1,1,0,-1,1,0,-1,0,1,1,0,1,1,1,1,-1,0,1,1,1,1,-1,1,1]);for(const e of(t.setAttribute("position",new L.BufferAttribute(i,3)),this.aStart=new L.InstancedBufferAttribute(new Float32Array(6144),3),this.aEnd=new L.InstancedBufferAttribute(new Float32Array(6144),3),this.aWidth=new L.InstancedBufferAttribute(new Float32Array(4096),2),this.aLife=new L.InstancedBufferAttribute(new Float32Array(4096),2),[this.aStart,this.aEnd,this.aWidth,this.aLife]))e.setUsage(L.DynamicDrawUsage);t.setAttribute("aStart",this.aStart),t.setAttribute("aEnd",this.aEnd),t.setAttribute("aWidth",this.aWidth),t.setAttribute("aLife",this.aLife),t.instanceCount=0,t.boundingSphere=new L.Sphere(new L.Vector3,1e6),this.material=new L.RawShaderMaterial({name:"Lightning",glslVersion:L.GLSL3,vertexShader:a_,fragmentShader:aL,uniforms:{uCamPos:{value:new L.Vector3},uColor:this.U.uLightningColor,uBoltState:{value:[new L.Vector4,new L.Vector4,new L.Vector4,new L.Vector4]}},transparent:!0,blending:L.AdditiveBlending,depthWrite:!1,depthTest:!0}),this.mesh=new L.Mesh(t,this.material),this.mesh.frustumCulled=!1,this.mesh.renderOrder=10,this.mesh.onBeforeRender=(e,t,i)=>this.material.uniforms.uCamPos.value.setFromMatrixPosition(i.matrixWorld),this.geom=t,this.segCount=0}burst(e,t={}){let i=t.radius??3200,a=t.cloudBase??1400;for(let r=0;r<e;r++){let e=Math.random()*(t.window??3),r=Math.random()*Math.PI*2,o=i*(.25+.95*Math.random());this.schedule(Math.cos(r)*o,Math.sin(r)*o,a*(.85+.5*Math.random()),e)}}schedule(e,t,i,a){this._pending=this._pending||[],this._pending.push({x:e,z:t,top:i,at:this.time+a})}strike(e,t,i){this.bolts.length>=3&&this.bolts.shift();let a=[],r=new L.Vector3(e,i,t),o=new L.Vector3(e+(Math.random()-.5)*i*.5,0,t+(Math.random()-.5)*i*.5);this._grow(a,r,o,.42*i,0,1);let s=2+(3*Math.random()|0);for(let r=0;r<s;r++){let r=Math.random()*Math.PI*2,o=i*(.5+Math.random()),s=new L.Vector3(e,i*(1+.25*Math.random()),t),n=new L.Vector3(e+Math.cos(r)*o,i*(1.05+.3*Math.random()),t+Math.sin(r)*o);this._grow(a,s,n,.3*o,2,.45)}let n=1+(3*Math.random()|0),l=[],h=0;for(let e=0;e<n;e++)l.push({at:h,dur:.035+.09*Math.random(),amp:Math.pow(.62,e)}),h+=.04+.11*Math.random();this.bolts.push({segments:a,flashes:l,born:this.time,life:h+.35,pos:new L.Vector3(e,.35*i,t),intensity:0}),this._dirty=!0}_grow(e,t,i,a,r,o){if(e.length>2040)return;if(r>7||8>t.distanceTo(i))return void e.push({a:t.clone(),b:i.clone(),fade:o});let s=t.clone().add(i).multiplyScalar(.5),n=i.clone().sub(t).normalize(),l=new L.Vector3(-n.z,0,n.x);1e-6>l.lengthSq()&&l.set(1,0,0),l.normalize();let h=new L.Vector3().crossVectors(n,l);if(s.addScaledVector(l,(Math.random()-.5)*a),s.addScaledVector(h,(Math.random()-.5)*a),this._grow(e,t,s,.55*a,r+1,o),this._grow(e,s,i,.55*a,r+1,o),r<3&&.42>Math.random()){let c=t.distanceTo(i)*(.35+.45*Math.random()),d=n.clone().addScaledVector(l,(Math.random()-.5)*1.5).addScaledVector(h,(Math.random()-.5)*1.5).normalize(),u=s.clone().addScaledVector(d,c);this._grow(e,s,u,.5*a,r+2,.5*o)}}clear(){this.bolts.length=0,this._pending=[],this.ambientFlash=0,this._dirty=!0,this.update(0,this.time,{lightningRate:0})}update(e,t,i){if(this.time=t,this._pending?.length){for(let e=this._pending.length-1;e>=0;e--)if(this._pending[e].at<=t){let t=this._pending.splice(e,1)[0];this.strike(t.x,t.z,t.top)}}let a=i?.lightningRate??0;a>0&&Math.random()<a*e*.9&&(this.ambientFlash=Math.max(this.ambientFlash,.35+.9*Math.random())),this.ambientFlash*=Math.exp(-(5.5*e));let r=!1;for(let e=this.bolts.length-1;e>=0;e--){let i=this.bolts[e],a=t-i.born;if(a>i.life){this.bolts.splice(e,1),r=!0;continue}let o=0;for(let e of i.flashes){let t=(a-e.at)/e.dur;if(t>=0&&t<=1){let i=Math.pow(1-t,1.7)*(.75+.25*Math.sin(61*t));o=Math.max(o,e.amp*i)}}i.intensity=o=Math.max(o,.05*Math.exp(-(7*a)))}r&&(this._dirty=!0),this._dirty&&this._rebuild();let o=this.material.uniforms.uBoltState.value;for(let e=0;e<4;e++){let t=this.bolts[e];o[e].set(0,0,0,t?t.intensity:0)}let s=[...this.bolts].sort((e,t)=>t.intensity-e.intensity);for(let e=0;e<2;e++){let t=0===e?this.U.uLightning0:this.U.uLightning1,i=s[e];i&&i.intensity>.001?t.value.set(i.pos.x,i.pos.y,i.pos.z,i.intensity):t.value.set(0,0,0,0)}this.U.uAmbientFlash.value=this.ambientFlash+(s[0]?.intensity??0)*.55,this.mesh.visible=this.bolts.length>0}_rebuild(){this._dirty=!1;let e=0,t=this.aStart.array,i=this.aEnd.array,a=this.aWidth.array,r=this.aLife.array;for(let o=0;o<this.bolts.length&&o<4;o++)for(let s of this.bolts[o].segments){if(e>=2048)break;t[3*e]=s.a.x,t[3*e+1]=s.a.y,t[3*e+2]=s.a.z,i[3*e]=s.b.x,i[3*e+1]=s.b.y,i[3*e+2]=s.b.z,a[2*e]=.22*s.fade,a[2*e+1]=1.2*s.fade,r[2*e]=o,r[2*e+1]=s.fade,e++}for(let t of(this.segCount=e,this.geom.instanceCount=e,[this.aStart,this.aEnd,this.aWidth,this.aLife]))t.needsUpdate=!0}dispose(){this.geom.dispose(),this.material.dispose(),this.mesh.removeFromParent()}}let aE=`
precision highp float;

in vec3 position;
uniform mat4 modelMatrix;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

out vec3 vWorld;

void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,aF=`
precision highp float;

${ae}
${al}
${iJ}

in vec3 vWorld;

uniform vec3  uCamPos;
uniform float uTime;
uniform vec3  uSunDir;
uniform float uSunIntensity;
uniform sampler2D uTransmittanceLUT;
uniform sampler2D uSkyViewLUT;
uniform vec3  uLightningColor;
uniform float uAmbientFlash;
uniform vec2  uWindDir;

// xy = base position on the sea (world x, z), z = intensity 0..1, w = height
uniform vec4  uSpout;
#define SPOUT_XZ (uSpout.xy)
#define SPOUT_AMP (uSpout.z)
// x = base radius, y = top flare, z = lean, w = age in seconds
uniform vec4  uShape;
uniform int   uSteps;
uniform float uDebug;

layout(location = 0) out vec4 oColor;

const float PLANET_R = 6360000.0;

// --------------------------------------------------------------- funnel form
// Where the axis sits at a given height. Real funnels lean downwind and snake:
// the vortex is embedded in a sheared flow, so each level is displaced a little
// further than the one below it and the whole column writhes on a slow period.
// A straight cone reads as a traffic cone no matter how well it is lit.
vec2 axisAt(float h){
  float t = uTime * 0.45;
  float lean = uShape.z * h * h;
  vec2 downwind = normalize(uWindDir + 1e-5);
  vec2 wander = vec2(
    sin(h * 3.1 + t * 1.1) * 0.55 + sin(h * 6.7 - t * 0.7) * 0.22,
    cos(h * 2.6 - t * 0.9) * 0.55 + cos(h * 5.3 + t * 1.3) * 0.22
  );
  return SPOUT_XZ + downwind * lean + wander * (14.0 + 30.0 * h);
}

// Sheath radius: a rope that necks down toward the water and opens out into the
// parent cloud at the top. The wobble matters as much as the taper — a perfect
// surface of revolution reads as turned metal however well it is shaded.
float radiusAt(float h){
  float tube = uShape.x * (0.48 + 0.85 * pow(h, 1.5));
  float flare = uShape.y * pow(smoothstep(0.58, 1.0, h), 2.6);
  float wob = 1.0 + 0.30 * sin(h * 7.3 - uTime * 0.9) * sin(h * 3.1 + uTime * 0.55)
                  + 0.14 * sin(h * 17.0 + uTime * 1.7);
  return tube * wob + flare;
}

/**
 * The analytic envelope of the column: sheath, hollow core and the spray
 * cascade at the waterline, with no noise at all.
 *
 * Kept separate from the textured density because it answers the two questions
 * that dominate the cost — "is this sample anywhere near the funnel" and "how
 * much water is between here and the sun" — and neither needs the detail. The
 * noise is only paid for on samples that actually contribute to the image.
 */
float funnelShape(vec3 p, float h, out float rn, out float ang, out float cascade){
  rn = 9.0; ang = 0.0; cascade = 0.0;
  vec2 d = p.xz - axisAt(h);
  float r = length(d);
  float R = radiusAt(h);
  if (r > R * 2.9 + 30.0) return 0.0;

  rn = r / max(R, 1.0);
  ang = atan(d.y, d.x);

  // Dense wall, hollow-ish core. Condensation tracks the steepest pressure
  // gradient, which sits at the radius of maximum wind rather than on the axis,
  // and that hollow is what gives a spout its glassy translucent edge.
  float wall = smoothstep(1.06, 0.80, rn) * smoothstep(0.10, 0.46, rn);
  float core = smoothstep(0.62, 0.0, rn) * 0.55;
  float body = wall + core;

  // ragged where it meets the water, dissolving into the parent cloud on top
  body *= mix(0.55, 1.0, smoothstep(0.0, 0.16, h));
  body *= 1.0 - smoothstep(0.70, 1.0, h);

  // Where the circulation reaches the sea it tears a cascade of spray off the
  // surface: far wider than the funnel, only tens of metres tall, and brighter
  // than the sheath because it is dense liquid water rather than vapour. It has
  // to stay low, or it stops reading as spray and becomes a plinth.
  float cascH = 22.0 + uShape.x * 0.7;
  if (p.y < cascH * 3.5) {
    float cr = r / (R * 3.4 + 34.0);
    cascade = exp(-p.y / cascH)
            * smoothstep(1.0, 0.30, cr)
            * smoothstep(0.0, 0.22, cr);
  }

  return max(body, 0.0);
}

// Textured density. Sampled in the rotating frame of the vortex so the noise
// resolves into helical striations climbing the column instead of a static
// crust. Angular speed rises as the radius drops — conservation of angular
// momentum, and the reason the neck of a spout always looks the most violent.
float funnelDetail(float shape, float cascade, float rn, float ang, float h, float y){
  float R = radiusAt(h);
  float omega = 3.4 * uShape.x / max(R, 4.0);
  float phase = ang + uTime * omega + h * 5.5;

  float n = vnoise3(vec3(phase * 1.7, h * 11.0 - uTime * 0.85, rn * 2.2));
  n = n * 0.62 + vnoise3(vec3(phase * 4.1, h * 26.0 - uTime * 1.7, rn * 4.0)) * 0.38;

  // Wide swing, because the striations are the only thing that keeps the sheath
  // from reading as a moulded surface, and a gentle modulation vanishes the
  // moment the column is optically thick.
  float body = shape * mix(0.10, 1.75, n);
  if (cascade > 0.001) {
    float cn = vnoise3(vec3(ang * 3.1 + uTime * 1.9, y * 0.10 - uTime * 0.8, rn * 2.4));
    cn = cn * 0.7 + vnoise3(vec3(ang * 7.0 - uTime * 2.6, y * 0.22, rn * 5.0)) * 0.3;
    // squared: spray is lumpy, with dense knots and torn gaps between them
    body += cascade * cn * cn * 3.4;
  }
  return max(body, 0.0) * SPOUT_AMP;
}

// Shadowing along the sun direction, so the column has a lit and an unlit side
// instead of glowing uniformly. The envelope alone is enough here: the light
// march only needs the bulk optical depth, and the striations average out.
float lightTransmittance(vec3 p, float top){
  float acc = 0.0;
  float step = max(top * 0.06, 8.0);
  for (int i = 1; i <= 2; ++i) {
    vec3 q = p + uSunDir * step * float(i);
    float h = clamp(q.y / top, 0.0, 1.0);
    float rn, ang, casc;
    acc += (funnelShape(q, h, rn, ang, casc) + casc * 1.2) * SPOUT_AMP;
  }
  return exp(-acc * step * 0.055);
}

void main(){
  // uDebug 3: paint every rasterised fragment of the proxy box, before any
  // analytic rejection, to separate "the box never draws" from "the march
  // rejects everything".
  if (uDebug > 2.5) {
    oColor = vec4(0.0, 0.0, 3.0, 0.4);

    return;
  }
  if (SPOUT_AMP <= 0.001) discard;

  vec3 ro = uCamPos;
  vec3 rd = normalize(vWorld - ro);
  float top = uSpout.w;

  // Bound the march to a vertical cylinder around the whole swept column. This
  // is far tighter than the proxy box and costs one quadratic.
  float Rmax = radiusAt(1.0) + 60.0;
  vec2 oc = ro.xz - SPOUT_XZ;
  float a = dot(rd.xz, rd.xz);
  float b = dot(oc, rd.xz);
  float c = dot(oc, oc) - Rmax * Rmax;
  float disc = b * b - a * c;
  if (disc <= 0.0 || a < 1e-6) discard;
  float sq = sqrt(disc);
  float t0 = (-b - sq) / a;
  float t1 = (-b + sq) / a;
  if (t1 <= 0.0) discard;
  t0 = max(t0, 0.0);

  // clip to the slab between the sea and the cloud base
  if (abs(rd.y) > 1e-5) {
    float ta = (0.0 - ro.y) / rd.y;
    float tb = (top - ro.y) / rd.y;
    float lo = min(ta, tb), hi = max(ta, tb);
    t0 = max(t0, lo); t1 = min(t1, hi);
  } else if (ro.y < 0.0 || ro.y > top) {
    discard;
  }
  if (t1 <= t0) discard;

  // The sea hides everything behind it. Cutting the ray at the water line stops
  // the funnel from painting over the ocean on the far side of the horizon.
  float seaT = 1e9;
  if (rd.y < -1e-5) seaT = (0.0 - ro.y) / rd.y;
  t1 = min(t1, seaT);
  if (t1 <= t0) discard;

  // uDebug 2: paint the bounding volume, so a missing funnel can be told apart
  // from a funnel that is simply too thin to see.
  if (uDebug > 1.5) {
    oColor = vec4(0.0, 3.0, 0.0, 0.35);

    return;
  }

  float span = t1 - t0;
  int steps = uSteps;
  float dt = span / float(steps);
  float jitter = bayer4(gl_FragCoord.xy);

  vec3 viewPos = vec3(0.0, groundRadiusMM + max(uCamPos.y, 0.2) * 1e-6, 0.0);
  vec3 sunCol = getValFromTLUT(uTransmittanceLUT, viewPos, uSunDir) * uSunIntensity;
  vec3 ambTop = getValFromSkyLUT(uSkyViewLUT, viewPos, vec3(0.0, 1.0, 0.0), uSunDir) * uSunIntensity;
  vec3 ambSide = getValFromSkyLUT(uSkyViewLUT, viewPos, normalize(vec3(rd.x, 0.08, rd.z)), uSunDir) * uSunIntensity;

  float cosT = dot(rd, uSunDir);
  // Water droplets throw most light forward; the strong forward lobe is why a
  // spout between you and the sun turns into a bright pillar.
  float phase = dualHG(cosT, 0.72, -0.15, 0.35) * 4.0;

  vec3 scatter = vec3(0.0);
  float transmit = 1.0;

  for (int i = 0; i < 96; ++i) {
    if (i >= steps || transmit < 0.012) break;
    float t = t0 + (float(i) + jitter) * dt;
    vec3 p = ro + rd * t;
    float h = clamp(p.y / top, 0.0, 1.0);

    float rn, ang, casc;
    float shape = funnelShape(p, h, rn, ang, casc);
    if (shape + casc < 0.004) continue;

    float dens = funnelDetail(shape, casc, rn, ang, h, p.y);
    if (dens > 0.002) {
      float lt = lightTransmittance(p, top);
      // Direct sun has to carry the form. Skylight is nearly isotropic, so
      // leaning on it flattens the column into a paper cut-out; the lit and
      // shadowed sides of the rope are what make it read as a solid volume.
      // The residential tornado sits beneath an overcast cloud deck.
      vec3 lum = sunCol * lt * phase * 0.2;
      lum += mix(ambSide * 0.9, ambTop * 1.15, h) * 0.26;
      // Deeper into the sheath is darker, because less skylight gets in.
      lum *= mix(1.0, 0.45, clamp(dens * 0.7, 0.0, 1.0));
      lum += uLightningColor * uAmbientFlash * 1.4;

      // Dense enough that the rope is solid where the sheath is thick, thin
      // enough that the march still resolves structure through it. Push this up
      // and every ray saturates on its first sample, which throws away the
      // striations and leaves a white plastic tube.
      float sigma = 0.042;
      float tr = exp(-dens * sigma * dt);
      scatter += lum * transmit * (1.0 - tr);
      transmit *= tr;
    }
  }

  float alpha = clamp(1.0 - transmit, 0.0, 1.0);
  if (alpha < 0.003) discard;

  if (uDebug > 0.5) {
    oColor = vec4(vec3(6.0, 0.0, 6.0) * alpha, alpha);

    return;
  }

  oColor = vec4(scatter, alpha);

}
`;class aI{constructor(e){this.U=e,this.active=!1,this.x=0,this.z=0,this.age=0,this.life=0,this.maxLife=34,this.strength=1,this.uniforms={uCamPos:{value:new L.Vector3},uTime:this.U.uTime,uSunDir:this.U.uSunDir,uSunIntensity:this.U.uSunIntensity,uTransmittanceLUT:{value:null},uSkyViewLUT:{value:null},uLightningColor:this.U.uLightningColor,uAmbientFlash:this.U.uAmbientFlash,uWindDir:this.U.uWindDir,uAtmoTurbidity:this.U.uAtmoTurbidity,uAtmoMieG:this.U.uAtmoMieG,uAtmoGroundAlbedo:this.U.uAtmoGroundAlbedo,uSpout:{value:new L.Vector4(0,0,0,900)},uShape:{value:new L.Vector4(26,150,90,0)},uSteps:{value:56},uDebug:{value:0}},this.material=new L.RawShaderMaterial({name:"Waterspout",glslVersion:L.GLSL3,vertexShader:aE,fragmentShader:aF,uniforms:this.uniforms,transparent:!0,depthWrite:!1,depthTest:!0,side:L.BackSide,blending:L.CustomBlending,blendSrc:L.OneFactor,blendDst:L.OneMinusSrcAlphaFactor}),this.mesh=new L.Mesh(new L.BoxGeometry(1,1,1),this.material),this.mesh.frustumCulled=!1,this.mesh.renderOrder=5,this.mesh.visible=!1,this.mesh.onBeforeRender=(e,t,i)=>this.uniforms.uCamPos.value.setFromMatrixPosition(i.matrixWorld)}setLUTs(e){this.uniforms.uTransmittanceLUT.value=e.transmittanceRT.texture,this.uniforms.uSkyViewLUT.value=e.skyViewRT.texture}setQuality(e){this.uniforms.uSteps.value=e.spoutSteps??56}spawn(e,t,i=30){this.active=!0,this.x=e,this.z=t,this.life=0,this.strength=i,this.maxLife=34}clear(){this.active=!1,this.mesh.visible=!1}update(e,t){if(!this.active){this.mesh.visible=!1;return}this.life+=e;let i=this.life/this.maxLife;if(i>=1)return void this.clear();let a=Math.min(1,this.life/4.5),r=Math.max(0,a*(1-Math.pow(Math.max(0,(i-.72)/.28),1.6))),o=Math.max(300,Math.min(t??900,1500)),s=this.strength/30,n=(9+9*s)*(.7+.3*a),l=30+45*s;this.uniforms.uSpout.value.set(this.x,this.z,r,o),this.uniforms.uShape.value.set(n,l,(30+55*s)*a,this.life);let h=1.4*n+l+60+60;this.mesh.position.set(this.x,.5*o,this.z),this.mesh.scale.set(2*h,o,2*h),this.mesh.visible=!0}dispose(){this.mesh.geometry.dispose(),this.material.dispose(),this.mesh.removeFromParent()}}let aU=`
vec2 cmul(vec2 a, vec2 b){ return vec2(a.x*b.x - a.y*b.y, a.x*b.y + a.y*b.x); }
vec2 cconj(vec2 a){ return vec2(a.x, -a.y); }
const float PI = 3.14159265358979323846;
`,aN=`
${aU}
uniform sampler2D uNoise;
uniform float uN;
uniform float uLengthScale;
uniform float uCutoffLow;
uniform float uCutoffHigh;
uniform float uDepth;
// per-spectrum: (scale, angle, spreadBlend, swell)
uniform vec4 uS0a;  // scale, angle, spreadBlend, swell
uniform vec4 uS0b;  // alpha, peakOmega, gamma, shortWavesFade
uniform vec4 uS1a;
uniform vec4 uS1b;
in vec2 vUv;
layout(location = 0) out vec4 oH0;

float freq(float k){ return sqrt(9.80665 * k * tanh(min(k * uDepth, 20.0))); }
float freqDeriv(float k){
  float th = tanh(min(k * uDepth, 20.0));
  float ch = cosh(k * uDepth);
  return 9.80665 * (uDepth * k / (ch*ch) + th) / max(2.0 * sqrt(9.80665 * k * th), 1e-9);
}
float normFactor(float s){
  float s2=s*s, s3=s2*s, s4=s3*s;
  if (s < 5.0) return -0.000564*s4 + 0.00776*s3 - 0.044*s2 + 0.192*s + 0.163;
  return -4.80e-8*s4 + 1.07e-5*s3 - 9.53e-4*s2 + 5.90e-2*s + 3.93e-1;
}
float cos2s(float theta, float s){ return normFactor(s) * pow(max(abs(cos(0.5*theta)), 1e-5), 2.0*s); }
float spreadPower(float omega, float peak){
  return omega > peak ? 9.77 * pow(max(omega/peak,1e-5), -2.5)
                      : 6.97 * pow(max(omega/peak,1e-5),  5.0);
}
float tmaCorrection(float omega){
  float oh = omega * sqrt(uDepth / 9.80665);
  if (oh <= 1.0) return 0.5 * oh * oh;
  if (oh <  2.0) return 1.0 - 0.5 * (2.0 - oh) * (2.0 - oh);
  return 1.0;
}
float jonswap(float omega, vec4 sb){
  float alpha = sb.x, peak = sb.y, gamma = sb.z;
  float sigma = omega <= peak ? 0.07 : 0.09;
  float r = exp(-(omega-peak)*(omega-peak) / (2.0*sigma*sigma*peak*peak));
  float invO = 1.0 / max(omega, 1e-5);
  float invO5 = invO*invO*invO*invO*invO;
  return tmaCorrection(omega) * alpha * 9.80665 * 9.80665 * invO5
       * exp(-1.25 * pow(peak * invO, 4.0)) * pow(abs(gamma), r);
}
float directional(float theta, float omega, vec4 sa, vec4 sb){
  float s = spreadPower(omega, sb.y) + 16.0 * tanh(min(omega / max(sb.y,1e-4), 20.0)) * sa.w * sa.w;
  float c = cos(theta - sa.y);
  float d = mix(1.0 / PI * c * c, cos2s(theta - sa.y, s), sa.z);
  return d;
}
float shortWaveFade(float k, float fade){ return exp(-fade*fade*k*k); }

float spectrumAt(float kLen, float kAngle, vec4 sa, vec4 sb){
  if (sa.x <= 1e-6) return 0.0;
  float omega = freq(kLen);
  float dOdk  = freqDeriv(kLen);
  return sa.x * jonswap(omega, sb) * directional(kAngle, omega, sa, sb)
       * shortWaveFade(kLen, sb.w) * abs(dOdk) / max(kLen, 1e-6);
}

void main(){
  float N = uN;
  vec2 xy = floor(vUv * N);
  float dk = 2.0 * PI / uLengthScale;
  vec2 k = (xy - N * 0.5) * dk;
  float kLen = length(k);

  vec2 h0 = vec2(0.0);
  if (kLen >= uCutoffLow && kLen <= uCutoffHigh && kLen > 1e-6) {
    float kAngle = atan(k.y, k.x);
    float S = spectrumAt(kLen, kAngle, uS0a, uS0b) + spectrumAt(kLen, kAngle, uS1a, uS1b);
    vec4 g = texture(uNoise, (xy + 0.5) / N);
    // JONSWAP is one-sided: split its variance across the two travelling
    // branches and the two unit-variance Gaussian components. The old 2*S
    // injected eight times the intended energy before the conjugate sum.
    h0 = g.xy * sqrt(0.25 * max(S, 0.0) * dk * dk);
  }
  oH0 = vec4(h0, 0.0, 0.0);
}
`,aB=`
uniform sampler2D uH0;
uniform float uN;
in vec2 vUv;
layout(location = 0) out vec4 oH0;
void main(){
  ivec2 p = ivec2(floor(vUv * uN));
  int N = int(uN);
  ivec2 m = ivec2((N - p.x) % N, (N - p.y) % N);
  vec2 h0k  = texelFetch(uH0, p, 0).xy;
  vec2 h0mk = texelFetch(uH0, m, 0).xy;
  oH0 = vec4(h0k, h0mk.x, -h0mk.y);
}
`,aV=`
${aU}
uniform sampler2D uH0;
uniform float uN;
uniform float uLengthScale;
uniform float uTime;
uniform float uDepth;
in vec2 vUv;
layout(location = 0) out vec4 oBuf0;
layout(location = 1) out vec4 oBuf1;

void main(){
  ivec2 p = ivec2(floor(vUv * uN));
  vec4 h0 = texelFetch(uH0, p, 0);
  float dk = 2.0 * PI / uLengthScale;
  vec2 k = (vec2(p) - uN * 0.5) * dk;
  float kLen = max(length(k), 1e-5);
  vec2 kn = k / kLen;

  float omega = sqrt(9.80665 * kLen * tanh(min(kLen * uDepth, 20.0)));
  // quantise to the fundamental frequency so the field loops seamlessly in time
  float phase = omega * uTime;
  vec2 e  = vec2(cos(phase), sin(phase));
  vec2 ec = vec2(e.x, -e.y);

  vec2 h  = cmul(h0.xy, e) + cmul(h0.zw, ec);
  vec2 ih = vec2(-h.y, h.x);

  vec2 Dx    = ih * kn.x;
  vec2 Dz    = ih * kn.y;
  vec2 Dy    = h;
  vec2 DyDx  = ih * k.x;
  vec2 DyDz  = ih * k.y;
  vec2 DxDx  = -h * k.x * kn.x;
  vec2 DzDz  = -h * k.y * kn.y;
  vec2 DxDz  = -h * k.y * kn.x;

  // pack pairs of real fields as f + i*g
  oBuf0 = vec4(Dx.x - Dz.y,    Dx.y + Dz.x,    Dy.x   - DyDx.y, Dy.y   + DyDx.x);
  oBuf1 = vec4(DyDz.x - DxDx.y, DyDz.y + DxDx.x, DzDz.x - DxDz.y, DzDz.y + DxDz.x);
}
`,aO=`
${aU}
uniform sampler2D uButterfly;
uniform sampler2D uSrc0;
uniform sampler2D uSrc1;
uniform int uStage;
uniform int uVertical;
layout(location = 0) out vec4 o0;
layout(location = 1) out vec4 o1;

void main(){
  ivec2 p = ivec2(gl_FragCoord.xy);
  int idx = (uVertical == 1) ? p.y : p.x;
  vec4 bf = texelFetch(uButterfly, ivec2(uStage, idx), 0);
  ivec2 a, b;
  if (uVertical == 1) { a = ivec2(p.x, int(bf.z)); b = ivec2(p.x, int(bf.w)); }
  else                { a = ivec2(int(bf.z), p.y); b = ivec2(int(bf.w), p.y); }
  vec2 w = bf.xy;

  vec4 pa = texelFetch(uSrc0, a, 0);
  vec4 pb = texelFetch(uSrc0, b, 0);
  o0 = vec4(pa.rg + cmul(w, pb.rg), pa.ba + cmul(w, pb.ba));

  vec4 qa = texelFetch(uSrc1, a, 0);
  vec4 qb = texelFetch(uSrc1, b, 0);
  o1 = vec4(qa.rg + cmul(w, qb.rg), qa.ba + cmul(w, qb.ba));
}
`,aG=`
uniform sampler2D uBuf0;
uniform sampler2D uBuf1;
uniform sampler2D uPrevTurb;
uniform float uLambda;
uniform float uFoamBias;
uniform float uSteepBias;
uniform float uCrestK;
uniform vec2  uWindDir;
uniform float uFoamMul;
uniform float uFoamDecay;
uniform float uBubbleDecay;
uniform float uDt;
uniform float uN;
uniform float uLengthScale;
in vec2 vUv;
layout(location = 0) out vec4 oDisp;
layout(location = 1) out vec4 oDeriv;
layout(location = 2) out vec4 oTurb;

void main(){
  ivec2 p = ivec2(gl_FragCoord.xy);
  float perm = ((p.x + p.y) % 2 == 0) ? 1.0 : -1.0;

  vec4 b0 = texelFetch(uBuf0, p, 0) * perm;
  vec4 b1 = texelFetch(uBuf1, p, 0) * perm;

  float Dx   = b0.x, Dz   = b0.y, Dy   = b0.z, DyDx = b0.w;
  float DyDz = b1.x, DxDx = b1.y, DzDz = b1.z, DxDz = b1.w;

  float lx = uLambda * DxDx;
  float lz = uLambda * DzDz;
  float lxz = uLambda * DxDz;
  float jacobian = (1.0 + lx) * (1.0 + lz) - lxz * lxz;

  oDisp  = vec4(uLambda * Dx, Dy, uLambda * Dz, jacobian);
  oDeriv = vec4(DyDx, DyDz, lx, lz);

  // ---- turbulence / foam accumulation (world-tiled, so it wraps naturally)
  //
  // Two independent breaking criteria, because neither alone covers the sea.
  //
  // Folding (Jacobian near zero) catches the plunging breaker whose face has
  // gone vertical, but it only fires when the horizontal displacement is pushed
  // past the point of self-intersection — which a physically-scaled chop never
  // reaches, so on its own it leaves a gale looking glassy.
  //
  // Steepness is what actually limits an ocean wave: past roughly H/L = 1/7 the
  // crest can no longer support itself and spills. That threshold lives in the
  // surface slope, which the FFT gives us directly, and it fires on the whole
  // spilling-breaker population that folding misses.
  vec4 prev = texture(uPrevTurb, vUv - uWindDir * uDt * .45 / uLengthScale);
  float fold = 1.0 - smoothstep(uFoamBias - 0.30, uFoamBias, jacobian);

  vec2 grad = vec2(DyDx, DyDz);
  float slope = length(grad);
  // Waves spill down their leeward face, so weight the injection toward crests
  // whose front is turned away from the wind rather than ringing the whole crest.
  float lee = 0.55 + 0.45 * clamp(dot(grad / max(slope, 1e-4), uWindDir), -1.0, 1.0);
  // Steepness alone also fires on the steep flank halfway down a big wave, which
  // paints broad blobs. Air is only entrained at the top, so require the water
  // to be high in its own band as well. uCrestK turns the cascade's elevation
  // into the same units as its slope, making the gate scale-free.
  float above = smoothstep(0.035, 0.265, Dy * uCrestK);
  float steep = smoothstep(uSteepBias, uSteepBias + 0.075, slope) * lee * above;

  fold = max(fold, steep);

  // Entrainment is a *rate*, not a level. Snapping the accumulator to 1 the
  // instant a texel folds means every texel the wave field sweeps over pins at
  // full white and the decay never gets ahead of it, which turns a storm sea
  // into a snowfield. Integrating a rate instead gives an equilibrium coverage
  // of rate*dutyCycle/decay, so only water that breaks repeatedly goes white.
  float foam = prev.r * exp(-uDt * uFoamDecay) + fold * uFoamMul * uDt;
  foam = max(foam - uDt * 0.015, 0.0);
  float bub  = prev.g * exp(-uDt * uBubbleDecay) + fold * uFoamMul * uDt * 0.55;
  // crest energy is the instantaneous folding, used for spray emission
  float crest = fold;
  float spray = max(prev.a * exp(-uDt * 6.0), smoothstep(0.45, 0.95, fold));

  oTurb = vec4(clamp(foam, 0.0, 1.0), clamp(bub, 0.0, 1.0), crest, spray);
}
`,aj=[.55,1,.22],aH=[.55,.9,1.1];class aW{constructor(e,t,i,a,r,o,s){this.N=t,this.lengthScale=i,this.cutLow=a,this.cutHigh=r;const n={type:L.FloatType,minFilter:L.NearestFilter,magFilter:L.NearestFilter};this.h0=i$(t,t,{...n,name:"h0"}),this.h0k=i$(t,t,{...n,name:"h0k"}),this.mrtA=i$(t,t,{...n,name:"mrtA",count:2}),this.mrtB=i$(t,t,{...n,name:"mrtB",count:2});const l=Math.min(16,e.capabilities.getMaxAnisotropy()),h={type:L.HalfFloatType,wrap:L.RepeatWrapping,minFilter:L.LinearMipmapLinearFilter,magFilter:L.LinearFilter,mipmaps:!0,anisotropy:l};this.out=i$(t,t,{...h,name:"oceanOut",count:3}),this.turbPrev=i$(t,t,{type:L.HalfFloatType,wrap:L.RepeatWrapping,minFilter:L.LinearFilter,magFilter:L.LinearFilter,name:"turbPrev"}),this.spectrumPass=new iZ(aN,{uNoise:{value:o},uN:{value:t},uLengthScale:{value:i},uCutoffLow:{value:a},uCutoffHigh:{value:r},uDepth:{value:500},uS0a:{value:new L.Vector4},uS0b:{value:new L.Vector4},uS1a:{value:new L.Vector4},uS1b:{value:new L.Vector4}},{name:"spectrum"}),this.conjPass=new iZ(aB,{uH0:{value:this.h0.texture},uN:{value:t}},{name:"conjugate"}),this.timePass=new iZ(aV,{uH0:{value:this.h0k.texture},uN:{value:t},uLengthScale:{value:i},uTime:{value:0},uDepth:{value:500}},{name:"timeSpectrum"}),this.butterflyPass=new iZ(aO,{uButterfly:{value:s},uSrc0:{value:null},uSrc1:{value:null},uStage:{value:0},uVertical:{value:0}},{name:"butterfly"}),this.assemblePass=new iZ(aG,{uBuf0:{value:null},uBuf1:{value:null},uPrevTurb:{value:this.turbPrev.texture},uLambda:{value:1},uFoamBias:{value:.85},uSteepBias:{value:.5},uCrestK:{value:16*Math.PI/i},uWindDir:{value:new L.Vector2(1,0)},uFoamMul:{value:1.2},uFoamDecay:{value:.35},uBubbleDecay:{value:.14},uDt:{value:.016},uN:{value:t},uLengthScale:{value:i}},{name:"assemble"}),this.copyTurb=new iZ(`
      uniform sampler2D uSrc; in vec2 vUv; layout(location=0) out vec4 o;
      void main(){ o = texture(uSrc, vUv); }`,{uSrc:{value:this.out.textures[2]}},{name:"copyTurb"}),this.stages=0|Math.log2(t)}get displacement(){return this.out.textures[0]}get derivatives(){return this.out.textures[1]}get turbulence(){return this.out.textures[2]}updateSpectrum(e,t,i,a,r,o){let s=this.spectrumPass.uniforms;s.uS0a.value.copy(t),s.uS0b.value.copy(i),s.uS1a.value.copy(a),s.uS1b.value.copy(r),s.uDepth.value=o,this.timePass.uniforms.uDepth.value=o,this.spectrumPass.render(e,this.h0),this.conjPass.render(e,this.h0k)}step(e,t,i,a,r,o=1){this.timePass.set("uTime",t).render(e,this.mrtA);let s=this.mrtA,n=this.mrtB,l=this.butterflyPass;for(let t=0;t<2;t++){l.set("uVertical",t);for(let t=0;t<this.stages;t++){l.set("uStage",t),l.set("uSrc0",s.textures[0]),l.set("uSrc1",s.textures[1]),l.render(e,n);let i=s;s=n,n=i}}let h=this.assemblePass;h.set("uBuf0",s.textures[0]),h.set("uBuf1",s.textures[1]),h.set("uLambda",a),h.set("uFoamBias",r.bias),h.set("uSteepBias",r.steepBias*Math.SQRT1_2*.32/Math.max(o,.35)),h.uniforms.uWindDir.value.copy(r.windDir),h.set("uFoamMul",r.mul*o),h.set("uFoamDecay",r.decay/Math.max(o,.15)),h.set("uBubbleDecay",r.bubbleDecay),h.set("uDt",i),h.render(e,this.out),this.copyTurb.render(e,this.turbPrev)}dispose(){[this.h0,this.h0k,this.mrtA,this.mrtB,this.out,this.turbPrev].forEach(e=>e.dispose()),[this.spectrumPass,this.conjPass,this.timePass,this.butterflyPass,this.assemblePass,this.copyTurb].forEach(e=>e.dispose())}}class aq{constructor(e,t={}){this.renderer=e,this.N=t.size||256,this.lengthScales=t.lengthScales||[4099,389,41.3],this.depth=900,this.time=0,this.timeScale=1,this.anisotropy=Math.min(16,e.capabilities.getMaxAnisotropy()),this.noise=function(e,t=1337){let i=t>>>0,a=()=>(i^=i<<13,i>>>=0,i^=i>>>17,i^=i<<5,((i>>>=0)>>>8)/0x1000000),r=e*e*4,o=new Float32Array(r);for(let e=0;e<r;e+=2){let t=Math.max(a(),1e-7),i=a(),r=Math.sqrt(-2*Math.log(t));o[e]=r*Math.cos(2*Math.PI*i),o[e+1]=r*Math.sin(2*Math.PI*i)}let s=new L.DataTexture(o,e,e,L.RGBAFormat,L.FloatType);return s.minFilter=s.magFilter=L.NearestFilter,s.wrapS=s.wrapT=L.RepeatWrapping,s.needsUpdate=!0,s}(this.N,0xc0ffee),this.butterfly=function(e){let t=0|Math.log2(e),i=new Float32Array(t*e*4),a=e=>{let i=0;for(let a=0;a<t;a++)i|=(e>>a&1)<<t-1-a;return i};for(let r=0;r<t;r++)for(let o=0;o<e;o++){let s,n,l=1<<r,h=o*(e>>r+1)%e,c=Math.cos(2*Math.PI*h/e),d=Math.sin(2*Math.PI*h/e),u=o%(1<<r+1)<l;0===r?u?(s=a(o),n=a(o+1)):(s=a(o-1),n=a(o)):u?(s=o,n=o+l):(s=o-l,n=o);let m=(r+o*t)*4;i[m]=c,i[m+1]=d,i[m+2]=s,i[m+3]=n}let r=new L.DataTexture(i,t,e,L.RGBAFormat,L.FloatType);return r.minFilter=r.magFilter=L.NearestFilter,r.needsUpdate=!0,r}(this.N),this._windDir=new L.Vector2(1,0);const i=this.lengthScales.map(e=>2*Math.PI*this.N/(6*e)),a=[[1e-4,i[0]],[i[0],i[1]],[i[1],i[2]]];this.cascades=this.lengthScales.map((t,i)=>new aW(e,this.N,t,a[i][0],a[i][1],this.noise,this.butterfly)),this.params={windSpeed:9,windDir:.6,fetch:22e4,swellHs:1.4,swellPeriod:11,swellDir:.9,swellGamma:6,swellCutoff:14,spread:.72,choppiness:1.35,amplitude:1,shortWaveFade:.0065,peakEnhancement:3.3,foamBias:.5,foamMul:1.35,foamDecay:.35,bubbleDecay:.12},this._s=[new L.Vector4,new L.Vector4,new L.Vector4,new L.Vector4],this._dirty=!0,this._sig=""}markDirty(){this._dirty=!0}get significantWaveHeight(){return this.hs||0}static _jonswapParams(e,t){let i=Math.max(e,.5),a=Math.max(Math.min(t,22e3*i*i/9.80665),400);return{alpha:.076*Math.pow(i*i/(9.80665*a),.22),peakOmega:Math.max(22*Math.pow(9.80665*9.80665/(i*a),1/3),.3)}}static _m0(e,t,i){let a=0,r=Math.log(175);for(let o=0;o<128;o++){let s=.08*Math.exp(r*(o+.5)/128),n=s*r/128,l=s<=t?.07:.09,h=Math.exp(-((s-t)**2)/(2*l*l*t*t));a+=9.80665*e*9.80665/Math.pow(s,5)*Math.exp(-1.25*Math.pow(t/s,4))*Math.pow(i,h)*n}return a}_buildSpectra(){let e=this.params,t=aq._jonswapParams(e.windSpeed,e.fetch),i=Math.max(e.swellPeriod,3),a=Math.max(e.swellGamma,1),r=Math.max(e.swellHs,0),o=r*r/(i*i*i*i)*5.061*(1-.287*Math.log(a)),s=2*Math.PI/i,n=aq._m0(t.alpha,t.peakOmega,e.peakEnhancement)*e.amplitude,l=aq._m0(o,s,a)*e.amplitude;this.hs=4*Math.sqrt(Math.max(n+l,1e-9)),this.windHs=4*Math.sqrt(Math.max(n,1e-9)),this.swellHsActual=4*Math.sqrt(Math.max(l,1e-9)),this.peakPeriod=2*Math.PI/t.peakOmega,this._s[0].set(e.amplitude,e.windDir,e.spread,0),this._s[1].set(t.alpha,t.peakOmega,e.peakEnhancement,e.shortWaveFade),this._s[2].set(r>.001?e.amplitude:0,e.swellDir,1,1),this._s[3].set(o,s,a,e.swellCutoff)}update(e){let t=this.renderer;this.time+=e*this.timeScale;let i=this.params,a=`${i.windSpeed.toFixed(2)}|${i.windDir.toFixed(3)}|${i.swellHs.toFixed(3)}|${i.swellDir.toFixed(3)}|${i.swellPeriod.toFixed(2)}|${i.swellGamma.toFixed(2)}|${i.swellCutoff.toFixed(2)}|${i.spread.toFixed(3)}|${i.amplitude.toFixed(3)}|${i.shortWaveFade.toFixed(4)}|${i.peakEnhancement.toFixed(2)}|${i.fetch.toFixed(0)}`;if(this._dirty||a!==this._sig)for(let e of(this._sig=a,this._dirty=!1,this._buildSpectra(),this.cascades))e.updateSpectrum(t,this._s[0],this._s[1],this._s[2],this._s[3],this.depth);let r={bias:i.foamBias,mul:i.foamMul,decay:i.foamDecay,bubbleDecay:i.bubbleDecay,steepBias:i.steepBias??.5,windDir:this._windDir.set(Math.cos(i.windDir??0),Math.sin(i.windDir??0))};for(let a=0;a<this.cascades.length;a++)this.cascades[a].step(t,this.time,e,i.choppiness*(aH[a]??1),r,aj[a]??1)}bind(e){return e.uOceanDisp0={value:this.cascades[0].displacement},e.uOceanDisp1={value:this.cascades[1].displacement},e.uOceanDisp2={value:this.cascades[2].displacement},e.uOceanDeriv0={value:this.cascades[0].derivatives},e.uOceanDeriv1={value:this.cascades[1].derivatives},e.uOceanDeriv2={value:this.cascades[2].derivatives},e.uOceanTurb0={value:this.cascades[0].turbulence},e.uOceanTurb1={value:this.cascades[1].turbulence},e.uOceanTurb2={value:this.cascades[2].turbulence},e.uOceanScales={value:new L.Vector3(...this.lengthScales)},e.uOceanTexels={value:this.N},e.uOceanAniso={value:this.anisotropy},e}dispose(){this.cascades.forEach(e=>e.dispose()),this.noise.dispose(),this.butterfly.dispose()}}let aX=`
precision highp float;
precision highp int;
precision highp sampler2D;

in vec2 aGrid;

uniform mat4 projectionMatrix;
uniform mat4 viewMatrix;
uniform mat4 uViewProjNJ;
uniform mat4 uPrevViewProjNJ;
uniform mat4 uInvViewProjNJ;
uniform vec3 uCamPos;
uniform float uTime;
uniform float uRMax;
uniform vec2 uGridSize;
uniform float uGridMargin;
uniform float uSkirt;
uniform float uGridPlane;
uniform float uCurrentStrength;
uniform float uDisplaceScale;
// Loop bounds, deliberately not compile-time constants. With literals the
// driver unrolls the ray search into forty inlined copies of the event field
// and the HLSL translation never finishes compiling.
uniform int uEventSteps;
uniform int uEventBisect;

${aS}
${iA}
${ik}

out vec3 vWorldPos;
out vec2 vFlatPos;
out vec3 vDisp;
out float vDist;
out float vCrest;
out float vCalm;
out float vWaveY;
out float vEventY;
out vec3 vLods;
out vec4 vClipNJ;
out vec4 vPrevClipNJ;

vec3 rayFor(vec2 ndc) {
  vec4 a = uInvViewProjNJ * vec4(ndc, -1.0, 1.0);
  vec4 b = uInvViewProjNJ * vec4(ndc,  1.0, 1.0);
  return normalize(b.xyz / b.w - a.xyz / a.w);
}

// -------------------------------------------------------- disaster brackets
// The stretch of a ray in which a given event can possibly reach it. Marching
// blind is hopeless: a degree above the horizon the water occupies kilometres
// of ray, and a hundred-and-fifty-metre crest falls clean between two samples.
// Every event is analytic though, so its footprint solves in closed form — a
// solitary wave is a band in its own front coordinate, everything else is a
// disc — and sixteen samples inside a tight bracket find what a hundred spread
// over the whole slab would miss. Distances are horizontal; the caller divides.
void bandSoliton(vec4 s, vec4 sb, vec2 o, vec2 d, inout vec2 span) {
  if (s.w <= 0.001) return;
  vec2 sd = normalize(s.xy);
  float w = max(sb.x, 1.0) * 3.0;
  float x0 = dot(o, sd) - s.z;
  float k = dot(d, sd);
  vec2 seg;
  if (abs(k) < 1e-5) {
    if (abs(x0) > w) return;      // running along the front, never crosses it
    seg = vec2(0.0, 1e7);
  } else {
    float a = (-w - x0) / k, b = (w - x0) / k;
    seg = vec2(min(a, b), max(a, b));
  }
  span = vec2(min(span.x, seg.x), max(span.y, seg.y));
}

void bandDisc(vec2 c, float r, float amp, vec2 o, vec2 d, inout vec2 span) {
  if (amp <= 0.001) return;
  vec2 m = o - c;
  float b = dot(m, d);
  float cc = dot(m, m) - r * r;
  float disc = b * b - cc;
  if (disc < 0.0) return;
  float sq = sqrt(disc);
  span = vec2(min(span.x, -b - sq), max(span.y, -b + sq));
}

/**
 * First crossing of a view ray with the analytic disaster field inside
 * [lo, hi], or -1 if the ray clears it. The tested quantity is the ray's
 * height above the surface, so the crossing is where it first goes negative.
 *
 * Two passes, and the second one is not optional. Where the ray is nearly
 * tangent to a crest — which is the silhouette, the one part of the wave the
 * eye is actually reading — the stretch in which the ray is below the surface
 * narrows towards nothing, and a single coarse march catches it on one row and
 * steps clean over it on the next. Adjacent vertices then land on different
 * branches, the mesh folds back on itself and the crest comes out as a zipper.
 * Re-marching the cell around the closest approach costs sixteen more samples
 * of a pure-ALU function and turns that rip back into an edge.
 */
float eventRayHit(vec3 dir, vec2 o2, float eye, float lo, float hi) {
  float a = lo, b = hi;
  float ta = -1.0, tb = 0.0;

  for (int pass = 0; pass < 2; pass++) {
    float dt = (b - a) / float(uEventSteps);
    float tPrev = a;
    float gPrev = eye + dir.y * a - oceanEventHeight(o2 + dir.xz * a);
    float gMin = gPrev, tMin = a;
    for (int i = 1; i <= uEventSteps; i++) {
      float tc = a + dt * float(i);
      float gc = eye + dir.y * tc - oceanEventHeight(o2 + dir.xz * tc);
      if (ta < 0.0 && gPrev > 0.0 && gc <= 0.0) { ta = tPrev; tb = tc; }
      if (gc < gMin) { gMin = gc; tMin = tc; }
      tPrev = tc; gPrev = gc;
    }
    if (ta > 0.0) break;
    // Nothing crossed. Re-march the cell around the closest approach in case
    // the coarse pass stepped over a narrow one.
    a = max(tMin - dt, lo);
    b = min(tMin + dt, hi);
  }
  if (ta < 0.0) return -1.0;

  for (int i = 0; i < uEventBisect; i++) {
    float tm = 0.5 * (ta + tb);
    if (eye + dir.y * tm - oceanEventHeight(o2 + dir.xz * tm) > 0.0) ta = tm; else tb = tm;
  }
  return 0.5 * (ta + tb);
}

/** Intersect a view ray with the parabolic (spherical) sea surface. */
vec2 seaHit(vec3 dir, float eyeHeight) {
  float curv = uEarthCurvature / (2.0 * EARTH_R);
  float a = max((1.0 - dir.y * dir.y) * curv, 1e-14);
  float b = dir.y;
  float c = eyeHeight;
  float disc = b * b - 4.0 * a * c;
  float t = 0.0;
  bool miss = true;
  if (disc >= 0.0) {
    // Citardauq form. The textbook (-b \xb1 sqrt(disc)) / 2a is unusable here: the
    // sea sphere has planetary radius, so a ~ 1e-8 and for any ray steeper than
    // a few degrees 4ac is a part in ten million of b*b. The subtraction then
    // cancels to float noise and gets amplified by 1/2a ~ 1e7, which scatters
    // near-field vertices to random distances and tears a hole in the mesh
    // wherever the camera looks down.
    float sq = sqrt(disc);
    float qq = -0.5 * (b + (b >= 0.0 ? sq : -sq));
    float r1 = qq / a;
    float r2 = abs(qq) > 1e-20 ? c / qq : -1.0;
    float lo = min(r1, r2), hi = max(r1, r2);
    t = lo > 0.02 ? lo : hi;
    miss = t <= 0.02;
  }
  if (miss || t > uRMax) {
    // snap to the azimuthal tangent point => lands exactly on the horizon
    float rh = sqrt(max(2.0 * EARTH_R * max(abs(c), 0.05) * uEarthCurvature, 1.0));
    rh = min(rh, uRMax);
    if (uEarthCurvature < 0.5) rh = uRMax;
    float horiz = max(length(dir.xz), 1e-5);
    t = rh / horiz;
    return vec2(t, 1.0);
  }
  return vec2(t, 0.0);
}

void main(){
  // A flat margin cannot guarantee coverage. Every vertex is placed on the
  // *undisplaced* sea and then moved by up to a few metres horizontally, and
  // for the bottom row — water eight metres from the lens — a few metres is a
  // large fraction of the frame. The boundary of the mesh then walks inward and
  // tears a wedge out of the corner of the screen. So the outermost ring is
  // thrown far outside the frustum: one ring of vertices, effectively free,
  // whose stretched triangles guarantee the visible area is always covered.
  vec2 cellIdx = aGrid * uGridSize;
  vec2 atMin = step(cellIdx, vec2(0.5));
  vec2 atMax = step(uGridSize - 0.5, cellIdx);
  vec2 ndc = (aGrid * 2.0 - 1.0) * uGridMargin + (atMax - atMin) * uSkirt;
  vec3 dir = rayFor(ndc);
  // Aim the rays at the water actually under the lens, not at mean sea level.
  //
  // A tsunami lifts the whole neighbourhood by tens of metres. Intersect the
  // flat plane instead and the near rows land on points that displacement then
  // throws above the sight line, uncovering the bottom third of the frame; no
  // amount of margin can reach far enough down to cover it, because the
  // geometry that belongs there is metres from the lens.
  //
  // The offset has to be constant across the grid. Re-intersecting per vertex
  // against the sampled height — by fixed point or by Newton — diverges for
  // grazing rays, where a wavy surface offers many intersections and adjacent
  // rays converge on different ones. The mesh comes apart into contour
  // terraces. A constant is continuous by construction.
  float eyeHeight = max(uCamPos.y - (uSeaLevel + uGridPlane), 0.35);

  vec2 hit = seaHit(dir, eyeHeight);
  float t = hit.x;
  float snapped = hit.y;

  // ---------------------------------------------- re-aim at the disasters
  // A flat reference plane is exactly right for a wind sea a few metres tall
  // and useless for a forty metre one. Every ray that points at a distant
  // tsunami either grazes the plane or misses it upward, so all of them are
  // snapped to the horizon ring and the wall is not drawn coarsely — it is not
  // drawn at all. Re-intersecting against the analytic event field puts those
  // rows back onto the face, and the density then takes care of itself: a wall
  // covering six degrees of the frame collects every row inside six degrees.
  //
  // The FFT relief is deliberately excluded. A metre-scale surface offers a
  // grazing ray dozens of intersections, adjacent vertices settle on different
  // ones, and the mesh comes apart into contour terraces.
  float horiz = length(dir.xz);
  // World distance covered by one radian of pitch on whatever surface the
  // vertex ended up on. Zero means "use the flat-plane estimate".
  float eventSpread = 0.0;
  if (horiz > 1e-5) {
    vec2 d2 = dir.xz / horiz;
    vec2 o2 = uCamPos.xz;
    vec2 span = vec2(1e9, -1e9);
    bandSoliton(uSoliton0, uSoliton0b, o2, d2, span);
    bandSoliton(uSoliton1, uSoliton1b, o2, d2, span);
    bandDisc(uRogue.xy, uRogue.z * 2.4, uRogue.w, o2, d2, span);
    bandDisc(uHurricane.xy, uHurricane.z * 3.0, uHurricane.w, o2, d2, span);
    bandDisc(uVortex0.xy, uVortex0.z * 3.0, uVortex0.w, o2, d2, span);
    bandDisc(uVortex1.xy, uVortex1.z * 3.0, uVortex1.w, o2, d2, span);
    bandDisc(uVortex2.xy, uVortex2.z * 3.0, uVortex2.w, o2, d2, span);
    bandDisc(uVortex3.xy, uVortex3.z * 3.0, uVortex3.w, o2, d2, span);

    if (span.y > span.x) {
      float lo = max(span.x / horiz, 0.05);
      float hi = min(span.y / horiz, uRMax);
      // A ray that already found flat water cannot be answered by an event
      // behind that water — it is occluded. The slack is for the opposite
      // case, the drawdown ahead of a crest, where the sea the ray wants is
      // *below* the plane and therefore slightly further out.
      if (snapped < 0.5) hi = min(hi, t * 1.06 + 60.0);
      hi = min(hi, lo + 8000.0);

      if (hi > lo) {
        float tHit = eventRayHit(dir, o2, uCamPos.y - uSeaLevel, lo, hi);
        if (tHit > 0.0) {
          t = clamp(tHit, 0.05, uRMax);
          snapped = 0.0;

          // How far apart consecutive rows land on this face. Where the ray
          // grazes the surface it is tens of metres even though the rows are a
          // fraction of a degree apart, and a footprint that still believes
          // the flat-plane spacing point-samples the cascade and serrates the
          // crest into a mountain ridge. Differentiating the intersection
          // itself: dt/dtheta = -t / (dir.y - dE/dt).
          float hs = max(t * 0.02, 0.5);
          float dEdt = (oceanEventHeight(o2 + dir.xz * (t + hs))
                      - oceanEventHeight(o2 + dir.xz * t)) / hs;
          eventSpread = t / max(abs(dir.y - dEdt), 2e-3);
        }
      }
    }
  }

  vec2 world = uCamPos.xz + dir.xz * t;

  // footprint from the neighbouring grid cells (uniform in screen space)
  vec2 ndcDu = (vec2(aGrid.x + 1.0 / uGridSize.x, aGrid.y) * 2.0 - 1.0) * uGridMargin;
  vec2 ndcDv = (vec2(aGrid.x, aGrid.y + 1.0 / uGridSize.y) * 2.0 - 1.0) * uGridMargin;
  vec3 dirU = rayFor(ndcDu);
  vec3 dirV = rayFor(ndcDv);
  // Scale the neighbours by however far the refinement moved this vertex.
  // Re-solving for each of them costs three times the search; the ratio is
  // accurate wherever the two rays land on the same face, which is the only
  // place the footprint matters.
  float tScale = t / max(hit.x, 1e-3);
  vec2 wu = uCamPos.xz + dirU.xz * (seaHit(dirU, eyeHeight).x * tScale);
  vec2 wv = uCamPos.xz + dirV.xz * (seaHit(dirV, eyeHeight).x * tScale);
  // Never finer than the cell subtends at this range. Rays that missed the
  // reference plane were all snapped to the same tangent ring, so their
  // neighbour footprints differ by nothing and the lookup collapses to the
  // sharpest mip — which is how a wave face four hundred metres out ends up
  // sampled per-texel and rendered as crumpled foil.
  float angU = length(dirU - dir), angV = length(dirV - dir);
  float pixel = max(t * angU, eventSpread * angV);
  float cell = max(max(length(wu - world), length(wv - world)), max(0.015, pixel));

  vec3 texel = uOceanScales / uOceanTexels;
  vec3 lods = log2(max(vec3(cell) / texel, vec3(1.0)));
  vLods = lods;

  vec2 q = swirlCoords(world, uTime);
  q = warpCoord(q, uTime, uCurrentStrength);

  float foamHint;
  float coastDepth = max(0., uSeaLevel - islandHeight(world));
  float shoal = smoothstep(0., 10., coastDepth);
  vec3 disp = oceanDisplacementLod(q, lods, foamHint) * uDisplaceScale * shoal;
  disp.y += shoreHeight(world);

  float crest, calm;
  vec3 mods = oceanModifiers(world, uTime, crest, calm);
  disp *= (1.0 - calm * 0.8);
  // Wind waves and disaster displacement have to stay separable. Shading uses
  // crest height as a stand-in for how thin the water is — a metre-high crest
  // with the sun behind it glows — and the two are only interchangeable while
  // the sea is made of wind waves. Fold in a forty metre tsunami and every
  // "thin sheet" term pins to its maximum across the entire wall, which is
  // what turned the face into a slab of jade.
  float waveY = disp.y;
  disp += mods;

  // fade the vertical relief out right at the horizon so the silhouette stays clean
  float horizonFade = 1.0 - snapped * 0.92;
  disp *= horizonFade;
  vWaveY = waveY * horizonFade;
  vEventY = mods.y * horizonFade;

  vec3 wp = vec3(world.x + disp.x, uSeaLevel + disp.y, world.y + disp.z);
  wp.y -= earthDrop(world, uCamPos);

  vWorldPos = wp;
  vFlatPos = world;
  vDisp = disp;
  vDist = length(wp - uCamPos);
  vCrest = crest;
  vCalm = calm;

  vClipNJ = uViewProjNJ * vec4(wp, 1.0);
  vPrevClipNJ = uPrevViewProjNJ * vec4(wp, 1.0);
  gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0);
}
`,aK=`
precision highp float;
precision highp int;
precision highp sampler2D;

uniform vec3 uCamPos;
uniform float uTime;
uniform vec2 uResolution;
uniform float uFogDensity;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunIntensity;
uniform vec3 uAmbientColor;
uniform sampler2D uTransmittanceLUT;
uniform sampler2D uWeatherMap;
uniform float uWeatherScaleM;
uniform float uCoverage;
uniform float uCloudContrast;
uniform float uCloudDensity;
uniform float uCloudBottom;
uniform vec2 uCloudWind;
uniform float uCloudTime;
uniform sampler2D uEnvMap;
uniform float uEnvMaxLod;
uniform float uEnvWidth;
uniform sampler2D uFoamTex;
uniform sampler2D uRippleTex;
uniform float uRain;
uniform float uWhitecapCoverage;
uniform float uStormFactor;
uniform vec3 uWaterScatter;
uniform vec3 uWaterAbsorb;
uniform float uFoamStrength;
uniform float uCurrentStrength;
uniform vec4 uLightning0;
uniform vec4 uLightning1;
uniform vec3 uLightningColor;
uniform float uAmbientFlash;
uniform float uExposure;
uniform float uUnderwater;
uniform float uDebugMode;

${ae}
${an}
${iJ}
${aS}
${iA}
${ik}
${al}

in vec3 vWorldPos;
in vec2 vFlatPos;
in vec3 vDisp;
in float vDist;
in float vCrest;
in float vCalm;
in float vWaveY;
in float vEventY;
in vec3 vLods;
in vec4 vClipNJ;
in vec4 vPrevClipNJ;

layout(location = 0) out vec4 oColor;

vec4 sampleCascadeGrad(sampler2D tex, vec2 p, float scale, vec2 ddx, vec2 ddy) {
  return textureGrad(tex, p / scale, ddx / scale, ddy / scale);
}

/**
 * How much of the direct beam survives the cloud deck on its way to this patch
 * of water. Reads the same weather map the deck is built from, at the point
 * where the beam crosses the cloud base, so the shadows are the actual clouds
 * overhead and they drift with them. Without this the sea kept a full midday
 * sun and a hard specular glint underneath a violent storm.
 */
float cloudShadow(vec3 p, vec3 L) {
  if (uCoverage <= 0.001) return 1.0;
  // Grazing sun would throw the sample kilometres away and swim; past this the
  // deck is edge-on and the beam is inside cloud the whole way regardless.
  float up = max(L.y, 0.22);
  vec2 xz = p.xz + L.xz / up * max(uCloudBottom - p.y, 0.0);

  vec2 w = xz + uCloudWind * uCloudTime * 0.6;
  vec4 m = textureLod(uWeatherMap, w / uWeatherScaleM, 0.0);
  vec4 n = textureLod(uWeatherMap, w / (uWeatherScaleM * 0.27)
                 + vec2(0.37, 0.11) - uCloudWind * uCloudTime * 0.00002, 0.0);
  float field = m.r * 0.62 + m.g * 0.22 + n.g * 0.16;
  float cov = clamp((field - 0.5) * uCloudContrast + uCoverage, 0.0, 1.0);

  // Thin edges of a cell shadow far less than its core, and a slanted beam
  // takes a longer path through the same deck.
  float od = smoothstep(0.04, 0.62, cov) * uCloudDensity * 4.2 / up;
  return exp(-od);
}

void main(){
  float coastDepth = uSeaLevel - islandHeight(vWorldPos.xz);
  if (coastDepth < -2.) discard;
  vec2 q = swirlCoords(vFlatPos, uTime);
  q = warpCoord(q, uTime, uCurrentStrength);

  vec2 ddx = dFdx(q);
  vec2 ddy = dFdy(q);

  // The two axes of this pixel's footprint on the water, in metres. You look at
  // an ocean almost edge-on, so they differ by orders of magnitude: at the
  // horizon a pixel is centimetres across and kilometres deep. The major axis
  // is what an unfiltered tap would alias on; the minor axis is the detail
  // anisotropic sampling still resolves, and it is the one that decides whether
  // a wavelength is worth shading or belongs in the roughness lobe instead.
  float fpA = length(ddx), fpB = length(ddy);
  float fpMajor = max(fpA, fpB);
  float fpMinor = max(max(min(fpA, fpB), fpMajor / max(uOceanAniso, 1.0)), 1e-5);
  // Roughness answers to the whole pixel, not to the one axis the anisotropic
  // taps sharpen. Charge it for the minor axis alone and the far sea stays
  // nearly mirror-smooth at grazing incidence: every wavelet the filter kept
  // becomes its own specular highlight, and the horizon turns into a field of
  // white speckle. The geometric mean is the isotropic footprint of equal area,
  // so detail stays sharp while the light it reflects is averaged honestly.
  float fpShade = sqrt(fpMinor * fpMajor);

  // ---------------------------------------------------------- surface normal
  vec4 d0 = sampleCascadeGrad(uOceanDeriv0, q, uOceanScales.x, ddx, ddy) * uCascadeGain.x;
  vec4 d1 = sampleCascadeGrad(uOceanDeriv1, q, uOceanScales.y, ddx, ddy) * uCascadeGain.y;
  vec4 d2 = sampleCascadeGrad(uOceanDeriv2, q, uOceanScales.z, ddx, ddy) * uCascadeGain.z;
  vec4 dsum = (d0 + d1 + d2) * smoothstep(0.,10.,coastDepth);

  vec2 slope = vec2(dsum.x / max(1.0 + dsum.z, 0.05), dsum.y / max(1.0 + dsum.w, 0.05));
  if (coastDepth < 10.) {
    // Differentiate the same shoaling relief used by the projected grid.
    vec2 dx = vec2(.2, 0.), dz = vec2(0., .2);
    slope += vec2(shoreHeight(vFlatPos + dx) - shoreHeight(vFlatPos - dx),
                  shoreHeight(vFlatPos + dz) - shoreHeight(vFlatPos - dz)) / .4;
  }
  slope *= (1.0 - vCalm * 0.85);
  vec3 N = normalize(vec3(-slope.x, 1.0, -slope.y));

  // Capillary detail on top of the spectrum. This used to fade on raw distance,
  // which threw it away past a few hundred metres however much of the frame the
  // water covered — from any high vantage the sea turned to plastic halfway up
  // the image. It fades on footprint now, and the taps are gradient-filtered so
  // the layer can live all the way to where it genuinely stops resolving
  // instead of being cut early to hide its own aliasing.
  float microFade = 1.0 - smoothstep(0.35, 2.2, fpShade);
  if (microFade > 0.004) {
    vec2 wdir = normalize(uWindDir + 1e-5);
    vec2 drift = wdir * uTime;
    // Three taps of the one tile at incommensurate scales, each turned to its
    // own angle. Axis-aligned layers print their lattice across the whole sea
    // now that the detail survives to the horizon — the old pair repeated every
    // ten metres and read as a crosshatch scratched into the water. Rotations
    // mean the repeats never line up, so the eye finds no grid to lock onto.
    mat2 rotA = mat2( 0.8339, 0.5519, -0.5519, 0.8339);
    mat2 rotB = mat2(-0.2225, 0.9749, -0.9749, -0.2225);
    vec2 qA = rotA * q, qB = rotB * q;
    vec3 r0 = textureGrad(uRippleTex, q * 0.0131 + drift * 0.0075,
                          ddx * 0.0131, ddy * 0.0131).xyz * 2.0 - 1.0;
    vec3 r1 = textureGrad(uRippleTex, qA * 0.0474 - drift * 0.019,
                          rotA * ddx * 0.0474, rotA * ddy * 0.0474).xyz * 2.0 - 1.0;
    vec3 r2 = textureGrad(uRippleTex, qB * 0.1327 + drift * 0.041,
                          rotB * ddx * 0.1327, rotB * ddy * 0.1327).xyz * 2.0 - 1.0;
    // Each layer's slope lives in its own rotated frame; carry it back with the
    // transpose before adding, or the ripples all lean the same wrong way.
    vec2 micro = r0.xz * 0.46 + (r1.xz * rotA) * 0.33 + (r2.xz * rotB) * 0.21;
    micro *= microFade * (0.05 + 0.011 * uWindSpeed);
    N = normalize(N + vec3(micro.x, 0.0, micro.y));
  }

  // rain impact ripples
  float rainRip = 0.0;
  if (uRain > 0.01) {
    float f = exp(-vDist * 0.012);
    if (f > 0.004) {
      vec2 cellUv = q * 2.2;
      vec2 ci = floor(cellUv);
      vec2 cf = fract(cellUv) - 0.5;
      float rnd = hash12(ci);
      float phase = fract(uTime * (0.9 + rnd * 0.6) + rnd);
      float rad = phase * 0.48;
      float dd = length(cf);
      float ring = exp(-pow((dd - rad) * 26.0, 2.0)) * (1.0 - phase) * step(rnd, uRain * 0.85);
      vec2 dir = normalize(cf + 1e-5);
      N = normalize(N + vec3(dir.x, 0.0, dir.y) * ring * .28 * f);
      rainRip = ring * f;
    }
  }

  vec3 Nflat = N;
  bool underwater = uUnderwater > 0.5;
  vec3 V = normalize(uCamPos - vWorldPos);
  // Only the geometric underside is submerged. A shaded ripple facing away
  // from the eye is still above water; treating it as submerged printed dark
  // horizontal strips across the grazing-angle sea. Keep its normal in the
  // visible hemisphere without switching the water-body shading branch.
  bool backLit = !gl_FrontFacing;
  if (backLit) N = -N;
  N = normalize(N + V * max(0., -dot(N, V) + .001));
  underwater = underwater || backLit;

  // -------------------------------------------------------------- roughness
  // Cox & Munk mean-square slope; only the sub-pixel part becomes roughness.
  float mssTotal = 0.003 + 0.00512 * max(uWindSpeed, 0.5);
  vec3 share = vec3(0.06, 0.30, 0.64);
  vec3 sampledLod = log2(max(vec3(fpShade) * (uOceanTexels / uOceanScales), vec3(1.0)));
  float lost = share.x * clamp(sampledLod.x / 6.0, 0.0, 1.0)
             + share.y * clamp(sampledLod.y / 6.0, 0.0, 1.0)
             + share.z * clamp(sampledLod.z / 6.0, 0.0, 1.0);
  lost = max(lost, 1.0 - microFade * 0.9);
  float mssUnres = mssTotal * lost + 0.0009;
  float alpha = clamp(sqrt(2.0 * mssUnres), 0.012, 0.62);
  float roughness = clamp(sqrt(alpha), 0.02, 0.86);

  // ------------------------------------------------------------------- foam
  vec4 t0 = sampleCascadeGrad(uOceanTurb0, q, uOceanScales.x, ddx, ddy);
  vec4 t1 = sampleCascadeGrad(uOceanTurb1, q, uOceanScales.y, ddx, ddy);
  vec4 t2 = sampleCascadeGrad(uOceanTurb2, q, uOceanScales.z, ddx, ddy);
  // The cascades overlap in space, so take the strongest raft rather than the
  // sum — adding them triple-counts a crest that all three see.
  float rawFoam = max(max(t0.r * 0.22, t1.r), t2.r * 0.45);
  // Active spilling crests show immediately; accumulated rafts trail behind.
  rawFoam = max(rawFoam * 1.45, max(t1.b * .95, t2.b * .22));
  float bubbles = t0.g * 0.35 + t1.g * 0.7 + t2.g * 0.3;

  float foamMask = (rawFoam * uFoamStrength + vCrest * 0.8) * (1.0 - vCalm * 0.9);

  // Erode with baked bubble rafts. The lookup is stretched along the wind
  // because Langmuir cells organise surface foam into windrows: long streaks
  // running downwind, tens of metres apart. Sampling isotropic noise instead
  // gives a spatter that reads as wet sand once it covers a whole wave face.
  vec2 wd = normalize(uWindDir + vec2(1e-5, 0.0));
  mat2 windFrame = mat2(wd.x, -wd.y, wd.y, wd.x);
  vec2 qs = windFrame * q;
  vec2 stretch = vec2(0.24, 1.0);   // wind tears old rafts into narrow streamers
  float t = uTime;
  vec2 gx = windFrame * ddx, gy = windFrame * ddy;
  vec4 fx0 = textureGrad(uFoamTex, qs * 0.031 * stretch + vec2(t * 0.004, -t * 0.003),
                         gx * 0.031 * stretch, gy * 0.031 * stretch);
  vec4 fx1 = textureGrad(uFoamTex, qs * 0.145 * stretch - vec2(t * 0.011, t * 0.008),
                         gx * 0.145 * stretch, gy * 0.145 * stretch);
  vec4 fx2 = textureGrad(uFoamTex, q * 0.62 + vec2(-t * 0.03, t * 0.021), ddx * 0.62, ddy * 0.62);
  float foamNoise = fx0.a * 0.5 + fx1.a * 0.42 + fx2.a * 0.22;
  float foamDetail = fx1.r * 0.55 + fx2.r * 0.45;
  float foamFine = fx2.g * 0.6 + fx1.g * 0.4;

  // Monahan whitecap coverage sets how easily a raft survives: a light breeze
  // leaves nothing behind, a storm keeps the sea streaked between breakers.
  // The noise multiplies rather than merely modulates, so where the windrow
  // pattern is empty the water stays water no matter how much foam the
  // simulation deposited there.
  float onset = mix(0.62, 0.28, clamp(uWhitecapCoverage / 0.16, 0.0, 1.0));
  float carved = foamMask * (0.10 + foamNoise * 1.55);
  float foam = smoothstep(onset, onset + 0.24, carved);
  float surfPhase = shorePhase(vFlatPos, uSeaLevel - islandHeight(vFlatPos));
  float breaker = smoothstep(.50, .96, sin(surfPhase));
  float foamAge = mod(surfPhase - 1.5707963 + 6.2831853, 6.2831853) / 1.25;
  float wash = exp(-foamAge * 1.2);
  float shoreBand = smoothstep(-.1, .45, coastDepth) * (1. - smoothstep(2., 5.5, coastDepth));
  vec4 surfTex = textureGrad(uFoamTex, vFlatPos * .055 + vec2(t * .003, -t * .002), ddx * .055, ddy * .055);
  float surfPatch = smoothstep(.46, .72, surfTex.a + fx1.r * .08);
  float shoreFoam = shoreBand * max(breaker * .92, wash * .64) * surfPatch * shoreBreakup(vFlatPos);
  foam = max(foam, shoreFoam);
  // Opaque bubble clusters with porous edges, instead of a uniformly grey film.
  // Resolve holes inside a raft as well as its outline, without painting a
  // solid white sheet wherever the low-resolution breaking field saturates.
  foam *= smoothstep(.40, .65, foamNoise) * smoothstep(.25, .65, foamDetail + fx0.r * .08);
  // Fresh aerated crests are denser than the perforated rafts left behind.
  // Keep their position tied to instantaneous breaking, not accumulated foam.
  float fresh = smoothstep(.42, .78, max(t1.b, t0.b * .5));
  fresh *= smoothstep(.36, .65, fx0.a * .65 + fx1.a * .35) * (.55 + fx1.r * .45);
  foam = max(foam, fresh);
  float foamThin = smoothstep(onset * 0.55, onset + 0.30, carved) * smoothstep(.35, .65, foamNoise);

  // foam perturbs the normal too
  N = normalize(N + vec3(fx2.r - fx2.b, 0.0, fx2.g - fx2.a) * foam * 0.35 * microFade);

  float NoV = max(dot(N, V), 1e-4);
  vec3 L = normalize(uSunDir);
  float NoL = dot(N, L);

  // --------------------------------------------------------------- lighting
  // The sky, the clouds and the spout all take the sun through the atmospheric
  // transmittance LUT; the sea used to take it raw, so at low elevations the
  // water kept a white midday sun while everything above it went red.
  vec3 tluPos = vec3(0.0, groundRadiusMM + max(uCamPos.y, 0.2) * 1e-6, 0.0);
  vec3 sunTrans = getValFromTLUT(uTransmittanceLUT, tluPos, uSunDir);
  vec3 sun = uSunColor * sunTrans * uSunIntensity * cloudShadow(vWorldPos, L);
  vec3 R = reflect(-V, N);

  // bend reflections that dive below the horizon back up along the surface
  float rUp = R.y;
  if (rUp < 0.0) R = normalize(vec3(R.x, mix(0.02, 0.35, roughness) - rUp * 0.15, R.z));

  // The GGX lobe half-angle is ~alpha radians; an equirect probe covers 2pi
  // across its width, so match the mip to the lobe instead of over-blurring —
  // the bright band just above the horizon is most of the water's reflection.
  float lobeTexels = alpha * 0.5 / (6.2831853 / max(uEnvWidth, 8.0));
  float envLod = clamp(log2(max(lobeTexels, 1.0)), 0.0, uEnvMaxLod);
  vec3 env = textureLod(uEnvMap, dirToEquirect(R), envLod).rgb;
  vec3 skyAmb = skyIrradiance(uEnvMap, uEnvMaxLod);

  float F = fresnelWater(NoV, roughness);

  // sun specular (disc-widened GGX)
  vec3 spec = vec3(0.0);
  if (NoL > 0.0) {
    vec3 H = normalize(L + V);
    float NoH = max(dot(N, H), 0.0);
    float VoH = max(dot(V, H), 1e-4);
    float a = alpha;
    float aP = clamp(a + 0.00465 / 2.0, 0.0, 1.0);
    float norm = (a * a) / (aP * aP);
    float D = ggxD(NoH, aP);
    float Vis = smithGGXCorrelated(NoV, max(NoL, 1e-4), a);
    float Fs = 0.02 + 0.98 * pow(1.0 - VoH, 5.0);
    spec = sun * D * Vis * Fs * NoL * norm;
  }
  spec += env * F * 0.0;   // (env already carries the mirror term below)

  // --------------------------------------------------- subsurface scattering
  // Everything the eye sees that did NOT reflect off the surface comes out of
  // the water body. Open ocean has a volume reflectance of a few percent that
  // peaks in the blue-green, and it is driven by the whole downwelling
  // irradiance, so it tracks the cloud deck through the probe.
  vec3 bodyR = uWaterScatter;

  // Light that entered a wave and left toward the eye: peaks looking into a
  // backlit crest, which is what makes a breaking wave glow. Only the wind-wave
  // relief counts — a crest is thin, which is the whole reason it lights up.
  float heightNorm = clamp(vWaveY * 0.35 + 0.35, 0.0, 1.5);
  // A tsunami face is not a backlit sheet, it is tens of metres of opaque
  // water, so the deeper the body behind the surface the less gets through.
  float thinness = 1.0 / (1.0 + max(vEventY, 0.0) * 0.075);
  float backlit = heightNorm * thinness
                * pow(clamp(dot(L, -V), 0.0, 1.0), 4.0)
                * pow(0.5 - 0.5 * dot(L, N), 3.0);
  vec3 scatter = bodyR * sun * backlit * 3.4 / (1.0 + max(0.0, -L.y) * 4.0);

  // Downwelling irradiance just under the surface: the direct beam landing on a
  // horizontal plane, plus the diffuse sky. skyIrradiance already returns E/pi,
  // so the beam needs its own 1/pi to sit on the same scale, and what the
  // surface reflects away never enters the volume.
  float sunUp = max(L.y, 0.0);
  vec3 beam = sun * sunUp * (1.0 - fresnelWater(max(sunUp, 1e-3), 0.0)) / PI_S;
  scatter += bodyR * (beam + skyAmb * 0.94);

  // Entrained bubbles keep scattering for a while after the crest has broken.
  scatter += bodyR * bubbles * 0.55 * (skyAmb * 1.6 + sun * 0.10);

  // Whatever little climbs back out of the deep water below.
  vec3 deep = uWaterAbsorb * skyAmb * 0.8;
  vec3 refracted = scatter + deep;
  // Sand shows through shallow water; red is absorbed first with depth.
  vec3 bottomTransmission = exp(-max(coastDepth, 0.) * vec3(.42, .17, .11) * 1.6);
  vec3 sand = vec3(.36, .29, .18) * (beam + skyAmb * .94);
  refracted = mix(refracted, sand, bottomTransmission);

  // ------------------------------------------------------------- combine
  vec3 color = mix(refracted, env, F) + spec;

  if (backLit) {
    // Looking out through the body of the wave. Almost nothing specular
    // survives — past the critical angle the surface is a mirror pointing back
    // into the dark water — but a great deal of light diffuses through the
    // sheet, which is why the inside of a breaking wave glows green.
    float thickness = clamp(0.35 + vWaveY * 0.04, 0.15, 1.0);
    // What reaches the eye through a sheet of water is the light behind it cut
    // down by absorption — not the two or three percent that backscatters.
    // Driving this off the volume reflectance instead makes the inside of every
    // wave a black hole, which is exactly what a tsunami face used to look like.
    vec3 through = (sun * max(L.y, 0.05) * 0.45 + skyAmb * 1.15)
                 * uWaterAbsorb / (1.0 + thickness * 2.0);
    // plus the light that genuinely scattered inside the body, and the bubbles
    // entrained in it, which is what gives a breaking wave its green core —
    // over a metre or two of water. Through the shoulder of a solitary wave the
    // same term is a wall of jade, so it dies with the depth behind the surface.
    through += bodyR * (sun * 2.2 + skyAmb * 1.8) * thinness;
    through += bodyR * bubbles * skyAmb * 1.4;
    color = mix(through, color, 0.18);
  }

  // ---------------------------------------------------------------- foam mat
  if (foam > 0.002 || foamThin > 0.002) {
    float foamAO = mix(0.82, 1.0, foamFine);
    vec3 foamAlbedo = vec3(0.93, 0.96, 0.985) * foamAO;
    float wrapNoL = clamp((dot(N, L) + 0.45) / 1.45, 0.0, 1.0);
    // The cloud probe carries only single scattering. Account for diffuse
    // interreflection inside the dense bubble layer, with the same sky tint.
    vec3 foamLit = foamAlbedo * (sun * wrapNoL * 0.30 + skyAmb * 6.0);
    // bubbles scatter the sun through the raft
    foamLit += foamAlbedo * sun * pow(clamp(dot(V, -L), 0.0, 1.0), 3.0) * 0.10 * foamFine;
    vec3 fspec = vec3(0.0);
    if (NoL > 0.0) {
      vec3 H = normalize(L + V);
      float NoH = max(dot(N, H), 0.0);
      float aF = 0.55;
      fspec = sun * ggxD(NoH, aF) * smithGGXCorrelated(NoV, max(NoL, 1e-4), aF) * 0.04 * NoL;
    }
    color = mix(color, foamLit + fspec, foam);
    // The bubble slick trailing a breaker is translucent, not paint: it lifts
    // the water a little and kills the specular, it does not turn it white.
    color = mix(color, mix(color, foamLit, 0.20), foamThin * (1.0 - foam));
  }

  color += vec3(rainRip) * sun * 0.02;
  vec3 preLightning = color;

  // ----------------------------------------------------------- lightning
  color += lightningContribution(vWorldPos, N, V, uLightning0, uLightning1, uLightningColor)
         * (0.55 + foam * 1.6);
  color += uAmbientFlash * uLightningColor * (0.02 + foam * 0.35 + F * 0.25);

  // ------------------------------------------------------ aerial perspective
  vec2 screenUv = gl_FragCoord.xy / uResolution;
  float haze = 1.-exp(-vDist * max(.000025,uFogDensity*.045));
  vec3 horizonDir = normalize(vec3(vWorldPos.x-uCamPos.x, 120., vWorldPos.z-uCamPos.z));
  vec4 ap = vec4(textureLod(uEnvMap, dirToEquirect(horizonDir), 4.).rgb * haze / max(uSunIntensity,.01), 1.-haze);
  vec3 tr = pow(vec3(clamp(ap.a, 0.0, 1.0)), vec3(1.0, 1.06, 1.16));
  color = color * tr + ap.rgb * uSunIntensity;

  if (uDebugMode > 0.5) {
    vec3 dbg = vec3(0.0);
    int m = int(uDebugMode + 0.5);
    if (m == 1) dbg = N * 0.5 + 0.5;
    else if (m == 2) dbg = vec3(foam, foamThin, foamMask * 0.3);
    else if (m == 3) dbg = env * 0.05;
    else if (m == 4) dbg = vec3(F);
    else if (m == 5) dbg = abs(vDisp) * 0.1;
    else if (m == 6) dbg = ap.rgb * uSunIntensity * 0.1;
    else if (m == 7) dbg = vec3(t1.r, t1.g, t1.b);
    else if (m == 8) dbg = vec3(roughness);
    else if (m == 9) dbg = refracted * 0.5;
    else if (m == 10) dbg = spec * 0.02;
    else if (m == 11) dbg = vec3(vLods / 8.0);
    else if (m == 12) dbg = vec3(fract(vDist * 0.001), fract(vDist * 0.01), 0.0);
    else if (m == 13) dbg = preLightning / 3.0;
    else if (m == 14) dbg = (color - preLightning * tr) / 3.0;
    else if (m == 15) dbg = vec3(sun) / 3.0;
    else if (m == 16) dbg = color / 3.0;
    else if (m == 17) dbg = lightningContribution(vWorldPos, N, V, uLightning0, uLightning1, uLightningColor) / 3.0;
    else if (m == 18) dbg = vec3(uAmbientFlash, uLightning0.w, uLightning1.w) / 3.0;
    oColor = vec4(dbg * 3.0, 1.0);
    return;
  }

  oColor = vec4(max(color, vec3(0.0)), 1.0);

  vec2 cur = vClipNJ.xy / max(vClipNJ.w, 1e-6);
  vec2 prv = vPrevClipNJ.xy / max(vPrevClipNJ.w, 1e-6);
}
`;class aY{constructor(e,t,i,a,r){this.fft=e,this.gridX=0,this.gridY=0;const o={uRMax:{value:68e3},uGridSize:{value:new L.Vector2(1,1)},uGridMargin:{value:1.04},uSkirt:{value:1.1},uGridPlane:{value:0},uEventSteps:{value:16},uEventBisect:{value:8},uCurrentStrength:{value:0},uDisplaceScale:{value:1},uCascadeGain:{value:new L.Vector3(1,1,.65)},uWaterScatter:{value:new L.Vector3(.018,.075,.088)},uWaterAbsorb:{value:new L.Vector3(.004,.021,.036)},uFoamStrength:{value:1},uUnderwater:{value:0},uDebugMode:{value:0},...r};e.bind(o),t.bind(o),o.uSunDir=r.uSunDir,o.uSunColor=r.uSunColor,o.uSunIntensity=r.uSunIntensity,o.uAtmoTurbidity=r.uAtmoTurbidity,o.uAtmoMieG=r.uAtmoMieG,o.uAtmoGroundAlbedo=r.uAtmoGroundAlbedo,o.uCamPos={value:new L.Vector3},o.uViewProjNJ={value:new L.Matrix4},o.uPrevViewProjNJ={value:new L.Matrix4},o.uInvViewProjNJ={value:new L.Matrix4},o.uWeatherMap=a?.uWeatherMap??{value:null},o.uWeatherScaleM=a?.uWeatherScaleM??{value:58e3},o.uCoverage=a?.uCoverage??{value:0},o.uCloudContrast=a?.uCloudContrast??{value:1.6},o.uCloudDensity=a?.uCloudDensity??{value:.6},o.uCloudBottom=a?.uCloudBottom??{value:1200},o.uCloudWind=a?.uCloudWind??{value:new L.Vector2},o.uCloudTime=a?.uCloudTime??{value:0},this.uniforms=o,this.material=new L.RawShaderMaterial({name:"OceanSurface",glslVersion:L.GLSL3,vertexShader:aX,fragmentShader:aK,uniforms:o,side:L.DoubleSide,transparent:!1,depthWrite:!0,depthTest:!0}),this.mesh=new L.Mesh(new L.BufferGeometry,this.material),this.mesh.frustumCulled=!1,this.mesh.name="abyssal-ocean";const s=new L.PerspectiveCamera;this.mesh.onBeforeRender=(e,t,i)=>{s.copy(i,!1),s.updateProjectionMatrix(),o.uCamPos.value.setFromMatrixPosition(i.matrixWorld),o.uViewProjNJ.value.multiplyMatrices(s.projectionMatrix,i.matrixWorldInverse),o.uInvViewProjNJ.value.copy(o.uViewProjNJ.value).invert(),o.uPrevViewProjNJ.value.copy(o.uViewProjNJ.value)},this.mesh.renderOrder=0,this.setResolution(i.oceanGridX,i.oceanGridY)}setResolution(e,t){if(e=Math.max(16,0|e),t=Math.max(12,0|t),this.gridX===e&&this.gridY===t)return;this.gridX=e,this.gridY=t;let i=this.mesh.geometry;this.mesh.geometry=function(e,t){let i=new Float32Array((e+1)*(t+1)*2),a=0;for(let r=0;r<=t;r++)for(let o=0;o<=e;o++)i[a++]=o/e,i[a++]=r/t;let r=new Uint32Array(e*t*6),o=0;for(let i=0;i<t;i++)for(let t=0;t<e;t++){let a=i*(e+1)+t,s=a+1,n=a+(e+1),l=n+1;r[o++]=a,r[o++]=l,r[o++]=n,r[o++]=a,r[o++]=s,r[o++]=l}let s=new L.BufferGeometry;return s.setAttribute("aGrid",new L.BufferAttribute(i,2)),s.setIndex(new L.BufferAttribute(r,1)),s.boundingSphere=new L.Sphere(new L.Vector3,1e9),s}(e,t),i&&i.dispose(),this.uniforms.uGridSize.value.set(e,t),this.triangles=e*t*2}update(e,t=0){this.uniforms.uUnderwater.value=+(e.y<t)}dispose(){this.mesh.geometry.dispose(),this.material.dispose()}}class aZ{constructor(e,t,i,a,r,o){this.renderer=e,this.narrow=t,this.island=!1,this.city=!1,this.anchorDirty=!1,this.viewDirection=new L.Vector3,this.oceanDirty=!1,this.U={uTime:{value:0},uDt:{value:1/60},uFrame:{value:0},uResolution:{value:new L.Vector2(1,1)},uInvResolution:{value:new L.Vector2(1,1)},uCamPos:{value:new L.Vector3},uPrevCamPos:{value:new L.Vector3},uViewProj:{value:new L.Matrix4},uPrevViewProj:{value:new L.Matrix4},uInvViewProj:{value:new L.Matrix4},uViewProjNJ:{value:new L.Matrix4},uPrevViewProjNJ:{value:new L.Matrix4},uInvViewProjNJ:{value:new L.Matrix4},uJitter:{value:new L.Vector2},uPrevJitter:{value:new L.Vector2},uNear:{value:.1},uFar:{value:12e4},uSunDir:{value:new L.Vector3(.3,.4,-.86)},uSunColor:{value:new L.Vector3(1,.96,.9)},uSunIntensity:{value:22},uMoonDir:{value:new L.Vector3(-.3,.5,.8)},uAtmoTurbidity:{value:1},uAtmoMieG:{value:.78},uAtmoGroundAlbedo:{value:new L.Vector3(.06,.09,.12)},uAmbientColor:{value:new L.Vector3(.1,.2,.35)},uWindDir:{value:new L.Vector2(1,0)},uWindSpeed:{value:8},uGustiness:{value:.3},uRain:{value:0},uFogDensity:{value:0},uSprayAmount:{value:0},uWhitecapCoverage:{value:0},uStormFactor:{value:0},uSeaLevel:{value:0},uLightning0:{value:new L.Vector4(0,0,0,0)},uLightning1:{value:new L.Vector4(0,0,0,0)},uLightningColor:{value:new L.Vector3(.75,.85,1)},uAmbientFlash:{value:0},uVortex0:{value:new L.Vector4(0,0,0,0)},uVortex1:{value:new L.Vector4(0,0,0,0)},uVortex2:{value:new L.Vector4(0,0,0,0)},uVortex3:{value:new L.Vector4(0,0,0,0)},uSoliton0:{value:new L.Vector4(0,0,0,0)},uSoliton0b:{value:new L.Vector4(0,0,0,0)},uSoliton1:{value:new L.Vector4(0,0,0,0)},uSoliton1b:{value:new L.Vector4(0,0,0,0)},uRogue:{value:new L.Vector4(0,0,0,0)},uRogueB:{value:new L.Vector4(0,0,0,0)},uHurricane:{value:new L.Vector4(0,0,0,0)},uFoamTex:{value:null},uRippleTex:{value:null},uCurlTex:{value:null},uEnvMap:{value:null},uEnvMaxLod:{value:6},uEnvWidth:{value:256},uExposure:{value:1},uEarthCurvature:{value:1}},this.root=new L.Group,this.root.name="abyssal-weather",this.atmosphere=new as(e),this.sky=new ab(e,this.atmosphere,this.U),this.rain=new aP({rainCount:t?9e3:24e3},this.U,i,a),this.lightning=new aR(this.U),this.spout=new aI(this.U),this.spout.setLUTs(this.atmosphere),this.spout.setQuality({spoutSteps:t?40:64}),this.weather=new aM(this,this.U),this.flash=new L.DirectionalLight(0xc7dfff,0),this.flash.position.set(-40,80,-70),this.root.add(this.sky.mesh,this.rain.mesh,this.lightning.mesh,this.spout.mesh,this.flash,this.flash.target),this.generator=new R.PMREMGenerator(e),this.environment=null,this.time=0,this.frame=0,this.nextStrike=1.6,this.cloudAt=-1/0,this.skyHeight=-1/0,this.dirty=!0,this.storm=!1,this.tornado=!1,this.motion=!0,this.status="loading",this.abort=new AbortController,this.size=new L.Vector2,this.ready=i6(e,void 0,this.abort.signal).then(i=>{this.abort.signal.aborted?i7(i):(this.textures=i,this.U.uCurlTex.value=i.curl,this.clouds=new au(e,this.atmosphere,i,{envSize:t?256:512,cloudSteps:256,cloudLightSteps:t?3:5},this.U),this.sky.setCloudTextures(this.clouds.screenRT.texture,this.clouds.envTexture),this.status="ready",this.ensureOcean(),this.dirty=!0,r())}).catch(e=>{this.abort.signal.aborted||(this.status="error",console.error("ABYSSAL weather initialization failed",e),o())})}set({cloud:e,rain:t,wind:i,fog:a,storm:r,tornado:o,sand:s,urban:n,island:l=!1,city:h=!1}){this.island=l,this.city=h,this.anchorDirty=h,this.sky.shared.uCityHaze.value=Number(h),this.ensureOcean(),this.oceanDirty=l,this.weather.set({windSpeed:l?Math.max(3.2,1.25*i):i,windAngle:.6,gustiness:r?.7:.25,swellHs:l?.55+.22*i:1.4,swellPeriod:8+.16*i,choppiness:.9+.012*Math.min(i,22),spray:l?L.MathUtils.smoothstep(i,4,24):0,waterScatter:new L.Vector3(.022+.028*e,.09+.055*e,.12+.035*e),waterAbsorb:new L.Vector3(.004,.025,.038),rain:t,turbidity:s?7:1+2.5*e,mieG:.78,cloudCoverage:e,cloudDensity:e>.8?.85:.55,cloudBottom:e>.8?600:1200,cloudTop:e>.8?3200:4e3,cloudAnvil:.65*!!r,storm:r?1:.35*e,fog:a,lightningRate:.12*!!r,seaLevel:l?-5.5:n?-120:-.6},!0),this.storm=r,this.tornado=o,this.lightning.clear(),this.spout.clear(),this.flash.intensity=0,this.spray&&(this.spray.reset=!0),this.time=0,this.nextStrike=1.6,this.cloudAt=-1/0,o&&(this.spout.spawn(-950,-3500,25),this.spout.life=6),this.dirty=!0}setTime(e,t,i){this.weather.set({sunElevation:e,sunAzimuth:t,sunIntensity:4.5,starIntensity:1-i},!0),this.sky.shared.uUrbanGlow.value=this.city?1-i:0,this.dirty=!0}update(e,t,i,a){var r,o;this.time=t;let s=this.U;if(this.motion&&!a&&(this.lightning.clear(),this.flash.intensity=0,this.dirty=!0),this.motion=a,r=e.projectionMatrix,o=this.frame++,s.uTime.value=t,s.uDt.value=i,s.uFrame.value=o,s.uPrevViewProj.value.copy(s.uViewProj.value),s.uPrevViewProjNJ.value.copy(s.uViewProjNJ.value),s.uPrevCamPos.value.copy(s.uCamPos.value),e.updateMatrixWorld(),s.uViewProj.value.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),s.uInvViewProj.value.copy(s.uViewProj.value).invert(),s.uViewProjNJ.value.multiplyMatrices(r,e.matrixWorldInverse),s.uInvViewProjNJ.value.copy(s.uViewProjNJ.value).invert(),s.uCamPos.value.setFromMatrixPosition(e.matrixWorld),s.uNear.value=e.near,s.uFar.value=e.far,this.weather.update(i),this.island&&this.ocean&&(i>0||this.oceanDirty)&&(this.ocean.update(i),this.oceanDirty=!1),this.oceanMesh?.update(e.position,s.uSeaLevel.value),this.spray?.update(a?i:0,this.island?s.uSprayAmount.value:0),a&&this.storm&&t>=this.nextStrike){e.getWorldDirection(this.viewDirection);let i=this.city?Math.atan2(this.viewDirection.z,this.viewDirection.x)+(Math.random()-.5)*1.4:-Math.PI*(.25+.6*Math.random());this.lightning.strike((this.city?e.position.x:0)+3e3*Math.cos(i),(this.city?e.position.z:0)+3e3*Math.sin(i),this.weather.state.cloudBottom),this.nextStrike=t+5+7*Math.random()}this.lightning.update(a?i:0,t,a?this.weather.state:{lightningRate:0}),this.flash.intensity=a?1.4*s.uAmbientFlash.value:0,this.tornado&&!this.spout.active&&this.spout.spawn(-950,-3500,25),this.city&&this.tornado&&(this.anchorDirty||Math.hypot(this.spout.x-e.position.x,this.spout.z-e.position.z)>4500)&&(e.getWorldDirection(this.viewDirection),this.viewDirection.y=0,.001>this.viewDirection.lengthSq()&&this.viewDirection.set(0,0,1),this.viewDirection.normalize(),this.spout.x=e.position.x+1800*this.viewDirection.x+750*this.viewDirection.z,this.spout.z=e.position.z+1800*this.viewDirection.z-750*this.viewDirection.x,this.anchorDirty=!1),this.spout.update(a?i:0,this.weather.state.cloudBottom),this.renderer.getDrawingBufferSize(this.size),this.rain.update(e,this.weather.state.rain,this.size.y),this.sky.mainCamera=e,this.sky.update(t),this.sky.shared.uCloudEnabled.value=this.clouds&&this.weather.state.cloudCoverage>0?1:0;let n=this.dirty||t-this.cloudAt>=.25||Math.abs(e.position.y-this.skyHeight)>1;n&&(this.atmosphere.update(e,e.position),this.atmosphere.syncUniforms(s)),this.clouds?.update(t,this.size.x,this.size.y,n),n&&(this.sky.renderEnv(),this.environment=this.generator.fromEquirectangular(this.sky.envRT.texture,this.environment),this.cloudAt=t,this.dirty=!1,this.skyHeight=e.position.y)}ensureOcean(){if(this.island&&"ready"===this.status&&!this.ocean){var e;let t;this.oceanTextures=(e=this.renderer,{foam:i4(e,i0,t=this.narrow?512:1024,t,{},!0),ripple:i4(e,i1,t,t,{uRes:{value:t},uSlope:{value:.03}},!0)}),this.U.uFoamTex.value=this.oceanTextures.foam.texture,this.U.uRippleTex.value=this.oceanTextures.ripple.texture,this.ocean=new aq(this.renderer,{size:this.narrow?64:256}),this.oceanMesh=new aY(this.ocean,this.atmosphere,{oceanGridX:this.narrow?128:320,oceanGridY:this.narrow?96:224},this.clouds?.shared,this.U),this.spray=new az(this.renderer,this.ocean,{sprayCount:this.narrow?4096:16384},this.oceanMesh.uniforms,this.U),this.root.add(this.oceanMesh.mesh,this.spray.mesh),this.oceanDirty=!0}this.oceanMesh&&(this.oceanMesh.mesh.visible=this.island)}dispose(){this.abort.abort(),this.spray?.dispose(),this.oceanMesh?.dispose(),this.ocean?.dispose(),this.oceanTextures?.foam.dispose(),this.oceanTextures?.ripple.dispose(),this.clouds?.dispose(),this.textures&&i7(this.textures),this.rain.dispose(),this.lightning.dispose(),this.spout.dispose(),this.sky.dispose(),this.atmosphere.dispose(),this.environment?.dispose(),this.generator.dispose(),this.flash.shadow.dispose(),this.root.removeFromParent()}}function a$(e){if(!tx(e))throw Error("timeOfDay");let[t,i]=e.split(":").map(Number),a=((60*t+i)/720-1)*Math.PI,r=L.MathUtils.degToRad(31.2534),o=new L.Vector3(-Math.sin(a),Math.cos(r)*Math.cos(a),Math.sin(r)*Math.cos(a)),s=Math.asin(o.y);return{direction:o,elevation:s,azimuth:Math.atan2(o.z,o.x),day:L.MathUtils.smoothstep(s,-.12,.12),sun:L.MathUtils.smoothstep(s,0,.18)}}let aQ={sunny:[0,0,0,0,0],cloudy:[.42,0,0,.7,0],overcast:[.9,0,0,1,.003],windy:[.45,4,.3,10,.002],drizzle:[.65,1,.22,.8,.004],rain:[.8,1,.6,2,.005],downpour:[1,1,1,4,.009],lightning:[.92,0,0,3,.004],thunderstorm:[1,1,.85,6,.008],fog:[.85,0,0,0,.032],snow:[.62,2,.65,1,.007],blizzard:[1,2,1,12,.022],sleet:[.85,2,.7,4,.008],hail:[.95,3,.65,5,.007],sandstorm:[1,4,1,14,.02],typhoon:[1,1,1,22,.015],tornado:[1,4,.5,10,.007],mudslide:[1,1,.8,6,.008],rainbow:[.25,0,0,0,.001]},aJ=`
uniform float uCompany;
float roofAt(vec2 p) {
  if(uCompany > 0.5) return p.x >= -26.2 && p.x <= 0.9 && p.y >= -5.9 && p.y <= 13.1 ? 3.8 : -120.;
  float h = -120.;
  ${Object.values(tw).map(e=>`if(abs(p.x - ${e.x.toFixed(2)}) <= ${(e.width/2+.35).toFixed(2)} && abs(p.y - ${e.z.toFixed(2)}) <= ${(e.depth/2+.35).toFixed(2)}) h = max(h, ${e.ceiling.toFixed(2)});`).join("\n")}
  return h;
}`;class a0{root=new L.Group;engine;daylight=a$("09:00");particles=null;mud=null;rocks=null;rainbowSky=null;uniforms={uTime:{value:0},uCompany:{value:0},uUrban:{value:0},uCity:{value:0},uWind:{value:0},uKind:{value:0},uDensity:{value:0},uSnow:{value:0},uWet:{value:0},uAnchor:{value:new L.Vector3},uTint:{value:new L.Color}};kind="sunny";elapsed=0;lastTime=0;animated=!1;patched=new Set;storm=!1;fogScale=1;matrix=new L.Object3D;budget;constructor(e,t,i,a){this.budget=e?2400:6500,this.root.name="space-weather",this.root.userData.spaceBackdrop=!0,this.engine=new aZ(t,e,aJ,{uCompany:this.uniforms.uCompany},i,a),this.root.add(this.engine.root)}get environment(){return this.engine.environment?.texture}set(e,t,i,a=!1,r=!1){this.clearEffects(),this.kind=e,this.elapsed=0,this.lastTime=0,this.fogScale=r?.025:a&&"fog"!==e?.15:1;let[o,s,n,l]=aQ[e];this.uniforms.uTime.value=0,this.uniforms.uKind.value=s,this.uniforms.uDensity.value=n,this.uniforms.uWind.value=l,this.uniforms.uCompany.value=Number("company"===t),this.uniforms.uCity.value=Number(r),this.uniforms.uUrban.value=Number(!a&&!r&&("penthouse"===t||"cyberpunk"===t)),this.uniforms.uSnow.value="snow"===e||"blizzard"===e?.88:.3*("sleet"===e),this.uniforms.uWet.value=+(1===s||3===s||"sleet"===e||"rainbow"===e),this.uniforms.uTint.value.setHex(4===s?"sandstorm"===e?0xb9a17c:0x9f997b:0xdce8f0),this.storm=["lightning","thunderstorm","typhoon"].includes(e),this.animated=a||r||l>0||s>0||this.storm||"mudslide"===e,this.engine.set({cloud:o,rain:1===s?n:"sleet"===e?.5*n:0,island:a,city:r,wind:l,fog:aQ[e][4]*this.fogScale,storm:this.storm,tornado:"tornado"===e,sand:"sandstorm"===e,urban:this.uniforms.uUrban.value>0}),"sleet"===e?this.precipitation(2,.5*n):s>1&&this.precipitation(s,n),"mudslide"===e&&this.mudslide(),"rainbow"===e&&this.rainbow(),this.patchSurfaces(i)}setTime(e){this.daylight=a$(e);let{elevation:t,azimuth:i,day:a}=this.daylight;this.engine.setTime(t,i,a),this.engine.sky.shared.uHorizonColor.value.copy(this.lighting().fog.color)}lighting(){let[e,,,,t]=aQ[this.kind],i=this.uniforms.uCity.value?function(e,t,i=!1){return new L.Color(2634564).lerp(new L.Color(i?9929319:t>.7?8821417:0xadc4d2),e**3)}(this.daylight.day,e,"sandstorm"===this.kind):new L.Color(1515566).lerp(new L.Color("sandstorm"===this.kind?9929319:e>.8?6583681:0xadc4d2),this.daylight.day);return{sun:Math.max(.04,1-.96*e),ambient:1-.32*e,fog:new L.FogExp2(i,Math.max(35e-6*(.025===this.fogScale),(t||8e-4)*this.fogScale))}}precipitation(e,t){let i=function(e){if(!Number.isInteger(e)||e<0||e>24e3)throw RangeError("Particle count must be an integer from 0 to 24000");let t=new Float32Array(4*e),i=7283;for(let e=0;e<t.length;e++)i=Math.imul(i,1664525)+0x3c6ef35f>>>0,t[e]=i/0x100000000;let a=new L.BufferGeometry;return a.setAttribute("position",new L.BufferAttribute(new Float32Array(3*e),3)),a.setAttribute("seed",new L.BufferAttribute(t,4)),a}(Math.floor(this.budget*t)),a=new L.ShaderMaterial({uniforms:{...this.uniforms,uKind:{value:e}},transparent:!0,depthWrite:!1,vertexShader:`${aJ}
        attribute vec4 seed; uniform float uTime, uWind, uKind, uUrban; uniform vec3 uAnchor;
        varying float vAlpha;
        void main() {
          float nearField=step(seed.w,0.68), span=mix(180.,42.,nearField), height=mix(55.,24.,nearField);
          float speed=uKind < 1.5 ? 18. : uKind < 2.5 ? 1.6 : uKind < 3.5 ? 14. : 0.6;
          vec3 p=vec3(mod(seed.x*span+uTime*uWind,span)-span*.5,mod(seed.y*height-uTime*speed,height),seed.z*span-span*.5);
          p.xz+=mix(vec2(-8.,0.),uAnchor.xz,nearField);
          p.y+=mix(-0.5,max(0.,uAnchor.y-10.),nearField);
          if(uKind>1.5) p.xz+=vec2(sin(uTime*.8+seed.x*60.),cos(uTime*.5+seed.z*80.))*.6;
          if(uKind<1.5) p+=vec3(-uWind*.015,.28,0.)*position.y;
          if(uKind>2.5 && uKind<3.5) p.y+=abs(sin(uTime*7.+seed.x*31.))*.35;
          vAlpha=p.y<roofAt(p.xz)+0.15 || (uUrban>0.5 && p.y<0. && abs(p.x+9.)<40. && abs(p.z)<25.) ? 0. : 1.;
          vec4 mv=modelViewMatrix*vec4(p,1.); gl_Position=projectionMatrix*mv;
          gl_PointSize=clamp((uKind<2.5 ? 55. : uKind<3.5 ? 85. : 40.)/max(1.,-mv.z),1.,7.);
        }`,fragmentShader:`uniform vec3 uTint; varying float vAlpha;
        void main(){ float a=(1.-smoothstep(.1,.5,length(gl_PointCoord-.5)))*.65*vAlpha; if(a<.01) discard; gl_FragColor=vec4(uTint,a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        }`});this.particles=new L.Points(i,a),this.particles.frustumCulled=!1,this.root.add(this.particles)}mudslide(){let e=this.uniforms.uUrban.value>0,t=new L.PlaneGeometry(34,110,32,80);t.rotateX(-Math.PI/2);let i=t.attributes.position;for(let e=0;e<i.count;e++){let t=i.getZ(e)+13,a=L.MathUtils.clamp((t+20)/75,0,1),r=1-L.MathUtils.smoothstep(Math.abs(i.getX(e)-3*Math.sin(5*a)),9,17);i.setY(e,(1-a)**3*18*r*L.MathUtils.smoothstep(t,-42,-20))}t.computeVertexNormals();let a=new L.Mesh(t,new L.MeshStandardMaterial({color:5130554,roughness:.94}));a.position.set(-42,e?-119.6:-.6,13),this.root.add(a);let r=new L.PlaneGeometry(15,75,24,64);r.rotateX(-Math.PI/2);let o=r.attributes.position;for(let e=0;e<o.count;e++){let t=o.getZ(e),i=(t+37.5)/75;o.setXYZ(e,o.getX(e)*(.45+.75*i)+3*Math.sin(5*i),(1-i)**3*18+.25,t)}r.computeVertexNormals();let s=new L.MeshStandardMaterial({color:5849905,roughness:.24,metalness:.08});s.onBeforeCompile=e=>{e.uniforms.uTime=this.uniforms.uTime,e.vertexShader="varying vec3 vFlow; uniform float uTime;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\ntransformed.y += sin(position.z*1.3-uTime*4.+position.x)*.12; vFlow=position;"),e.fragmentShader=`${iq} varying vec3 vFlow; uniform float uTime;
`+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <map_fragment>","#include <map_fragment>\nfloat mudNoise=noise(vec3(vFlow.x*2.,vFlow.z*.7-uTime*3.,2.)); diffuseColor.rgb*=.55+mudNoise*.9;")},this.mud=new L.Mesh(r,s),this.mud.position.set(-42,e?-119.6:-.6,17.5),this.root.add(this.mud),this.rocks=new L.InstancedMesh(new L.DodecahedronGeometry(1,0),new L.MeshStandardMaterial({color:7890256,roughness:.8}),80),this.rocks.frustumCulled=!1,this.root.add(this.rocks)}rainbow(){let e=new L.ShaderMaterial({transparent:!0,depthWrite:!1,side:L.BackSide,uniforms:{uSun:{value:this.daylight.direction.clone()},uDay:{value:1}},vertexShader:"varying vec3 vDirection;void main(){vDirection=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",fragmentShader:`varying vec3 vDirection;uniform vec3 uSun;uniform float uDay;void main(){
        vec3 direction=normalize(vDirection);
        float angle=degrees(acos(clamp(dot(direction,-uSun),-1.,1.)));
        float band=(angle-40.4)/2.4, hue=(1.-clamp(band,0.,1.))*.76;
        vec3 color=clamp(abs(mod(hue*6.+vec3(0.,4.,2.),6.)-3.)-1.,0.,1.);
        float a=smoothstep(0.,.18,band)*(1.-smoothstep(.78,1.,band))*smoothstep(-.01,.025,direction.y)*.34*uDay;
        gl_FragColor=vec4(mix(color,vec3(1.),.2),a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`});this.rainbowSky=new L.Mesh(new L.SphereGeometry(1,48,24),e),this.rainbowSky.name="rainbow-sky",this.rainbowSky.frustumCulled=!1,this.root.add(this.rainbowSky)}patchSurfaces(e){e.traverse(e=>{if(e instanceof L.Mesh)for(let t of Array.isArray(e.material)?e.material:[e.material]){if(!(t instanceof L.MeshStandardMaterial)||this.patched.has(t))continue;this.patched.add(t);let e=t.onBeforeCompile,i=t.customProgramCacheKey();t.onBeforeCompile=(i,a)=>{e.call(t,i,a),i.uniforms.uCompany=this.uniforms.uCompany,i.uniforms.uSnow=this.uniforms.uSnow,i.uniforms.uWet=this.uniforms.uWet,i.uniforms.uCity=this.uniforms.uCity,i.vertexShader="varying vec3 vWeatherPosition; varying vec3 vWeatherNormal;\n"+i.vertexShader,i.vertexShader=i.vertexShader.replace("#include <project_vertex>",`#include <project_vertex>
            vec4 weatherPosition=vec4(transformed,1.); vec3 weatherNormal=objectNormal;
            #ifdef USE_INSTANCING
            weatherPosition=instanceMatrix*weatherPosition; weatherNormal=mat3(instanceMatrix)*weatherNormal;
            #endif
            vWeatherPosition=(modelMatrix*weatherPosition).xyz; vWeatherNormal=normalize(mat3(modelMatrix)*weatherNormal);`),i.fragmentShader=`${aJ}
${iq}
uniform float uSnow,uWet,uCity; varying vec3 vWeatherPosition,vWeatherNormal;
`+i.fragmentShader,i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>","#include <color_fragment>\nfloat exposed=step(roofAt(vWeatherPosition.xz)-.55,vWeatherPosition.y)*smoothstep(.45,.85,vWeatherNormal.y); diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.86,.92,.95),exposed*uSnow); diffuseColor.rgb*=1.-exposed*uWet*.14;"),i.fragmentShader=i.fragmentShader.replace("#include <roughnessmap_fragment>",`#include <roughnessmap_fragment>
            // Rain darkens porous surfaces but does not turn an entire city into
            // polished metal. Broad puddle variation stays stable while flying.
            float puddle=noise(vec3(vWeatherPosition.xz*.012,2.7))*.7+noise(vec3(vWeatherPosition.xz*.037,7.1))*.3;
            float wetRoughness=mix(.16,mix(.42,.64,puddle),uCity);
            roughnessFactor=mix(roughnessFactor,min(roughnessFactor,wetRoughness),exposed*uWet);
            roughnessFactor=mix(roughnessFactor,.88,exposed*uSnow);
          `)},t.customProgramCacheKey=()=>i+"-space-weather",t.needsUpdate=!0}})}update(e,t,i){let a=i&&this.animated,r=a&&this.lastTime?Math.min(.1,(e-this.lastTime)/1e3):0;if(this.elapsed+=r,this.lastTime=a?e:0,this.uniforms.uTime.value=this.elapsed,this.uniforms.uAnchor.value.copy(t.position),this.engine.update(t,this.elapsed,r,i),this.rainbowSky&&(this.rainbowSky.position.copy(t.position),this.rainbowSky.scale.setScalar(.8*t.far),this.rainbowSky.material.uniforms.uSun.value.copy(this.daylight.direction),this.rainbowSky.material.uniforms.uDay.value=this.daylight.sun,this.rainbowSky.visible=this.daylight.sun>0),this.rocks){for(let e=0;e<this.rocks.count;e++){let t=function(e,t){if(!Number.isInteger(e)||e<0||!Number.isFinite(t)||t<0)throw RangeError("Invalid debris animation sample");let i=(.61803398875*e+.045*t)%1;return{x:.2*Math.sin(5*i)+Math.sin(3.1*e)/3*(.45+.75*i),y:(1-i)**3,z:i}}(e,this.elapsed);this.matrix.position.set(-42+15*t.x,(this.uniforms.uUrban.value?-119.6:-.6)+18*t.y+.7,-20+75*t.z),this.matrix.rotation.set(e+this.elapsed,.7*e,.8*this.elapsed),this.matrix.scale.setScalar(.2+e%7*.09),this.matrix.updateMatrix(),this.rocks.setMatrixAt(e,this.matrix.matrix)}this.rocks.instanceMatrix.needsUpdate=!0}return a}clearEffects(){for(let e of[...this.root.children])if(e!==this.engine.root&&(e.removeFromParent(),e instanceof L.InstancedMesh&&e.dispose(),e instanceof L.Mesh||e instanceof L.Points||e instanceof L.LineSegments))for(let t of(e.geometry.dispose(),Array.isArray(e.material)?e.material:[e.material]))t.dispose();this.particles=null,this.mud=null,this.rocks=null,this.rainbowSky=null}forgetRoom(){this.patched.clear()}dispose(){this.clearEffects(),this.engine.dispose(),this.patched.clear(),this.root.removeFromParent()}}var a1=L;class a2 extends a1.Mesh{constructor(e,t={}){super(e),this.isWater=!0;const i=this,a=void 0!==t.textureWidth?t.textureWidth:512,r=void 0!==t.textureHeight?t.textureHeight:512,o=void 0!==t.clipBias?t.clipBias:0,s=void 0!==t.alpha?t.alpha:1,n=void 0!==t.time?t.time:0,l=void 0!==t.waterNormals?t.waterNormals:null,h=void 0!==t.sunDirection?t.sunDirection:new a1.Vector3(.70707,.70707,0),c=new a1.Color(void 0!==t.sunColor?t.sunColor:0xffffff),d=new a1.Color(void 0!==t.waterColor?t.waterColor:8355711),u=void 0!==t.eye?t.eye:new a1.Vector3(0,0,0),m=void 0!==t.distortionScale?t.distortionScale:20,p=void 0!==t.side?t.side:a1.FrontSide,f=void 0!==t.fog&&t.fog,g=new a1.Plane,v=new a1.Vector3,b=new a1.Vector3,w=new a1.Vector3,y=new a1.Matrix4,x=new a1.Vector3(0,0,-1),M=new a1.Vector4,S=new a1.Vector3,T=new a1.Vector3,C=new a1.Vector4,P=new a1.Matrix4,A=new a1.PerspectiveCamera,k=new a1.WebGLRenderTarget(a,r,{type:a1.HalfFloatType}),D={name:"MirrorShader",uniforms:a1.UniformsUtils.merge([R.UniformsLib.fog,R.UniformsLib.lights,{normalSampler:{value:null},mirrorSampler:{value:null},alpha:{value:1},time:{value:0},size:{value:1},distortionScale:{value:20},textureMatrix:{value:new a1.Matrix4},sunColor:{value:new a1.Color(8355711)},sunDirection:{value:new a1.Vector3(.70707,.70707,0)},eye:{value:new a1.Vector3},waterColor:{value:new a1.Color(5592405)}}]),vertexShader:`
				uniform mat4 textureMatrix;
				uniform float time;

				varying vec4 mirrorCoord;
				varying vec4 worldPosition;

				#include <common>
				#include <fog_pars_vertex>
				#include <shadowmap_pars_vertex>
				#include <logdepthbuf_pars_vertex>

				void main() {
					mirrorCoord = modelMatrix * vec4( position, 1.0 );
					worldPosition = mirrorCoord.xyzw;
					mirrorCoord = textureMatrix * mirrorCoord;
					vec4 mvPosition =  modelViewMatrix * vec4( position, 1.0 );
					gl_Position = projectionMatrix * mvPosition;

				#include <beginnormal_vertex>
				#include <defaultnormal_vertex>
				#include <logdepthbuf_vertex>
				#include <fog_vertex>
				#include <shadowmap_vertex>
			}`,fragmentShader:`
				uniform sampler2D mirrorSampler;
				uniform float alpha;
				uniform float time;
				uniform float size;
				uniform float distortionScale;
				uniform sampler2D normalSampler;
				uniform vec3 sunColor;
				uniform vec3 sunDirection;
				uniform vec3 eye;
				uniform vec3 waterColor;

				varying vec4 mirrorCoord;
				varying vec4 worldPosition;

				vec4 getNoise( vec2 uv ) {
					vec2 uv0 = ( uv / 103.0 ) + vec2(time / 17.0, time / 29.0);
					vec2 uv1 = uv / 107.0-vec2( time / -19.0, time / 31.0 );
					vec2 uv2 = uv / vec2( 8907.0, 9803.0 ) + vec2( time / 101.0, time / 97.0 );
					vec2 uv3 = uv / vec2( 1091.0, 1027.0 ) - vec2( time / 109.0, time / -113.0 );
					vec4 noise = texture2D( normalSampler, uv0 ) +
						texture2D( normalSampler, uv1 ) +
						texture2D( normalSampler, uv2 ) +
						texture2D( normalSampler, uv3 );
					return noise * 0.5 - 1.0;
				}

				void sunLight( const vec3 surfaceNormal, const vec3 eyeDirection, float shiny, float spec, float diffuse, inout vec3 diffuseColor, inout vec3 specularColor ) {
					vec3 reflection = normalize( reflect( -sunDirection, surfaceNormal ) );
					float direction = max( 0.0, dot( eyeDirection, reflection ) );
					specularColor += pow( direction, shiny ) * sunColor * spec;
					diffuseColor += max( dot( sunDirection, surfaceNormal ), 0.0 ) * sunColor * diffuse;
				}

				#include <common>
				#include <packing>
				#include <bsdfs>
				#include <fog_pars_fragment>
				#include <logdepthbuf_pars_fragment>
				#include <lights_pars_begin>
				#include <shadowmap_pars_fragment>
				#include <shadowmask_pars_fragment>

				void main() {

					#include <logdepthbuf_fragment>
					vec4 noise = getNoise( worldPosition.xz * size );
					vec3 surfaceNormal = normalize( noise.xzy * vec3( 1.5, 1.0, 1.5 ) );

					vec3 diffuseLight = vec3(0.0);
					vec3 specularLight = vec3(0.0);

					vec3 worldToEye = eye-worldPosition.xyz;
					vec3 eyeDirection = normalize( worldToEye );
					sunLight( surfaceNormal, eyeDirection, 100.0, 2.0, 0.5, diffuseLight, specularLight );

					float distance = length(worldToEye);

					vec2 distortion = surfaceNormal.xz * ( 0.001 + 1.0 / distance ) * distortionScale;
					vec3 reflectionSample = vec3( texture2D( mirrorSampler, mirrorCoord.xy / mirrorCoord.w + distortion ) );

					float theta = max( dot( eyeDirection, surfaceNormal ), 0.0 );
					float rf0 = 0.02;
					float reflectance = rf0 + ( 1.0 - rf0 ) * pow( ( 1.0 - theta ), 5.0 );
					vec3 scatter = max( 0.0, dot( surfaceNormal, eyeDirection ) ) * waterColor;
					vec3 albedo = mix( ( sunColor * diffuseLight * 0.3 + scatter ) * getShadowMask(), reflectionSample + specularLight, reflectance );
					vec3 outgoingLight = albedo;
					gl_FragColor = vec4( outgoingLight, alpha );

					#include <tonemapping_fragment>
					#include <colorspace_fragment>
					#include <fog_fragment>	
				}`},z=new a1.ShaderMaterial({name:D.name,uniforms:a1.UniformsUtils.clone(D.uniforms),vertexShader:D.vertexShader,fragmentShader:D.fragmentShader,lights:!0,side:p,fog:f});z.uniforms.mirrorSampler.value=k.texture,z.uniforms.textureMatrix.value=P,z.uniforms.alpha.value=s,z.uniforms.time.value=n,z.uniforms.normalSampler.value=l,z.uniforms.sunColor.value=c,z.uniforms.waterColor.value=d,z.uniforms.sunDirection.value=h,z.uniforms.distortionScale.value=m,z.uniforms.eye.value=u,i.material=z,i.onBeforeRender=function(e,t,a){if(b.setFromMatrixPosition(i.matrixWorld),w.setFromMatrixPosition(a.matrixWorld),y.extractRotation(i.matrixWorld),v.set(0,0,1),v.applyMatrix4(y),S.subVectors(b,w),S.dot(v)>0)return;S.reflect(v).negate(),S.add(b),y.extractRotation(a.matrixWorld),x.set(0,0,-1),x.applyMatrix4(y),x.add(w),T.subVectors(b,x),T.reflect(v).negate(),T.add(b),A.position.copy(S),A.up.set(0,1,0),A.up.applyMatrix4(y),A.up.reflect(v),A.lookAt(T),A.far=a.far,A.updateMatrixWorld(),A.projectionMatrix.copy(a.projectionMatrix),P.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),P.multiply(A.projectionMatrix),P.multiply(A.matrixWorldInverse),g.setFromNormalAndCoplanarPoint(v,b),g.applyMatrix4(A.matrixWorldInverse),M.set(g.normal.x,g.normal.y,g.normal.z,g.constant);let r=A.projectionMatrix;C.x=(Math.sign(M.x)+r.elements[8])/r.elements[0],C.y=(Math.sign(M.y)+r.elements[9])/r.elements[5],C.z=-1,C.w=(1+r.elements[10])/r.elements[14],M.multiplyScalar(2/M.dot(C)),r.elements[2]=M.x,r.elements[6]=M.y,r.elements[10]=M.z+1-o,r.elements[14]=M.w,u.setFromMatrixPosition(a.matrixWorld);let s=e.getRenderTarget(),n=e.xr.enabled,l=e.shadowMap.autoUpdate;i.visible=!1,e.xr.enabled=!1,e.shadowMap.autoUpdate=!1,e.setRenderTarget(k),e.state.buffers.depth.setMask(!0),!1===e.autoClear&&e.clear(),e.render(t,A),i.visible=!0,e.xr.enabled=n,e.shadowMap.autoUpdate=l,e.setRenderTarget(s);let h=a.viewport;void 0!==h&&e.state.viewport(h)}}}function a9(e){let t=new L.Shape(e.points.map(([e,t])=>new L.Vector2(e,-t)));return t.holes=(e.holes??[]).map(e=>new L.Path(e.map(([e,t])=>new L.Vector2(e,-t)))),t}class a3{group=new L.Group;batches=new Map;add(e,t,i=[0,0,0],a){if(a&&e.applyQuaternion(a),e.translate(...i),e.index){let t=e.toNonIndexed();e.dispose(),e=t}e.clearGroups();let r=this.batches.get(t)??[];r.push(e),this.batches.set(t,r)}box(e,t,i){this.add(new L.BoxGeometry(...e),i,t)}beam(e,t,i,a,r=i,o=!1){let s=new L.Vector3(...e),n=new L.Vector3(...t),l=n.clone().sub(s),h=l.length();if(h<1e-4)return;let c=o?new L.CylinderGeometry(i/2,i/2,h,8):new L.BoxGeometry(i,h,r);this.add(c,a,s.add(n).multiplyScalar(.5).toArray(),new L.Quaternion().setFromUnitVectors(new L.Vector3(0,1,0),l.normalize()))}extrude(e,t,i,a){let r=new L.ExtrudeGeometry(a9(e),{depth:i,bevelEnabled:!1,steps:1});r.rotateX(-Math.PI/2),this.add(r,a,[0,t,0])}finish(){for(let[e,t]of this.batches){let i=(0,tR.mergeGeometries)(t);if(t.forEach(e=>e.dispose()),!i)throw Error("City geometry merge failed");i.computeBoundingSphere();let a=new L.Mesh(i,e);a.castShadow=a.receiveShadow=!0,this.group.add(a)}return this.batches.clear(),this.group}}let a5=new Set([0xaa25bdd,0xd828420,0x2c6adf78,0x2c6adf79,0x2c6adf7a,0x2c6adf80]),a4=e=>["footway","pedestrian","steps","path","cycleway"].includes(e.kind??""),a8=([e,t])=>e>-1400&&e<-1100&&t>=1200&&t<=1840,a6=e=>!e.bridge&&"中山东一路"===e.name&&e.points.some(a8);function a7(e){return a6(e)?7:e.width}function re(e,t,i){let a=i[0]-t[0],r=i[1]-t[1],o=L.MathUtils.clamp(((e[0]-t[0])*a+(e[1]-t[1])*r)/(a*a+r*r||1),0,1);return Math.hypot(e[0]-t[0]-o*a,e[1]-t[1]-o*r)}function rt(e,t,i=!1){let a=e(t?0xa7a69a:4278086,.025,.93,.001*!!i),r=a.onBeforeCompile,o=a.customProgramCacheKey();return a.onBeforeCompile=(e,o)=>{r.call(a,e,o),e.vertexShader="varying vec2 streetPosition,streetLightUV;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\nstreetPosition=position.xz; streetLightUV=uv;"),e.fragmentShader="varying vec2 streetPosition,streetLightUV;\nfloat streetHash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}\n"+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
      vec2 stoneUV=vec2(streetPosition.x*.992+streetPosition.y*.126,-streetPosition.x*.126+streetPosition.y*.992);
      vec2 cell=stoneUV/vec2(.6,1.2);
      vec2 footprint=max(fwidth(cell),vec2(.0001));
      float detail=1.-smoothstep(.15,.65,max(footprint.x,footprint.y));
      vec2 seam=min(fract(cell),1.-fract(cell));
      float joint=1.-smoothstep(.005,.005+max(footprint.x,footprint.y),min(seam.x,seam.y));
      float grainDetail=1.-smoothstep(.1,.6,max(fwidth(stoneUV.x*55.),fwidth(stoneUV.y*55.)));
      float grain=(streetHash(floor(stoneUV*55.))-.5)*grainDetail;
      diffuseColor.rgb*= ${t?"(1.-joint*.22*detail)*(1.+(streetHash(floor(cell))-.5)*.08*detail)":"1."} *(1.+grain*.12);
    `),i&&(e.fragmentShader=e.fragmentShader.replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
      // Analytic irradiance confined to mapped road and walk surfaces. Shared
      // path distance prevents a new bright spot at every vertex.
      float along=streetLightUV.x;
      float a=fract(along+.5)-.5, b=fract(along)-.5;
      float pools=exp(-a*a*30.-pow(streetLightUV.y-.85,2.)*1.8)+exp(-b*b*30.-pow(streetLightUV.y+.85,2.)*1.8);
      float resolved=1.-smoothstep(.25,1.3,fwidth(along));
      pools=mix(.22,pools,resolved)*step(-999.,along);
      totalEmissiveRadiance+=(vec3(.014,.02,.03)+vec3(1.,.67,.38)*pools*${t?".1":".14"})*cityNight;
    `))},a.customProgramCacheKey=()=>`${o}-bund-street-${t}-${i}`,a}function ri(e){e.polygonOffset=!0,e.polygonOffsetFactor=-1,e.polygonOffsetUnits=-2,e.transparent=!0,e.depthWrite=!1;let t=e.onBeforeCompile,i=e.customProgramCacheKey();e.onBeforeCompile=(i,a)=>{t.call(e,i,a),i.vertexShader="varying vec2 roadMark;\n"+i.vertexShader,i.vertexShader=i.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\nroadMark=uv;"),i.fragmentShader="varying vec2 roadMark;\n"+i.fragmentShader,i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
      float pixel=max(fwidth(roadMark.x),.001);
      diffuseColor.a*=min(2.*roadMark.y/pixel,clamp((roadMark.y+pixel*.5-abs(roadMark.x))/pixel,0.,1.));
    `)},e.customProgramCacheKey=()=>`${i}-bund-marking-aa`}let ra={nanpu:{name:"Nanpu Bridge",x:173.7,z:5106.4,angle:1.166,length:846,span:423,width:30.35,deck:48.4,tower:150},lupu:{name:"Lupu Bridge",x:-2159.6,z:6927.8,angle:.328,length:750,span:550,width:40,deck:48.4,rise:100},waibaidu:{name:"Waibaidu Bridge",x:-1271.75,z:900.15,angle:-.267,length:107,span:53.5,width:18,deck:6.2}};function rr(e,t){return a4(e)?void 0:function([e,t]){return Object.values(ra).find(i=>{let a=e-i.x,r=t-i.z;return Math.abs(a*Math.cos(i.angle)-r*Math.sin(i.angle))<=i.width/2+1&&Math.abs(a*Math.sin(i.angle)+r*Math.cos(i.angle))<=i.length/2})}(t)}function ro(e){let t=e=>`${e[0]},${e[1]}`,i=new Set(e.filter(e=>!e.bridge).flatMap(e=>[t(e.points[0]),t(e.points[e.points.length-1])])),a=new Map;for(let r of e)if(r.bridge)for(let e=0;e<r.points.length;e++){let o=r.points[e],s=t(o),n=o[1]<1400,l=a.get(s)??{p:o,edges:new Map,ground:i.has(s),fallback:n?6.2:12*Math.max(1,r.layer??2)};if(l.deck=rr(r,o)?.deck??l.deck,a.set(s,l),e){let i=t(r.points[e-1]),n=Math.hypot(o[0]-r.points[e-1][0],o[1]-r.points[e-1][1]);l.edges.set(i,n),a.get(i).edges.set(s,n)}}let r=e=>{let t=new Map,i=[];for(let[r,o]of a)e(o)&&(t.set(r,{distance:0,height:o.deck??-.64}),i.push(r));for(let e=0;e<i.length;e++){let r=i[e],o=t.get(r);for(let[e,s]of a.get(r).edges)o.distance+s<(t.get(e)?.distance??1/0)&&(t.set(e,{distance:o.distance+s,height:o.height}),i.push(e))}return t},o=r(e=>void 0!==e.deck),s=r(e=>e.ground&&void 0===e.deck);return e.map(e=>e.points.map(i=>{if(!e.bridge)return -.64;let r=t(i),n=a.get(r),l=o.get(r),h=s.get(r);return void 0!==n.deck?n.deck:n.ground?-.64:l&&h?L.MathUtils.lerp(-.64,l.height,h.distance/(l.distance+h.distance)):l?l.height:h?Math.min(n.fallback,-.64+.045*h.distance):n.fallback}))}function rs(e){let t=new Uint8Array(524288),i=e?107:307,a=()=>(i=Math.imul(i,1664525)+0x3c6ef35f>>>0)/0x100000000;for(let i=0;i<64;i++){let r=!e||a()>.35,o=0;for(let s=0;s<32;s++){e&&s%2!=0||(o=r&&a()>(e?.48:.7)?Math.round(100+155*a()):0);let n=a()>.75?3:1;for(let e=0;e<8;e++)for(let a=0;a<8;a++){let r=((8*i+e)*256+8*s+a)*4,l=a>=1&&a<=6&&e>=n&&e<=6?o:0;t.set([l,l,l,255],r)}}}let r=new L.DataTexture(t,256,512);return r.name=e?"Shanghai office windows":"Shanghai residential windows",r.wrapS=r.wrapT=L.RepeatWrapping,r.magFilter=L.LinearFilter,r.minFilter=L.LinearMipmapLinearFilter,r.generateMipmaps=!0,r.anisotropy=8,r.needsUpdate=!0,r}function rn(e){return[(Math.min(...e.points.map(e=>e[0]))+Math.max(...e.points.map(e=>e[0])))/2,(Math.min(...e.points.map(e=>e[1]))+Math.max(...e.points.map(e=>e[1])))/2]}function rl(e,t,i=rn(e)){return{...e,points:e.points.map(([e,a])=>[i[0]+(e-i[0])*t,i[1]+(a-i[1])*t])}}function rh(e,t){for(let i=0;i<e.points.length;i++){let a=e.points[i],r=e.points[(i+1)%e.points.length],o=Math.hypot(r[0]-a[0],r[1]-a[1]);o>.1&&t(a,r,o)}}function rc(e,t){let i=Math.cos(t),a=Math.sin(t);return{plan:t=>{let r=t=>t.map(([t,r])=>[i*(t-e[0])-a*(r-e[1]),a*(t-e[0])+i*(r-e[1])]);return{...t,points:r(t.points),holes:t.holes?.map(r)}},place:i=>(i.position.set(e[0],0,e[1]),i.rotation.y=t,i)}}function rd(e,t,i,a,r){let o=t[1];for(let s of(e.add(new L.BoxGeometry(1.55,2.5,.16),a,t,i),e.add(new L.BoxGeometry(1.9,.2,.4),r,[t[0],o-1.35,t[2]],i),e.add(new L.BoxGeometry(.065,2.5,.22),r,t,i),e.add(new L.BoxGeometry(1.9,.22,.38),r,[t[0],o+1.35,t[2]],i),e.add(new L.BoxGeometry(1.55,.065,.24),r,[t[0],o+.35,t[2]],i),[-1,1])){let a=new L.Vector3(.86*s,0,0).applyQuaternion(i);e.add(new L.BoxGeometry(.16,2.6,.3),r,[t[0]+a.x,o,t[2]+a.z],i)}}function ru(e,t,i,a,r,o,s=!1,n=[0]){rh(t,(t,l,h)=>{if(s&&n.some(e=>.25>Math.abs(t[1]-e)&&.25>Math.abs(l[1]-e)))return;let c=Math.floor(h/a),d=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),-Math.atan2(l[1]-t[1],l[0]-t[0]));for(let a=0;a<c;a++)for(let s of i)rd(e,[L.MathUtils.lerp(t[0],l[0],(a+.5)/c),s,L.MathUtils.lerp(t[1],l[1],(a+.5)/c)],d,r,o)})}function rm(e,t,i,a=!0,r=[],o=4.7){let s=e(t,.025,.84,.001);s.userData.bundStone=!0;let n=s.onBeforeCompile,l=s.customProgramCacheKey();return s.onBeforeCompile=(e,t)=>{n.call(s,e,t),e.uniforms.cityFacadeLight=s.userData.cityFacadeLight??{value:new L.Vector2(-1,0)},e.vertexShader="attribute float bundBuildingId, bundLightTop; varying float bundId, bundTop; varying vec3 bundPosition, bundNormal;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\nbundPosition=position; bundNormal=normal; bundId=bundBuildingId; bundTop=bundLightTop;"),e.fragmentShader=`uniform vec2 cityFacadeLight; varying float bundId, bundTop; varying vec3 bundPosition, bundNormal;
      float bundHash(vec2 p) { return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
      float bundNoise(vec2 p) {
        vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f);
        return mix(mix(bundHash(i),bundHash(i+vec2(1,0)),f.x),mix(bundHash(i+vec2(0,1)),bundHash(i+vec2(1)),f.x),f.y);
      }
    `+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
      vec2 stoneUV=abs(bundNormal.x)>.65 ? bundPosition.zy : bundPosition.xy;
      if(abs(bundNormal.y)>.65) stoneUV=bundPosition.xz;
      float course=stoneUV.y/.68;
      vec2 blockUV=vec2(stoneUV.x/1.55+mod(floor(course),2.)*.5,course);
      vec2 seam= min(fract(blockUV),1.-fract(blockUV));
      vec2 footprint=max(fwidth(blockUV),vec2(.0001));
      float resolved=1.-smoothstep(.18,.6,max(footprint.x,footprint.y));
      float mortar=(1.-smoothstep(.009,.009+footprint.x,seam.x))+(1.-smoothstep(.012,.012+footprint.y,seam.y));
      float blockTint=mix(1.,.95+.08*bundHash(floor(blockUV)),resolved);
      float grainResolved=1.-smoothstep(.12,.6,max(fwidth(stoneUV.x*18.),fwidth(stoneUV.y*18.)));
      float grain=(bundNoise(stoneUV*18.)-.5)*grainResolved;
      float age=bundNoise(stoneUV*.34);
      diffuseColor.rgb*= ${a?"blockTint*(1.-min(1.,mortar)*.16*resolved)":"1."} *(.95+.06*age+grain*.055);
      float bundDistantWash=1.-.92*cityFacadeLight.y*(1.-step(.1,abs(bundId-cityFacadeLight.x)))*(1.-smoothstep(bundTop-2.,bundTop+4.,bundPosition.y));
      // Fade subpixel courses and grain to avoid crawling in drone/zoom views.
    `),e.fragmentShader=e.fragmentShader.replace("#include <roughnessmap_fragment>","#include <roughnessmap_fragment>\nroughnessFactor=clamp(roughnessFactor+grain*.14,0.55,1.);"),e.fragmentShader=e.fragmentShader.replace("#include <lights_fragment_end>",`#include <lights_fragment_end>
      {
      float wall=1.-smoothstep(.45,.85,abs(bundNormal.y));
      float height=max(0.,bundPosition.y);
      // Broad overlapping uplights: no repeating vertical reset that paints
      // every storey with a scalloped, self-luminous checkerboard.
      float spread=2.1+height*.035;
      float lampOffset=abs(mod(stoneUV.x+${(o/2).toFixed(3)},${o.toFixed(3)})-${(o/2).toFixed(3)});
      float pools=exp(-lampOffset*lampOffset/(spread*spread));
      float wash=(.19+.3*pools)*(.7+.3*exp(-height/35.));
      ${r.map(e=>`wash+=.22*exp(-abs(height-${e.toFixed(3)})/1.8);`).join("\n")}
      // Upward light responds to the actual surface orientation. Undersides,
      // curved columns and side returns no longer emit the same golden colour.
      vec3 fixtureDirection=normalize(vec3(.16,-.64,-.75));
      float relief=max(0.,dot(normalize(bundNormal),fixtureDirection));
      float frontage=mix(.32,1.,1.-smoothstep(.2,2.,bundPosition.z));
      reflectedLight.directDiffuse+=vec3(1.,.69,.38)*diffuseColor.rgb*cityNight*${i.toFixed(3)}*wash*(.12+.88*relief)*mix(.08,1.,wall)*frontage*bundDistantWash*2.1;
      }
    `)},s.customProgramCacheKey=()=>`${l}-bund-stone-shadowed-${i}-${a}-${r.join(",")}-${o}`,s}function rp(e,t,i,a){let r=e(t,.28,.62,.001),o=r.onBeforeCompile,s=r.customProgramCacheKey(),n=r.userData.spaceRoofWash;if(void 0!==n&&(!n||"object"!=typeof n||!Number.isFinite(n.bottom)||!Number.isFinite(n.top)||n.top<=n.bottom||!Array.isArray(n.color)||3!==n.color.length||!n.color.every(e=>"number"==typeof e&&Number.isFinite(e)&&e>=0&&e<=1)))throw Error("Invalid Blender roof wash profile");return r.userData.bundRoof=!0,r.onBeforeCompile=(e,t)=>{o.call(r,e,t),n&&(e.uniforms.roofWashHeight={value:new L.Vector2(n.bottom,n.top)},e.uniforms.roofWashColor={value:new L.Color().fromArray(n.color)},e.vertexShader="varying float roofHeight;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\nroofHeight=position.y;"),e.fragmentShader="uniform vec2 roofWashHeight; uniform vec3 roofWashColor; varying float roofHeight;\n"+e.fragmentShader),e.uniforms.cityFacadeLight=r.userData.cityFacadeLight??{value:new L.Vector2(-1,0)},e.vertexShader="attribute float bundBuildingId; varying float roofId; varying vec3 roofNormal; varying vec2 roofUV;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\nroofNormal=normal; roofUV=uv; roofId=bundBuildingId;"),e.fragmentShader="uniform vec2 cityFacadeLight; varying float roofId; varying vec3 roofNormal; varying vec2 roofUV;\n"+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
      float panel=roofUV.x*${a.toFixed(1)}, footprint=max(fwidth(panel),.0001);
      float joint=(1.-smoothstep(.007,.007+footprint,min(fract(panel),1.-fract(panel))))*(1.-smoothstep(.15,.6,footprint));
      diffuseColor.rgb*=1.-joint*.35;
    `),e.fragmentShader=e.fragmentShader.replace("#include <lights_fragment_end>",`#include <lights_fragment_end>
      float grazing=.26+.74*pow(max(0.,dot(normalize(roofNormal),normalize(vec3(.65,.55,-.45)))),.75);
      float roofDistantWash=1.-.92*cityFacadeLight.y*(1.-step(.1,abs(roofId-cityFacadeLight.x)));
      reflectedLight.directDiffuse+=diffuseColor.rgb*${n?"roofWashColor*mix(1.,.04,smoothstep(roofWashHeight.x,roofWashHeight.y,roofHeight))":"vec3(1.,.9,.7)"}*cityNight*${i.toFixed(3)}*grazing*roofDistantWash;
    `)},r.customProgramCacheKey=()=>`${s}-bund-roof-shadowed-${i}-${a}${n?"-height-wash-v1":""}`,r}function rf(e){let t=e.x-e.width/2,i=e.x+e.width/2,a=e.y-e.height/2,r=e.y+e.height/2,o=new L.Path().moveTo(t,a).lineTo(i,a);return"pointed"===e.arch?(o.lineTo(i,r-.72*e.width),o.quadraticCurveTo(i,r-.3*e.width,e.x,r),o.quadraticCurveTo(t,r-.3*e.width,t,r-.72*e.width)):"segmental"===e.arch?(o.lineTo(i,r-.18*e.width),o.quadraticCurveTo(e.x,r+.18*e.width,t,r-.18*e.width)):e.arch?(o.lineTo(i,r-e.width/2),o.absarc(e.x,r-e.width/2,e.width/2,0,Math.PI,!1)):o.lineTo(i,r).lineTo(t,r),o.closePath(),o}function rg(e,t,i,a,r,o){rh(t,(t,s)=>{if(Math.abs(t[1])>=.25||Math.abs(s[1])>=.25)return void e.beam([t[0],i,t[1]],[s[0],i,s[1]],a,r);let n=Math.min(t[0],s[0]),l=Math.max(t[0],s[0]);for(let[t,s]of[...o.filter(e=>Math.abs(i-e.y)<(e.height+a)/2).map(e=>[e.x-e.width/2-.12,e.x+e.width/2+.12]).sort((e,t)=>e[0]-t[0]),[l,l]])if(t>n&&e.beam([n,i,0],[Math.min(t,l),i,0],a,r),(n=Math.max(n,s))>=l)break})}function rv(e,t,i,a,r,o,s,n,l={}){let h=new L.ExtrudeGeometry(a9(t),{depth:i+.65,bevelEnabled:!1});h.rotateX(-Math.PI/2),h.translate(0,-.65,0);let c=h.getAttribute("position"),d=h.getAttribute("normal"),u=[];for(let e=0;e<c.count;e+=3)-.9>d.getZ(e)&&(l.frontDepths??[0]).some(t=>[e,e+1,e+2].every(e=>.25>Math.abs(c.getZ(e)-t)))||u.push(e,e+1,e+2);h.setIndex(u),e.add(h,r);let m=t.points.filter(e=>.25>Math.abs(e[1])),p=Math.min(...m.map(e=>e[0])),f=Math.max(...m.map(e=>e[0]));e.group.userData.facadeLighting={width:f-p,height:i};let g=l.outline??new L.Shape().moveTo(p,-.65).lineTo(f,-.65).lineTo(f,i).lineTo(p,i).closePath();for(let t of(g.holes=a.map(rf),e.add(new L.ExtrudeGeometry(g,{depth:.72,bevelEnabled:!1,curveSegments:16}),r,[0,0,-.06]),a)){let i=t.y-t.height/2,a=t.y+t.height/2,r=new L.Shape(rf(t).getPoints(32)),h=new L.ShapeGeometry(r);if(h.rotateY(Math.PI),e.add(h,s,[2*t.x,0,.6]),!1!==l.decorate)if(t.arch){let r=t.width/2,s="pointed"===t.arch?.72*t.width:"segmental"===t.arch?.18*t.width:r,l=a-s;if("pointed"===t.arch)for(let i of[-1,1]){let s=new L.QuadraticBezierCurve3(new L.Vector3(t.x+i*(r+.2),a-.72*t.width,-.2),new L.Vector3(t.x+i*(r+.2),a-.3*t.width,-.2),new L.Vector3(t.x,a+.2,-.2)).getPoints(12);for(let t=0;t<12;t++)e.beam(s[t].toArray(),s[t+1].toArray(),.28,o,.38)}else if("segmental"===t.arch){let i=new L.QuadraticBezierCurve3(new L.Vector3(t.x-r-.2,a-.18*t.width,-.2),new L.Vector3(t.x,a+.18*t.width+.25,-.2),new L.Vector3(t.x+r+.2,a-.18*t.width,-.2)).getPoints(16);for(let t=0;t<16;t++)e.beam(i[t].toArray(),i[t+1].toArray(),.28,o,.38)}else for(let i=0;i<17;i++){let a=(i+.5)*Math.PI/17,s=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,0,1),a-Math.PI/2);e.add(new L.BoxGeometry((r+.22)*Math.PI/17*.95,.4,.38),o,[t.x+Math.cos(a)*(r+.22),l+Math.sin(a)*(r+.22),-.21],s)}for(let r of(e.box([.4,.58,.48],[t.x,a+.17,-.25],o),[-(.28*t.width),0,.28*t.width]))e.box([.055,t.height-s,.1],[t.x+r,i+(t.height-s)/2,.49],n);for(let a=i+.9;a<l;a+=1.1)e.box([t.width,.065,.1],[t.x,a,.49],n);e.box([t.width,.08,.1],[t.x,l,.49],n);for(let i=1;!0===t.arch&&i<6;i++){let a=i*Math.PI/6;e.beam([t.x,l,.49],[t.x+Math.cos(a)*r,l+Math.sin(a)*r,.49],.045,n,.08)}}else{for(let i of[-1,1])e.box([.18,t.height+.3,.35],[t.x+i*(t.width/2+.1),t.y,-.2],o);if(e.box([t.width+.65,.22,.7],[t.x,i-.12,-.28],o),e.box([t.width+.4,.22,.4],[t.x,a+.12,-.18],o),e.box([.065,t.height,.09],[t.x,t.y,.46],n),e.box([t.width,.075,.09],[t.x,t.y+.18*t.height,.46],n),t.pediment)for(let i of[-1,1])e.box([.24,.5,.56],[t.x+i*t.width*.48,a+.4,-.3],o),e.beam([t.x+i*(t.width/2+.45),a+.6,-.35],[t.x,a+1.12,-.35],.22,o,.5)}}}function rb(e,t,i,a,r){let o=e.onBeforeCompile,s=e.customProgramCacheKey();e.onBeforeCompile=(s,n)=>{o.call(e,s,n),s.fragmentShader=s.fragmentShader.replace("#include <lights_fragment_end>",`#include <lights_fragment_end>
      {
      float fixtureX[14]=float[14](${[...i,...a].map(e=>e.toFixed(4)).join(",")});
      float fixtureY[4]=float[4](.25,5.2,9.9,14.4);
      float irradiance=0.;
      for(int row=0;row<4;row++) {
        float ceiling=row==0?4.95:row==1?9.65:row==2?14.15:24.;
        float visible=smoothstep(fixtureY[row]-.1,fixtureY[row]+.2,bundPosition.y)*(1.-smoothstep(ceiling-.18,ceiling+.05,bundPosition.y));
        for(int i=0;i<14;i++) {
          if(i>=11 && row==3) continue;
          float depth=i<11?0.:${r.toFixed(4)};
          vec3 toLight=vec3(fixtureX[i],fixtureY[row],depth-.85)-bundPosition;
          float d2=max(.1,dot(toLight,toLight));
          vec3 l=toLight*inversesqrt(d2);
          float cone=smoothstep(.2,.88,dot(-l,normalize(vec3(0.,1.,.27))));
          float facade=1.-smoothstep(depth+.2,depth+.65,bundPosition.z);
          irradiance+=facade*visible*cone*max(0.,dot(normalize(bundNormal),l))*8./(1.+d2);
        }
      }
      // The 2010 night photograph also shows continuous illuminated cornices.
      // Approximate shielded linear fixtures separately from the window lights;
      // retain the underside response and keep this light off the roof/rear.
      float ledges[3]=float[3](4.95,9.65,14.15);
      float depth=bundPosition.x>${(t/2).toFixed(4)}?${r.toFixed(4)}:0.;
      float frontage=1.-smoothstep(depth+.1,depth+.4,bundPosition.z);
      for(int row=0;row<3;row++) {
        vec3 toLight=vec3(0.,ledges[row]-.48-bundPosition.y,depth-1.05-bundPosition.z);
        float d2=max(.1,dot(toLight,toLight));
        float strip=exp(-pow((bundPosition.y-ledges[row])/.62,2.));
        irradiance+=frontage*strip*max(0.,dot(normalize(bundNormal),normalize(toLight)))*1.8/(1.+d2);
      }
      // Deep reveals and the unlit rear keep their environment lighting.
      reflectedLight.directDiffuse+=diffuseColor.rgb*vec3(1.,.52,.19)*cityNight*irradiance*bundDistantWash;
      }
    `)},e.customProgramCacheKey=()=>s+"-commercial-bank-fixtures-"+t}let rw=[{number:1,id:"way/178410323",name:"Asia Building",edge:2,top:30.5,floors:[3,7,11,15,19,23.5,27.5],bays:11,stone:"warm",cornices:[8.8,21,25.6,30.3],arches:[3,19]},{number:2,id:"way/178410325",name:"Shanghai Club",edge:4,top:22.5,floors:[3,7,12,17,20.5],bays:9,stone:"ivory",cornices:[8.8,19.2,22.5],arches:[3,7,20.5],order:{count:6,bottom:9,top:18.8,span:.64}},{number:3,id:"way/178408816",name:"Union Building",edge:2,top:26.5,floors:[3,7.4,12,16.4,20.7,24.5],bays:7,stone:"grey",cornices:[8.9,18.6,22.3,26.5],arches:[3,24.5]},{number:5,id:"way/178408821",name:"Nissin Building",edge:6,top:26,floors:[3,7,11.5,16,20.5,24],bays:5,stone:"warm",cornices:[8.9,22,26],arches:[3,7],order:{count:4,bottom:9,top:22,span:.65,pilaster:!0}},{number:6,id:"way/178408827",name:"China Commercial Bank",edge:9,top:14.15,floors:[2.7,7.35,11.65,15.7],bays:11,stone:"grey",cornices:[4.95,9.65,14.15]},{number:7,id:"way/178408810",name:"Great Northern Telegraph",edge:3,top:19.2,floors:[3,8.5,13.7,17.3],bays:7,stone:"warm",cornices:[5.7,15.8,19],arches:[3]},{number:9,id:"way/178408820",name:"China Merchants Building",edge:17,top:13.8,floors:[2.7,7,11.5],bays:5,stone:"brick",cornices:[4.7,9.3,13.8],arches:[2.7]},{number:14,id:"way/178405872",name:"Bank of Communications Bund",edge:5,top:27.5,floors:[3,8,12.3,16.6,20.9,25.2],bays:5,stone:"ivory",cornices:[5.8,27.5]},{number:15.1,id:"way/178405874",name:"Bund Public Service Center 15-1",edge:6,top:23.8,floors:[2.8,7.5,12.3,17,21.7],bays:7,stone:"ivory",cornices:[9.6,19.4,23.8]},{number:15,id:"way/178405875",name:"Russo-Chinese Bank",edge:2,top:18,floors:[3,8.7,14.1],bays:9,stone:"grey",cornices:[5.6,16.3,18],arches:[3],order:{count:6,bottom:5.8,top:16.1,span:.67}},{number:16,id:"way/1196704496",name:"Bank of Taiwan Bund",edge:2,top:20.3,floors:[3,8.2,13.2,18.1],bays:5,stone:"ivory",cornices:[5.7,16.2,20.3],arches:[3],order:{count:4,bottom:5.9,top:16,span:.7}},{number:17,id:"way/1196704497",name:"North China Daily News AIA",edge:2,top:39.5,floors:[3.1,7.6,12.2,16.5,20.8,25.1,29.4,33.5,37.4],bays:5,stone:"ivory",cornices:[9.8,31.4,39.5],arches:[3.1]},{number:18,id:"way/1196704498",name:"Chartered Bank Bund",edge:2,top:28.3,floors:[3.2,8.5,13,17.5,22,26.2],bays:7,groundBays:5,stone:"warm",cornices:[5.8,20.1,24.1,28.3],order:{count:2,bottom:6,top:19.9,span:.23}},{number:19,id:"way/177998982",name:"Palace Hotel Peace South",edge:16,top:25.8,floors:[2.9,7.4,11.8,16.2,20.6,24],bays:3,stone:"brick",cornices:[5.1,9.4,18.5,22.5,25.8],arches:[2.9]},{number:23,id:"way/177995050",name:"Bank of China Bund",edge:2,top:57.8,floors:[3,7,11,15,19,23,27,31,35,39,43,47,51,55],bays:7,stone:"warm",cornices:[9.2,57.8]},{number:24,id:"way/177993356",name:"Yokohama Specie Bank",edge:2,top:29.2,floors:[3.1,8.4,13,17.6,22.2,27],bays:7,stone:"grey",cornices:[5.9,24.3,29.2],arches:[3.1],order:{count:4,bottom:6.1,top:24.1,span:.62}},{number:26,id:"way/177931019",name:"Yangtze Insurance Building",edge:3,top:28.2,floors:[3,7,11.2,15.4,19.6,23.8,26.8],bays:3,stone:"grey",cornices:[5.2,21.6,25.4,28.2],arches:[3,19.6],order:{count:2,bottom:21.7,top:25.2,span:.35}},{number:27,id:"way/177930855",name:"Jardine Matheson Building",edge:10,top:27.8,floors:[3,8.5,13.1,17.7,22.3,26.1],bays:11,stone:"ivory",cornices:[5.8,20.2,24.4,27.8],arches:[3],order:{count:6,bottom:6,top:20,span:.62}},{number:28,id:"way/177930858",name:"Glen Line Building",edge:6,top:28.4,floors:[3,7.3,11.7,16.1,20.5,24.8],bays:5,stone:"warm",cornices:[5.2,22.6,28.4],arches:[3],order:{count:4,bottom:9.4,top:22.5,span:.75,pilaster:!0}},{number:29,id:"way/177930859",name:"Banque de Indochine",edge:6,top:17.5,floors:[3,8.5,13.8],bays:5,stone:"grey",cornices:[5.5,16.3,17.5],arches:[3],order:{count:4,bottom:5.7,top:16.1,span:.75,pilaster:!0}},{number:33,id:"way/160152535",name:"Former British Consulate",edge:5,top:11.4,floors:[2.8,8],bays:5,stone:"grey",cornices:[5.1,11.3],arches:[2.8]}],ry=["way/177995048","way/177998983"],rx="way/160152533",rM=new Set([...rw.map(e=>e.id),...ry,rx]);function rS(e,t,i,a,r,o,s,n=!1){let l=r-a;if(n)e.box([1.6*o,l-.7,o],[t,(a+r)/2,i],s);else{e.add(new L.CylinderGeometry(.77*o,o,l-.8,20),s,[t,(a+r)/2,i]);for(let n=0;n<16;n++){let l=n*Math.PI/8;e.beam([t+Math.cos(l)*o*.98,a+.5,i+Math.sin(l)*o*.98],[t+Math.cos(l)*o*.77,r-.55,i+Math.sin(l)*o*.77],.035,s,.035,!0)}}for(let[n,l,h]of[[a+.12,1.38,.24],[a+.4,1.13,.22],[r-.25,1.3,.18]])e.add(new L.CylinderGeometry(o*l,o*l,h,20),s,[t,n,i]);if(e.box([2.9*o,.3,2.3*o],[t,r-.02,i],s),!n)for(let a of[-1,1])e.add(new L.TorusGeometry(.31*o,.09*o,5,14),s,[t+a*o,r-.34,i-.8*o])}function rT(e,t,i,a,r,o,s){let n=new L.Shape().moveTo(-r/2,0).lineTo(r/2,0).lineTo(0,o).closePath();for(let l of(e.add(new L.ExtrudeGeometry(n,{depth:.48,bevelEnabled:!1}),s,[t,i,a]),[-1,1]))e.beam([t+l*r/2,i,a-.15],[t,i+o,a-.15],.25,s,.4);e.box([r+.5,.32,.9],[t,i,a],s)}function rC(e,t,i,a,r){let o=Math.hypot(t[0]-i[0],t[1]-i[1]);if(o<2)return;for(let o of[0,1.05])e.beam([t[0],a+o,t[1]],[i[0],a+o,i[1]],.26,r,.4);let s=Math.floor(o/.85);for(let o=0;o<=s;o++){let n=L.MathUtils.lerp(t[0],i[0],o/s),l=L.MathUtils.lerp(t[1],i[1],o/s);e.add(new L.CylinderGeometry(.105,.145,.8,6),r,[n,a+.55,l]),o%6==0&&e.box([.5,1.12,.5],[n,a+.55,l],r)}}function rP(e,t,i,a,r,o,s,n,l=!1){e.add(new L.CylinderGeometry(1.14*r,1.14*r,.4,8),s,[t,i,a]);for(let n=0;n<8;n++){let l=n*Math.PI/4;e.beam([t+Math.cos(l)*r*.83,i,a+Math.sin(l)*r*.83],[t+Math.cos(l)*r*.83,i+o,a+Math.sin(l)*r*.83],.27,s)}e.add(new L.CylinderGeometry(1.12*r,1.12*r,.45,8),s,[t,i+o,a]);let h=l?new L.ConeGeometry(1.16*r,1.2*r,8):new L.SphereGeometry(1.12*r,20,10,0,2*Math.PI,0,Math.PI/2);l||h.scale(1,.63,1),e.add(h,n,[t,i+o+(l?.6*r:.1),a]),e.beam([t,i+o+.6*r,a],[t,i+o+r*(l?1.7:1.15),a],.13,n)}function rA(e,t,i,a,r,o,s,n){let l=a>r,h=Math.max(0,(Math.max(a,r)-Math.min(a,r))/2),c=[-a/2,0,-r/2],d=[a/2,0,-r/2],u=[a/2,0,r/2],m=[-a/2,0,r/2],p=l?[-h,s,0]:[0,s,-h],f=l?[h,s,0]:[0,s,h],g=l?[c,p,f,c,f,d,d,f,u,u,f,p,u,p,m,m,p,c]:[c,p,d,d,p,f,d,f,u,u,f,m,m,f,p,m,p,c],v=new L.BufferGeometry;v.setAttribute("position",new L.Float32BufferAttribute(g.flat(),3)),v.setAttribute("uv",new L.Float32BufferAttribute(g.flatMap(e=>[e[0]/a+.5,e[2]/r+.5]),2)),v.computeVertexNormals(),e.add(v,n,[t,o,i])}function rk(e){let t=e.onBeforeCompile,i=e.customProgramCacheKey();e.onBeforeCompile=(i,a)=>{t.call(e,i,a),i.fragmentShader=i.fragmentShader.replace("#include <color_fragment>","#include <color_fragment>\nif(bundPosition.y>31.3 || bundPosition.y<9.8) diffuseColor.rgb*=vec3(.52,.54,.52);")},e.customProgramCacheKey=()=>`${i}-news-two-stone-zones`}let rD=[{id:"relation/12966760",floors:40,height:142,roof:"hip"},{id:"relation/12966761",floors:40,height:142,roof:"hip"},{id:"way/964405391",floors:44,height:153,roof:"flat"},{id:"way/964405392",floors:44,height:153,roof:"flat"}],rz=["way/178407318","way/178407323","way/178407326","way/178407328","way/178407330","way/178407333"],r_=["way/964405396","way/964405397","way/964405398","way/964405399","way/964405400"],rL=new Set([...rM,...rD.map(e=>e.id),"relation/2376366","relation/2380996",...rz,...r_]);function rR(e,t){let[i,a]=(tx(t)?t:"09:00").split(":").map(Number),r=60*i+a;e.traverse(e=>{"Customs hour hand"===e.name&&(e.rotation.z=-r*Math.PI/360),"Customs minute hand"===e.name&&(e.rotation.z=-(r%60)*Math.PI/30)})}function rE(e){let t=e.onBeforeCompile,i=e.customProgramCacheKey();e.onBeforeCompile=(i,a)=>{t.call(e,i,a),i.fragmentShader=i.fragmentShader.replace("vec3 fixtureDirection=normalize(vec3(.16,-.64,-.75));",`
      float peaceRiverfront=smoothstep(-1344.,-1315.,bundPosition.x);
      float peaceTower=smoothstep(36.,42.,bundPosition.y);
      wash*=mix(.09,.82,max(peaceRiverfront,peaceTower));
      vec3 fixtureDirection=normalize(vec3(.75,-.64,.16));`),i.fragmentShader=i.fragmentShader.replace("float frontage=mix(.32,1.,1.-smoothstep(.2,2.,bundPosition.z));","float frontage=1.;")},e.customProgramCacheKey=()=>`${i}-peace-riverfront-wash`}var rF=L;class rI extends rF.Loader{constructor(e){super(e)}load(e,t,i,a){let r=this,o=new rF.FileLoader(this.manager);o.setPath(this.path),o.setRequestHeader(this.requestHeader),o.setWithCredentials(this.withCredentials),o.load(e,function(e){let i=r.parse(JSON.parse(e));t&&t(i)},i,a)}parse(e){return new rU(e)}}class rU{constructor(e){this.isFont=!0,this.type="Font",this.data=e}generateShapes(e,t=100,i="ltr"){let a=[],r=function(e,t,i,a){let r=Array.from(e),o=t/i.resolution,s=(i.boundingBox.yMax-i.boundingBox.yMin+i.underlineThickness)*o,n=[],l=0,h=0;("rtl"==a||"tb"==a)&&r.reverse();for(let e=0;e<r.length;e++){let t=r[e];if("\n"===t)l=0,h-=s;else{let e=function(e,t,i,a,r){let o,s,n,l,h,c,d,u,m=r.glyphs[e]||r.glyphs["?"];if(!m)return void console.error('THREE.Font: character "'+e+'" does not exists in font family '+r.familyName+".");let p=new rF.ShapePath;if(m.o){let e=m._cachedOutline||(m._cachedOutline=m.o.split(" "));for(let r=0,m=e.length;r<m;)switch(e[r++]){case"m":o=e[r++]*t+i,s=e[r++]*t+a,p.moveTo(o,s);break;case"l":o=e[r++]*t+i,s=e[r++]*t+a,p.lineTo(o,s);break;case"q":n=e[r++]*t+i,l=e[r++]*t+a,h=e[r++]*t+i,c=e[r++]*t+a,p.quadraticCurveTo(h,c,n,l);break;case"b":n=e[r++]*t+i,l=e[r++]*t+a,h=e[r++]*t+i,c=e[r++]*t+a,d=e[r++]*t+i,u=e[r++]*t+a,p.bezierCurveTo(h,c,d,u,n,l)}}return{offsetX:m.ha*t,path:p}}(t,o,l,h,i);"tb"==a?(l=0,h+=i.ascender*o):l+=e.offsetX,n.push(e.path)}}return n}(e,t,this.data,i);for(let e=0,t=r.length;e<t;e++)a.push(...r[e].toShapes());return a}}var rN=e.i(994612);let rB=[16,14,12,10,8,7,6,5,4,3,2,1];function rV(e,t,i,a,r,o=!1){let s=e(i,.38,.3,.001),n=s.onBeforeCompile,l=s.customProgramCacheKey();return s.onBeforeCompile=(e,i)=>{n.call(s,e,i),e.uniforms.towerWindows={value:t},e.vertexShader="varying vec2 towerUV;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\ntowerUV=uv;"),e.fragmentShader="varying vec2 towerUV; uniform sampler2D towerWindows;\n"+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
      vec2 grid=towerUV/vec2(${r.toFixed(3)},${a.toFixed(3)});
      vec2 footprint=max(fwidth(grid),vec2(.0001));
      vec2 edge=min(fract(grid),1.-fract(grid));
      vec2 line=(1.-smoothstep(vec2(.022),vec2(.022)+footprint,edge));
      vec2 resolved=1.-smoothstep(vec2(.18),vec2(.7),footprint);
      line=mix(vec2(.044),line,resolved);
      float frame=max(line.x*${o?".38":".75"},line.y);
      diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.57,.6,.59),frame*.8);
      float lit=texture2D(towerWindows,grid/vec2(32.,64.)).r;
    `),e.fragmentShader=e.fragmentShader.replace("#include <emissivemap_fragment>","#include <emissivemap_fragment>\ntotalEmissiveRadiance+=vec3(1.,.82,.6)*lit*(1.-frame)*cityNight*.14;")},s.customProgramCacheKey=()=>`${l}-supertall-glass-${a}-${r}-${o}`,s}function rO(e){let t=.27*e,i=.32*e,a=[];for(let r=0;r<4;r++){let o=r*Math.PI/2;for(let[r,s]of[[e-t,e],[i+.9,e],[i,e-.65],[-i,e-.65],[-i-.9,e],[-e+t,e]])a.push([r*Math.cos(o)-s*Math.sin(o),r*Math.sin(o)+s*Math.cos(o)])}return a}function rG(e,t,i,a,r,o){let s=[],n=[],l=0;for(let e=0;e<t.length;e++){let o=(e+1)%t.length,h=t[e],c=t[o],d=i[e],u=i[o],m=Math.hypot(c[0]-h[0],c[1]-h[1]);s.push(h[0],a,h[1],d[0],r,d[1],c[0],a,c[1],c[0],a,c[1],d[0],r,d[1],u[0],r,u[1]),n.push(l,a,l,r,l+m,a,l+m,a,l,r,l+m,r),l+=m}let h=new L.BufferGeometry;h.setAttribute("position",new L.Float32BufferAttribute(s,3)),h.setAttribute("uv",new L.Float32BufferAttribute(n,2)),h.computeVertexNormals(),e.add(h,o)}function rj(e,t,i,a,r,o=a){t.forEach(([s,n],l)=>{let h=t[(l+1)%t.length];e.beam([s,i,n],[h[0],i,h[1]],a,r,o)})}let rH=new Set(["motorway","trunk","primary","secondary","tertiary","residential","unclassified"]);class rW{root=new L.Group;tracks;cars=[];meshes=[];matrices;visibility;wet={value:0};night={value:0};lastTime=0;transform=new L.Object3D;direction=new L.Vector3;constructor(e,t,i,a){for(const{i:t}of(this.root.name="Shanghai road traffic",this.tracks=function(e){let t=ro(e),i=[];e.forEach((e,a)=>{if(!rH.has(e.kind??"")||e.width<5||(e.layer??0)<0)return;let r=e.points.map(([e,i],r)=>new L.Vector3(e,t[a][r],i)).filter((e,t,i)=>!t||e.distanceToSquared(i[t-1])>1e-4);if(!(r.length<2))for(let t of e.oneway?[e.oneway]:[1,-1]){let o=1===t?r:[...r].reverse(),s=[0];for(let e=1;e<o.length;e++)s.push(s[e-1]+o[e].distanceTo(o[e-1]));8>s.at(-1)||i.push({road:a,points:o,distances:s,length:s.at(-1),offset:e.oneway?0:Math.min(a7(e)/4,3.3),next:[]})}});let a=e=>`${e.x},${e.y.toFixed(2)},${e.z}`,r=new Map;return i.forEach((e,t)=>{let i=a(e.points[0]),o=r.get(i)??[];o.push(t),r.set(i,o)}),i.forEach(e=>{let t=e.points.at(-1),o=t.clone().sub(e.points.at(-2)).normalize();e.next=(r.get(a(t))??[]).filter(t=>i[t].road!==e.road&&i[t].points[1].clone().sub(i[t].points[0]).normalize().dot(o)>-.65)}),i}(e),this.tracks.map((e,t)=>({i:t,priority:Math.min(...e.points.map(e=>Math.hypot(e.x+650,(e.z-1900)*.7)))})).sort((e,t)=>e.priority-t.priority))){const e=this.tracks[t],a=Math.floor(e.length/48);for(let r=0;r<a&&this.cars.length<(i?420:1200);r++){const i=(37*t+19*r)%997;this.cars.push({track:t,distance:(r+.25+i%17/34)*e.length/a,speed:6+i%5,seed:i,fadeIn:!1})}}if(this.matrices=new L.InstancedBufferAttribute(new Float32Array(16*this.cars.length),16).setUsage(L.DynamicDrawUsage),this.visibility=new L.InstancedBufferAttribute(new Float32Array(this.cars.length).fill(1),1).setUsage(L.DynamicDrawUsage),this.root.userData.cars=this.cars.length,this.root.userData.tracks=this.tracks.length,!this.cars.length)return;const r=a?.children.filter(e=>e instanceof L.Mesh&&e.material instanceof L.MeshStandardMaterial&&!e.material.userData.spaceRuntimeShader),o=a?.children.find(e=>e instanceof L.Mesh&&e.material.userData.spaceRuntimeShader),s=r?.find(({material:{userData:e}})=>"traffic-shanghai-illumination-0.1"===e.spaceShaderKey||"traffic-shanghai-illumination-uniform-v1"===e.spaceShaderKey&&.1===e.spaceIllumination);if(a&&(r?.length!==6||!s||!o))throw Error("Incomplete Blender traffic prefab");const{template:n,body:l}=a?{template:{children:r},body:s.material}:this.carTemplate(t);for(const e of n.children){const t=e.material,i=t.onBeforeCompile;t.onBeforeCompile=(e,a)=>{i.call(t,e,a),e.vertexShader="attribute float trafficVisibility; varying float carVisibility;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\ncarVisibility=trafficVisibility;"),e.fragmentShader="varying float carVisibility;\n"+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <alphatest_fragment>","#include <alphatest_fragment>\nif(carVisibility < fract(dot(floor(gl_FragCoord.xy),vec2(.75487766,.56984029)))) discard;")};const a=t.customProgramCacheKey();t.customProgramCacheKey=()=>`traffic-${a}`,this.instance(e.geometry,t)}const h=this.meshes.find(e=>e.material===l),c=[0xe0ddd2,1976628,8557464,0xb9c4cd,3419957,5405571,7684153];this.cars.forEach((e,t)=>h.setColorAt(t,new L.Color(c[e.seed%c.length])));const d=o?.geometry??new L.PlaneGeometry(3.1,12);o||(d.rotateX(-Math.PI/2),d.translate(0,.035,2.4));const u=new L.ShaderMaterial({transparent:!0,depthWrite:!1,blending:L.AdditiveBlending,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2,fog:!0,uniforms:{...R.UniformsLib.fog,night:this.night,wet:this.wet},vertexShader:`attribute float trafficVisibility; varying vec2 lightUV; varying float lightVisibility;
        #include <fog_pars_vertex>
        void main(){ lightUV=uv; lightVisibility=trafficVisibility; vec4 mvPosition=modelViewMatrix*instanceMatrix*vec4(position,1.); gl_Position=projectionMatrix*mvPosition;
        #include <fog_vertex>
        }`,fragmentShader:`uniform float night,wet; varying vec2 lightUV; varying float lightVisibility;
        #include <fog_pars_fragment>
        void main(){ float x=(lightUV.x-.5)*2., z=1.-lightUV.y;
          float front=smoothstep(.3,.42,z)*(1.-smoothstep(.55,1.,z));
          float back=(1.-smoothstep(.1,.29,z))*smoothstep(0.,.12,z);
          float width=mix(.18,.82,smoothstep(.4,1.,z));
          float beam=exp(-x*x/max(.025,width*width));
          float streak=exp(-pow((abs(x)-.39)*8.,2.));
          vec3 rgb=vec3(.68,.82,1.)*front*(beam*.26+wet*streak*.52)+vec3(1.,.018,.003)*back*wet*(beam*.2+streak*.9);
          gl_FragColor=vec4(rgb*night*lightVisibility,1.);
          #ifdef USE_FOG
            #ifdef FOG_EXP2
              float fogFactor=1.-exp(-fogDensity*fogDensity*vFogDepth*vFogDepth);
            #else
              float fogFactor=smoothstep(fogNear,fogFar,vFogDepth);
            #endif
            gl_FragColor.rgb*=1.-fogFactor;
          #endif
        }`});this.instance(d,u),a&&(this.root.position.copy(a.position),this.root.quaternion.copy(a.quaternion),this.root.scale.copy(a.scale),a.removeFromParent(),a.traverse(e=>{e instanceof L.InstancedMesh&&e.dispose()}));const m=new L.Box3;for(const e of this.tracks)for(const t of e.points)m.expandByPoint(t);const p=m.expandByScalar(20).getBoundingSphere(new L.Sphere);for(const e of this.meshes)e.boundingSphere=p;this.update(0)}carTemplate(e){let t=new a3,i=e(0xc6cbd0,.55,.3,.1),a=e(1057067,.55,.22,.035),r=e(1251612,.05,.94),o=e(6318962,.72,.28,.07),s=e(0xe1efff,.1,.24,18),n=e(0xff2610,.1,.28,12),l=new L.Shape([[-.88,-2.08],[-.72,-2.28],[.72,-2.28],[.88,-2.08],[.9,1.75],[.7,2.2],[-.7,2.2],[-.9,1.75]].map(([e,t])=>new L.Vector2(e,-t))),h=new L.ExtrudeGeometry(l,{depth:.52,bevelEnabled:!0,bevelSize:.1,bevelThickness:.1,bevelSegments:2,steps:1});h.rotateX(-Math.PI/2),t.add(h,i,[0,.38,0]);let c=new L.BoxGeometry(1.62,.58,2.35),d=c.getAttribute("position");for(let e=0;e<d.count;e++)d.getY(e)>0&&(d.setX(e,.83*d.getX(e)),d.setZ(e,.61*d.getZ(e)-.13));for(let e of(c.computeVertexNormals(),t.add(c,a,[0,1.13,-.18]),t.box([1.39,.07,1.4],[0,1.45,-.31],i),[-.77,.77]))t.box([.055,.5,.08],[e,1.15,-.18],o),t.box([.22,.16,.3],[1.27*e,1.04,.52],i);for(let e of[-.86,.86])for(let i of[-1.43,1.4]){let a=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,0,1),Math.PI/2);t.add(new L.CylinderGeometry(.32,.32,.22,12),r,[e,.32,i],a),t.add(new L.CylinderGeometry(.19,.19,.235,10),o,[e,.32,i],a)}for(let e of(t.box([1.25,.14,.055],[0,.5,2.27],r),[-.59,.59]))t.box([.48,.13,.075],[e,.78,2.22],s),t.box([.49,.15,.08],[e,.79,-2.3],n);return{template:t.finish(),body:i}}instance(e,t){e.setAttribute("trafficVisibility",this.visibility);let i=new L.InstancedMesh(e,t,this.cars.length);i.instanceMatrix=this.matrices,i.receiveShadow=!0,i.castShadow=!1,this.meshes.push(i),this.root.add(i)}setWeather(e,t){this.night.value=e,this.wet.value=t}update(e){let t=Math.min(.1,Math.max(0,e-this.lastTime));this.lastTime=e;for(let e=0;e<this.cars.length;e++){let i=this.cars[e],a=this.tracks[i.track];i.distance+=t*i.speed,i.distance>=a.length&&(i.distance-=a.length,i.fadeIn=!a.next.length,a.next.length&&(i.track=a.next[i.seed%a.next.length]),a=this.tracks[i.track]),function(e,t,i,a){let r=L.MathUtils.clamp(t,0,e.length),o=1,s=e.distances.length-1;for(;o<s;){let t=o+s>>>1;e.distances[t]<r?o=t+1:s=t}let n=e.points[o-1],l=e.points[o],h=e.distances[o]-e.distances[o-1];i.lerpVectors(n,l,(r-e.distances[o-1])/h),a.subVectors(l,n).normalize(),i.x-=a.z*e.offset,i.z+=a.x*e.offset}(a,i.distance,this.transform.position,this.direction),this.transform.rotation.set(-Math.asin(this.direction.y),Math.atan2(this.direction.x,this.direction.z),0,"YXZ"),this.transform.updateMatrix(),this.matrices.set(this.transform.matrix.elements,16*e),this.visibility.setX(e,Math.min(1,i.fadeIn?i.distance/8:1,a.next.length?1:(a.length-i.distance)/8))}this.matrices.needsUpdate=!0,this.visibility.needsUpdate=!0}}let rq=e=>Array.isArray(e)&&3===e.length&&e.every(Number.isFinite);class rX{root=new L.Group;active={value:new L.Vector2(-1,0)};lights=Array.from({length:6},()=>new L.SpotLight(0xffdbaf,0,100,.29*Math.PI,.8,2));frontages=[];selected;direction=new L.Vector3;offset=new L.Vector3;localCamera=new L.Vector3;lastNight=-1;initialized=!1;transitioning=!1;constructor(e){for(const t of(this.root.name="Bund facade light pool",this.lights))t.castShadow=!0,t.shadow.mapSize.setScalar(e?512:1024),t.shadow.camera.near=.3,t.shadow.normalBias=.04,t.shadow.bias=-7e-5,t.shadow.autoUpdate=!1,t.shadow.needsUpdate=!0,t.target.position.set(0,1,0),this.root.add(t,t.target)}register(e){e.updateWorldMatrix(!0,!0),this.frontages=[],this.selected=void 0,this.initialized=!1,this.transitioning=!1,this.active.value.set(-1,0),this.lights.forEach(e=>{e.intensity=0}),e.traverse(e=>{let t=e.userData.facadeLighting;if(!t||!Number.isFinite(t.width)||!Number.isFinite(t.height)||t.width<=0||t.height<=0)return;let i=t.interiorBounds;if(void 0!==i&&(!i||!rq(i.min)||!rq(i.max)||i.min.some((e,t)=>e>=i.max[t])))throw Error("Invalid Blender facade interior bounds");if(void 0!==t.centre&&!rq(t.centre))throw Error("Invalid Blender facade light centre");if(void 0!==t.washTop&&(!Number.isFinite(t.washTop)||t.washTop<0))throw Error("Invalid Blender facade wash height");if(void 0!==t.lamps&&(!Array.isArray(t.lamps)||6!==t.lamps.length||!t.lamps.every(e=>e&&rq(e.position)&&rq(e.target)&&e.position.some((t,i)=>Math.abs(t-e.target[i])>1e-5)&&rq(e.color)&&e.color.every(e=>e>=0&&e<=1)&&Number.isFinite(e.intensity)&&e.intensity>=0&&Number.isFinite(e.angle)&&e.angle>0&&e.angle<=Math.PI/2&&Number.isFinite(e.penumbra)&&e.penumbra>=0&&e.penumbra<=1&&Number.isFinite(e.distance)&&e.distance>.3)))throw Error("Invalid Blender facade light rig");let a=this.frontages.length+1,r=t.crown&&Object.values(t.crown).every(Number.isFinite)&&t.crown.width>0&&t.crown.height>t.height?t.crown:void 0;e.traverse(e=>{if(!(e instanceof L.Mesh)||Array.isArray(e.material)||!(e.material.userData.bundStone||e.material.userData.bundRoof)||e.material.userData.bundRoof&&!r&&!t.lamps)return;let i=e.geometry.getAttribute("position").count;e.geometry.setAttribute("bundBuildingId",new L.Float32BufferAttribute(new Float32Array(i).fill(a),1)),e.geometry.setAttribute("bundLightTop",new L.Float32BufferAttribute(new Float32Array(i).fill(t.washTop??(r?r.height+6:t.height)),1))}),this.frontages.push({building:e,...t,crown:r,id:a,centre:e.localToWorld(new L.Vector3(...t.centre??[0,t.height/2,0]))})})}update(e,t,i=0){t=Number.isFinite(t)?L.MathUtils.clamp(t,0,1):0,e.getWorldDirection(this.direction);let a,r=1/0;for(let t of this.frontages){let i=t.interiorBounds;if(i&&(t.building.worldToLocal(this.localCamera.copy(e.position)),this.localCamera.toArray().every((e,t)=>e>=i.min[t]&&e<=i.max[t]))){a=t,r=-1;break}this.offset.copy(t.centre).sub(e.position);let o=this.offset.length(),s=this.offset.normalize().dot(this.direction);if(o>320||s<.35)continue;let n=o*(1+8*(1-s));n<r&&(r=n,a=t)}if(this.selected&&a&&a!==this.selected){this.offset.copy(this.selected.centre).sub(e.position);let t=this.offset.length(),i=this.offset.normalize().dot(this.direction);t<320&&i>.35&&t*(1+8*(1-i))<1.15*r&&(a=this.selected)}let o=a,s=o?1-L.MathUtils.smoothstep(e.position.distanceTo(o.centre),150,320):0,n=this.active.value.y;if(this.initialized&&0!==t){let e=o===this.selected?s:0,t=(Number.isFinite(i)?L.MathUtils.clamp(i,0,.1):0)/.3;(n+=L.MathUtils.clamp(e-n,-t,t))<1e-6&&(n=0),a!==this.selected&&n>0&&(a=this.selected)}else n=s,this.initialized=!0;this.transitioning=a!==o||Math.abs(n-s)>1e-6;let l=!1;if(a!==this.selected&&(this.selected=a,a)){let{building:e,width:t,height:i,crown:r,lamps:o}=a;for(let a=0;a<this.lights.length;a++){let s=this.lights[a],n=t*((a+.5)/4-.5),l=a>=4&&r;if(s.position.copy(e.localToWorld(l?new L.Vector3((4===a?-1:1)*r.width,i+3.6,-9):new L.Vector3(n,5.5,-12))),s.target.position.copy(e.localToWorld(l?new L.Vector3(0,r.height,r.depth):new L.Vector3(n,.65*i,.5))),s.distance=l?45:Math.max(65,2.2*i),s.angle=Math.PI*(l?.22:.29),s.color.set(0xffdbaf),s.penumbra=.8,o){let t=o[a];s.position.copy(e.localToWorld(new L.Vector3(...t.position))),s.target.position.copy(e.localToWorld(new L.Vector3(...t.target))),s.color.setRGB(...t.color,L.LinearSRGBColorSpace),s.distance=t.distance,s.angle=t.angle,s.penumbra=t.penumbra}s.shadow.camera.far=s.distance,s.shadow.camera.updateProjectionMatrix(),s.shadow.needsUpdate=!0}l=!0}this.active.value.set(a?.id??-1,n);let h=a?1050*L.MathUtils.clamp(a.width*a.height/2453.43,.12,1.25):0;return this.lights.forEach((e,i)=>{e.intensity=t*n*(a?.lamps?.[i].intensity??(i<4?h:1300*!!a?.crown))}),t>0&&this.lastNight<=0&&a&&(this.lights.forEach(e=>{e.shadow.needsUpdate=!0}),l=!0),this.lastNight=t,l}dispose(){this.lights.forEach(e=>e.shadow.dispose()),this.frontages=[],this.selected=void 0,this.root.clear(),this.root.removeFromParent()}}let rK={northBund:{zh:"北外滩",en:"North Bund",camera:[450,210,80],target:[-150,180,1650]},lujiazui:{zh:"陆家嘴",en:"Lujiazui",camera:[-1210,215,2440],target:[50,255,1670]},jinmao:{zh:"金茂大厦",en:"Jin Mao Tower",camera:[-273,241,1353],target:[218,217,1796]},swfc:{zh:"环球金融中心",en:"World Financial Center",camera:[775,300,1215],target:[371,258,1871]},shanghaiTower:{zh:"上海中心",en:"Shanghai Tower",camera:[-585,380,2498],target:[206,326,1982]},bund:{zh:"外滩建筑群",en:"Bund architecture",camera:[-680,110,1860],target:[-1340,35,1580]},peace:{zh:"和平饭店",en:"Peace Hotel",camera:[-1165,64,1475],target:[-1345,36,1367]},customs:{zh:"江海关",en:"Customs House",camera:[-1188,49,1678],target:[-1301,37,1644]},hsbc:{zh:"汇丰大楼",en:"HSBC Building",camera:[-1169,22,1765],target:[-1302,20,1718]},commercialBank:{zh:"通商银行",en:"Commercial Bank",camera:[-1188.28,11.28,1834.96],target:[-1228.35,10.34,1853.15]},tomson:{zh:"汤臣一品",en:"Tomson Riviera",camera:[-570,115,2260],target:[-185,80,2050]},tomsonGarden:{zh:"汤臣庭院",en:"Tomson garden",camera:[-257,18,2095],target:[-205,3,2064]},waibaidu:{zh:"外白渡桥",en:"Waibaidu Bridge",camera:[-1130,45,965],target:[-1272,10,900]},nanpu:{zh:"南浦大桥",en:"Nanpu Bridge",camera:[610,175,4540],target:[174,76,5106]},nanpuApproach:{zh:"南浦螺旋引桥",en:"Nanpu spiral approach",camera:[-455,165,4560],target:[-150,30,4840]},lupu:{zh:"卢浦大桥",en:"Lupu Bridge",camera:[-2550,175,7520],target:[-2160,62,6930]},xuhui:{zh:"徐汇滨江",en:"Xuhui waterfront",camera:[-2790,190,8560],target:[-4040,100,9740]},alibabaAll:{zh:"阿里园区全景",en:"Alibaba whole campus",camera:[-3626,290,9922],target:[-3990,24,9599]},alibabaX:{zh:"X 区艺岛",en:"X Art Tower",camera:[-3829,92,9867],target:[-3955,23,9730]},alibaba:{zh:"Y 区主楼",en:"Y main building",camera:[-3828,100,9732],target:[-3980,26,9594]},alibabaCourt:{zh:"Y 区中庭",en:"Y courtyard",camera:[-3965,4,9653],target:[-3980,13,9590]},alibabaZ:{zh:"Z 区方案",en:"Z design",camera:[-3821,95,9625],target:[-3986,23,9479]},alibabaZCourt:{zh:"Z 区中庭",en:"Z courtyard",camera:[-3988,5,9532],target:[-3986,20,9469]},xujiahui:{zh:"徐家汇",en:"Xujiahui",camera:[-5010,290,6900],target:[-5375.8,25,6478.1]},qiantan:{zh:"前滩",en:"Qiantan",camera:[-4020,210,11100],target:[-2520,155,10400]},huangpu:{zh:"黄浦江全景",en:"Huangpu overview",camera:[-7600,7200,14400],target:[-1200,0,5450]}},rY=[{x:-365,z:1280,radius:78,name:"Oriental Pearl"},{x:206,z:1982,radius:70,name:"Shanghai Tower"},{x:371,z:1871,radius:63,name:"Shanghai World Financial Center"},{x:218,z:1796,radius:51,name:"Jin Mao Tower"}];class rZ{narrow;changed;source;root;ready;route;cruising;distance;elapsed;lastTime;abort;disposed;water;interiorMirrors;boats;boatDetails;traffic;night;timeOfDay;textures;officeWindows;homeWindows;materials;facadeLighting;batches;constructor(e,t,i=iS){this.narrow=e,this.changed=t,this.source=i,this.root=new L.Group,this.route=null,this.cruising=!1,this.distance=0,this.elapsed=0,this.lastTime=0,this.abort=new AbortController,this.disposed=!1,this.boatDetails=[],this.night={value:0},this.timeOfDay="09:00",this.textures=new Set,this.officeWindows=rs(!0),this.homeWindows=rs(!1),this.materials=new Set,this.batches=new Map,this.root.name="Shanghai Huangpu River",this.facadeLighting=new rX(e),this.root.add(this.facadeLighting.root),this.textures.add(this.officeWindows),this.textures.add(this.homeWindows),this.ready=this.load()}material(e,t=0,i=.8,a=0,r){let o=r??new L.MeshStandardMaterial({color:e,metalness:t,roughness:i});if(o.userData.cityFacadeLight=this.facadeLighting.active,o.userData.spaceIllumination=a,a){let e={value:Number(a.toFixed(3))};o.onBeforeCompile=t=>{t.uniforms.cityNight=this.night,t.uniforms.cityIllumination=e,t.fragmentShader="uniform float cityNight, cityIllumination;\n"+t.fragmentShader,t.fragmentShader=t.fragmentShader.replace("#include <emissivemap_fragment>","#include <emissivemap_fragment>\ntotalEmissiveRadiance+=diffuse*cityNight*cityIllumination;")},o.customProgramCacheKey=()=>"shanghai-illumination-uniform-v1"}return this.materials.add(o),o}facade(e,t,i=!1,a){let r=this.material(e,t?.58:.06,t?.3:.83,0,a);return r.onBeforeCompile=e=>{e.uniforms.cityNight=this.night,e.uniforms.cityWindows={value:t?this.officeWindows:this.homeWindows},e.vertexShader="attribute vec3 buildingData; varying vec3 cityBuilding,cityPosition,cityNormal; varying vec2 cityUV;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\ncityPosition=(modelMatrix*vec4(position,1.)).xyz; cityNormal=normalize(mat3(modelMatrix)*normal); cityUV=uv; cityBuilding=buildingData;"),e.fragmentShader="varying vec3 cityBuilding,cityPosition,cityNormal; varying vec2 cityUV; uniform float cityNight; uniform sampler2D cityWindows;\n"+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
        vec2 facadeUV=${i?"cityUV":"vec2(abs(cityNormal.x)>.6?cityPosition.z:cityPosition.x,cityPosition.y)"}/vec2(${t?"2.8,3.8":"3.4,3.2"});
        vec2 edge=abs(fract(facadeUV)-.5), aa=fwidth(facadeUV);
        float resolved=1.-smoothstep(.3,.85,max(aa.x,aa.y));
        float windowMask=(1.-smoothstep(.39-aa.x,.39+aa.x,edge.x))*(1.-smoothstep(.36-aa.y,.36+aa.y,edge.y));
        windowMask=mix(.5616,windowMask,resolved)*(1.-smoothstep(.5,.85,abs(cityNormal.y)));
        diffuseColor.rgb*=mix(1.,${t?".66":".32"},windowMask);
        // Each footprint owns a seed, height and base. Offices light up in floor
        // groups; homes in separate rooms, with one colour temperature per block.
        // Keep the per-building atlas offset constant across every triangle.
        float seed=floor(cityBuilding.x+.5), localHeight=max(0.,cityPosition.y-cityBuilding.z);
        float office=step(65.,cityBuilding.y);
        float lit=texture2D(cityWindows,(facadeUV+vec2(mod(seed,32.),floor(seed/32.)))/vec2(32.,64.)).r;
        vec3 lampColor=mix(vec3(1.,.66,.34),vec3(.65,.82,1.),step(.57,fract(seed*.017)) * office);
        float wall=1.-smoothstep(.5,.85,abs(cityNormal.y));
        float crownDistance=abs(localHeight-cityBuilding.y+1.2);
        float crownAA=max(fwidth(localHeight),.2);
        float crown=(1.-smoothstep(.35,.35+crownAA,crownDistance))*min(1.,1.4/crownAA)*office*step(.72,fract(seed*.031));
      `),e.fragmentShader=e.fragmentShader.replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
        float occupancy=mix(.12,1.,smoothstep(.15,.85,fract(seed*.043)));
        totalEmissiveRadiance+=cityNight*wall*(lampColor*lit*.09*occupancy + vec3(1.,.52,.18)*crown*.9 + vec3(.055,.029,.012)*exp(-localHeight*.14));
      `)},r.customProgramCacheKey=()=>`shanghai-facade-${t}-${i}`,r}batch(e,t,i){if(t.index){let e=t.toNonIndexed();t.dispose(),t=e}t.clearGroups();let a=this.batches.get(e)??{geometries:[],material:i};a.geometries.push(t),this.batches.set(e,a)}flush(){for(let{geometries:e,material:t}of this.batches.values()){let i=(0,tR.mergeGeometries)(e);if(e.forEach(e=>e.dispose()),!i)throw Error("Shanghai geometry merge failed");i.computeBoundingSphere();let a=new L.Mesh(i,t);a.castShadow=a.receiveShadow=!0,this.root.add(a)}this.batches.clear()}async load(){try{var e,t;let i,a,r,o,s,n,l,h,c,d,u,m=await fetch("/assets/space/shanghai-v1/huangpu.json?v=20260908-traffic",{signal:this.abort.signal});if(!m.ok)throw Error(`Shanghai map HTTP ${m.status}`);let p=await m.json(),f=e=>Array.isArray(e)&&2===e.length&&e.every(e=>Number.isFinite(e)&&2e4>Math.abs(e)),g=e=>Array.isArray(e)&&e.length>=3&&e.length<2e4&&e.every(f);if(!p||1!==p.version||!f(p.origin)||Math.abs(p.origin[0])>180||Math.abs(p.origin[1])>90||!Array.isArray(p.river)||p.river.length<2||p.river.length>2e4||!p.river.every(f)||!p.river.some(e=>e[0]!==p.river[0][0]||e[1]!==p.river[0][1])||!Array.isArray(p.polygons)||!p.polygons.length||p.polygons.length>5e4||p.polygons.some(e=>!e||!g(e.points)||void 0!==e.holes&&(!Array.isArray(e.holes)||e.holes.some(e=>!g(e)))||!["building","water","green"].includes(e.kind)||"building"===e.kind&&(!Number.isFinite(e.height)||e.height<0||e.height>650||!Number.isFinite(e.minHeight)||e.minHeight<0||e.minHeight>e.height))||!Array.isArray(p.roads)||p.roads.length>5e4||p.roads.some(e=>!e||!Array.isArray(e.points)||e.points.length<2||e.points.length>2e4||!e.points.every(f)||!Number.isFinite(e.width)||e.width<=0||e.width>100||"boolean"!=typeof e.bridge||void 0!==e.layer&&(!Number.isInteger(e.layer)||e.layer<-5||e.layer>5)||void 0!==e.oneway&&![-1,0,1].includes(e.oneway)||void 0!==e.lanes&&(!Number.isInteger(e.lanes)||e.lanes<1||e.lanes>12)))throw Error("Invalid Shanghai map");if(this.disposed)return;this.route=new L.CurvePath;for(let e=1;e<p.river.length;e++)this.route.add(new L.LineCurve3(new L.Vector3(p.river[e-1][0],0,p.river[e-1][1]),new L.Vector3(p.river[e][0],0,p.river[e][1])));if("blender"===this.source)return void await this.loadBlender(p);let v=[this.facade(0xc2beb0,!1),this.facade(0xa4a49b,!1),this.facade(8297642,!0),this.facade(0xadb7b6,!0)],b=this.material(5465416),w=this.material(0x9a9788);w.depthWrite=!1;let y=new L.Mesh(new L.PlaneGeometry(2e5,2e5),w);y.renderOrder=-1,y.rotation.x=-Math.PI/2,y.position.set(-2e3,-1,6e3),y.receiveShadow=!0,this.root.add(y);let x=[];for(let e=0;e<p.polygons.length;e++){let t=p.polygons[e],[i,a]=t.points[0];if("water"===t.kind){x.push(a9(t));continue}if("building"===t.kind&&rL.has(t.id)||"building"===t.kind&&rY.some(e=>t.points.every(([t,i])=>Math.hypot(t-e.x,i-e.z)<e.radius))||"building"===t.kind&&t.height<=t.minHeight)continue;let r="building"===t.kind?new L.ExtrudeGeometry(a9(t),{depth:t.height-t.minHeight,bevelEnabled:!1,steps:1}):new L.ShapeGeometry(a9(t));if(r.rotateX(-Math.PI/2),r.translate(0,"building"===t.kind?-.65+t.minHeight:-.75,0),"building"===t.kind){let e=new Float32Array(3*r.attributes.position.count),i=[...t.id].reduce((e,t)=>(31*e+t.charCodeAt(0))%9973,0);for(let a=0;a<e.length;a+=3)e.set([i,t.height-t.minHeight,t.minHeight-.65],a);r.setAttribute("buildingData",new L.BufferAttribute(e,3))}let o="green"===t.kind?4:t.height>65?2+e%2:e%2;if(this.batch(`${Math.floor(i/2e3)}:${Math.floor(a/2e3)}:${o}`,r,"green"===t.kind?b:v[o]),e%700==699&&(await new Promise(e=>setTimeout(e,0)),this.disposed))return}this.root.add((e=p.roads,t=this.material.bind(this),i=new a3,a=ro(e),i.group.name="Shanghai roads and graded approaches",r=rt(t,!1,!0),o=t(0xafafa3,0,.82),s=t(0xb3b8b0,.25,.6),(n=rt(t,!0)).polygonOffset=!0,n.polygonOffsetFactor=1,n.polygonOffsetUnits=2,l=[],h=[],c=[],d=[],e.forEach((e,t)=>{let r=a4(e)?h:l,n=0,u=0;for(let l=1;l<e.points.length;l++){let h=e.points[l-1],m=e.points[l],p=m[0]-h[0],f=m[1]-h[1],g=Math.hypot(p,f);if(g<.01)continue;let v=a7(e),b=-f/g*v/2,w=p/g*v/2,y=e.bridge?Math.ceil(g/8):1;for(let m=0;m<y;m++){let x=m/y,M=(m+1)/y,S=h[0]+p*x,T=h[1]+f*x,C=h[0]+p*M,P=h[1]+f*M;if(e.bridge&&rr(e,[(S+C)/2,(T+P)/2]))continue;let A=L.MathUtils.lerp(a[t][l-1],a[t][l],x),k=L.MathUtils.lerp(a[t][l-1],a[t][l],M);if(r.push(S-b,A,T-w,S+b,A,T+w,C+b,k,P+w,S-b,A,T-w,C+b,k,P+w,C-b,k,P-w),!a4(e)){let t=["motorway","trunk","primary","secondary","tertiary","residential","unclassified"].includes(e.kind??"")&&v>=5,i=t?(u+g*x)/34:-1e3,a=t?(u+g*M)/34:-1e3;d.push(i,-1,i,1,a,1,i,-1,a,1,a,-1)}if(!(!e.bridge||2>Math.min(A,k))&&Object.values(ra).some(e=>Math.hypot(S-e.x,T-e.z)<(e.length>200?1050:85))){for(let e of[-1,1]){let t=[S+e*b,A,T+e*w],a=[C+e*b,k,P+e*w],r=1===e?a:t,o=1===e?t:a;c.push(...r,...o,o[0],o[1]-1.6,o[2],...r,o[0],o[1]-1.6,o[2],r[0],r[1]-1.6,r[2]),i.beam([t[0],A+.8,t[2]],[a[0],k+.8,a[2]],.13,s),i.box([.12,.9,.12],[t[0],A+.45,t[2]],s)}c.push(S-b,A-1.6,T-w,C+b,k-1.6,P+w,S+b,A-1.6,T+w,S-b,A-1.6,T-w,C-b,k-1.6,P-w,C+b,k-1.6,P+w),(n+=g/y)>=32&&(n%=32,i.box([2.3,A-1.6,2.3],[S,(A-1.6)/2,T],o))}}u+=g}}),(u=(e,t,a)=>{if(!e.length)return;let r=new L.BufferGeometry;r.setAttribute("position",new L.Float32BufferAttribute(e,3)),r.computeVertexNormals(),r.setAttribute("uv",new L.Float32BufferAttribute(a??new Float32Array(e.length/3*2),2)),i.add(r,t)})(l,r,d),u(h,n),u(c,o),i.finish())),this.root.add(function(e,t,i){let a=new a3;a.group.name="Bund streetscape",a.group.userData.reconstruction="OSM road and footway positions; four surface lanes from Shanghai 2010 project report. Lane widths, paving, curb heights and lighting furniture are estimates, not a current street survey.";let r=e.filter(a6);if(!r.length)return a.group;let o=e.filter(e=>!e.bridge&&!a4(e)&&e.points.some(e=>e[0]>-1460&&e[0]<-1e3&&e[1]>1100&&e[1]<1940)),s=e.filter(e=>a5.has(e.id??0)&&!e.bridge),n=e=>s.some(t=>t.points.slice(1).some((i,a)=>2>re(e,t.points[a],i))),l=t.filter(e=>"green"!==e.kind&&e.points.some(e=>e[0]>-1470&&e[0]<-1e3&&e[1]>1100&&e[1]<1940)),h=(e,t=0,i)=>o.some(a=>a!==i&&a.points.slice(1).some((i,r)=>re(e,a.points[r],i)<a7(a)/2+t)),c=(e,t)=>l.some(i=>{let a=!1;for(let r=0,o=i.points.length-1;r<i.points.length;o=r++){let s=i.points[o],n=i.points[r];if(re(e,s,n)<t)return!0;s[1]>e[1]!=n[1]>e[1]&&e[0]<(n[0]-s[0])*(e[1]-s[1])/(n[1]-s[1])+s[0]&&(a=!a)}return a}),d=rt(i,!0,!0),u=i(0xc2c1b5,.015,.85),m=i(0xdad8c6,.01,.87),p=i(0xb8a55f,.01,.87);for(let e of[m,p])ri(e);let f=i(5463128,.6,.48),g=i(0xffecd0,.1,.55,18),v=[],b=[],w=[],y=[],x=[],M=[],S=(e,t,i,a,r,o)=>e.push(t[0],o,t[1],i[0],o,i[1],a[0],o,a[1],t[0],o,t[1],a[0],o,a[1],r[0],o,r[1]),T=(e,t,i,a)=>{let r=t[0]-e[0],o=t[1]-e[1],s=Math.hypot(r,o);if(s<.01)return;let n=i/2+.45,l=-o/s*n,h=r/s*n;S(a,[e[0]-l,e[1]-h],[e[0]+l,e[1]+h],[t[0]+l,t[1]+h],[t[0]-l,t[1]-h],-.61),(a===b?y:x).push(-n,i/2,n,i/2,n,i/2,-n,i/2,n,i/2,-n,i/2)},C=0,P=0,A=0,k=(e,t,i)=>{for(let r of(P++,a.add(new L.CylinderGeometry(.15,.23,.8,10),f,[e[0],-.04,e[1]]),a.add(new L.CylinderGeometry(.075,.13,7.3,10),f,[e[0],3.5,e[1]]),[-1,1])){let o=[e[0],6.8,e[1]];for(let s=1;s<=8;s++){let n=s/8,l=1.45*r*n,h=[e[0]+t*l,6.8+.7*Math.sin(n*Math.PI/2),e[1]+i*l];a.beam(o,h,.065,f,.065,!0),o=h}let s=new L.SphereGeometry(.25,10,6);s.scale(1.5,.4,.8),a.add(s,f,o);let n=new L.SphereGeometry(.2,10,6);n.scale(1.5,.22,.8),a.add(n,g,[o[0],o[1]-.07,o[2]])}},D=(e,t,i=-1,a=1)=>{let r=e/32,o=(e+t)/32;M.push(r,i,r,a,o,a,r,i,o,a,o,i)},z=(e,t)=>{let i=0;for(let a=1;a<e.points.length;a++){let r=e.points[a-1],o=e.points[a],s=o[0]-r[0],n=o[1]-r[1],l=Math.hypot(s,n);if(l<.01)continue;let h=Math.ceil(l/1.5);for(let e=0;e<h;e++){let a=[r[0]+s*e/h,r[1]+n*e/h],o=[r[0]+s*(e+1)/h,r[1]+n*(e+1)/h];a8(a)&&a8(o)&&t(a,o,-n/l,s/l,i+l*e/h)}i+=l}};for(let e of r)z(e,(t,i,a,s,l)=>{let h=(e,t)=>[e[0]+a*t,e[1]+s*t],c=[(t[0]+i[0])/2,(t[1]+i[1])/2];if(o.some(t=>t!==e&&!a6(t)&&t.points.slice(1).some((e,i)=>re(c,t.points[i],e)<t.width/2+2))||n(c))return;let d=(e,a)=>T(h(t,e),h(i,e),.12,a);for(let t of(l%9<3&&d(0,b),[-1,1])){let i=r.some(i=>i!==e&&i.points.slice(1).some((e,a)=>2>re(h(c,7.5*t),i.points[a],e)));d(3.25*t,i?w:b)}});for(let t of e.filter(e=>0xaa25bdb===e.id&&!e.bridge)){let e=-1/0;z(t,(t,i,r,o,s)=>{let d=(e,t)=>[e[0]+r*t,e[1]+o*t],m=[d(t,-4.6),d(t,4.6),d(i,4.6),d(i,-4.6)],p=[(t[0]+i[0])/2,(t[1]+i[1])/2],f=Math.hypot(i[0]-t[0],i[1]-t[1])/2;if(l.some(e=>e.points.some(([e,t])=>4.8>=Math.abs((e-p[0])*r+(t-p[1])*o)&&Math.abs((e-p[0])*o-(t-p[1])*r)<=f+.2))||[...m,p].some(e=>h(e,.3)||c(e,.2)))return;for(let e of(S(v,m[0],m[1],m[2],m[3],-.44),C++,D(s,2*f),[-1,1])){let r=d(t,4.6*e),o=d(i,4.6*e);n(r)||n(o)||a.add(new L.BoxGeometry(.24,.2,Math.hypot(o[0]-r[0],o[1]-r[1])),u,[(r[0]+o[0])/2,-.54,(r[1]+o[1])/2],new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),Math.atan2(o[0]-r[0],o[1]-r[1])))}if(s-e<32)return;let g=d(t,r<0?-3.7:3.7);h(g,1.2)||c(g,1.2)||n(g)||(e=s,k(g,r,o))})}let _=0,R=0;for(let t of e.filter(e=>909213e3===e.id&&!e.bridge)){let e=i(6640189,.02,.83,.12),r=-32,o=-46;z(t,(t,i,s,n,d)=>{let u=(e,t)=>[e[0]+s*t,e[1]+n*t],m=[(t[0]+i[0])/2,(t[1]+i[1])/2],p=Math.hypot(i[0]-t[0],i[1]-t[1]);for(let e=-4;e<56;e+=2){let a=[t,i,m].some(t=>h(u(t,e+2),.5));if([t,i,m].some(t=>h(u(t,e),.5)))break;let r=t=>{let i=e,a=e+2;if(!h(u(t,a),.5))return a;for(let e=0;e<12;e++){let e=(i+a)/2;h(u(t,e),.5)?a=e:i=e}return i},o=a?r(t):e+2,f=a?r(i):e+2,g=[u(t,e),u(t,o),u(i,f),u(i,e)],b=u(m,(e+(o+f)/2)/2),w=l.some(e=>e.points.some(([e,t])=>1.5>=Math.abs((e-b[0])*s+(t-b[1])*n)&&Math.abs((e-b[0])*n-(t-b[1])*s)<=p/2+.5));if([...g,b,u(m,(o+f)/2)].some(e=>h(e,.499)))break;if(w||[...g,b].some(e=>c(e,.5)))continue;S(v,g[0],g[1],g[2],g[3],-.44);let y=d/32,x=(d+p)/32;if(M.push(y,e/6,y,o/6,x,f/6,y,e/6,x,f/6,x,e/6),_++,a)break}let g=u(t,1.5);if(!(d-r>=32)||h(g,1.5)||c(g,1.5)||(k(g,s,n),r=d),d-o<46)return;let b=u(t,4.5),w=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),Math.atan2(s,n));if(!(h(b,2)||c(b,2))){for(let e of(o=d,R++,[-.7,.7]))a.add(new L.BoxGeometry(.18,.43,.58),f,[b[0]-n*e,-.225,b[1]+s*e],w);for(let t=0;t<5;t++)a.add(new L.BoxGeometry(2,.055,.095),e,[b[0]+s*(t-2)*.11,.01,b[1]+n*(t-2)*.11],w)}})}for(let e of s)z(e,(e,t,i,a,r)=>{if(r%2>=1)return;let o=[(e[0]+t[0])/2,(e[1]+t[1])/2];!(!h(o,-.7)||c(o,.2))&&(T([o[0]-1.35*i,o[1]-1.35*a],[o[0]+1.35*i,o[1]+1.35*a],.48,b),A++)});for(let[e,t]of[[b,m],[w,p],[v,d]])if(e.length){let i=new L.BufferGeometry;i.setAttribute("position",new L.Float32BufferAttribute(e,3)),i.computeVertexNormals();let r=e===b?y:e===w?x:M;i.setAttribute("uv",new L.Float32BufferAttribute(r,2)),a.add(i,t)}Object.assign(a.group.userData,{pavingSections:C,promenadeSections:_,benches:R,lamps:P,crossingStripes:A});let E=a.finish();return E.traverse(e=>{e instanceof L.Mesh&&(e.material===m||e.material===p||e.material===d)&&(e.castShadow=!1)}),E}(p.roads,p.polygons,this.material.bind(this))),this.root.add(function(e,t){let i=new a3;i.group.name="Central Huangpu illuminated quays";let a=e.find(e=>"way/71118583"===e.id&&"water"===e.kind),r=([e,t])=>e>-1500&&e<450&&t>700&&t<2600;if(!a)return i.group;let o=a.points.flatMap((e,t)=>{let i=a.points[(t+a.points.length-1)%a.points.length],o=Math.hypot(e[0]-i[0],e[1]-i[1]);return r(i)&&r(e)&&o>.01&&o<120?[{a:i,b:e,length:o}]:[]});if(!o.length)return i.group;let s=t(0xb6ac96,.03,.84,.07),n=t(0xffbe68,.05,.55,2.4);for(let{a:e,b:t,length:a}of o){let r=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),Math.atan2(t[0]-e[0],t[1]-e[1])),o=(e[0]+t[0])/2,l=(e[1]+t[1])/2;i.add(new L.BoxGeometry(.75,1.6,a),s,[o,.15,l],r),i.add(new L.BoxGeometry(.78,.12,a),n,[o,.78,l],r)}return i.group.userData.segments=o.length,i.finish()}(p.polygons,this.material.bind(this))),this.traffic=new rW(p.roads,this.material.bind(this),this.narrow),this.root.add(this.traffic.root),this.flush();let M=await new L.TextureLoader().loadAsync("/assets/space/shanghai-v1/waternormals.jpg");if(this.disposed)return void M.dispose();this.textures.add(M),this.makeWater(x,M),this.makeLandmarks(this.material(0xadb7b6,.58,.3)),this.root.add(function(e){let t=new L.Group;t.name="Shanghai detailed bridges";let i=e(0xd0cec2,.06,.76),a=e(0xdce0db,.36,.42),r=e(8161411,.5,.5),o=e(3619901,.02,.95),s=e(0xdad5bc,.05,.8),n=e(0xbcc3bf,.5,.36),l=e(0xf6d69a,.1,.35,2.2),h=e(0xd0cec2,.06,.76,.24),c=e(0xdce0db,.36,.42,.18),d=e(8161411,.5,.5,.28);for(let[e,u]of Object.entries(ra)){let m=new a3,p=u.deck,f=u.width/2,g="waibaidu"===e;m.group.name=u.name,m.group.position.set(u.x,0,u.z),m.group.rotation.y=u.angle,m.box([u.width,.4,u.length],[0,p-.2,0],o);let v=g?5.5:"nanpu"===e?10.8:11.3;for(let e of[-1,1]){for(let t of(m.box([g?3.5:2,.35,u.length],[e*(f-(g?1.75:1)),p+.12,0],i),m.box([.26,1.05,u.length],[e*(v+.5),p+.5,0],i),m.box([.18,.025,u.length],[e*v,p+.025,0],s),[.4,1.05]))m.box([.08,.08,u.length],[e*(f-.18),p+t,0],a);for(let t=-u.length/2;t<=u.length/2;t+=3)m.box([.085,1.12,.085],[e*(f-.18),p+.56,t],a);m.box([.12,.12,u.length],[e*(f-.1),p-.4,0],l);let t=g?1:3;for(let i=1;i<t;i++)for(let a=-u.length/2+4;a<u.length/2-4;a+=12)m.box([.15,.025,5],[e*v*i/t,p+.025,a],s)}m.box([g?.14:.5,g?.025:.65,u.length],[0,p+(g?.025:.32),0],g?s:i);let b="nanpu"===e?12.275:g?5.8:16,w="nanpu"===e?2.21:g?1.15:2.6;for(let e of[-1,1])for(let t of(m.box([.2,w,u.length],[e*b,p-.4-w/2,0],a),[-.4,-.4-w]))m.box([.85,.14,u.length],[e*b,p+t,0],a);for(let e=-u.length/2;e<=u.length/2;e+=g?6.6875:4.5)m.box([u.width-.6,.65,.24],[0,p-1.2,e],a);if("nanpu"===e){let e=ra.nanpu;for(let t of[-e.span/2,e.span/2]){for(let r of[-1,1]){for(let a of(m.box([12,4,20],[18*r,0,t],i),m.beam([18*r,2,t],[17*r,52,t],5.4,h,8),m.beam([17*r,52,t],[12.6*r,e.tower-3,t],4.8,h,7),m.box([5.4,3,7.6],[12.6*r,e.tower-1.5,t],h),[-1,1]))m.beam([17*r,52,t+3.55*a],[12.6*r,e.tower-3,t+3.55*a],.18,l);for(let i of[-1,1])for(let o=1;o<=22;o++){let s=104+1.8*o,l=[r*L.MathUtils.lerp(17,12.6,(s-52)/(e.tower-55)),s,t],h=[12.275*r,p+.25,t+i*(9+9*o)];m.beam(l,h,.146,n,.146,!0);let c=new L.Vector3(...l).sub(new L.Vector3(...h)).normalize().multiplyScalar(2).add(new L.Vector3(...h)).toArray();m.beam(h,c,.44,a,.44,!0),m.box([.9,.32,1.5],[h[0],p+.1,h[2]],a)}m.beam([14.5*r,107,t],[12.275*r,p,t],.146,n,.146,!0),m.box([.24,4,.24],[12.6*r,152,t],a)}for(let[e,i,a]of[[53,35,4],[108,31,5],[146,28,3.2]])m.box([i,a,7],[0,e,t],h)}for(let e of[-410,-320,320,410])for(let t of[-10,10])m.box([3,p-2.6,4],[t,(p-2.6)/2,e],i),m.box([7,2,8],[t,.2,e],i)}else if("lupu"===e){let e=ra.lupu,t=(t,i)=>{let a=12+e.rise*(1-(t/(e.span/2))**2);return[i*(20+(p-a)/5),a,t]};for(let e of[-1,1]){for(let i=1;i<=110;i++){let a=t(-275+(i-1)*5,e),r=t(-275+5*i,e);m.beam(a,r,4.5,c,5.2),m.beam([a[0]+2.3*e,a[1],a[2]],[r[0]+2.3*e,r[1],r[2]],.18,l)}for(let i=-264;i<=264;i+=12){let r=t(i,e);m.beam([20*e,p-.5,i],r,r[1]>p?.15:1.8,r[1]>p?n:a,.22,r[1]>p)}for(let r of[-275,275]){let o=t(r,e);m.box([12,12,18],[o[0],5.5,r],i),m.beam(o,[20*e,p-2,r],3.5,a,5)}for(let r of[-1,1])m.beam([20*e,p-2,375*r],t(275*r,e),3.2,a,4),m.box([4,p-2.6,5],[16*e,(p-2.6)/2,375*r],i)}for(let e=-204;e<=204;e+=24)m.beam(t(e,-1),t(e,1),2.1,c,3)}else{let e=[0,6.3,8.6,9.6,10,9.6,8.6,6.3,0];for(let t of[-53.5,0])for(let i of[-1,1]){let a=5.8*i;for(let o=0;o<e.length;o++){let s=t+53.5*o/8,n=[a,p+e[o],s];if(o){let t=[a,p+e[o-1],s-6.6875];m.beam(t,n,.48,d,.65),m.beam(o<=4?t:n,[a,p,o<=4?s:s-6.6875],.22,d,.28)}if(o&&o<8)for(let e of(m.beam([a,p,s],n,.26,d,.42),m.beam(n,[-a,n[1],s],.24,d,.35),m.box([.08,.85,.9],[a+.27*i,p+.4,s],r),m.box([.08,.85,.9],[a+.27*i,n[1]-.15,s],r),[p+.4,n[1]-.15]))for(let t of[-.25,.25])for(let o of[-.3,0,.3])m.beam([a+.31*i,e+t,s+o],[a+.37*i,e+t,s+o],.08,r,.08,!0)}}for(let e of[-53.5,0,53.5])m.box([19,5.2,e?4:5.5],[0,1.5,e],i)}t.add(m.finish())}return t}(this.material.bind(this)));let S=function(e,t,i=[]){let a=new L.Group;a.name="Shanghai architectural reconstructions";let r=t(0xc9b38b,.08,.72),o=t(0xe5d5b3,.05,.69,.045),s=t(8942173,.32,.45),n=t(4608851,.35,.26),l=t(0xf1d6a2,.05,.5,.7),h=t(8546641,.15,.55,1.15);for(let t of rD){let i=e.filter(e=>"building"===e.kind&&e.id===t.id);if(!i.length)continue;let c=new a3;c.group.name=`Tomson Riviera ${t.id}`,c.group.userData.reconstruction="OSM footprint; per-tower heights and façade dimensions estimated from developer photos";let d=i.reduce((e,t)=>e.points.length>t.points.length?e:t),u=(t.height-12)/t.floors,m=t.height-9;for(let e of i){if(e!==d){c.extrude(e,-.65,m,r);continue}c.extrude(rl(e,.87),-.65,m,n),c.extrude(e,-.65,4.1,r);for(let i=1;i<=t.floors;i++){let t=3+i*u;c.extrude(e,t,.23,o),rh(rl(e,.985),(e,i,a)=>{let r=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),-Math.atan2(i[1]-e[1],i[0]-e[0]));c.add(new L.BoxGeometry(a,1.06,.075),s,[(e[0]+i[0])/2,t+.85,(e[1]+i[1])/2],r),c.beam([e[0],t+1.4,e[1]],[i[0],t+1.4,i[1]],.055,o);for(let r=0;r<Math.ceil(a/2.5);r++){let o=r/Math.ceil(a/2.5),n=L.MathUtils.lerp(e[0],i[0],o),l=L.MathUtils.lerp(e[1],i[1],o);c.box([.075,1.18,.075],[n,t+.82,l],s)}})}if(rh(rl(e,.992),(e,t,i)=>{let a=Math.max(1,Math.floor(i/4.1));for(let i=0;i<a;i++){let r=L.MathUtils.lerp(e[0],t[0],i/a),s=L.MathUtils.lerp(e[1],t[1],i/a);c.box([.96,m,.96],[r,m/2,s],o)}}),rh(rl(e,.87),(e,i,a)=>{let r=Math.floor(a/3.2),o=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),-Math.atan2(i[1]-e[1],i[0]-e[0]));for(let a=0;a<r;a++)for(let s=2;s<t.floors;s++){if(Math.abs(13*s+7*a+Math.round(e[0]))%11>1)continue;let t=(a+.5)/r;c.add(new L.BoxGeometry(1.5,1.65,.15),h,[L.MathUtils.lerp(e[0],i[0],t),3+s*u+2.15,L.MathUtils.lerp(e[1],i[1],t)],o)}}),c.extrude(rl(e,1.035),m-.8,.7,o),c.extrude(rl(e,.98),m,3.4,n),"hip"===t.roof){for(let t=0;t<16;t++)c.extrude(rl(e,1.1-.022*t),m+3.4+.32*t,.35,s);c.extrude(rl(e,.78),t.height-.5,.5,s)}else c.extrude(rl(e,1.055),m+3.4,.9,o),c.extrude(rl(e,.68),m+4.3,4.7,s),rh(rl(e,1.03),(e,t)=>c.beam([e[0],m+3.4,e[1]],[t[0],m+3.4,t[1]],.14,l))}a.add(c.finish())}let c=e.find(e=>"building"===e.kind&&"relation/2376366"===e.id);if(c){let e=new a3;e.group.name="Fairmont Peace Hotel",e.group.userData.reconstruction="OSM courtyards retained; 77 m overall and 19 m roof from Shanghai heritage account; façade, setbacks and night wash estimated";let i=rm(t,0xbeb5a1,1.15,!0,[5.2,11.2,33,37.6,44.5,50,58],3.4),r=rm(t,0xd9d0b8,1.7,!1,[11.2,33,37.6,50,58],3.4);for(let e of[i,r])rE(e);let o=rp(t,4750177,1.7,64);for(let t of(e.extrude(c,-.65,38.5,i),[5.2,11.2,33,37.6]))rh(c,(i,a)=>e.beam([i[0],t,i[1]],[a[0],t,a[1]],.65,r));for(let[t,a,o,l]of(rh(c,(t,i,a)=>{let o=(i[0]-t[0])/a,l=(i[1]-t[1])/a,c=Math.floor(a/3.4),d=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),-Math.atan2(l,o));for(let a=0;a<c;a++)for(let o=0;o<9;o++){let l=(a+.5)/c,u=[L.MathUtils.lerp(t[0],i[0],l),7.4+3.2*o,L.MathUtils.lerp(t[1],i[1],l)];e.add(new L.BoxGeometry(1.5,2.05,.18),(7*a+3*o)%11<3?h:n,u,d),e.add(new L.BoxGeometry(1.7,.18,.35),r,[u[0],u[1]-1.1,u[2]],d),e.add(new L.BoxGeometry(.055,2.05,.2),s,u,d)}}),[[30,29,38.5,6],[26,25,44.5,5.5],[23,22,50,8]]))for(let s of(e.box([t,l,a],[-1328,o+l/2,1367],i),e.box([t+1,.55,a+1],[-1328,o+l,1367],r),[-1,1]))for(let i of[-7.5,-2.5,2.5,7.5])e.box([1.4,2.7,.15],[-1328+i,o+l/2,1367+s*a/2],n),e.box([.15,2.7,1.4],[-1328+s*t/2,o+l/2,1367+i],n);let l=new L.ConeGeometry(16.3,19,4);for(let t of(l.rotateY(Math.PI/4),e.add(l,o,[-1328,67.5,1367]),[-1,1]))for(let i=-10.5;i<=10.5;i+=1.5)e.beam([-1328+11.5*t,58,1367+i],[-1328,76.8,1367],.035,s),e.beam([-1328+i,58,1367+11.5*t],[-1328,76.8,1367],.035,s);a.add(e.finish())}for(let r of[function(e,t){let i=e.find(e=>e.id===rz[0]);if(!i)return null;let a=rc([-1288.8,1643.9],-Math.atan2(36.2,4.2)),r=new a3;r.group.name="Shanghai Customs House",r.group.userData.reconstruction="OSM six building parts; 79.2 m overall from Xinhua; intermediate heights, clock diameter and façade details estimated from onsite photo";let o=rm(t,0xbcb6a5,1.12,!0,[6.6,26,34.5,49.5,63.8],5.2),s=rm(t,0xcfc6b1,1.65,!1,[26,34.5,49.5,63.8],5.2),n=t(2438450,.38,.3),l=t(7628364,.48,.48,.1),h=a.plan(i),c=[];for(let e of[-14.8,-8,0,8,15.1]){for(let t of[9.3,13.6,18,22.4,26.8])c.push({x:e,y:t,width:2.35,height:2.9});c.push({x:e,y:32.6,width:1.8,height:2.1}),Math.abs(e)>12&&c.push({x:e,y:3.3,width:2.1,height:3.2})}for(let e of[-6.5,0,6.5])c.push({x:e,y:2.9,width:3.4,height:5.4,arch:!0});for(let e of(rv(r,h,34.5,c,o,s,n,l),[1.2,6.7,29.5,31,34.4]))rg(r,h,e,29.5===e?.9:.4,s,c);for(let t of(ru(r,h,[4,9.2,13.6,18,22.4,26.8,32.6],4.4,n,s,!0),rz.slice(1).filter(e=>"way/178407326"!==e))){let i=e.find(e=>e.id===t);if(!i)continue;let l=a.plan(i);for(let e of(r.extrude(l,34.4,5.1,o),[34.7,38.5,39.4]))rh(l,(t,i)=>r.beam([t[0],e,t[1]],[i[0],e,i[1]],.6,s));ru(r,l,[36.5],4.1,n,s)}for(let e of[-12,-4,4,12])r.box([1.6,22,1.25],[e,18.1,-1.05],s),r.box([2.15,.75,1.6],[e,29.2,-1.05],o);for(let e of[-8,0,8])for(let t of[11.5,15.8,20.2,24.6])for(let i of(r.box([2.32,1.05,.18],[e,t,-.16],l),[-.8,-.4,0,.4,.8]))r.box([.035,.87,.09],[e+i,t,-.29],s);for(let e=-17;e<=17;e+=.9)r.box([.35,.65,.82],[e,30.1,-.46],s),r.box([.48,.12,.94],[e,30.48,-.46],o);for(let e of[29.1,30.6,31])r.box([37.2,.22,1.1],[.6,e,-.38],s);for(let e=0;e<4;e++)r.box([21,.2,1+.6*e],[0,-.45+.2*e,-2.1],o);let d=e.find(e=>"way/178407326"===e.id),[u,m]=d?rn(a.plan(d)):[0,6];for(let[e,t,i]of[[14.5,34.5,8.5],[11,43,6.5],[9,49.5,12.3],[7.5,62.1,4],[5.6,66.6,4]])if(r.box([e,i,e],[u,t+i/2,m],o),r.box([e+.9,.5,e+.9],[u,t+i,m],s),49.5!==t)for(let a of[-1,1])for(let o of[-(.27*e),.27*e]){r.box([.9,.62*i,.12],[u+o,t+.48*i,m+a*(e/2+.04)],n),r.box([.12,.62*i,.9],[u+a*(e/2+.04),t+.48*i,m+o],n);for(let s=t+.2*i;s<t+.77*i;s+=.32)r.box([.9,.075,.23],[u+o,s,m+a*(e/2+.11)],l),r.box([.23,.075,.9],[u+a*(e/2+.11),s,m+o],l)}let p=new L.ConeGeometry(4.55,1.7,4);for(let e of(p.rotateY(Math.PI/4),r.add(p,s,[u,71.45,m]),r.beam([u,72.3,m],[u,79.2,m],.09,l),[-1,1]))r.beam([u+2.8*e,70.6,m],[u,77,m],.025,l);let f=r.finish(),g=t(0xe5e2ca,.02,.5,.9),v=t(2700080,.28,.42);for(let e=0;e<4;e++){let t=new a3;t.group.name=`Customs clock ${e}`,t.add(new L.CircleGeometry(2.72,64),g),t.add(new L.TorusGeometry(2.76,.095,6,64),v,[0,0,.035]),t.add(new L.TorusGeometry(2.08,.025,4,64),v,[0,0,.055]);for(let e=0;e<60;e++){let i=e*Math.PI/30,a=e%5==0?2.17:2.48;t.beam([Math.sin(i)*a,Math.cos(i)*a,.07],[2.61*Math.sin(i),2.61*Math.cos(i),.07],e%5==0?.1:.035,v),e%5==0&&t.beam([.48*Math.sin(i),.48*Math.cos(i),.055],[1.93*Math.sin(i),1.93*Math.cos(i),.055],.028,v)}let i=t.finish();for(let[e,t,a]of[["hour",1.48,.14],["minute",2.13,.085]]){let r=new L.Mesh(new L.BoxGeometry(a,t,.08).translate(0,.4*t,.16),v);r.name=`Customs ${e} hand`,i.add(r)}i.rotation.y=e*Math.PI/2,i.position.set(u+4.53*Math.sin(i.rotation.y),55.7,m+4.53*Math.cos(i.rotation.y)),f.add(i)}return a.place(f)}(e,t),function(e,t){let i=e.find(e=>"relation/2380996"===e.id);if(!i)return null;let a=rc([-1277.3,1716.3],-Math.atan2(82.8,10.4)),r=new a3;r.group.name="HSBC Building Bund",r.group.userData.reconstruction="OSM plan and courtyard; façade composition from Shanghai tourism photographs; 46.3 m model height and detail dimensions remain estimates";let o=rm(t,0xc4bdaa,1.12,!0,[6.2,20.8,28.7,35.5]),s=rm(t,0xd5ccb8,1.65,!1,[20.8,28.7,35.5]),n=t(2307640,.4,.27),l=t(6839624,.48,.44),h=t(0xb6b3a1,.12,.57),c=a.plan(i),d=[];for(let e of[-1,1])for(let t of[19,23.5,28,32.5,37.5]){let i=e*t;for(let[e,t]of[[9.3,3.5],[14.5,2.9],[19.3,2.9],[27.1,2.7]])d.push({x:i,y:e,width:2.25,height:t,pediment:9.3===e});37.5===t?d.push({x:i,y:2.8,width:3.1,height:5.3,arch:!0}):(d.push({x:i,y:2.4,width:2.4,height:2.2}),d.push({x:i,y:5.2,width:2.4,height:.85}))}for(let e of[-6.2,0,6.2])d.push({x:e,y:2.8,width:3.4,height:5.4,arch:!0});for(let e of[-9.3,0,9.3]){for(let t of[9.5,14.6,19.7])d.push({x:e,y:t,width:4.4,height:3.5});d.push({x:e,y:27.1,width:2.25,height:2.7})}for(let e of(rv(r,c,29.4,d,o,s,n,h),r.group.userData.facadeLighting.crown={height:41,depth:4.7,width:22},ru(r,c,[3.2,9,14.1,19.2,27.1],4.8,n,s,!0),[1.3,5.9,6.6,23.1,24.1,29.3]))rg(r,c,e,24.1===e?.85:.38,s,d);for(let e of[-12.7,-6.3,-4.5,4.5,6.3,12.7]){for(let[t,i,a]of(r.add(new L.CylinderGeometry(.73,.87,15.5,20),s,[e,14.55,-2.1]),[[6.8,1.03,.45],[7.15,.94,.22],[22.3,1.02,.6]]))r.add(new L.CylinderGeometry(i,i,a,20),s,[e,t,-2.1]);r.box([2.15,.4,2.15],[e,22.8,-2.1],s);for(let t=0;t<16;t++){let i=t*Math.PI/8;r.beam([e+.8*Math.sin(i),7.5,-2.1+.8*Math.cos(i)],[e+.68*Math.sin(i),21.7,-2.1+.68*Math.cos(i)],.045,o)}for(let t=0;t<8;t++){let i=t*Math.PI/4,a=new L.SphereGeometry(.22,6,5);a.scale(1,2,1),r.add(a,o,[e+.8*Math.sin(i),22.05,-2.1+.8*Math.cos(i)])}}for(let e of(r.box([29,1,3.3],[0,23.55,-1.2],s),[-40.8,-17,17,40.8])){r.box([1.5,17,.65],[e,14.5,-.5],s);for(let t=7;t<23;t+=.7)r.box([1.6,.055,.1],[e,t,-.87],o)}for(let e=-40;e<41;e+=1.25)r.box([.42,.5,.9],[e,23.45,-.55],o);for(let e=-40;e<=40;e+=1.15)r.add(new L.CylinderGeometry(.11,.17,.95,8),s,[e,30,-.12]),Math.round((e+40)/1.15)%7==0&&r.box([.5,1.3,.7],[e,30.1,-.12],o);for(let e of(r.box([83,.27,.8],[0,30.65,-.12],s),[-37.5,37.5]))for(let t of(r.box([8,.45,1.6],[e,29.6,-.7],s),[-1,1]))r.box([.6,3.7,.9],[e+2.7*t,27.5,-.45],s);for(let[e,t,i]of[[10,29.4,4.2],[8.4,33.6,4.1]]){let a=new L.CylinderGeometry(e,e,i,8);a.rotateY(Math.PI/8),r.add(a,o,[0,t+i/2,4.7]);let h=new L.CylinderGeometry(e+.35,e+.35,.45,8);h.rotateY(Math.PI/8),r.add(h,s,[0,t+i,4.7]);for(let a=0;a<8;a++){let o=a*Math.PI/4,h=e*Math.cos(Math.PI/8)+.06,c=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),o);for(let e of(r.add(new L.BoxGeometry(2.1,2.5,.15),n,[Math.sin(o)*h,t+i/2,4.7+Math.cos(o)*h],c),[-1,1]))r.add(new L.BoxGeometry(.35,3.25,.4),s,[Math.sin(o)*h+Math.cos(o)*e*1.45,t+i/2,4.7+Math.cos(o)*h-Math.sin(o)*e*1.45],c);let d=new L.Vector3(0,t+i-.3,h+.18).applyAxisAngle(new L.Vector3(0,1,0),o);for(let e of[-1,1]){let a=new L.Vector3(1.8*e,t+i-1.05,h+.18).applyAxisAngle(new L.Vector3(0,1,0),o);r.beam([a.x,a.y,a.z+4.7],[d.x,d.y,d.z+4.7],.2,s)}if(33.6===t){let i=(e,t,i)=>{let a=new L.Vector3(e,t,i).applyQuaternion(c);return[a.x,a.y,a.z+4.7]};r.add(new L.BoxGeometry(4.6,.25,1.15),s,i(0,t+.2,h+.38),c),r.add(new L.BoxGeometry(4.6,.18,.3),s,i(0,t+1.25,h+.82),c);for(let e=-1.9;e<=1.9;e+=.47)r.add(new L.CylinderGeometry(.075,.12,.9,8),s,i(e,t+.75,h+.82));let o=(a+.5)*Math.PI/4,n=Math.sin(o)*e,d=4.7+Math.cos(o)*e;r.box([.6,4.6,.6],[n,t+2,d],s),r.add(new L.CylinderGeometry(.27,.36,.5,10),l,[n,38.5,d]),r.add(new L.SphereGeometry(.28,10,8),s,[n,38.85,d])}}}let u=new L.SphereGeometry(8.3,48,20,0,2*Math.PI,0,Math.PI/2);u.scale(1,.64,1),r.add(u,rp(t,0xc6baa0,1.3,32),[0,37.9,4.7]);for(let e=0;e<16;e++){let t=e*Math.PI/8;for(let e=0;e<12;e++){let i=e*Math.PI/24,a=(e+1)*Math.PI/24;r.beam([8.34*Math.sin(t)*Math.cos(i),37.9+5.35*Math.sin(i),4.7+8.34*Math.cos(t)*Math.cos(i)],[8.34*Math.sin(t)*Math.cos(a),37.9+5.35*Math.sin(a),4.7+8.34*Math.cos(t)*Math.cos(a)],.055,o)}}r.add(new L.CylinderGeometry(1.45,1.65,.5,24),l,[0,43.3,4.7]),r.add(new L.CylinderGeometry(.42,.9,1.45,20),s,[0,44.15,4.7]),r.beam([0,44.875,4.7],[0,45.8,4.7],.075,l);let m=new L.Shape;for(let e=0;e<10;e++){let t=e*Math.PI/5,i=e%2?.14:.35,a=Math.sin(t)*i,r=Math.cos(t)*i;e?m.lineTo(a,r):m.moveTo(a,r)}m.closePath();let p=new L.ExtrudeGeometry(m,{depth:.07,bevelEnabled:!1});r.add(p,l,[0,45.95,4.7]);for(let e=0;e<5;e++)r.box([29,.16,1.2+.55*e],[0,-.5+.16*e,-3.2],o);return a.place(r.finish())}(e,t),function(e,t,i){let a=e.filter(e=>"building"===e.kind&&r_.includes(e.id));if(!a.length)return null;let r=new a3;r.group.name="Tomson Riviera podium and garden",r.group.userData.reconstruction="Five OSM podium footprints and mapped pool retained; podium elevations, paving, planted beds and landscape details are illustrative estimates, not a surveyed garden";let o=t(0xccbca1,.03,.8,.06),s=t(0xe0cfac,.04,.7,.13),n=t(3426632,.28,.26),l=t(7889737,.35,.49),h=t(0xd8b576,.05,.5,1.4),c=t(4086080,0,.98),d=t(6385994,0,.96),u=t(5592123,0,1),m=t(6705469,0,.95);for(let e of a){let t="way/964405396"===e.id?7.2:"way/964405397"===e.id?4.5:5.8;r.extrude(e,-.65,t,n),r.extrude(e,-.65,.9,o),r.extrude(e,t-.65,.45,s),r.extrude(rl(e,.89),t-.2,.35,l),rh(e,(e,i,a)=>{let s=Math.ceil(a/3.3);for(let a=0;a<s;a++){let n=a/s,l=L.MathUtils.lerp(e[0],i[0],n),h=L.MathUtils.lerp(e[1],i[1],n);r.box([.46,t,.46],[l,t/2-.65,h],o)}r.beam([e[0],t-.8,e[1]],[i[0],t-.8,i[1]],.075,h),r.beam([e[0],2.2,e[1]],[i[0],2.2,i[1]],.1,l)})}let p=e.find(e=>"way/964405405"===e.id);p&&rh(p,(e,t)=>r.beam([e[0],-.12,e[1]],[t[0],-.12,t[1]],.38,s,.38));let f=e.filter(e=>e.points.some(([e,t])=>e>-300&&e<-70&&t>1960&&t<2160)),g=i.filter(e=>!e.bridge&&e.points.some(([e,t])=>e>-320&&e<-50&&t>1940&&t<2180)),v=(e,t,i)=>!g.some(a=>a.points.slice(1).some((r,o)=>{let s=a.points[o],n=r[0]-s[0],l=r[1]-s[1],h=L.MathUtils.clamp(((e-s[0])*n+(t-s[1])*l)/(n*n+l*l||1),0,1);return Math.hypot(e-s[0]-h*n,t-s[1]-h*l)<i+a.width/2}))&&!f.some(a=>{let r=!1,o=1/0;for(let i=0,s=a.points.length-1;i<a.points.length;s=i++){let n=a.points[s],l=a.points[i],h=l[0]-n[0],c=l[1]-n[1];n[1]>t!=l[1]>t&&e<h*(t-n[1])/c+n[0]&&(r=!r);let d=L.MathUtils.clamp(((e-n[0])*h+(t-n[1])*c)/(h*h+c*c||1),0,1);o=Math.min(o,Math.hypot(e-n[0]-d*h,t-n[1]-d*c))}return r||o<i}),b=0;for(let[e,t,i]of[[-245,2052,5],[-247,2078,5],[-222,2095,5],[-200,2115,5],[-188,2061,4.5],[-173,2041,4],[-173,2084,4],[-216,2038,3],[-181,2135,3.5]]){if(!v(e,t,i+1))continue;let a=.68+ ++b%3*.11,s=new L.CylinderGeometry(i,i,.12,48);s.scale(1,1,a),r.add(s,o,[e,-.56,t]);let n=new L.CylinderGeometry(i-.25,i-.25,.1,48);n.scale(1,1,a),r.add(n,u,[e,-.48,t]),r.beam([e,-.2,t],[e+.3,4.1,t+.15],.27,m,.27,!0);for(let i=0;i<7;i++){let a=2.399*i,o=1.2+i%3*.34,s=[e+Math.cos(a)*o,3.8+i%3*.48,t+Math.sin(a)*o];r.beam([e+.2,2.6,t],s,.11,m,.11,!0);let n=new L.IcosahedronGeometry(1.15+b%3*.09,2);n.scale(1,.72,1),r.add(n,i%3?c:d,s);for(let e=0;e<9;e++){let t=2.399*e+b,i=.75+e%2*.25,a=new L.IcosahedronGeometry(.42+e%3*.08,1);a.scale(1,.65,1),r.add(a,e%3?c:d,[s[0]+Math.cos(t)*i,s[1]+.55*Math.sin(1.7*t),s[2]+Math.sin(t)*i])}}for(let o=0;o<13;o++){let s=2.399*o,n=(i-1)*Math.sqrt((o+1)/13),l=new L.IcosahedronGeometry(.75+o%3*.12,1);l.scale(1,.42,1),r.add(l,o%2?c:d,[e+Math.cos(s)*n,-.17,t+Math.sin(s)*n*a])}let p=e+i+.45;r.box([.16,.75,.16],[p,-.15,t],l),r.box([.2,.14,.2],[p,.27,t],h)}return r.group.userData.plantedBeds=b,r.finish()}(e,t,i)])r&&a.add(r);let d=function(e,t){let i=new L.Group;i.name="Bund photographic reconstructions";let a=rw.filter(t=>e.some(e=>e.id===t.id));if(!a.length)return i;let r={grey:rm(t,0xb1b0a8,.8),warm:rm(t,0xc4b99e,.8),ivory:rm(t,0xd3d0bc,.8),brick:rm(t,8604477,.75,!1)},o=rm(t,0xdbd1b9,1.05,!1),s=rm(t,7829614,.85),n=t(3425087,.38,.3,.48),l=t(6575936,.4,.5,.035),h=rp(t,3499868,.9,24),c=rp(t,5593943,.55,32),d=rm(t,0xd3d0bc,.8);for(let u of(rk(d),a)){let a=e.find(e=>e.id===u.id),m=a.points[u.edge],p=a.points[u.edge+1];24===u.number&&(p=a.points[u.edge+2]),m[1]>p[1]&&([m,p]=[p,m]);let f=Math.hypot(p[0]-m[0],p[1]-m[1]);if(f<2||!Number.isFinite(f))continue;let g=rc([(m[0]+p[0])/2,(m[1]+p[1])/2],-Math.atan2(p[1]-m[1],p[0]-m[0])),v=g.plan(a),b=new a3;if(b.group.name=u.name,b.group.userData.osmIds=[u.id],b.group.userData.bundNumber=u.number,b.group.userData.frontage=f,b.group.userData.groundBayPitch=f/(u.groundBays??u.bays),b.group.userData.groundOpeningWidth=Math.min(2.5,.53*b.group.userData.groundBayPitch),b.group.userData.reconstruction=`Individual facade and roof from ${15.1===u.number?"Wenhui completed-building photograph (2019 report)":"Asisbiz onsite photographs"}; OSM plan, estimated vertical dimensions; not a surveyed replica`,6===u.number){!function(e,t,i,a){let r=[-.405,-.368,-.241,-.203,-.0715,0,.0715,.203,.241,.368,.405].map(e=>e*i),o=t.points.filter(([e,t])=>e>i/2-.2&&t<-.5),s=Math.min(...o.map(e=>e[0])),n=Math.max(...o.map(e=>e[0])),l=Math.min(...o.map(e=>e[1])),h=n-s;if(!Number.isFinite(h)||h<1||!Number.isFinite(l))throw Error("Commercial Bank requires its mapped annex frontage");let c=[.24,.5,.76].map(e=>L.MathUtils.lerp(s,n,e)),d=F(0xa9aaa5),u=F(0xdbdbce),m=F(8488834),p=a(2634286,.45,.34,.035),f=a(4082505,.3,.24,.025),g=rp(a,4541261,.18,110),v=a(0xf4dab1,.1,.5,2.4),b=.031*i,w=[{x:-(.3865*i),half:.0575*i,peak:18.7},{x:-(.222*i),half:.0575*i,peak:18.7},{x:0,half:.128*i,peak:22.1},{x:.222*i,half:.0575*i,peak:18.7},{x:.3865*i,half:.0575*i,peak:18.7}],y=[[-i/2,14.15]];for(let{x:e,half:t,peak:i}of w)y.push([e-t,14.15],[e-t,16.5],[e,i],[e+t,16.5],[e+t,14.15]);y.push([i/2,14.15]);let x=new L.Shape().moveTo(-i/2,-.65).lineTo(i/2,-.65);for(let[e,t]of y.toReversed())x.lineTo(e,t);x.closePath();let M=[];for(let[e,t]of r.entries()){let a=e>=4&&e<=6,r=a?.054*i:b;M.push({x:t,y:a?2.35:2.7,width:r,height:a?4.2:3.5,arch:!0}),M.push({x:t,y:7.35,width:r,height:2.65,arch:"segmental"}),M.push({x:t,y:11.65,width:r,height:2.3}),M.push({x:t,y:5===e?16.2:15.7,width:.84*r,height:5===e?3.25:2.25,arch:"pointed"})}let S={x:0,y:19.62,width:1.25,height:1.9,arch:!0};for(let{x:e,peak:t}of(M.push(S),w.filter(e=>0!==e.x)))M.push({x:e,y:t-1,width:.15,height:.48});rv(e,t,14.15,M,d,u,f,p,{outline:x,decorate:!1,frontDepths:[0,l]}),e.group.userData.groundOpeningCenters=r,e.group.userData.groundOpeningWidth=b,e.group.scale.y=.94,e.group.userData.reconstruction="Shanghai Urban Construction Archives east elevation and Asisbiz photograph; OSM frontage, photo-estimated heights; not surveyed";let T=(t,i,a,r,o)=>{let s=new L.Shape(rf({...t,width:t.width+2*i,height:t.height+2*i}).getPoints(24));s.holes.push(rf(t)),e.add(new L.ExtrudeGeometry(s,{depth:r,bevelEnabled:!1,curveSegments:16}),o,[0,0,a])},C=new L.Shape(rf(S).getPoints(32));for(let[e,t]of[[-.34,1.05],[0,1.5],[.34,1.05]])C.holes.push(rf({x:e,y:18.83+t/2,width:.13,height:t,arch:!0}));e.add(new L.ExtrudeGeometry(C,{depth:.12,bevelEnabled:!1,curveSegments:16}),d,[0,0,.15]);let P=(t,i,a,r,o=-.18)=>{for(let s of(e.box([a,r,.1],[t,i,o],d),[-1,1]))e.box([.055,r+.08,.08],[t+s*a/2,i,o-.08],u);for(let s of[-1,1])e.box([a+.1,.055,.08],[t,i+s*r/2,o-.08],u)},A=(t,i,a,r,o)=>{let s=a-i;e.add(new L.LatheGeometry([[1.45*r,0],[1.45*r,.12],[1.2*r,.17],[1.15*r,.26],[r,.34],[.85*r,s-.32],[1.2*r,s-.22],[1.4*r,s-.16],[1.4*r,s]].map(([e,t])=>new L.Vector2(e,t)),20),u,[t,i,o]),e.box([3.2*r,.12,3.2*r],[t,a,o],u)},k=new L.Shape().moveTo(s,-.65).lineTo(n,-.65).lineTo(n,14.15).lineTo(s,14.15).closePath();for(let t of c)for(let i of[2.7,7.35,11.65]){let a={x:t,y:i,width:.2*h,height:i<4?3.5:2.65};k.holes.push(rf(a));let r=new L.ShapeGeometry(new L.Shape(rf(a).getPoints(4)));r.rotateY(Math.PI),e.add(r,f,[2*t,0,l+.6]),T(a,.13,l-.23,.17,u),T({...a,width:a.width-.1,height:a.height-.1},.05,l+.42,.08,p),e.box([a.width,.045,.065],[t,i+.65,l+.47],p),P(t,i-a.height/2-.5,a.width,.55,l-.18)}for(let t of(e.add(new L.ExtrudeGeometry(k,{depth:.72,bevelEnabled:!1}),d,[0,0,l-.06]),[4.95,9.65,14.15])){for(let[i,a,r]of[[-.22,.12,.23],[0,.18,.45],[.17,.12,.64]])e.box([h,a,r],[(s+n)/2,t+i,l-r/2],u);for(let i of[-1,1])e.box([.18,3.3,.28],[-1===i?s+.14:n-.14,t-2,l-.14],u)}let D=(t,i,a)=>{for(let r of[.27,.9])e.beam([t,14.15+r,a],[i,14.15+r,a],.12,u,.27);let r=Math.floor((i-t)/.36);for(let o=0;o<=r;o++)e.box([.13,.55,.2],[L.MathUtils.lerp(t,i,o/r),14.72,a],u)};D(s,n,l-.05);for(let e=0;e<w.length-1;e++)D(w[e].x+w[e].half,w[e+1].x-w[e+1].half,-.05);for(let[t,i]of M.entries()){if(t>=44){44===t&&T(i,.16,-.19,.15,u);continue}let a=i.y-i.height/2,r=i.y+i.height/2;T(i,.15,-.25,.17,u),T({...i,width:i.width+.36,height:i.height+.36},.045,-.15,.1,u),T({...i,width:i.width-.1,height:i.height-.1},.05,.42,.08,p);let o="pointed"===i.arch?.72*i.width:"segmental"===i.arch?.18*i.width:i.arch?i.width/2:0,s=r-o;if(e.box([.045,s-a,.065],[i.x,(a+s)/2,.47],p),t%4!=0&&e.box([i.width,.04,.065],[i.x,a+(s-a)*.76,.47],p),e.box([i.width,.05,.065],[i.x,s,.47],p),"pointed"===i.arch)e.box([.04,o-.12,.065],[i.x,s+(o-.12)/2,.47],p);else if(!0===i.arch)for(let t of[Math.PI/4,Math.PI/2,3*Math.PI/4])e.beam([i.x,s,.47],[i.x+Math.cos(t)*i.width/2,s+Math.sin(t)*i.width/2,.47],.035,p,.065);e.box([i.width+.42,.12,.65],[i.x,a-.15,-.27],u),(t%4==1||t%4==2)&&P(i.x,a-.5,i.width,.48),t%4==0&&(t<16||t>27)&&(P(i.x,.57,i.width+.2,.5),e.box([i.width+.5,.15,.7],[i.x,.22,-.25],m))}for(let t of[4.95,9.65,14.15]){for(let[a,r,o]of[[-.22,.12,.23],[0,.18,.45],[.17,.12,.64]])e.box([i+.18,r,o],[0,t+a,-o/2],u);for(let a=-i/2+.26;a<i/2;a+=.48)e.box([.19,.2,.36],[a,t-.29,-.22],u);if(14.15!==t)for(let i of r)e.box([.18,.18,.035],[i,t-.58,-.075],p)}for(let{x:t,half:i}of w){for(let a of(e.box([2*i-.1,.13,.36],[t,13.35,-.21],u),[-1,1]))e.box([.13,2.98,.32],[t+a*(i-.11),11.92,-.2],u);let a=r.filter(e=>e>t-i&&e<t+i);for(let e=0;e<a.length-1;e++){let t=(a[e]+a[e+1])/2;A(t,5.67,8.54,.11,-.3),A(t,10.03,12.95,.09,-.24),A(t,14.43,16.22,.09,-.29)}}for(let t of[-.1125,-.0375,.0375,.1125].map(e=>e*i))A(t,.15,3.63,.22,-.58),e.box([.67,.18,.75],[t,3.69,-.55],u);e.box([.269*i,.23,1.1],[0,5.24,-.4],u),P(0,5.76,.269*i,.82,-.59),e.box([.282*i,.14,1.2],[0,6.23,-.45],u);let z=Math.min(15,Math.max(...t.points.map(e=>e[1]))),_=.54*z,R=[-i/2,14.15,1.2,i/2,21.7,_,i/2,14.15,1.2,-i/2,14.15,1.2,-i/2,21.7,_,i/2,21.7,_,-i/2,21.7,_,i/2,14.15,z,i/2,21.7,_,-i/2,21.7,_,-i/2,14.15,z,i/2,14.15,z],E=new L.BufferGeometry;for(let{x:t,half:a,peak:r}of(E.setAttribute("position",new L.Float32BufferAttribute(R,3)),E.setAttribute("uv",new L.Float32BufferAttribute(R.flatMap((e,t)=>t%3==0?[R[t]/i,R[t+2]/z]:[]),2)),E.computeVertexNormals(),e.add(E,g),w)){for(let o of[-1,1]){e.box([.16,2.3,1.7],[t+o*a,15.3,1.05],d),e.beam([t+o*(a+.04),16.52,-.16],[t,r+.08,-.16],.17,u,.42),e.beam([t+o*(a+.1),16.57,-.07],[t,r+.19,-.07],.11,u,.6);let s=[t+o*a,16.5,.3,t,r,.3,t,r,3.4,t+o*a,16.5,.3,t,r,3.4,t+o*a,16.5,3.4];if(o<0)for(let e=0;e<s.length;e+=9){let t=s.slice(e,e+3);s.splice(e,3,...s.slice(e+6,e+9)),s.splice(e+6,3,...t)}let n=new L.BufferGeometry;n.setAttribute("position",new L.Float32BufferAttribute(s,3)),n.setAttribute("uv",new L.Float32BufferAttribute(s.flatMap((e,t)=>t%3==0?[s[t]/i,s[t+2]/z]:[]),2)),n.computeVertexNormals(),e.add(n,g)}e.beam([t,r,-.04],[t,r+.6,-.04],.11,u,.11,!0),e.add(new L.SphereGeometry(.12,10,8),u,[t,r+.58,-.04]),e.beam([t-.18,r+.5,-.04],[t+.18,r+.5,-.04],.09,u,.09,!0)}for(let t of[-(.493*i),-(.128*i),.128*i,.493*i]){for(let i of(A(t,10.9,16.5,.23,-.25),[13.9,16.45]))e.add(new L.CylinderGeometry(.34,.34,.16,20),u,[t,i,-.25]);for(let i of(e.add(new L.ConeGeometry(.34,1.45,24),u,[t,17.25,-.25]),e.beam([t,17.96,-.25],[t,18.44,-.25],.085,u,.085,!0),e.beam([t-.17,18.25,-.25],[t+.17,18.25,-.25],.085,u,.085,!0),[-.17,0,.17]))e.add(new L.SphereGeometry(.085,8,6),u,[t+i,0===i?18.44:18.25,-.25])}for(let t of[-(.32*i),.32*i])for(let i of(e.beam([t,.1,-.17],[t,14.05,-.17],.09,p,.09,!0),[2,6.2,10.8,13.2]))e.box([.17,.065,.24],[t,i,-.19],p);for(let t of r)for(let i of[.25,5.2,9.9,14.4])e.box([.22,.18,.26],[t,i,-.53],m),e.box([.18,.035,.2],[t,i+.11,-.56],v);for(let t of c)for(let i of[.25,5.2,9.9])e.box([.22,.18,.26],[t,i,l-.53],m),e.box([.18,.035,.2],[t,i+.11,l-.56],v);function F(e){let t=rm(a,e,0,!1);return rb(t,i,r,c,l),t}ru(e,t,[2.7,7.35,11.65],3.6,f,u,!0,[0,l])}(b,v,f,t),i.add(g.place(b.finish()));continue}let w=Math.min(2.5,.53*(f/u.bays)),y=[],x=u.order&&!u.order.pilaster?f*(u.order.span+.1):0;for(let e of u.floors){let t=e<4?u.groundBays??u.bays:u.bays;for(let i=0;i<t;i++){let a=(i-(t-1)/2)*f/t;!(15.1===u.number&&e<9&&Math.abs(a)<.23*f)&&(23!==u.number||!(e>9))&&(x&&u.order&&e>u.order.bottom&&e<u.order.top&&Math.abs(a)<x/2+w/2||y.push({x:a,y:e,width:e<4?b.group.userData.groundOpeningWidth:w,height:Math.min(e<4?4.5:2.7,(u.top-e)*1.6),arch:u.arches?.includes(e)||17===u.number&&37.4===e&&i%2==0,pediment:[3,7,19,29].includes(u.number)&&e>6&&e<17}))}}if(x&&u.order&&y.push({x:0,y:(u.order.bottom+u.order.top)/2,width:x,height:u.order.top-u.order.bottom-.7}),15.1===u.number&&y.push({x:0,y:4.4,width:.4*f,height:8.5}),23===u.number){for(let e of[-(.34*f),.34*f])y.push({x:e,y:33.2,width:.17*f,height:46.3});for(let e of u.floors.filter(e=>e>9))for(let t of[-(.12*f),0,.12*f])y.push({x:t,y:e,width:.079*f,height:3.3})}for(let e of(rv(b,v,u.top,y,17===u.number?d:r[u.stone],o,n,l),ru(b,v,u.floors,23===u.number?2.6:3.6,n,o,!0),u.cornices))if(rg(b,v,e,e===u.top?.68:.36,o,y),(e===u.top||e===u.cornices.at(-2))&&(rg(b,v,e-.35,.26,o,y),15.1!==u.number))for(let t=-f/2+.55;t<f/2;t+=.72)b.box([.22,.32,.65],[t,e-.65,-.33],o);let M=Math.max(...v.points.map(e=>e[1])),S=rn(v);if(u.order){let e=u.order;for(let t=0;t<e.count;t++)rS(b,(t/(e.count-1)-.5)*f*e.span,-1.2,e.bottom,e.top,Math.min(.85,f/32),o,e.pilaster);if(b.box([f*(e.span+.13),.65,2.3],[0,e.top+.35,-.7],o),x)for(let t of u.floors.filter(t=>t>e.bottom+1&&t<e.top-1)){b.box([x,.55,.2],[0,t-1.65,.32],s);for(let i=0;i<e.count-1;i++){let a=(i/(e.count-1)-.5)*f*e.span+f*e.span/(e.count-1)/2;b.box([.14,3,.2],[a-1,t,.32],o),b.box([.14,3,.2],[a+1,t,.32],o),b.box([2.2,.18,.2],[a,t+1.4,.32],o)}}}if([6,9,14,15.1,23,33].includes(u.number)||rC(b,[-f/2,-.3],[f/2,-.3],u.top+.25,o),1===u.number){for(let e of[-1,1]){let t=e*f*.37;b.box([7,2.3,6],[t,31.6,3],r.warm),rT(b,t,32.7,-.6,7.6,1.9,o)}for(let e=-(.3*f);e<=.3*f;e+=3.2)rS(b,e,-.55,21.6,29.7,.38,o)}else if(2===u.number)for(let e of[-1,1])rP(b,e*f*.37,u.top+.4,3.4,2.3,3.1,o,c);else if(3===u.number)for(let e of(rP(b,.39*f,u.top+.6,3.4,2.5,5.4,o,h,!0),[-(.34*f),0,.34*f]))b.box([1.1,13.5,.8],[e,15.8,-.35],o);else if(5===u.number)for(let e of[-1,1]){let t=e*f*.33;rT(b,t,u.top+.6,-.5,.36*f,2.4,o),b.add(new L.CircleGeometry(.68,18,0,Math.PI),n,[t,u.top+.8,-.56])}else if(7===u.number){for(let e of(rA(b,0,5,f-2,10,u.top,3.8,c),[-1,1]))rP(b,e*f*.36,u.top,3.2,2.1,2.4,o,c);for(let e of[-(.18*f),0,.18*f])b.box([2.6,2.8,2.1],[e,u.top+1.2,.6],o),rT(b,e,u.top+2.5,-.6,3,1,o)}else if(9===u.number){rA(b,0,Math.min(9,M/2),f+1,Math.min(18,M),u.top,3.6,c),rT(b,0,u.top+.3,-.6,.42*f,3.2,o);for(let e=0;e<=u.bays;e++)rS(b,(e/u.bays-.5)*f*.94,-.72,5,13.5,.22,o);for(let e of[5.1,9.5])rC(b,[-(.46*f),-.9],[.46*f,-.9],e,o)}else if(14===u.number){for(let[e,t]of[[.82,2.4],[.54,5],[.27,8]])b.box([f*e,t,7],[0,u.top+t/2,3.5],r.ivory),b.box([f*e+.35,.35,7.4],[0,u.top+t,3.5],o);for(let e=-3;e<=3;e++)b.box([.34,29,.75],[e*f/9,19,-.4],o);b.box([.35*f,5.5,1.2],[0,2.3,-.28],s),b.box([.24*f,4.3,.12],[0,2.1,-.92],n)}else if(15.1===u.number){for(let e=0;e<=u.bays;e++){let t=(e/u.bays-.5)*f;b.box([.44,9.8,.65],[t,14.5,-.3],o)}for(let e of(b.box([.44*f,.35,.9],[0,8.9,-.35],o),[-(.067*f),.067*f]))b.box([.11,8.5,.16],[e,4.4,.38],l);b.box([.4*f,.12,.16],[0,3.1,.38],l)}else if(15===u.number||16===u.number||24===u.number){for(let e of[-1,1])b.box([1.15,1.8,1.5],[e*f*.43,u.top+.9,.5],o);if(24===u.number)for(let e=-(.34*f);e<.4*f;e+=3.6)rS(b,e,-.4,24.7,28.7,.27,o)}else if(17===u.number){for(let e of[-1,1]){let t=e*f*.33;for(let i of(rP(b,t,u.top+.6,2.4,1.8,3.4,s,c),rS(b,e*f*.15,-.85,.1,9.2,.52,s),rT(b,t,u.top-.15,-.6,.35*f,1.8,s),[-(.105*f),.105*f]))rS(b,t+i,-.6,31.7,39,.25,s,!0)}b.box([f,.8,1.8],[0,31.3,-.5],s)}else if(18===u.number){b.box([.56*f,3.1,9],[0,u.top+1.55,5],r.warm),b.box([.6*f,.45,9.4],[0,u.top+3.1,5],o);for(let e=-(.22*f);e<.25*f;e+=2.4)b.box([1.2,2.2,.14],[e,u.top+1.4,.42],n);for(let e of(rT(b,0,u.top+3.3,.35,.58*f,1.8,o),[-1,1]))b.box([1.1,14,1.4],[e*f*.34,13,-.65],o)}else if(19===u.number){for(let e of(b.box([f,1.45,.7],[0,u.top+.86,-.12],r.brick),[u.top+.18,u.top+1.56]))b.box([f+.25,.16,.85],[0,e,-.12],o);for(let e of[[17,20,23,26],[6,8,10,12,13],[28,31,34,35]])for(let t=0;t<e.length-1;t++){let i=v.points[e[t]],a=v.points[e[t+1]],r=(i[0]+a[0])/2,s=(i[1]+a[1])/2,l=-Math.atan2(a[1]-i[1],a[0]-i[0]),h=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),l),c=v.points[Math.round((e[t]+e[t+1])/2)],d=new L.Vector3(0,0,.72*Math.sign((c[0]-r)*Math.sin(l)+(c[1]-s)*Math.cos(l))).applyQuaternion(h);for(let e of u.floors)rd(b,[r+d.x,e,s+d.z],h,n,o)}for(let[e,t]of(rh(v,(e,t,i)=>{let a=Math.floor(i/3.6),r=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),-Math.atan2(t[1]-e[1],t[0]-e[0]));for(let i=0;i<a;i++)for(let s of[7.4,11.8,16.2,20.6,24]){let n=(i+.5)/a,l=e[0]+(t[0]-e[0])*n,h=e[1]+(t[1]-e[1])*n;for(let e of(b.add(new L.BoxGeometry(2.7,.5,.56),o,[l,s+1.55,h],r),[-1,1])){let t=new L.Vector3(1.08*e,0,0).applyQuaternion(r);b.add(new L.BoxGeometry(.58,3.1,.32),o,[l+t.x,s,h+t.z],r)}b.add(new L.BoxGeometry(2.7,.9,.28),o,[l,s-1.95,h],r)}}),[[-2.2,2.3],[S[0]-3,M-5]])){b.add(new L.CylinderGeometry(2.25,2.25,3.6,8),o,[e,u.top+2.1,t]);for(let i=0;i<8;i++){let a=i*Math.PI/4,r=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),a);b.add(new L.BoxGeometry(.8,1.8,.15),n,[e+2.12*Math.sin(a),u.top+2.1,t+2.12*Math.cos(a)],r)}b.add(new L.ConeGeometry(2.5,1.6,8),h,[e,u.top+4.65,t]),b.beam([e,u.top+5.45,t],[e,u.top+6.15,t],.12,l)}b.box([4.6,2.5,2],[0,u.top+1.25,2.5],o),rT(b,0,u.top+2.5,1.2,5.2,1.4,o)}else if(23===u.number){for(let e of[-1,1]){let t=e*f*.34;for(let e=0;e<23;e++)for(let i=0;i<4;i++){let a=t+(i-1.5)*f*.04,r=11+1.96*e;b.box([.034*f,.18,.35],[a,r,-.25],o),b.box([.16,1.96,.35],[a+(e%2?1:-1)*f*.014,r+.98,-.25],o)}}for(let e of[-(.2*f),.2*f])b.box([.75,48,1],[e,33,-.3],o);!function(e,t,i,a,r,o,s){let n=Math.max(...t.points.map(e=>e[1])),l=n/2;for(let[t,o,h,c]of[[.78*i,.86*n,57.8,4.3],[.64*i,.75*n,62.1,4.1]]){e.box([t,c,o],[0,h+c/2,l],a);for(let i=-(.36*t);i<=.36*t;i+=2.4)e.box([1.25,c-1.1,.15],[i,h+c/2,l-o/2-.08],s);e.box([t+.7,.35,o+.7],[0,h+c,l],r)}let h=.76*i,c=.85*n;for(let t=0;t<9;t++){let i=t/9,a=(t+1)/9,r=e=>66.5+2.9*e*e+.55*Math.exp(-(16*e)),s={x:h*(1-.6*i)/2,z:c*(1-.68*i)/2},n={x:h*(1-.6*a)/2,z:c*(1-.68*a)/2},d=(e,t)=>[[-e.x,t,l-e.z],[e.x,t,l-e.z],[e.x,t,l+e.z],[-e.x,t,l+e.z]],u=d(s,r(i)),m=d(n,r(a)),p=[];for(let e=0;e<4;e++)p.push(...u[e],...m[e],...m[(e+1)%4],...u[e],...m[(e+1)%4],...u[(e+1)%4]);let f=new L.BufferGeometry;f.setAttribute("position",new L.Float32BufferAttribute(p,3)),f.setAttribute("uv",new L.Float32BufferAttribute(p.flatMap((e,t)=>t%3==0?[.2*p[t],.2*p[t+2]]:[]),2)),f.computeVertexNormals(),e.add(f,o)}rA(e,0,l,.4*h,.32*c,69.4,1.6,o)}(b,v,f,r.warm,o,c,n);let t=e.find(e=>e.id===ry[1]);if(t){let e=g.plan(t);b.extrude(e,-.65,20.4,r.warm),ru(b,e,[3,8,13,18],3.6,n,o),rh(e,(e,t)=>b.beam([e[0],20,e[1]],[t[0],20,t[1]],.55,o)),b.group.userData.osmIds.push(t.id)}b.group.userData.osmIds.push(ry[0])}else if(26===u.number)for(let e of[-1,1]){let t=e*f*.32;rA(b,t,3.1,.32*f,6,u.top+.3,2.7,c),b.box([2,2.4,.6],[t,u.top+1.3,-.3],o),b.box([1.1,1.5,.16],[t,u.top+1.4,-.65],n)}else if(27===u.number){rT(b,0,u.top+.8,-.3,.27*f,2.2,o);for(let e=-f/2+1;e<f/2;e+=1.1)b.box([.28,.48,.8],[e,19.6,-.6],o)}else if(28===u.number){for(let[e,t,i]of[[.55*f,u.top,3.4],[.36*f,u.top+3.4,2.6],[.27*f,u.top+6,1]])b.box([e,i,6],[0,t+i/2,3],r.warm),b.box([e+.65,.35,6.7],[0,t+i,3],o);b.add(new L.CircleGeometry(1.1,24,0,Math.PI),n,[0,u.top+1,-.05]),rT(b,0,u.top+4,-.45,.55*f,1.9,o)}else if(29===u.number)rT(b,0,u.top+.35,-.3,.43*f,3.3,o);else if(33===u.number){rA(b,S[0],S[1],f+15,Math.min(36,M),u.top,4.5,c),rT(b,0,u.top,-.5,.5*f,3.5,o);for(let e=0;e<5;e++)b.box([1.2,4.3,1.4],[S[0]+(e-2)*5.8,u.top+3.4,S[1]+(e%2?6:-6)],r.grey);let t=e.find(e=>e.id===rx);if(t){let e=g.plan(t),i=rn(e);b.extrude(e,-.65,11.5,r.grey),ru(b,e,[2.8,8],3.7,n,o),rA(b,i[0],i[1],Math.max(...e.points.map(e=>e[0]))-Math.min(...e.points.map(e=>e[0])),Math.max(...e.points.map(e=>e[1]))-Math.min(...e.points.map(e=>e[1])),10.85,4.3,c),b.group.userData.osmIds.push(t.id)}}i.add(g.place(b.finish()))}return i}(e,t);return d.children.length&&a.add(d),rR(a,"09:00"),a}(p.polygons,this.material.bind(this),p.roads);this.root.add(S),this.facadeLighting.register(S);let T=await fetch("/assets/space/shanghai-v1/sign-font.json?v=20260908b",{signal:this.abort.signal});if(!T.ok)throw Error(`Bund sign font HTTP ${T.status}`);let C=await T.json();if(this.disposed)return;!function(e,t,i){let a=new Map;if(e.traverse(e=>{"number"==typeof e.userData.bundNumber&&a.set(e.userData.bundNumber,e),"Fairmont Peace Hotel"===e.name&&a.set(20,e),"HSBC Building Bund"===e.name&&a.set(12,e)}),!rN.default.some(e=>a.has(e.building)))return;let r={gold:i(0xd5b774,.65,.32,.3),warm:i(0xffdb9c,.25,.36,2.2),red:i(0xbb1632,.28,.38,1.6),ink:i(2567208,.18,.5,.08),teal:i(1469284,.32,.4,.35),bronze:i(3156515,.48,.4,.02),lightbox:i(0xf1ecdb,.12,.55,1.5),ivory:i(0xe5e0ce,.35,.4,.65),shopGreen:i(476213,.25,.35,.07)};for(let e of rN.default){let i=a.get(e.building);if(!i)continue;let o=new a3;o.group.name=`Bund ${e.building} physical signage`,o.group.userData.signTexts=e.lines.map(e=>e.text);let s=e=>{let a=i.userData.groundOpeningCenters,s=void 0===e.bay?e.x??(e.xFraction??0)*(i.userData.frontage??0):a?.[e.bay+(a.length-1)/2]??e.bay*i.userData.groundBayPitch,n=void 0===e.bay?e.width:Math.min(e.width,i.userData.groundOpeningWidth-.16),l=[s,e.y,e.z],h=new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),e.yaw??Math.PI),c=function(e,t,i,a){if(!t.trim()||!Number.isFinite(i)||!Number.isFinite(a)||i<=0||a<=0)throw Error("Invalid Bund sign dimensions or text");for(let i of t)if(!e.data.glyphs[i])throw Error(`Missing Bund sign glyph: ${i}`);let r=e.generateShapes(t,1),o=new L.ExtrudeGeometry(r,{depth:.045,bevelEnabled:!0,bevelThickness:.003,bevelSize:.003,bevelSegments:1,curveSegments:3,steps:1});o.computeBoundingBox();let s=o.boundingBox,n=s.getSize(new L.Vector3),l=Math.min(i/n.y,a/n.x);return o.translate(-(s.min.x+s.max.x)/2,-(s.min.y+s.max.y)/2,0),o.scale(l,l,1),o}(t,e.text,e.height,n);if(c.computeBoundingBox(),e.panel){let t=c.boundingBox.getSize(new L.Vector3),a=new L.Vector3(0,0,-.085).applyQuaternion(h).add(new L.Vector3(...l));o.add(new L.BoxGeometry(void 0===e.bay?t.x+.5:i.userData.groundOpeningWidth-.04,t.y+.26,.14),r[e.panel],a.toArray(),h)}o.add(c,r[e.finish??"gold"],l,h)};if(18===e.building){let e=i.userData.groundOpeningWidth-.12;for(let t of[-2,-1,1,2]){let a=t*i.userData.groundBayPitch;for(let t of[-e/2,e/2])o.box([.1,3.35,.13],[a+t,2.66,.38],r.bronze);for(let t of[1,4.33])o.box([e,.1,.13],[a,t,.38],r.bronze);o.box([e-.22,2.95,.04],[a,2.65,.55],r.ivory),o.box([e-.4,2.65,.04],[a,2.65,.52],r.bronze),o.box([.56*e,.48,.28],[a,1.43,.32],r.ivory),o.box([.46*e,.03,.26],[a,1.69,.31],r.gold)}}if(27===e.building){let e=i.userData.groundOpeningWidth-.08;for(let t of[-5,-4,-3,-2,-1,1,2,3,4,5]){let a=t*i.userData.groundBayPitch;for(let t of(o.box([e,2.2,.075],[a,1.92,.39],r.shopGreen),[-e/2,0,e/2]))o.box([.065,2.3,.1],[a+t,1.92,.32],r.bronze);for(let t of[.82,2.35,3.02])o.box([e,.065,.1],[a,t,.32],r.bronze)}}for(let t of e.lines)s(t);if(e.blade){let t=new L.Shape().moveTo(-2.35/2,-5.9+.3).quadraticCurveTo(-2.35/2,-5.9,-2.35/2+.3,-5.9).lineTo(.875,-5.9).quadraticCurveTo(1.175,-5.9,1.175,-5.9+.3).lineTo(1.175,5.15).quadraticCurveTo(1.175,5.9,0,5.9).quadraticCurveTo(-2.35/2,5.9,-2.35/2,5.15).closePath(),i=new L.ExtrudeGeometry(t,{depth:.38,bevelEnabled:!1,curveSegments:12});for(let a of(i.translate(0,0,-.19),o.add(i,r.bronze,[-1318.7,12.1,1383.2],new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),Math.PI/2)),[-1,1])){let i=a*Math.PI/2,n=new L.Shape(t.getPoints(12).map(e=>e.multiply(new L.Vector2(.94,.985))));n.holes.push(new L.Path(t.getPoints(12).map(e=>e.multiply(new L.Vector2(.885,.975))))),o.add(new L.ExtrudeGeometry(n,{depth:.04,bevelEnabled:!1}),r.warm,[-1318.7+.215*a,12.1,1383.2],new L.Quaternion().setFromAxisAngle(new L.Vector3(0,1,0),i)),[...e.blade.text].forEach((e,t)=>s({text:e,x:-1318.7+.26*a,y:15.75-2.35*t,z:1383.2-.3*a,yaw:i,height:1.65,width:1.15,finish:"warm"}));let l=0;for(let t of e.blade.english){if(" "===t){l+=.7;continue}s({text:t,x:-1318.7+.26*a,y:16.15-.79*l,z:1383.2+.76*a,yaw:i,height:.53,width:.4,finish:"warm"}),l++}}for(let e of[7,17.2])o.beam([-1318.7,e,1382.025],[-1318.7,e,1380.9],.16,r.bronze,.16);for(let t of(o.group.userData.signTexts.push(e.blade.text,e.blade.english),o.box([2.6,.25,10.2],[-1310.4,5.6,1366.5],r.bronze),[1361.8,1371.2]))o.beam([-1311.6,6.5,t],[-1309.35,5.72,t],.09,r.bronze);for(let e of(o.box([.16,3.55,6.1],[-1311.15,1.9,1366.5],r.ink),[-3.05,-1.3,0,1.3,3.05]))o.box([.24,3.65,.085],[-1311.02,1.9,1366.5+e],r.bronze);for(let e of[.1,3.05,3.72])o.box([.24,.085,6.2],[-1311.02,e,1366.5],r.bronze);for(let e of[-.2,.2])o.box([.2,.7,.045],[-1310.8,1.75,1366.5+e],r.gold)}i.add(o.finish())}}(S,new rI().parse(C),this.material.bind(this)),this.makeTrees(p.polygons,b),this.makeBoats(),this.changed()}catch(e){if(!this.disposed)throw this.dispose(),e}}async loadBlender(e){let{scene:t}=await iT("shanghai");if(this.root.add(t),this.disposed)return void this.dispose();if(2!==t.userData.space_contract)throw Error("Shanghai needs Blender contract 2");this.root.userData.spaceSource="blender";let i=new Map;t.traverse(e=>{if(i.set(e.userData.spaceId,e),"string"==typeof e.userData.spaceName&&(e.name=e.userData.spaceName),/^Customs_(hour|minute)_hand$/.test(e.name)&&(e.name=e.name.replaceAll("_"," ")),"boolean"==typeof e.userData.spaceVisible&&(e.visible=e.userData.spaceVisible),Number.isFinite(e.userData.spaceRenderOrder)&&(e.renderOrder=e.userData.spaceRenderOrder),e instanceof L.Mesh){for(let[t,i]of(e.castShadow=!0===e.userData.spaceCastShadow,e.receiveShadow=!0===e.userData.spaceReceiveShadow,[["_buildingdata","buildingData"],["_bundbuildingid","bundBuildingId"],["_bundlighttop","bundLightTop"]])){let a=e.geometry.getAttribute(t);a&&e.geometry.setAttribute(i,a)}for(let t of Array.isArray(e.material)?e.material:[e.material])for(let e of(this.materials.add(t),Object.values(t)))e instanceof L.Texture&&this.textures.add(e)}});let a=i.get("root/0"),r=i.get("root/5"),o=i.get("root/131"),s=["149","150","151","152"].map(e=>i.get(`root/${e}`));if(!a||!r||!(o instanceof L.Mesh)||s.some(e=>!(e instanceof L.InstancedMesh)))throw Error(`Missing Shanghai animation bindings: ${[a,r,o,...s].map(e=>`${e?.userData.spaceId}:${e?.type}`).join(", ")}`);a.removeFromParent(),t.updateWorldMatrix(!0,!0);let n=[...i.values()].find(e=>6===e.userData.bundNumber),l=e.polygons.find(e=>"way/178408827"===e.id),h=n?.userData.frontage,c=n&&l?l.points.map(([e,t])=>n.worldToLocal(new L.Vector3(e,0,t))).filter(e=>e.x>h/2-.2&&e.z<-.5):[],d=Math.min(...c.map(e=>e.x)),u=Math.max(...c.map(e=>e.x)),m=Math.min(...c.map(e=>e.z));if(![h,d,u,m].every(Number.isFinite)||u-d<1)throw Error("Invalid Commercial Bank lighting binding");let p={width:h,axes:n.userData.groundOpeningCenters,wingAxes:[.24,.5,.76].map(e=>L.MathUtils.lerp(d,u,e)),wingZ:m};for(let e of this.materials)"boolean"==typeof e.userData.spaceDepthWrite&&(e.depthWrite=e.userData.spaceDepthWrite),e instanceof L.MeshStandardMaterial&&!e.userData.spaceRuntimeShader&&this.restoreBlenderMaterial(e,p);let f=i.get("swfc-skywalk-20260913/interior-mirror");if(f instanceof L.Mesh&&f.material instanceof L.MeshStandardMaterial){let e;t.traverse(t=>{t instanceof L.Mesh&&!Array.isArray(t.material)&&"pier-cladding"===t.material.userData.spaceSwfcTopMaterialRole&&(e=t)});let a=["swfc-hall-lighting-20260913/handrails","swfc-hall-lighting-20260913/lamp-trim","swfc-hall-ends-20260913/metal","swfc-hall-ends-20260913/panels"].flatMap(e=>{let t=i.get(e);return t instanceof L.Mesh&&t.material instanceof L.MeshStandardMaterial?[t.material]:[]}),r=i.get("swfc-floor-finish-20260913/floor");this.interiorMirrors=new tI(f,this.narrow,e,a,r instanceof L.Mesh&&r.material instanceof L.MeshStandardMaterial?r:void 0)}for(let t of(this.traffic=new rW(e.roads,this.material.bind(this),this.narrow,r),this.root.add(this.traffic.root),this.boats=s[0],this.boatDetails=s.slice(1),this.boatDetails))t.instanceMatrix=this.boats.instanceMatrix;let g=await new L.TextureLoader().loadAsync("/assets/space/shanghai-v1/waternormals.jpg");(this.textures.add(g),this.disposed)?this.dispose():(this.makeWater(o.geometry,g),this.water.position.copy(o.position),this.water.quaternion.copy(o.quaternion),this.water.scale.copy(o.scale),this.water.renderOrder=o.renderOrder,o.parent.add(this.water),o.removeFromParent(),this.facadeLighting.register(t),this.changed())}restoreBlenderMaterial(e,t){let i=String(e.userData.spaceShaderKey??"").replace(/^traffic-/,""),a=(t,i,a,r)=>this.material(t,i,a,r,e),r=/^shanghai-facade-(true|false)-(true|false)$/.exec(i),o=/-bund-stone-shadowed-([\d.]+)-(true|false)-([\d.,]*)-([\d.]+)/.exec(i),s=/-bund-roof-shadowed-([\d.]+)-([\d.]+)/.exec(i),n=/-bund-street-(true|false)-(true|false)/.exec(i),l=/-supertall-glass-([\d.]+)-([\d.]+)-(true|false)/.exec(i);if(r)this.facade(e.color.getHex(),"true"===r[1],"true"===r[2],e);else if(o)rm(a,e.color.getHex(),Number(o[1]),"true"===o[2],o[3]?o[3].split(",").map(Number):[],Number(o[4])),i.endsWith("-peace-riverfront-wash")&&rE(e),i.endsWith("-news-two-stone-zones")&&rk(e),i.includes("-commercial-bank-fixtures-")&&rb(e,t.width,t.axes,t.wingAxes,t.wingZ);else if(s)rp(a,e.color.getHex(),Number(s[1]),Number(s[2]));else if(n)rt(a,"true"===n[1],"true"===n[2]);else if(l)rV(a,this.officeWindows,e.color.getHex(),Number(l[1]),Number(l[2]),"true"===l[3]);else if(i.endsWith("-bund-marking-aa"))ri(e);else if("oriental-pearl-led"===i)this.pearlMaterial(e);else if("shanghai-lit-boat-cabin"===i)this.cabinMaterial(e);else{let t=/^shanghai-illumination-([\d.]+)$/.exec(i);if(t||"shanghai-illumination-uniform-v1"===i){let r=t?Number(t[1]):e.userData.spaceIllumination;if("number"!=typeof r||!Number.isFinite(r)||r<0)throw Error(`Invalid Blender illumination: ${i}`);a(e.color.getHex(),e.metalness,e.roughness,r)}else if(i&&!i.includes("onBeforeCompile")&&!i.includes("trafficVisibility"))throw Error(`Unsupported Blender material: ${i}`)}e.needsUpdate=!0}makeWater(e,t){t.wrapS=t.wrapT=L.RepeatWrapping,t.anisotropy=4,t.needsUpdate=!0;let i=e instanceof L.BufferGeometry?e:new L.ShapeGeometry(e),a=new a2(i,{waterNormals:t,waterColor:5068614,sunColor:0xffebca,sunDirection:new L.Vector3(-.5,.55,.5).normalize(),distortionScale:1.2,fog:!0}).material,r={...a.uniforms};delete r.mirrorSampler;let o=a.vertexShader.replace("mirrorCoord = textureMatrix * mirrorCoord;","mirrorCoord = textureMatrix * vec4( position, 1.0 );");this.water=new tL(i,{textureWidth:this.narrow?512:1024,textureHeight:this.narrow?512:1024,multisample:0,shader:{name:"HuangpuWater",uniforms:{...r,riverSlope:{value:.28},riverTint:{value:0},riverNight:this.night,tDiffuse:{value:null},color:{value:new L.Color}},vertexShader:o,fragmentShader:("uniform float riverSlope, riverTint, riverNight;\n"+a.fragmentShader).replaceAll("mirrorSampler","tDiffuse").replace("vec4 noise = getNoise( worldPosition.xz * size );","vec4 noise = mix(getNoise(worldPosition.xz*size),getNoise(worldPosition.xz*2.4),.45);").replace("( 0.001 + 1.0 / distance )","( 0.004 + 1.0 / distance )").replace("noise.xzy * vec3( 1.5, 1.0, 1.5 )","noise.xzy * vec3( riverSlope, 1.0, riverSlope )").replace("* waterColor;","* waterColor * mix(1.0, 0.06, riverNight);").replace("sunColor * diffuseLight * 0.3","sunColor * diffuseLight * mix(vec3(0.3), waterColor * 0.8, riverTint)")}}),a.dispose();let s=this.water.material;s.lights=!0,s.fog=!0,s.uniforms.normalSampler.value=t;let n=this.water.onBeforeRender.bind(this.water);this.water.onBeforeRender=(...e)=>{s.uniforms.eye.value.setFromMatrixPosition(e[2].matrixWorld),n(...e)},tF(this.water),this.water.rotation.x=-Math.PI/2,this.water.position.y=-.5,this.water.userData.spaceBackdrop=!0,s.uniforms.size.value=48,this.root.add(this.water)}mesh(e,t,i,a=this.root){let r=new L.Mesh(e,t);return r.castShadow=r.receiveShadow=!0,r.position.set(...i),a.add(r),r}beam(e,t,i,a,r=this.root){let o=new L.Vector3(...e),s=new L.Vector3(...t),n=s.clone().sub(o),l=this.mesh(new L.CylinderGeometry(i,i,n.length(),8),a,o.add(s).multiplyScalar(.5).toArray(),r);return l.quaternion.setFromUnitVectors(new L.Vector3(0,1,0),n.normalize()),l}pearlMaterial(e){let t=this.material(0xc3629a,.55,.34,.008,e),i=t.onBeforeCompile;return t.onBeforeCompile=(e,a)=>{i.call(t,e,a),e.vertexShader="varying vec2 pearlUV; varying vec3 pearlViewNormal;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\npearlUV=uv; pearlViewNormal=normalize(normalMatrix*normal);"),e.fragmentShader="varying vec2 pearlUV; varying vec3 pearlViewNormal;\n"+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
        vec2 led=pearlUV*vec2(96.,48.); vec2 pixel=max(fwidth(led),vec2(.001));
        vec2 edge=abs(fract(led)-.5);
        float dots=(1.-smoothstep(.075,.075+pixel.x,edge.x))*(1.-smoothstep(.075,.075+pixel.y,edge.y));
        dots=mix(.0225,dots,1.-smoothstep(.15,.55,max(pixel.x,pixel.y)));
        // Photo reference shows discrete LEDs on a dark shell. Preserve their
        // integrated energy at distance instead of flooding the whole sphere.
        float facing=pow(abs(normalize(pearlViewNormal).z),.65);
        vec3 ledColor=mix(vec3(.035,.22,1.),vec3(.1,.8,.7),smoothstep(.18,.7,pearlUV.y));
        ledColor=mix(ledColor,vec3(.8,.025,.24),smoothstep(.72,.95,pearlUV.y));
        totalEmissiveRadiance+=cityNight*ledColor*dots*3.2*facing;
      `)},t.customProgramCacheKey=()=>"oriental-pearl-led",t}makeLandmarks(e){var t,i;let a,r=this.material(0xd8d3c2,.1,.65,.065),o=this.pearlMaterial(),s=this.material(3234029,.25,.4,5);this.root.add((t=this.material.bind(this),i=this.officeWindows,(a=new L.Group).name="Shanghai supertall reconstructions",a.add(function(e,t){let i=new a3;i.group.name="Jin Mao Tower",i.group.position.set(218,-.65,1796),i.group.rotation.y=-.12;let a=rV(e,t,8557464,4.04,1.4),r=e(0xc1c1b4,.48,.38,.32),o=e(0xbdbdaf,.42,.4,1.4),s=e(0xc8c6b8,.4,.38,3.2),n=e(3491403,.32,.5),l=[29.3,28.5,27.7,26.9,26.1,25.3,24.5,23.7,22.9,22.1,21.3,20.5],h=0;for(let[e,t,d]of(rB.forEach((e,t)=>{let c=h+4.04*e,d=l[t],u=rO(d),m=rO(d+.6);rG(i,u,m,h,c,a);for(let e=0;e<4;e++){let t=e*Math.PI/2,a=(e,i,a)=>[e*Math.cos(t)-a*Math.sin(t),i,e*Math.sin(t)+a*Math.cos(t)],s=.32*d;for(let e=-s;e<=s+.01;e+=s/3)i.beam(a(e,h,d-.45),a(e,c,d+.15),.22,r,.48);for(let e of[-s-.45,s+.45])i.beam(a(e,h,d+.55),a(e,c,d+1.1),.65,o,.9)}for(let e=0;e<u.length;e++)i.beam([u[e][0],h,u[e][1]],[m[e][0],c,m[e][1]],.5,r,.62);rj(i,m,c-.35,.5,n,.8),rj(i,m,c,.6,t>8?s:r,1.1),i.extrude({points:m},c-.12,.12,r),h=c}),[[355.52,7.5,18.8],[363.02,7,15.1],[370.02,6.4,11.3],[376.42,5.5,7.6]])){var c;let r=[[d,d-(c=.32*d)],[d-c,d],[-d+c,d],[-d,d-c],[-d,-d+c],[-d+c,-d],[d-c,-d],[d,-d+c]];rG(i,r,r,e,e+t,a),rj(i,r,e+t-.2,.4,s,.65),r.forEach(([a,r])=>i.beam([a,e,r],[.97*a,e+t+.8,.97*r],.42,s))}i.add(new L.CylinderGeometry(1.05,3.1,12,8),s,[0,387.5,0]);for(let e=0;e<4;e++){let t=e*Math.PI/2+Math.PI/4;i.beam([1.8*Math.cos(t),388,1.8*Math.sin(t)],[4.6*Math.cos(t),397.5,4.6*Math.sin(t)],.65,s)}i.add(new L.CylinderGeometry(.08,.62,29,12),s,[0,406,0]);let d=i.finish();return d.userData.reconstruction={height:420.5,floors:88,sectionFloors:rB,estimated:["plan widths","crown details","lighting"]},d}(t,i),function(e,t){let i=new a3;i.group.name="Shanghai World Financial Center",i.group.position.set(371,-.65,1871),i.group.rotation.y=-.58;let a=rV(e,t,8560558,4.4,1.45,!0),r=e(0xafbcc0,.48,.3,.11),o=e(4357851,.3,.38,6.4),s=e(3361108,.36,.4),n=e=>29-22*Math.pow(e/492,1.65),l=e=>29-4*e/492,h=e=>13.8+(e-444)/33*6.2,c=(e,t,i)=>[[t,n(i)],[e,n(i)],[e,-n(i)],[t,-n(i)]],d=[...new Set([0,...Array.from({length:111},(e,t)=>(t+1)*4.4),444,477,492])].sort((e,t)=>e-t);for(let e=1;e<d.length;e++){let t=d[e-1],r=d[e];t>=444&&r<=477?(rG(i,c(-l(t),-h(t),t),c(-l(r),-h(r),r),t,r,a),rG(i,c(h(t),l(t),t),c(h(r),l(r),r),t,r,a)):rG(i,c(-l(t),l(t),t),c(-l(r),l(r),r),t,r,a)}for(let e of(i.box([27.6,.18,2*n(444)],[0,443.91,0],r),i.box([40,.18,2*n(477)],[0,477.09,0],r),i.box([50,.2,14],[0,491.9,0],r),[-1,1]))for(let t of[-1,1])for(let a=0;a<48;a++){let r=492*a/48,s=(a+1)*492/48;i.beam([e*(29-4*r/492),r,t*n(r)],[e*(29-4*s/492),s,t*n(s)],.45,o)}for(let e of[-1,1]){let t=(t,i)=>[t,i,e*(n(i)+.13)],a=[[-13.8,444],[-20,477],[20,477],[13.8,444]];for(let e of(a.forEach(([e,o],s)=>{let n=a[(s+1)%4];i.beam(t(e,o),t(n[0],n[1]),.5,r)}),i.beam(t(-25,491.7),t(25,491.7),.55,o),[77,154,231,308,385,439]))i.beam(t(-29+4*e/492,e),t(29-4*e/492,e),.65,s,.26)}let u=i.finish();return u.userData.reconstruction={height:492,floors:101,estimated:["plan widths","portal dimensions","lighting"]},u}(t,i),function(e,t){let i=new a3;i.group.name="Shanghai Tower",i.group.position.set(206,-.65,1982);let a=rV(e,t,0xa5b8bb,4.2,1.5,!0);a.side=L.DoubleSide;let r=e(0xb2c0bf,.45,.32,.075),o=e(0xd9c6a1,.42,.36,3),s=e(4413018,.3,.5,.02),n=function(){let e=Array.from({length:3},(e,t)=>new L.Vector2(69*Math.cos(t*Math.PI*2/3),69*Math.sin(t*Math.PI*2/3))),t=new L.CurvePath;for(let i=0;i<3;i++){let a=e[i],r=e[(i+1)%3],o=e[(i+2)%3],s=a.clone().lerp(r,.2),n=a.clone().lerp(r,.8),l=r.clone().lerp(o,.2);t.add(new L.QuadraticBezierCurve(s,a.clone().add(r).multiplyScalar(.69),n)),t.add(new L.QuadraticBezierCurve(n,r,l))}return t.getSpacedPoints(96).slice(0,-1).map(e=>[e.x,e.y])}(),l=n.length,h=(e,t)=>{let[i,a]=n[e%l],r=t*Math.PI*2/3-.34,o=Math.exp(Math.log(.5686)*t);return[(i*Math.cos(r)-a*Math.sin(r))*o,603*t+Math.max(0,(t-.91)/.09)*(617.5+14.5*Math.cos(e/l*Math.PI*2)-603),(i*Math.sin(r)+a*Math.cos(r))*o]},c=[],d=[],u=[];for(let e=0;e<=100;e++)for(let t=0;t<l;t++){let i=h(t,e/100);c.push(...i),d.push(t/l*330,i[1])}for(let e=0;e<100;e++)for(let t=1;t<l-1;t++){let i=e*l+t,a=i+l;u.push(i,a,i+1,i+1,a,a+1)}let m=new L.BufferGeometry;m.setAttribute("position",new L.Float32BufferAttribute(c,3)),m.setAttribute("uv",new L.Float32BufferAttribute(d,2)),m.setIndex(u),m.computeVertexNormals(),i.add(m,a),i.add(new L.CylinderGeometry(12,12.5,14,48),s,[0,580,0]);for(let e=1;e<l;e++)if(e<l-1&&i.beam(h(e,1),h(e+1,1),.45,o),e%3==1||e===l-1)for(let t=0;t<100;t+=2)i.beam(h(e,t/100),h(e,(t+2)/100),1===e||e===l-1?.68:.14,1===e||e===l-1?o:r);for(let e of[68,128,190,252,313,374,435,496,558])for(let t of[-1.2,1.2])for(let a=1;a<l-1;a++)i.beam(h(a,(e+t)/603),h(a+1,(e+t)/603),.32,r);let p=i.finish();return p.userData.reconstruction={height:632,twistDegrees:120,estimated:["plan curves","design-stage taper","cladding","lighting"]},p}(t,i)),a));let n=new L.Group;n.name=rY[0].name,n.position.set(-365,-.65,1280),this.root.add(n);for(let e=0;e<3;e++){let t=e*Math.PI*2/3;this.beam([67*Math.cos(t),0,67*Math.sin(t)],[10*Math.cos(t),100,10*Math.sin(t)],6,r,n),this.beam([8*Math.cos(t),105,8*Math.sin(t)],[8*Math.cos(t),350,8*Math.sin(t)],4.5,r,n),this.beam([12*Math.cos(t),113,12*Math.sin(t)],[12*Math.cos(t),345,12*Math.sin(t)],.65,s,n)}for(let[e,t]of[[93,25],[272,22.5],[350,7]]){let i=this.mesh(new L.SphereGeometry(t,40,24),o,[0,e,0],n),a=new L.TorusGeometry(1.006*t,.22,6,48);this.mesh(a,s,[0,e,0],n).rotation.x=Math.PI/2,i.name="Observation sphere"}this.mesh(new L.CylinderGeometry(.3,4,118,12),r,[0,409,0],n),this.mesh(new L.SphereGeometry(87,48,20),e,[-991,20,6952]).scale.set(1,.26,.82);let l=this.material(9846064,.2,.6);for(let e=0;e<7;e++)this.mesh(new L.BoxGeometry(70+12*e,5,66+11*e),l,[-878,20+6*e,7460]);for(let e of[-903,-853])for(let t of[7435,7485])this.mesh(new L.BoxGeometry(10,25,10),l,[e,12,t])}makeTrees(e,t){let i=[];for(let t of e){if("green"!==t.kind)continue;let e=a9(t),a=new L.ShapeGeometry(e),r=a.attributes.position,o=a.index;for(let e=0;e<o.count&&i.length<(this.narrow?1200:2800);e+=3){let t=new L.Vector3().fromBufferAttribute(r,o.getX(e)),a=new L.Vector3().fromBufferAttribute(r,o.getX(e+1)),s=new L.Vector3().fromBufferAttribute(r,o.getX(e+2));if(50>a.clone().sub(t).cross(s.clone().sub(t)).length())continue;let n=t.add(a).add(s).multiplyScalar(1/3);i.push([n.x,3,-n.y])}a.dispose()}let a=new L.InstancedMesh(new L.IcosahedronGeometry(1,1),t,i.length),r=new L.Object3D;i.forEach((e,t)=>{r.position.set(...e),r.scale.set(2.7+t%3,4+t%3,2.8+t%2),r.rotation.y=2.4*t,r.updateMatrix(),a.setMatrixAt(t,r.matrix)}),this.root.add(a)}cabinMaterial(e){let t=this.material(2377299,.2,.3,.001,e),i=t.onBeforeCompile;return t.onBeforeCompile=(e,a)=>{i.call(t,e,a),e.vertexShader="varying float cabinAlong,cabinWall;\n"+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <begin_vertex>","#include <begin_vertex>\ncabinAlong=(abs(normal.x)>.5?position.z:position.x)/2.8; cabinWall=1.-abs(normal.y);"),e.fragmentShader="varying float cabinAlong,cabinWall;\n"+e.fragmentShader,e.fragmentShader=e.fragmentShader.replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
        float frame=abs(fract(cabinAlong)-.5), aa=max(fwidth(cabinAlong),.001);
        float windowLight=mix(.7,1.-smoothstep(.35-aa,.35+aa,frame),1.-smoothstep(.3,1.,aa));
        totalEmissiveRadiance+=vec3(1.,.65,.3)*cityNight*1.8*windowLight*cabinWall;
      `)},t.customProgramCacheKey=()=>"shanghai-lit-boat-cabin",t}makeBoats(){let e=new L.Shape([[-6,-24],[6,-24],[6,16],[3,25],[0,29],[-3,25],[-6,16]].map(([e,t])=>new L.Vector2(e,-t))),t=new L.ExtrudeGeometry(e,{depth:4,bevelEnabled:!1});t.rotateX(-Math.PI/2),t.translate(0,-2,0),this.boats=new L.InstancedMesh(t,this.material(3359559,.3,.4),12),this.root.add(this.boats);let i=new L.BoxGeometry(10,3,34);i.translate(0,3,-3);let a=new L.BoxGeometry(8.8,2.2,25);a.translate(0,5.6,-5);let r=new L.BoxGeometry(10,.7,29);r.translate(0,7,-4);let o=this.cabinMaterial();for(let[e,t]of[[i,this.material(0xd9d9cd,.2,.45,.2)],[a,o],[r,this.material(0xe1e1d5,.2,.5,.15)]]){let i=new L.InstancedMesh(e,t,12);i.instanceMatrix=this.boats.instanceMatrix,this.boatDetails.push(i),this.root.add(i)}}setWeather(e,t,i,a="huangpu",r){if(this.interiorMirrors?.invalidateProbe(),this.night.value=t,this.traffic?.setWeather(t,+!!["drizzle","rain","downpour","thunderstorm","typhoon"].includes(e)),void 0!==r&&(this.timeOfDay=r),rR(this.root,this.timeOfDay),!this.water)return;let o=["typhoon","thunderstorm","downpour"].includes(e),s=["windy","rain","drizzle"].includes(e);this.water.material.uniforms.riverSlope.value=o?.9:s?.65:.4,this.water.material.uniforms.distortionScale.value=o?8:s?4:1.8;let n=this.water.material.uniforms.waterColor.value;this.water.material.uniforms.riverTint.value=Number("huangpu"!==a),n.setHex(tg[a].color),o&&("huangpu"===a?n.setHex(3557184):n.multiplyScalar(.65)),this.water.material.uniforms.sunDirection.value.copy(i),this.water.material.uniforms.sunColor.value.setHex(o?7899794:0xffebca).multiplyScalar(L.MathUtils.smoothstep(i.y,0,.18))}get lightingTransitioning(){return this.facadeLighting?.transitioning??!1}update(e,t,i,a){let r=this.lastTime?Math.min(.1,(e-this.lastTime)/1e3):0;this.lastTime=e,t&&(this.elapsed+=r),this.water&&(this.water.material.uniforms.time.value=.65*this.elapsed),this.traffic?.update(this.elapsed);let o=this.facadeLighting?.update(i,this.night.value,r)??!1;if(this.interiorMirrors?.update(i,!this.lightingTransitioning),!this.route)return o;let s=this.route.getLength();if(this.cruising){this.distance=Math.min(s,this.distance+95*r);let e=this.route.getPoint(Math.min(.999,this.distance/s)),t=this.route.getPoint(Math.min(1,(this.distance+460)/s));i.position.set(e.x,165,e.z),a.set(t.x,125,t.z),i.lookAt(a),this.distance>=s-1&&(this.cruising=!1,this.changed())}if(this.boats){let e=new L.Object3D;for(let t=0;t<this.boats.count;t++){let i=(t/this.boats.count+this.elapsed*(t%2?-5e-4:6e-4)+1)%1,a=this.route.getPoint(i),r=this.route.getTangent(i);e.position.set(a.x+r.z*(t%2?65:-65),1.7,a.z-r.x*(t%2?65:-65)),e.rotation.y=Math.atan2(r.x,r.z)+(t%2?Math.PI:0),e.scale.setScalar(.65+t%3*.17),e.updateMatrix(),this.boats.setMatrixAt(t,e.matrix)}this.boats.instanceMatrix.needsUpdate=!0,this.boats.computeBoundingSphere(),this.boatDetails.forEach(e=>e.computeBoundingSphere())}return o}dispose(){this.disposed=!0,this.cruising=!1,this.abort.abort(),this.root.removeFromParent(),this.interiorMirrors?.dispose(),this.batches.forEach(e=>e.geometries.forEach(e=>e.dispose())),this.batches.clear(),this.root.traverse(e=>{if(e instanceof L.Mesh)for(let t of(e.geometry.dispose(),Array.isArray(e.material)?e.material:[e.material]))this.materials.add(t);e instanceof L.InstancedMesh&&e.dispose()}),this.water?.dispose(),this.facadeLighting.dispose(),this.materials.forEach(e=>e.dispose()),this.textures.forEach(e=>e.dispose()),this.root.clear()}}let r$=[2,10,50,200,500];function rQ(e,t){return e.intersectObjects(t.filter(e=>e.visible),!1).find(e=>e.face&&e.face.normal.clone().transformDirection(e.object.matrixWorld).y>.8)}function rJ(e,t){e.updateWorldMatrix(!0,!0);let i=new L.Box3,a=new L.Vector3,r=t?.matrixWorld.clone().invert(),o=new L.Matrix4,s=new L.Matrix4;return e.traverseVisible(e=>{if(!(e instanceof L.Mesh)||(Array.isArray(e.material)?e.material.every(e=>!e.visible):!e.material.visible))return;let t=e.geometry.getAttribute("position");for(let n=0;n<(e instanceof L.InstancedMesh?e.count:1);n++){o.copy(e.matrixWorld),e instanceof L.InstancedMesh&&(e.getMatrixAt(n,s),o.multiply(s)),r&&o.premultiply(r);for(let e=0;e<t.count;e++)i.expandByPoint(a.fromBufferAttribute(t,e).applyMatrix4(o))}}),i}class r0{host;callbacks;scene;camera;disposed;sky;renderer;composer;bloom;ao;hemisphere;sun;fill;interiorLight;orbit;zoomValue;transform;entries;surfaces;ray;pointer;outline;grid;drop;floorMaterial;pedestalMaterial;room;city;preparingCity;cityPreparation;cityCompilation;weatherPatchedCity;environment;outdoorEnvironment;weather;weatherKey;lightingKey;currentWeather;riverColor;weatherMotion;weatherTimer;shadowDirty;reducedMotion;currentView;flight;observer;themeObserver;media;events;frame;themeFrame;selected;placing;snap;mode;cancelling;touches;consumedTouch;forwarding;drag;press;turnDrag;navigation;freeCamera;droneSpeed;altitude;get navigating(){return"orbit"!==this.navigation}get droneMinHeight(){return this.room?.environment==="island"?-5:1}walkKeys;walkTime;walkLook;constructor(e,t){this.host=e,this.callbacks=t,this.scene=new L.Scene,this.camera=new L.PerspectiveCamera(42,1,.05,1e5),this.disposed=!1,this.sky=null,this.hemisphere=new L.HemisphereLight(0xcbdfff,3683112,.3),this.sun=new L.DirectionalLight(0xffe2b5,2.5),this.fill=new L.DirectionalLight(0xc4daff,.25),this.interiorLight=new L.SpotLight(0xffe2bb,0,35,Math.PI/2.8,1,2),this.zoomValue=-1,this.entries=new Map,this.surfaces=[],this.ray=new L.Raycaster,this.pointer=new L.Vector2,this.outline=new L.Box3Helper(new L.Box3),this.grid=new L.GridHelper(40,80),this.drop=new L.Mesh(new L.RingGeometry(.3,.35,40),new L.MeshBasicMaterial({depthWrite:!1,side:L.DoubleSide})),this.floorMaterial=new L.MeshStandardMaterial({roughness:.95}),this.pedestalMaterial=new L.MeshStandardMaterial({roughness:.7}),this.room=null,this.city=null,this.preparingCity=!1,this.cityPreparation=0,this.cityCompilation=null,this.weatherPatchedCity=null,this.weatherKey="",this.lightingKey="",this.currentWeather="sunny",this.riverColor="huangpu",this.weatherMotion=!0,this.weatherTimer=0,this.shadowDirty=!0,this.reducedMotion=window.matchMedia("(prefers-reduced-motion: reduce)"),this.currentView="home",this.flight=null,this.media=window.matchMedia("(prefers-color-scheme: dark)"),this.events=new AbortController,this.frame=0,this.themeFrame=0,this.selected=null,this.placing=!1,this.snap=!1,this.mode="translate",this.cancelling=!1,this.touches=new Map,this.consumedTouch=null,this.forwarding=!1,this.drag=null,this.press=null,this.turnDrag=null,this.navigation="orbit",this.freeCamera=!1,this.droneSpeed=500,this.altitude=NaN,this.walkKeys=new Map,this.walkTime=0,this.walkLook=null,this.theme=()=>{cancelAnimationFrame(this.themeFrame),this.themeFrame=requestAnimationFrame(this.updateTheme)},this.updateTheme=()=>{let e=document.createElement("span");this.host.appendChild(e);let t=document.createElement("canvas");t.width=t.height=1;let i=t.getContext("2d",{willReadFrequently:!0}),a=t=>{e.style.color=`var(${t})`,i.clearRect(0,0,1,1),i.fillStyle=getComputedStyle(e).color,i.fillRect(0,0,1,1);let[a,r,o]=i.getImageData(0,0,1,1).data;return new L.Color().setRGB(a/255,r/255,o/255,L.SRGBColorSpace)};this.outline.material.color.copy(a("--accent")),this.drop.material.color.copy(a("--accent"));let r=this.grid.material;r.color.copy(a("--border-strong")),r.vertexColors=!1,r.transparent=!0,r.opacity=.35,e.remove(),this.render()},this.render=()=>{this.shadowDirty=!0,this.room&&this.weather.patchSurfaces(this.room.root),this.scheduleRender()},this.scheduleRender=()=>{this.disposed||this.preparingCity||this.frame||document.hidden||(this.frame=requestAnimationFrame(e=>{if(this.frame=0,this.disposed||this.preparingCity)return;if(this.navigating&&this.walkKeys.size&&this.room){let t=this.walkTime?Math.min(.05,(e-this.walkTime)/1e3):0;this.walkTime=e;let i=new Set(this.walkKeys.values());"drone"===this.navigation&&this.look((Number(i.has("look-left"))-Number(i.has("look-right")))*t*Math.PI/3,(Number(i.has("look-up"))-Number(i.has("look-down")))*t*Math.PI/3);let a=function(e,t,i,a){let r=new L.Vector3;if(![e.x,e.y,e.z,i,a].every(Number.isFinite)||i<=0||a<=0)return r;let o=new L.Vector3(e.x,0,e.z).normalize(),s=new L.Vector3(-o.z,0,o.x);return r.copy(o).multiplyScalar(Number(t.has("forward"))-Number(t.has("back"))).addScaledVector(s,Number(t.has("right"))-Number(t.has("left"))).setY(Number(t.has("up"))-Number(t.has("down"))).normalize().multiplyScalar(Math.min(i,2e3)*Math.min(a,.05))}(this.camera.getWorldDirection(new L.Vector3),i,"drone"===this.navigation?this.droneSpeed:2.2,t),r=this.camera.position,o=r.y-1.65,s="drone"===this.navigation?[r.x+a.x,L.MathUtils.clamp(r.y+a.y,this.droneMinHeight,6e3)-1.65,r.z+a.z]:function(e,t,i,a,r){if(![...e,t,i].every(Number.isFinite))return e;let o=[...e],s=Math.ceil(Math.hypot(t,i)/.1);if(s>100)return e;let n=(e,t)=>{let i=tC(e,t,o[1],a);null===i||r.some(a=>a.maxY>i+.3&&a.minY<i+1.8&&.22>Math.hypot(e-Math.max(a.minX,Math.min(a.maxX,e)),t-Math.max(a.minZ,Math.min(a.maxZ,t))))||(o[0]=e,o[1]=i,o[2]=t)};for(let e=0;e<s;e++)n(o[0]+t/s,o[2]),n(o[0],o[2]+i/s);return o}([r.x,o,r.z],a.x,a.z,this.room.style,this.room.obstacles),n=new L.Vector3(s[0]-r.x,s[1]-o,s[2]-r.z);this.camera.position.add(n),this.orbit.target.add(n),this.render()}else this.walkTime=0;if(this.flight){let t=Math.min(1,(e-this.flight.start)/450),i=t*t*(3-2*t);this.camera.position.lerpVectors(this.flight.from,this.flight.to,i),this.orbit.target.lerpVectors(this.flight.fromTarget,this.flight.target,i),this.camera.lookAt(this.orbit.target),1===t?(this.flight=null,this.orbit.update()):this.render()}let t=this.selected&&this.entries.get(this.selected);for(let e of(t&&this.outline.box.setFromObject(t.proxy),this.entries.values()))iH(e.model)?this.render():e.turning&&(e.turning=!1,this.apply(e,e.data));this.room?.update(this.camera,!this.freeCamera&&["home","front","side","top"].includes(this.currentView)),this.city?.update(e,this.weatherMotion&&!this.reducedMotion.matches,this.camera,this.orbit.target)&&(this.shadowDirty=!0),this.reportZoom(),this.reportAltitude(),(this.city?.cruising||"drone"===this.navigation)&&this.sun.target.position.distanceToSquared(this.orbit.target)>25e4&&(this.sun.target.position.copy(this.orbit.target),this.positionSun(),this.shadowDirty=!0);let i=this.weather.update(e,this.camera,this.weatherMotion&&!this.reducedMotion.matches);(this.room?.style!=="company"||this.city)&&this.weather.environment&&(this.scene.environment=this.weather.environment),this.renderer.shadowMap.needsUpdate=this.shadowDirty,this.shadowDirty=!1,this.composer.render(),clearTimeout(this.weatherTimer),(i||this.city?.cruising||this.city?.lightingTransitioning)&&(this.weatherTimer=window.setTimeout(this.scheduleRender,Math.max(0,33-(performance.now()-e))))}))},this.cameraChanged=()=>{let e=this.cameraRoomBounds();!e||this.flight||this.navigating||(this.camera.position.clamp(e.min,e.max),this.camera.lookAt(this.orbit.target)),this.reportZoom(),this.render()},this.down=e=>{if(this.cruise(!1),this.forwarding)return;if(this.navigating){0!==e.button||this.walkLook||(this.renderer.domElement.focus({preventScroll:!0}),this.walkLook={id:e.pointerId,x:e.clientX,y:e.clientY},this.renderer.domElement.setPointerCapture(e.pointerId)),e.stopImmediatePropagation();return}if(this.flight=null,"touch"===e.pointerType&&this.touches.set(e.pointerId,e),this.touches.size>1){this.cancel();let e=null!==this.consumedTouch&&this.touches.get(this.consumedTouch);this.consumedTouch=null,this.transform.enabled=!1,e&&(this.forwarding=!0,this.renderer.domElement.dispatchEvent(new PointerEvent("pointerdown",e)),this.forwarding=!1);return}if(0!==e.button)return;if(this.renderer.domElement.focus({preventScroll:!0}),this.cast(e),this.press={x:e.clientX,y:e.clientY,blank:!1},this.placing){this.orbit.enabled=!1,"touch"===e.pointerType&&(this.consumedTouch=e.pointerId),this.renderer.domElement.setPointerCapture(e.pointerId),e.stopImmediatePropagation();return}if("twist"!==this.mode&&(this.transform.pointerHover(new PointerEvent("pointermove",{clientX:this.pointer.x,clientY:this.pointer.y,button:e.button})),this.transform.axis))return;let t=this.ray.intersectObjects([...this.entries.values()].map(e=>e.proxy),!1)[0],i=t&&this.entries.get(t.object.userData.spaceId);if(this.press.blank=!i,!i)return;if(this.selected!==i.data.id){"touch"===e.pointerType&&(this.consumedTouch=e.pointerId),this.callbacks.select(i.data.id),e.stopImmediatePropagation();return}if("twist"===this.mode){let t=this.renderer.domElement.getBoundingClientRect(),a=function(e,t,i,a,r,o,s){if(iH(e))return null;if(t.updateMatrixWorld(!0),e instanceof tl.default){let n=(0,iV.pyraPickHit)(e,t,i,a,r,o,s);return n&&((a,r)=>{let l=(0,iV.pyraResolveMove)(e,n,t,i,a,r,o,s);return l&&(0,iU.pyraMoveToString)(l)})}if(e instanceof th.default){let n=(0,iO.megaPickHit)(e,t,i,a,r,o,s);return n&&((a,r)=>{let l=(0,iO.megaResolveMove)(e,n,t,i,a,r,o,s);return l&&(0,iN.megaMoveToString)(l)})}if(e instanceof tc.default){let n=(0,iG.skewbPickHit)(e,t,i,a,r,o,s);return n&&((a,r)=>{let l=(0,iG.skewbResolveMove)(e,n,t,i,a,r,o,s);return l&&(0,iB.skewbMoveToString)(l)})}let n=new L.Raycaster;n.setFromCamera(new L.Vector2(a/o*2-1,1-r/s*2),i);let l=n.intersectObject(e,!0).find(e=>e.object.visible&&e.object.material&&!(Array.isArray(e.object.material)?e.object.material:[e.object.material]).every(e=>!e.visible));if(!l)return null;let h=e.worldToLocal(l.point.clone()),c=e.localToWorld(new L.Vector3);if(e instanceof tn.default){let t=!1;for(let i=l.object;i&&i!==e;i=i.parent)e.middle.some(e=>e.pivot===i)&&(t=!0);return(a,r)=>{if(t||Math.abs(r)>1.6*Math.abs(a))return"/";let n=(0,ij.scoreCornerTwist)([0],()=>new L.Vector3(0,1,0).transformDirection(e.matrixWorld),l.point,c,a,r,i,o,s);return n?h.y>=0?"("+-n.dir+",0)":"(0,"+-n.dir+")":null}}let d=[Math.abs(h.x),Math.abs(h.y),Math.abs(h.z)].indexOf(Math.max(Math.abs(h.x),Math.abs(h.y),Math.abs(h.z)));return(t,a)=>{let r=(0,ij.scoreCornerTwist)([0,1,2].filter(e=>e!==d),t=>new L.Vector3().setComponent(t,-1).transformDirection(e.matrixWorld),l.point,c,t,a,i,o,s,.25);if(!r)return null;let n=Math.max(0,Math.min(e.order-1,Math.floor(h.getComponent(r.corner)/tr.default.SIZE+e.order/2))),u=iF.default.wideFromClick("xyz"[r.corner],n,e.order).sign;return new iI.TwistAction(u,r.dir<0).value}}(i.model,this.scene,this.camera,e.clientX-t.left,e.clientY-t.top,t.width,t.height);if(!a)return;this.turnDrag={id:e.pointerId,x:e.clientX,y:e.clientY,entry:i,resolve:a,fired:!1},this.orbit.enabled=this.transform.enabled=!1,"touch"===e.pointerType&&(this.consumedTouch=e.pointerId),this.renderer.domElement.setPointerCapture(e.pointerId),e.stopImmediatePropagation();return}if("translate"!==this.mode)return;let a=new L.Plane(new L.Vector3(0,1,0),-t.point.y);this.drag={id:e.pointerId,entry:i,before:this.read(i),plane:a,offset:i.root.position.clone().sub(t.point),x:e.clientX,y:e.clientY,moved:!1},this.orbit.enabled=!1,this.transform.enabled=!1,"touch"===e.pointerType&&(this.consumedTouch=e.pointerId),this.renderer.domElement.setPointerCapture(e.pointerId),e.stopImmediatePropagation()},this.move=e=>{if(this.navigating){this.walkLook?.id===e.pointerId&&(this.look(-(.003*(e.clientX-this.walkLook.x)),-(.003*(e.clientY-this.walkLook.y))),this.walkLook.x=e.clientX,this.walkLook.y=e.clientY,this.render()),e.stopImmediatePropagation();return}if(this.touches.has(e.pointerId)&&this.touches.set(e.pointerId,e),this.turnDrag?.id===e.pointerId){let t=this.turnDrag,i=e.clientX-t.x,a=e.clientY-t.y;if(!t.fired&&Math.hypot(i,a)>12){let e=t.resolve(i,a);e&&(t.fired=!0,this.twist(e,t.entry))}e.stopImmediatePropagation();return}if(this.placing){this.cast(e);let t=this.placementHit();if(this.drop.visible=!!t,t){let[e,i]=tz([t.point.x,t.point.z],this.snap);this.drop.position.set(e,t.point.y+.02,i)}this.render()}if(!this.drag||this.drag.id!==e.pointerId)return;this.cast(e);let t=this.ray.ray.intersectPlane(this.drag.plane,new L.Vector3);t&&Math.hypot(e.clientX-this.drag.x,e.clientY-this.drag.y)>3&&(this.drag.moved=!0,this.drag.entry.root.position.copy(t).add(this.drag.offset),this.settle(this.drag.entry),this.render()),e.stopImmediatePropagation()},this.up=e=>{if(this.navigating){this.walkLook?.id===e.pointerId&&(this.walkLook=null,this.renderer.domElement.hasPointerCapture(e.pointerId)&&this.renderer.domElement.releasePointerCapture(e.pointerId)),e.stopImmediatePropagation();return}if(this.touches.delete(e.pointerId),this.consumedTouch===e.pointerId&&(this.consumedTouch=null),this.touches.size||(this.transform.enabled=!0),this.turnDrag?.id===e.pointerId){this.turnDrag=null,this.press=null,this.orbit.enabled=this.transform.enabled=!0,this.renderer.domElement.hasPointerCapture(e.pointerId)&&this.renderer.domElement.releasePointerCapture(e.pointerId),e.stopImmediatePropagation();return}if(this.drag?.id===e.pointerId){let t=this.drag;this.drag=null,this.orbit.enabled=this.transform.enabled=!0,this.renderer.domElement.hasPointerCapture(e.pointerId)&&this.renderer.domElement.releasePointerCapture(e.pointerId),t.moved&&this.callbacks.change(this.read(t.entry)),e.stopImmediatePropagation()}else if(this.press&&5>Math.hypot(e.clientX-this.press.x,e.clientY-this.press.y))if(this.placing){this.cast(e);let t=this.placementHit();if(t){let e=+(t.point.y>4),i=!this.surfaces.includes(t.object)&&t.point.y>5*e+.12;this.callbacks.place(tz([t.point.x,t.point.z],this.snap),e,this.room?.style==="company"||i?.06:1)}this.orbit.enabled=!0,this.renderer.domElement.hasPointerCapture(e.pointerId)&&this.renderer.domElement.releasePointerCapture(e.pointerId),e.stopImmediatePropagation()}else this.press.blank&&!this.transform.dragging&&this.callbacks.select(null);this.placing&&(this.orbit.enabled=!0),this.press=null},this.cancel=()=>{this.cruise(!1),this.walkKeys.clear();let e=this.walkLook;this.walkLook=null,this.walkTime=0,e&&this.renderer.domElement.hasPointerCapture(e.id)&&this.renderer.domElement.releasePointerCapture(e.id),this.turnDrag&&this.renderer.domElement.hasPointerCapture(this.turnDrag.id)&&this.renderer.domElement.releasePointerCapture(this.turnDrag.id),this.turnDrag=null;let t=this.drag;this.drag=null,this.press=null,t&&(this.apply(t.entry,t.before),this.renderer.domElement.hasPointerCapture(t.id)&&this.renderer.domElement.releasePointerCapture(t.id)),this.transform.dragging&&(this.cancelling=!0,this.transform.reset(),this.transform.pointerUp(new PointerEvent("pointerup",{button:0})),this.cancelling=!1),this.orbit.enabled=this.transform.enabled=!this.navigating,this.render()},this.renderer=new R.WebGLRenderer({antialias:!0,alpha:!1}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio,2)),this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.autoUpdate=!1,this.renderer.shadowMap.type=L.PCFShadowMap,this.renderer.toneMapping=L.ACESFilmicToneMapping,this.renderer.toneMappingExposure=.95,this.weather=new a0(e.clientWidth<600,this.renderer,this.render,t.weatherError),this.scene.add(this.weather.root),this.composer=new eQ(this.renderer,new L.WebGLRenderTarget(1,1,{type:L.HalfFloatType,samples:4})),this.composer.addPass(new eJ(this.scene,this.camera)),this.ao=new te(this.scene,this.camera,1,1),this.ao.updateGtaoMaterial({radius:.24,thickness:.5,distanceExponent:1.4}),this.ao.blendIntensity=.6;const i=this.ao.render.bind(this.ao);this.ao.render=(...e)=>{let t=[];this.scene.traverseVisible(e=>{(e===this.transform.getHelper()||e.userData.spaceBackdrop||e instanceof L.Mesh&&("Reflector"===e.type||(Array.isArray(e.material)?e.material:[e.material]).every(e=>!e.visible||e.transparent)))&&t.push(e)}),t.forEach(e=>{e.visible=!1});try{i(...e)}finally{t.forEach(e=>{e.visible=!0})}},this.composer.addPass(this.ao),this.bloom=new e1(new L.Vector2(1,1),.22,.65,1.1),this.composer.addPass(this.bloom),this.composer.addPass(new e9),this.composer.addPass(new ti);const a=this.renderer.domElement;a.tabIndex=0,a.setAttribute("aria-label",e.getAttribute("aria-label")??"3D cube space"),a.setAttribute("aria-describedby","space-instructions"),e.appendChild(a),this.orbit=new j(this.camera,a),this.orbit.minDistance=4,this.orbit.maxDistance=240,this.orbit.maxPolarAngle=Math.PI/2-.025,this.orbit.maxTargetRadius=70,this.orbit.screenSpacePanning=!1,this.orbit.addEventListener("change",this.cameraChanged),this.transform=new eu(this.camera,a),this.transform.setSize(.85),this.scene.add(this.transform.getHelper()),this.transform.addEventListener("change",this.render),this.transform.addEventListener("dragging-changed",e=>{this.orbit.enabled=!e.value}),this.transform.addEventListener("objectChange",()=>{let e=this.selected&&this.entries.get(this.selected);e&&(this.settle(e),this.render())}),this.transform.addEventListener("mouseUp",()=>{let e=this.selected&&this.entries.get(this.selected);e&&!this.cancelling&&this.callbacks.change(this.read(e))}),this.scene.add(this.hemisphere);const r=this.sun;r.position.set(-12,10,9),r.castShadow=!0,r.shadow.mapSize.set(2048,2048),Object.assign(r.shadow.camera,{left:-42,right:42,top:42,bottom:-42,near:.5,far:180}),r.shadow.bias=-2e-4,r.shadow.normalBias=.025,r.shadow.radius=3,this.scene.add(r);const o=this.fill;o.position.set(6,5,10),this.scene.add(o),this.interiorLight.castShadow=!0,this.interiorLight.shadow.mapSize.set(1024,1024),this.interiorLight.shadow.normalBias=.018,this.interiorLight.shadow.bias=-1e-4,this.interiorLight.shadow.radius=4,this.scene.add(this.interiorLight,this.interiorLight.target);const s=new eU,n=new R.PMREMGenerator(this.renderer);this.environment=n.fromScene(s),this.scene.environment=this.environment.texture,s.dispose(),n.dispose(),new eV().load("/assets/space/v1/sunset.hdr.bin",e=>{if(!this.disposed){let t=new R.PMREMGenerator(this.renderer);this.outdoorEnvironment=t.fromEquirectangular(e),this.weatherKey||(this.scene.environment=this.outdoorEnvironment.texture),t.dispose(),this.render(),e.mapping=L.EquirectangularReflectionMapping,this.sky=e,this.weatherKey||(this.scene.background=e),this.scene.backgroundIntensity=.12;return}e.dispose()});const l=new L.Mesh(new L.PlaneGeometry(100,100),this.floorMaterial);for(const e of(l.rotation.x=-Math.PI/2,l.position.y=-.32,l.receiveShadow=!0,this.scene.add(l),this.surfaces.push(l),tT)){const t=new L.Mesh(new eO.RoundedBoxGeometry(e.width,e.height,e.depth,2,.035),this.pedestalMaterial);t.position.set(e.x,e.height/2,e.z),t.castShadow=t.receiveShadow=!0,this.scene.add(t),this.surfaces.push(t)}for(const t of(this.grid.position.y=.006,this.grid.visible=!1,this.scene.add(this.grid),this.drop.rotation.x=-Math.PI/2,this.drop.visible=!1,this.scene.add(this.drop),this.outline.visible=!1,this.scene.add(this.outline),this.observer=new ResizeObserver(()=>{let t=e.clientWidth,i=e.clientHeight;t&&i&&(this.camera.aspect=t/i,this.camera.fov=["interior","study","bedroom","bathroom","courtyard","garage","cinema","gym"].includes(this.currentView)?t<600?76:this.room?.style==="company"?65:58:t<600?60:46,this.camera.updateProjectionMatrix(),this.renderer.setSize(t,i),this.composer.setSize(t,i),this.ao.setSize(Math.ceil(.75*t),Math.ceil(.75*i)),this.room?.resize(t),this.render())}),this.observer.observe(e),this.themeObserver=new MutationObserver(this.theme),this.themeObserver.observe(document.documentElement,{attributes:!0}),this.media.addEventListener("change",this.theme),this.reducedMotion.addEventListener("change",this.render,{signal:this.events.signal}),document.addEventListener("visibilitychange",()=>{clearTimeout(this.weatherTimer),document.hidden?(this.cancel(),cancelAnimationFrame(this.frame),this.frame=0):this.render()},{signal:this.events.signal}),["transitionend","transitioncancel"]))document.documentElement.addEventListener(t,e=>{("--background"===e.propertyName||"--muted"===e.propertyName||"--accent"===e.propertyName)&&this.theme()},{signal:this.events.signal});this.theme();const h={capture:!0,signal:this.events.signal};a.addEventListener("pointerdown",this.down,h),a.addEventListener("wheel",e=>{if(this.flight=null,this.cruise(!1),!this.navigating)return;e.preventDefault();let t=e.deltaY*(1===e.deltaMode?16:2===e.deltaMode?this.host.clientHeight:1);this.reportZoom(),this.setZoom(this.zoomValue-.05*t)},{passive:!1,signal:this.events.signal}),a.addEventListener("pointermove",this.move,h),a.addEventListener("pointerleave",()=>{this.drop.visible=!1,this.render()},{signal:this.events.signal}),a.addEventListener("pointerup",this.up,h),a.addEventListener("pointercancel",e=>{this.touches.delete(e.pointerId),this.consumedTouch=null,this.cancel()},h),a.addEventListener("lostpointercapture",this.cancel,h),a.addEventListener("webglcontextlost",e=>{e.preventDefault(),this.callbacks.unavailable()},{signal:this.events.signal}),window.addEventListener("blur",()=>{this.touches.clear(),this.consumedTouch=null,this.cancel()},{signal:this.events.signal});const c={KeyW:"forward",ArrowUp:"forward",KeyS:"back",ArrowDown:"back",KeyA:"left",ArrowLeft:"left",KeyD:"right",ArrowRight:"right",KeyR:"up",KeyF:"down",KeyE:"up",KeyQ:"down"},d={ArrowUp:"look-up",ArrowDown:"look-down",ArrowLeft:"look-left",ArrowRight:"look-right"};a.addEventListener("blur",()=>{this.walkKeys.clear(),this.walkTime=0},{signal:this.events.signal}),a.addEventListener("keydown",e=>{if(!this.navigating||e.ctrlKey||e.metaKey||e.altKey)return;let t="drone"===this.navigation&&d[e.code]||c[e.code];t&&(e.preventDefault(),this.navigationInput(t,!0,e.code))},{signal:this.events.signal}),window.addEventListener("keyup",e=>{let t=c[e.code];t&&this.navigationInput(t,!1,e.code)},{signal:this.events.signal}),this.view("interior")}theme;updateTheme;render;scheduleRender;afterCityCompilation(e){this.cityCompilation?this.cityCompilation.then(e,e):e()}retireScene(e){e&&(e.root.removeFromParent(),this.afterCityCompilation(()=>e.dispose()))}async prepareCity(e,t){let i=++this.cityPreparation,a=()=>!this.disposed&&this.cityPreparation===i&&this.city===e&&this.room===t;this.preparingCity=!0;try{let i;if(await Promise.all([e?.ready,t.ready,this.weather.engine.ready,this.cityCompilation?.catch(()=>{})]),!a()||!e)return;e.root.visible=!0,t.root.visible=!0,e.setWeather(this.currentWeather,1-this.weather.daylight.day,this.weather.daylight.direction,this.riverColor),this.weatherPatchedCity!==e&&(this.weather.patchSurfaces(e.root),this.weatherPatchedCity=e),this.weather.patchSurfaces(t.root),t.update(this.camera,!this.freeCamera&&["home","front","side","top"].includes(this.currentView)),e.update(performance.now(),!1,this.camera,this.orbit.target),this.weather.update(performance.now(),this.camera,!1),this.weather.environment&&(this.scene.environment=this.weather.environment);let r=new L.Group;r.add(e.root,t.root);let o=this.renderer.getRenderTarget();try{this.renderer.setRenderTarget(this.composer.readBuffer),i=this.renderer.compileAsync(r,this.camera,this.scene),this.cityCompilation=i}finally{this.renderer.setRenderTarget(o),this.scene.add(e.root,t.root)}try{await i}finally{this.cityCompilation===i&&(this.cityCompilation=null)}a()&&this.callbacks.cityState("ready")}catch(i){if(!a())return;console.error("Space city preparation failed",i),e&&(e.root.visible=!1,this.callbacks.cityState("error")),t.root.visible=!1,this.callbacks.roomState?.("error")}finally{a()&&(this.preparingCity=!1,this.render())}}create(e){let t="sq1"===e.kind?new tn.default:"pyram"===e.kind?new tl.default:"minx"===e.kind?new th.default:"skewb"===e.kind?new tc.default:new ta.default("mirror"===e.kind?3:Number(e.kind[0]),"mirror"===e.kind);if(t instanceof ta.default){t.instancedRenderer.thickness=!0;let e=t.isMirror?(0,to.mirrorFaces)():ts.CUBE_FILL;t.instancedRenderer.setFaceColorOverride(e),t.isMirror&&t.instancedRenderer.setRawCore(!0,e,tr.default.CORE.color.getStyle(),!0)}let i=rJ(t),a=i.getSize(new L.Vector3),r=i.getCenter(new L.Vector3),o=new L.Group,s=1.55/Math.max(a.x,a.y,a.z);o.scale.setScalar(s);let n=new L.Group;n.position.copy(r).negate(),n.add(t),o.add(n);let l=new L.Group;l.add(o);let h=new Map,c=new Map;t.traverse(t=>{if(!(t instanceof L.Mesh))return;t.castShadow=t.receiveShadow=!0,c.set(t,t.material);let i=t=>{if(!t.visible||t.transparent||t.side===L.BackSide)return t;let i=h.get(t);return i||((i=new L.MeshPhysicalMaterial({color:t.color,map:t.map??null,vertexColors:t.vertexColors,side:t.side,roughness:"mirror"===e.kind?.16:.28,metalness:"mirror"===e.kind?.94:.04,clearcoat:.5,clearcoatRoughness:.2,polygonOffset:t.polygonOffset,polygonOffsetFactor:t.polygonOffsetFactor,polygonOffsetUnits:t.polygonOffsetUnits,depthWrite:t.depthWrite})).onBeforeCompile=t.onBeforeCompile,i.customProgramCacheKey=()=>t.customProgramCacheKey(),h.set(t,i)),i};t.material=Array.isArray(t.material)?t.material.map(i):i(t.material)});let d=new L.Mesh(new L.BoxGeometry(a.x*s,a.y*s,a.z*s),new L.MeshBasicMaterial({visible:!1}));return d.userData.spaceId=e.id,l.add(d),this.scene.add(l),{root:l,model:t,proxy:d,data:e,appliedMoves:"",materials:h,originals:c}}apply(e,t){let i=(t.moves??[]).join(" ");if(i!==e.appliedMoves){for(let i of(e.model.twister.setup(""),t.moves??[]))iW(e.model,i,!0);e.appliedMoves=i}e.data=t,iH(e.model)||(e.root.position.set(t.position[0],0,t.position[1]),e.root.rotation.set(...t.rotation),e.root.scale.setScalar(t.scale),this.settle(e,!1))}settle(e,t=this.snap){var i,a;let r=tz([e.root.position.x,e.root.position.z],t);e.root.position.set(r[0],0,r[1]);let o=rJ(e.model),s=e.data.level??0,n=this.room?.style==="company"?0:(i=r[0],a=r[1],Object.values(tw).some(e=>e.level===s&&Math.abs(i-e.x)<=e.width/2&&Math.abs(a-e.z)<=e.depth/2)?5*s:-.32);for(let e of this.room?.style==="company"||1===s?[]:tT)o.max.x>e.x-e.width/2&&o.min.x<e.x+e.width/2&&o.max.z>e.z-e.depth/2&&o.min.z<e.z+e.depth/2&&(n=Math.max(n,e.height));this.room?.root.updateWorldMatrix(!0,!0);let l=rQ(new L.Raycaster(new L.Vector3(r[0],5*s+1.5,r[1]),new L.Vector3(0,-1,0),0,1.6),this.room?.surfaces??[]);l&&(n=Math.max(n,l.point.y)),e.root.position.y=n-o.min.y,e.root.updateMatrixWorld(!0);let h=rJ(e.model,e.root);e.proxy.geometry.dispose(),e.proxy.geometry=new L.BoxGeometry(...h.getSize(new L.Vector3).toArray()),e.proxy.position.copy(h.getCenter(new L.Vector3))}read(e){let{rotation:t,position:i}=e.root;return{...e.data,position:[i.x,i.z],rotation:[t.x,t.y,t.z]}}sync(e,t,i,a,r){this.turnDrag&&i===this.mode&&t===this.selected&&e.objects.find(e=>e.id===t)?.moves?.join(" ")===this.turnDrag.entry.appliedMoves||this.cancel();let o=e.room??"minimal",s=e.environment??"original";this.currentWeather=e.weather??"sunny",this.riverColor=e.riverColor??"huangpu",this.orbit.maxTargetRadius="shanghai"===s?2e4:"island"===s?500:70,this.orbit.maxDistance="shanghai"===s?24e3:240;let n=this.room?.environment!==s,l=this.room?.style!==o||n;if(n)if(this.cruise(!1),this.retireScene(this.city),this.city=null,this.weatherPatchedCity=null,"shanghai"===s){this.callbacks.cityState("loading");let e=new rZ(this.host.clientWidth<600,()=>{this.callbacks.cruising(e.cruising),this.render()});this.city=e,this.scene.add(e.root)}else this.callbacks.cityState(null);if(l){this.weather.forgetRoom(),this.retireScene(this.room),this.room=new iR(o,[this.transform.getHelper(),this.outline,this.grid,this.drop],this.render,s),this.scene.add(this.room.root);let e=this.room;this.callbacks.roomState?.("loading"),e.ready.then(()=>{this.disposed||this.room!==e||(e.resize(this.host.clientWidth),this.weather.patchSurfaces(e.root),this.callbacks.roomState?.("ready"),this.render())}).catch(t=>{this.disposed||this.room!==e||(console.error("Space room asset failed to load",t),this.callbacks.roomState?.("error"))}),this.room.resize(this.host.clientWidth);let t=this.room.palette;this.scene.background=this.sky&&"cyberpunk"!==o&&"company"!==o?this.sky:new L.Color(t.sky),this.scene.fog=new L.Fog("cyberpunk"===o||"company"===o?t.sky:8552061,120,550),this.scene.backgroundRotation.y=2,this.scene.environmentRotation.y=2*("company"!==o);let i="cyberpunk"===o;this.scene.environment="company"===o?this.environment.texture:(this.outdoorEnvironment??this.environment).texture,this.scene.environmentIntensity=i?.3:"company"===o?.25:.38,this.hemisphere.color.setHex("company"===o?0xf3f3ef:0xcbdfff),this.hemisphere.intensity=i?.06:"company"===o?.16:.1,this.sun.color.setHex(i?9222399:0xffead4),this.sun.intensity=i?.15:2.2,this.sun.position.set(-35,32,42),this.sun.target.position.set(-9,0,-3),this.scene.add(this.sun.target),"company"===o&&(this.sun.intensity=.12),this.fill.intensity=i?.08:.12,this.bloom.strength=i?.18:.04,this.renderer.toneMappingExposure=i?.85:.92,this.floorMaterial.color.setHex(t.ground),this.pedestalMaterial.color.setHex(t.stone),this.pedestalMaterial.metalness="cyberpunk"===o?.65:.2,this.pedestalMaterial.roughness=.22,this.surfaces.forEach((e,t)=>{e.visible="company"!==o&&t>0}),this.view(n?"shanghai"===s?"northBund":"island"===s?"island":"exterior":"company"===o?"interior":this.currentView)}this.weatherMotion=e.weatherMotion??!0;let h=e.weather??"sunny",c=`${o}:${s}:${h}`;c!==this.weatherKey&&(this.weatherKey=c,this.weather.set(h,o,this.room.root,"island"===s,"shanghai"===s));let d=tM(e),u=`${c}:${d}`;if(u!==this.lightingKey){this.lightingKey=u,this.weather.setTime(d);let e=this.weather.daylight;this.scene.background=null;let t=this.weather.lighting(),i="company"===o&&"shanghai"!==s,a="shanghai"===s;this.renderer.toneMappingExposure=a?L.MathUtils.lerp(1.08,.92,e.day):"cyberpunk"===o?.85:.92,this.bloom.strength=a?L.MathUtils.lerp(.18,.06,e.day):"cyberpunk"===o?.18:.04,this.bloom.radius=a?.55:.65,this.bloom.threshold=a?1.2:1.1,this.scene.environment=i?this.environment.texture:this.weather.environment??this.environment.texture,this.scene.environmentIntensity=i?.25:L.MathUtils.lerp(.45,.8,e.day),this.scene.environmentRotation.y=0,this.scene.fog=t.fog,this.sun.intensity=(i?.12:2.2)*t.sun*e.sun,this.sun.color.setHex(0xffb66e).lerp(new L.Color(0xffead4),e.sun),this.hemisphere.color.setHex("shanghai"===s?0xe2e8e6:0xcbdfff),this.hemisphere.intensity=(i?.16:a?L.MathUtils.lerp(.25,.85,e.day**2):L.MathUtils.lerp(.08,.28,e.day))*t.ambient,this.fill.intensity=L.MathUtils.lerp(a?.025:.035,a?.22:.12,a?e.day**2:e.day)*t.ambient,this.positionSun()}for(let[t,i]of(this.city?.setWeather(h,1-this.weather.daylight.day,this.weather.daylight.direction,this.riverColor,d),this.entries))e.objects.some(e=>e.id===t&&e.kind===i.data.kind)||(this.transform.detach(),this.remove(i),this.entries.delete(t));for(let t of e.objects){let e=this.entries.get(t.id);e||(e=this.create(t),this.entries.set(t.id,e)),this.apply(e,t)}this.selected=t,this.mode=i,this.snap=a,this.placing=r,this.drop.visible=!1,this.grid.visible=a,this.transform.setMode("twist"===i?"rotate":i),this.transform.showY="rotate"===i,this.transform.setTranslationSnap(a?.5:null),this.transform.setRotationSnap(a?Math.PI/12:null);let m=t&&this.entries.get(t);!m||r||this.navigating||"twist"===i?this.transform.detach():this.transform.attach(m.root),this.outline.visible=!!m&&!r&&!this.navigating,this.renderer.domElement.style.cursor=r?"crosshair":"grab",l&&(this.city||this.cityCompilation?this.prepareCity(this.city,this.room):(++this.cityPreparation,this.preparingCity=!1)),this.render()}twist(e,t=this.selected?this.entries.get(this.selected):void 0){return!(!t||(t.data.moves?.length??0)>=2e3)&&!!tA(t.data.kind,e)&&!!iW(t.model,e)&&(t.data={...t.data,moves:[...t.data.moves??[],e]},t.appliedMoves=t.data.moves.join(" "),t.turning=!0,this.callbacks.change(this.read(t)),this.render(),!0)}cameraChanged;cameraRoomBounds(){if(this.freeCamera)return null;let e=tw[this.currentView];return e&&this.room?.style!=="company"?new L.Box3(new L.Vector3(e.x-e.width/2+.3,5*e.level+.4,e.z-e.depth/2+.3),new L.Vector3(e.x+e.width/2-.3,e.ceiling-.3,e.z+e.depth/2-.3)):null}zoomLimits(){let e=this.orbit.minDistance,t=this.orbit.maxDistance,i=this.cameraRoomBounds();if(i?.containsPoint(this.orbit.target)){let e=this.camera.position.clone().sub(this.orbit.target).normalize(),a=new L.Ray(this.orbit.target,e).intersectBox(i,new L.Vector3);a&&(t=Math.min(t,a.distanceTo(this.orbit.target)))}return{min:e,max:Math.max(e+.001,t)}}reportZoom(){let{min:e,max:t}=this.zoomLimits(),i=L.MathUtils.clamp(this.orbit.getDistance(),e,t),a=this.navigating?Math.round((90-this.camera.fov)/75*1e3)/10:Math.round(1e3*Math.log(t/i)/Math.log(t/e))/10;a!==this.zoomValue&&(this.zoomValue=a,this.callbacks.zoom(a))}setZoom(e){if(!Number.isFinite(e))return;if(this.flight=null,this.cruise(!1),this.navigating){this.camera.fov=90-.75*L.MathUtils.clamp(e,0,100),this.camera.updateProjectionMatrix(),this.reportZoom(),this.render();return}let{min:t,max:i}=this.zoomLimits(),a=i*(t/i)**(L.MathUtils.clamp(e,0,100)/100),r=this.camera.position.clone().sub(this.orbit.target).setLength(a);this.camera.position.copy(this.orbit.target).add(r),this.orbit.update(),this.reportZoom(),this.render()}positionSun(){this.sun.position.copy(this.sun.target.position).addScaledVector(this.weather.daylight.direction,this.sun.shadow.camera.far>180?6e3:65),this.shadowDirty=!0}view(e){this.cruise(!1),this.setNavigation("orbit"),this.cancel(),this.freeCamera=!1,this.orbit.cursor.set(0,0,0),this.orbit.maxPolarAngle=Math.PI/2-.025,this.currentView=e;let t=["interior","study","bedroom","bathroom","courtyard","garage","cinema","gym","alibabaCourt","alibabaZCourt"].includes(e);this.scene.backgroundIntensity=.12,this.orbit.minDistance=t?.2:4;let i=!!this.city&&Object.hasOwn(rK,e);this.ao.enabled=!i,this.camera.near=i?1:.05;let a=this.host.clientWidth<600;this.camera.fov=t?a?76:this.room?.style==="company"?65:58:a?60:46,this.camera.updateProjectionMatrix();let r=new L.Vector3(-9,3,-2),o=new L.Vector3(...{home:[.72,.85,1],front:[0,.2,1],side:[1,.35,0],top:[0,1,.001]}[e]??[.85,.35,1]).normalize(),s=r.clone().addScaledVector(o,a?76:62);if("exterior"===e&&(s.set(a?75:42,a?36:21,a?97:57),r.set(0,3,4)),"exterior"===e&&(this.room?.style==="penthouse"||this.room?.style==="cyberpunk")&&(r.set(0,-3,4),s.set(a?95:55,a?55:27,a?115:64)),"island"===e&&(s.set(a?162:155,a?90:64,a?168:162),r.set(-6,-2,3)),"shore"===e&&(s.set(32,-1.8,63),r.set(8,-4.8,135)),i){let t=rK[e];s.set(...t.camera),r.set(...t.target),s.y<r.y&&(this.orbit.maxPolarAngle=Math.PI-.025),a&&s.sub(r).multiplyScalar(1.2).add(r)}this.sun.target.position.copy(i?r:new L.Vector3(-9,0,-3));let n=i&&["hsbc","customs","peace","tomsonGarden","commercialBank","alibabaAll","alibabaX","alibaba","alibabaCourt","alibabaZ","alibabaZCourt"].includes(e),l=i?"commercialBank"===e?60:"alibabaAll"===e?360:n?160:2300:42;Object.assign(this.sun.shadow.camera,{left:-l,right:l,top:l,bottom:-l,near:.5,far:i?11e3:180}),this.sun.shadow.normalBias=i?"commercialBank"===e?.015:n?.06:1:.025,this.sun.shadow.bias=n?-8e-6:-2e-4,this.sun.shadow.camera.updateProjectionMatrix(),this.shadowDirty=!0,this.positionSun();let h=iE.default[this.room?.style==="company"?"company":"villa"];h[e]&&(s.set(...h[e][0]),r.set(...h[e][1]));let c=this.room?.style==="company"?{interior:[[-23,2.65,2],[-23,0,1.5]],study:[[-13,3.15,2],[-13,0,-1]],courtyard:[[-17,3.2,11],[-17,0,9]]}:{interior:[[-7,6.8,-3],[-4,0,-6]],study:[[-24,4.4,2],[-25,0,0]],bedroom:[[-23,8.8,2],[-24,5,0]],bathroom:[[-24,9,-10],[-24,5,-11]],garage:[[21,3.8,-10],[21,0,-10]],gym:[[21,3.8,18],[21,0,20]]};this.interiorLight.intensity=c[e]?this.room?.style==="company"?22:this.room?.style==="cyberpunk"?35:100:0,this.interiorLight.penumbra="garage"===e?.25:1,this.interiorLight.color.setHex(this.room?.style==="company"?0xf1f4ef:this.room?.style==="cyberpunk"?6011391:0xffe2bb),c[e]&&(this.interiorLight.position.set(...c[e][0]),this.interiorLight.target.position.set(...c[e][1])),this.fly(s,r)}fly(e,t){!this.room||window.matchMedia("(prefers-reduced-motion: reduce)").matches?(this.flight=null,this.camera.position.copy(e),this.orbit.target.copy(t),this.orbit.update()):this.flight={start:performance.now(),from:this.camera.position.clone(),to:e,fromTarget:this.orbit.target.clone(),target:t},this.render()}focus(){this.cruise(!1),this.ao.enabled=!0,this.camera.near=.05,this.camera.updateProjectionMatrix(),this.setNavigation("orbit");let e=this.selected&&this.entries.get(this.selected);if(!e)return;this.currentView="home",this.orbit.minDistance=.15;let t=this.camera.position.clone().sub(this.orbit.target).normalize();this.fly(e.root.position.clone().addScaledVector(t,Math.max(.3,5*e.data.scale)),e.root.position.clone())}cast(e){let t=this.renderer.domElement.getBoundingClientRect();this.pointer.set((e.clientX-t.left)/t.width*2-1,-(e.clientY-t.top)/t.height*2+1),this.ray.setFromCamera(this.pointer,this.camera)}setNavigation(e){if(!["orbit","walk","drone"].includes(e)||e===this.navigation)return;let t="orbit"!==e;if(!t||this.room){if(this.cancel(),"walk"===e&&(this.freeCamera||!["interior","study","bedroom","bathroom","courtyard","garage","cinema","gym"].includes(this.currentView))&&this.view("interior"),"walk"===e&&this.flight&&(this.camera.position.copy(this.flight.to),this.orbit.target.copy(this.flight.target),this.camera.lookAt(this.orbit.target),this.flight=null),"walk"===e){let e=this.camera.position,t=tC(e.x,e.z,5*(e.y>5),this.room.style);if(null===t)return;let i=t+1.65-e.y;e.y+=i,this.orbit.target.y+=i}"drone"===e&&(this.flight=null,this.freeCamera=!0,this.orbit.maxPolarAngle=Math.PI-.025),t?(this.transform.detach(),this.outline.visible=!1,this.renderer.domElement.focus({preventScroll:!0})):this.freeCamera&&this.orbit.cursor.copy(this.orbit.target),this.navigation=e,this.orbit.enabled=this.transform.enabled=!t,this.callbacks.navigation(e),this.reportAltitude(),this.reportZoom(),this.render()}}navigationInput(e,t,i=e){if(!t){this.walkKeys.delete(i),this.walkKeys.size||(this.walkTime=0);return}this.navigating&&["forward","back","left","right",..."drone"===this.navigation?["up","down","look-up","look-down","look-left","look-right"]:[]].includes(e)&&(this.flight=null,this.cruise(!1),this.walkKeys.set(i,e),this.render())}setDroneSpeed(e){Number.isFinite(e)&&(this.droneSpeed=L.MathUtils.clamp(e,.1,2e3))}look(e,t){if(!e&&!t)return;let i=new L.Euler().setFromQuaternion(this.camera.quaternion,"YXZ");i.y+=e,i.x=L.MathUtils.clamp(i.x+t,-1.3,1.3);let a=this.orbit.getDistance();this.camera.quaternion.setFromEuler(i),this.orbit.target.copy(this.camera.position).addScaledVector(this.camera.getWorldDirection(new L.Vector3),a)}setDroneHeight(e){if("drone"!==this.navigation||!Number.isFinite(e))return;let t=L.MathUtils.clamp(e,this.droneMinHeight,6e3)-this.camera.position.y;this.camera.position.y+=t,this.orbit.target.y+=t,this.reportAltitude(),this.render()}reportAltitude(){if("drone"!==this.navigation)return;let e=Math.round(this.camera.position.y);e!==this.altitude&&(this.altitude=e,this.callbacks.altitude(e))}placementHit(){let e=rQ(this.ray,[...this.surfaces,...this.room?.surfaces??[]]);if(!e)return;let t=new L.Vector3;if(!this.room?.obstacles.some(i=>this.ray.ray.intersectBox(new L.Box3(new L.Vector3(i.minX,i.minY,i.minZ),new L.Vector3(i.maxX,i.maxY,i.maxZ)),t)&&t.distanceTo(this.ray.ray.origin)<e.distance-.025))return e}down;move;up;cancel;cruise(e){this.city?.route&&e!==this.city.cruising&&(e&&(this.view("northBund"),this.flight=null,this.currentView="huangpu",this.ao.enabled=!1,this.camera.near=1,this.camera.fov=58,this.camera.updateProjectionMatrix(),this.city.distance>=this.city.route.getLength()-1&&(this.city.distance=0),this.transform.detach(),this.outline.visible=!1),this.city.cruising=e,this.callbacks.cruising(e),this.render())}remove(e){this.scene.remove(e.root),e.originals.forEach((e,t)=>{t.material=e}),e.materials.forEach(e=>e.dispose()),e.model.dispose(),e.proxy.geometry.dispose(),e.proxy.material.dispose()}dispose(){this.disposed=!0,this.flight=null,this.cancel(),this.events.abort(),this.observer.disconnect(),this.themeObserver.disconnect(),this.media.removeEventListener("change",this.theme),this.transform.dispose(),this.orbit.dispose(),clearTimeout(this.weatherTimer),cancelAnimationFrame(this.frame),cancelAnimationFrame(this.themeFrame),this.renderer.domElement.remove(),this.afterCityCompilation(()=>this.disposeRenderer())}disposeRenderer(){for(let e of this.entries.values())this.remove(e);for(let e of this.surfaces)e.geometry.dispose();this.scene.traverse(e=>{e instanceof L.DirectionalLight&&e.shadow.dispose()}),this.floorMaterial.dispose(),this.pedestalMaterial.dispose(),this.room?.dispose(),this.city?.dispose(),this.weather.dispose(),this.environment.dispose(),this.interiorLight.shadow.dispose(),this.outdoorEnvironment?.dispose(),this.sky?.dispose(),this.drop.geometry.dispose(),this.drop.material.dispose(),this.outline.dispose(),this.grid.dispose(),this.composer.passes.forEach(e=>e.dispose()),this.composer.dispose(),this.renderer.dispose()}}var r1=e.i(887553),r2=e.i(783574);let r9=r1.default.filter(e=>"space"in e&&e.space),r3=[{move:"forward",look:"look-up",key:"W",arrow:"↑",icon:l.ArrowUp,label:{zh:"向前",en:"Move forward"},lookLabel:{zh:"镜头上仰",en:"Tilt camera up"}},{move:"left",look:"look-left",key:"A",arrow:"←",icon:s.ArrowLeft,label:{zh:"向左",en:"Move left"},lookLabel:{zh:"镜头左转",en:"Turn camera left"}},{move:"back",look:"look-down",key:"S",arrow:"↓",icon:a.ArrowDown,label:{zh:"向后",en:"Move backward"},lookLabel:{zh:"镜头下俯",en:"Tilt camera down"}},{move:"right",look:"look-right",key:"D",arrow:"→",icon:n.ArrowRight,label:{zh:"向右",en:"Move right"},lookLabel:{zh:"镜头右转",en:"Turn camera right"}}];e.s(["default",0,function(){var e;let a=(0,i.useRef)(null),r=(0,i.useRef)(null),s=(0,i.useRef)(null),n=(0,i.useRef)(null),[l,L]=(0,i.useState)({past:[],current:tS,future:[]}),[R,E]=(0,i.useState)(null),[F,I]=(0,i.useState)("333"),[U,N]=(0,i.useState)(!1),[B,V]=(0,i.useState)("translate"),[O,G]=(0,i.useState)(!1),[j,H]=(0,i.useState)(!1),[W,q]=(0,i.useState)(!1),[X,K]=(0,i.useState)(!1),[Y,Z]=(0,i.useState)("orbit"),[$,Q]=(0,i.useState)(0),[J,ee]=(0,i.useState)(500),et="orbit"!==Y,[ei,ea]=(0,i.useState)(50),[er,eo]=(0,i.useState)(null),[es,en]=(0,i.useState)("loading"),[el,eh]=(0,i.useState)(!1),[ec,ed]=(0,i.useState)("saved"),[eu,em]=(0,i.useState)(null),[ep,ef]=(0,i.useState)(!1),eg=l.current.objects,ev=l.current.room??"minimal",eb=l.current.environment??"original",ew=l.current.weather??"sunny",ey=l.current.riverColor??"huangpu",ex=eg.find(e=>e.id===R);function eM(e){ee(e),r.current?.setDroneSpeed(e)}function eS(e){L(t=>tD(t,{...t.current,objects:t.current.objects.map(t=>t.id===e.id?e:t)}))}function eT(){r.current?.setNavigation("orbit"),r.current?.cancel(),n.current=null,N(!1)}function eC(){ex&&(L(e=>tD(e,{...e.current,objects:e.current.objects.filter(e=>e.id!==ex.id)})),E(null))}function eP(e){eT(),L(t=>(function(e,t){if("undo"===t){let t=e.past.at(-1);return t?{past:e.past.slice(0,-1),current:t,future:[e.current,...e.future]}:e}let i=e.future[0];return i?{past:[...e.past,e.current],current:i,future:e.future.slice(1)}:e})(t,e))}function eA(){let e=URL.createObjectURL(new Blob([JSON.stringify(l.current,null,2)],{type:"application/json"})),t=document.createElement("a");t.href=e,t.download="cuberoot-space.json",t.click(),setTimeout(()=>URL.revokeObjectURL(e),1e3)}async function ek(e){if(e){try{if(e.size>128e3)throw Error("size");let t=tk(await e.text());eT(),L(e=>tD(e,t)),E(null),em(null)}catch(e){em(e instanceof Error&&"timeOfDay"===e.message?"time":"import")}s.current&&(s.current.value="")}}(0,i.useEffect)(()=>{try{let e=localStorage.getItem(tm);e&&L({past:[],current:tk(e),future:[]})}catch{ed("blocked")}K(!0)},[]),(0,i.useEffect)(()=>{X&&"blocked"!==ec&&ed((0,z.persistItem)(tm,JSON.stringify(l.current))?"saved":"failed")},[l.current,X,ec]),(0,i.useEffect)(()=>{let e;if(X&&a.current){try{r.current=e=new r0(a.current,{select:E,change:eS,place:(e,t,i)=>{let a=n.current;if(!a)return;let r={id:crypto.randomUUID(),kind:a,position:e,level:t,rotation:[0,0,0],scale:i};L(e=>e.current.objects.length>=64?e:tD(e,{...e.current,objects:[...e.current.objects,r]})),E(r.id),n.current=null,N(!1)},unavailable:()=>ef(!0),navigation:Z,altitude:Q,weatherError:()=>em("weather"),cityState:eo,roomState:en,cruising:eh,zoom:ea})}catch{ef(!0);return}return()=>{r.current=null,e.dispose()}}},[X]),(0,i.useEffect)(()=>{r.current?.sync(l.current,ex?.id??null,B,O,U)},[l.current,ex?.id,B,O,U,X]),(0,i.useEffect)(()=>{function e(e){if(e.defaultPrevented)return;let t=e.target;if(!t.closest('input, textarea, select, [contenteditable="true"], [role="dialog"], [role="menu"], [role="listbox"]')){if("Escape"===e.key)return void eT();if((e.ctrlKey||e.metaKey)&&"z"===e.key.toLowerCase())e.preventDefault(),eP(e.shiftKey?"redo":"undo");else if((e.ctrlKey||e.metaKey)&&"y"===e.key.toLowerCase())e.preventDefault(),eP("redo");else if(t===a.current?.querySelector("canvas")&&(("Delete"===e.key||"Backspace"===e.key)&&(e.preventDefault(),eC()),"f"===e.key.toLowerCase()&&r.current?.focus(),ex&&!r.current?.navigating&&["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].includes(e.key))){e.preventDefault();let t=e.shiftKey?1:.5;eS({...ex,position:tz([ex.position[0]+("ArrowRight"===e.key?t:"ArrowLeft"===e.key?-t:0),ex.position[1]+("ArrowDown"===e.key?t:"ArrowUp"===e.key?-t:0)],O)})}}}return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)});let eD=[{value:"orbit",label:(0,_.tr)({zh:"环绕",en:"Orbit"}),icon:g},{value:"walk",label:(0,_.tr)({zh:"漫游",en:"Walk"}),icon:p},{value:"drone",label:(0,_.tr)({zh:"无人机",en:"Drone"}),icon:m}],ez=eD.find(e=>e.value===Y),e_=ez.icon,eL=[{value:"home",label:(0,_.tr)({zh:"全景",en:"Overview"})},{value:"interior",label:(0,_.tr)({zh:"室内",en:"Interior"})},{value:"exterior",label:(0,_.tr)({zh:"建筑外观",en:"Exterior"})},{value:"front",label:(0,_.tr)({zh:"正面",en:"Front"})},{value:"side",label:(0,_.tr)({zh:"侧面",en:"Side"})},{value:"top",label:(0,_.tr)({zh:"俯视",en:"Top"})}],eR=ex?(0,_.tr)(ty[ex.kind]):"";return(0,t.jsxs)("main",{className:"cube-space",children:[(0,t.jsxs)("header",{className:"space-header",children:[(0,t.jsxs)("div",{className:"space-heading",children:[(0,t.jsx)("h1",{children:(0,_.tr)({zh:"魔方空间",en:"Cube space"})}),(0,t.jsx)(A.CompactSelect,{label:(0,_.tr)(tp[ev]),ariaLabel:(0,_.tr)({zh:"选择房间风格",en:"Choose room style"}),value:ev,valueText:(0,_.tr)(tp[ev]),items:Object.keys(tp).map(e=>({value:e,label:(0,_.tr)(tp[e])})),onChange:e=>{eT(),L(t=>tD(t,{...t.current,timeOfDay:tM(t.current),room:e}))}}),(0,t.jsx)(A.CompactSelect,{label:(0,_.tr)(tf[eb]),ariaLabel:(0,_.tr)({zh:"选择环境",en:"Choose environment"}),value:eb,valueText:(0,_.tr)(tf[eb]),items:Object.keys(tf).map(e=>({value:e,label:(0,_.tr)(tf[e])})),onChange:e=>{eT(),L(t=>tD(t,{...t.current,environment:e}))}}),(0,t.jsx)(A.CompactSelect,{label:(0,t.jsxs)("span",{className:"space-weather-label",children:[(0,t.jsx)(c,{size:16}),(0,_.tr)(tv[ew])]}),ariaLabel:(0,_.tr)({zh:"切换天气",en:"Change weather"}),value:ew,valueText:(0,_.tr)(tv[ew]),items:Object.keys(tv).map(e=>({value:e,label:(0,_.tr)(tv[e])})),onChange:e=>{eT(),L(t=>tD(t,{...t.current,weather:e}))}}),(0,t.jsxs)("label",{className:"space-time",children:[(0,_.tr)({zh:"时间",en:"Time"}),(0,t.jsx)("input",{className:"space-time-input",type:"time","aria-label":(0,_.tr)({zh:"场景时间",en:"Scene time"}),min:"00:00",max:"23:59",step:60,required:!0,value:tM(l.current),onChange:e=>{let t=e.currentTarget.value;tx(t)&&L(e=>tD(e,{...e.current,timeOfDay:t}))}})]}),"shanghai"===eb&&(0,t.jsx)(A.CompactSelect,{label:(0,t.jsxs)(t.Fragment,{children:[(0,_.tr)({zh:"水色",en:"Water"}),": ",(0,_.tr)(tg[ey])]}),ariaLabel:(0,_.tr)({zh:"江水颜色",en:"River color"}),value:ey,valueText:(0,_.tr)(tg[ey]),items:Object.keys(tg).map(e=>({value:e,label:(0,_.tr)(tg[e])})),onChange:e=>L(t=>tD(t,{...t.current,riverColor:e}))}),("sunny"!==ew||"original"!==eb)&&(0,t.jsx)(C.default,{value:l.current.weatherMotion??!0,onChange:e=>L(t=>tD(t,{...t.current,weatherMotion:e})),label:(0,_.tr)({zh:"动态天气",en:"Animate weather"})})]}),(0,t.jsxs)("div",{className:"space-header-actions",children:[(0,t.jsx)(S.default,{href:"/sim",children:(0,_.tr)({zh:"模拟器",en:"Simulator"})}),(0,t.jsx)(T.default,{})]})]}),(0,t.jsxs)("nav",{className:"space-destinations","aria-label":(0,_.tr)({zh:"前往房间",en:"Go to a room"}),children:[("company"===ev?["interior","study","courtyard"]:Object.keys(tb)).map(e=>(0,t.jsx)("button",{className:"space-destination",onClick:()=>{eT(),r.current?.view(e)},children:(0,_.tr)("company"===ev?({interior:{zh:"办公室 406",en:"Office 406"},study:{zh:"公共休息区",en:"Shared lounge"},courtyard:{zh:"电话亭",en:"Phone booths"}})[e]:tb[e])},e)),"island"===eb&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("button",{className:"space-destination",onClick:()=>{eT(),r.current?.view("island")},children:(0,_.tr)({zh:"全岛鸟瞰",en:"Island overview"})}),(0,t.jsx)("button",{className:"space-destination",onClick:()=>{eT(),r.current?.view("shore")},children:(0,_.tr)({zh:"海边观浪",en:"Watch the waves"})})]})]}),"shanghai"===eb&&(0,t.jsxs)("nav",{className:"space-destinations","aria-label":(0,_.tr)({zh:"黄浦江沿岸",en:"Huangpu waterfront"}),children:[Object.keys(rK).map(e=>(0,t.jsx)("button",{className:"space-destination",disabled:"ready"!==er,onClick:()=>{eT(),r.current?.view(e)},children:(0,_.tr)(rK[e])},e)),(0,t.jsx)("button",{className:"space-destination","aria-pressed":el,disabled:"ready"!==er,onClick:()=>r.current?.cruise(!el),children:el?(0,_.tr)({zh:"暂停巡游",en:"Pause cruise"}):(0,_.tr)({zh:"沿江巡游",en:"Cruise the river"})})]}),(0,t.jsxs)("div",{className:"space-workspace",children:[(0,t.jsx)("div",{ref:a,className:"space-canvas",role:"region","aria-label":(0,_.tr)({zh:"三维魔方空间",en:"3D cube space"})}),(0,t.jsxs)("div",{className:"space-top-tools",children:[(0,t.jsxs)("div",{className:"space-row",children:[(0,t.jsx)(P.default,{selectedEvent:F,onSelect:e=>{tP(e)&&I(e)},groups:[{id:"space",label:(0,_.tr)({zh:"选择项目",en:"Choose a puzzle"}),items:Object.entries(ty).map(([e,t])=>({id:e,label:(0,_.tr)(t),iconClass:t.icon}))}]}),(0,t.jsxs)("button",{className:"space-control space-add",disabled:!X||ep||eg.length>=64,onClick:()=>{eT(),n.current=F,N(!0),E(null),em(null)},children:[(0,t.jsx)(v.Plus,{size:16}),(0,_.tr)({zh:"放入空间",en:"Place a cube"})]})]}),(0,t.jsxs)("div",{className:"space-row",children:[(0,t.jsx)("button",{className:"space-control","aria-label":(0,_.tr)({zh:"撤销",en:"Undo"}),title:"Ctrl+Z",disabled:!l.past.length,onClick:()=>eP("undo"),children:(0,t.jsx)(M.Undo2,{size:18})}),(0,t.jsx)("button",{className:"space-control","aria-label":(0,_.tr)({zh:"重做",en:"Redo"}),title:"Ctrl+Shift+Z",disabled:!l.future.length,onClick:()=>eP("redo"),children:(0,t.jsx)(b,{size:18})}),(0,t.jsx)("button",{className:"space-control","aria-label":(0,_.tr)({zh:"导入布局",en:"Import layout"}),onClick:()=>s.current?.click(),children:(0,t.jsx)(h,{size:18})}),(0,t.jsx)("button",{className:"space-control","aria-label":(0,_.tr)({zh:"导出布局",en:"Export layout"}),onClick:eA,children:(0,t.jsx)(o,{size:18})}),(0,t.jsx)("input",{ref:s,type:"file",accept:".json,application/json",hidden:!0,onChange:e=>void ek(e.target.files?.[0])})]})]}),(0,t.jsxs)("aside",{className:"space-inspector","aria-label":(0,_.tr)({zh:"摆放工具",en:"Placement tools"}),children:[(0,t.jsx)(A.CompactSelect,{label:eR||(0,_.tr)({zh:"选择物件",en:"Select object"}),ariaLabel:(0,_.tr)({zh:"空间中的魔方",en:"Cubes in the space"}),value:ex?.id??"",valueText:eR||(0,_.tr)({zh:"选择物件",en:"Select object"}),items:eg.map((e,t)=>({value:e.id,label:`${(0,_.tr)(ty[e.kind])} ${t+1}`})),onChange:e=>{eT(),E(e)}}),ex?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:"space-modes space-row",children:[(0,t.jsxs)("button",{className:"space-control","aria-pressed":"translate"===B,onClick:()=>V("translate"),children:[(0,t.jsx)(g,{size:16}),(0,_.tr)({zh:"移动",en:"Move"})]}),(0,t.jsxs)("button",{className:"space-control","aria-pressed":"rotate"===B,onClick:()=>V("rotate"),children:[(0,t.jsx)(y.RotateCw,{size:16}),(0,_.tr)({zh:"摆放旋转",en:"Rotate object"})]}),(0,t.jsxs)("button",{className:"space-control","aria-pressed":"twist"===B,onClick:()=>{V("twist"),r.current?.focus()},children:[(0,t.jsx)(w.RotateCcw,{size:16}),(0,_.tr)({zh:"拧魔方",en:"Twist puzzle"})]})]}),"twist"===B?(0,t.jsxs)("div",{className:"space-turns space-row",children:["sq1"!==ex.kind&&(0,t.jsx)("button",{className:"space-control","aria-pressed":j,onClick:()=>H(e=>!e),children:(0,_.tr)({zh:"逆时针",en:"Inverse"})}),("sq1"===(e=ex.kind)?["(1,0)","(-1,0)","(0,1)","(0,-1)","/"]:"pyram"===e?["U","L","R","B","u","l","r","b"]:"skewb"===e?["R","U","L","B","F","D","UL","UR"]:"minx"===e?["U","R","F","L","BL","BR","BF","D","C","A","I","E"]:["R","U","F","L","D","B"]).map(e=>(0,t.jsxs)("button",{className:"space-control",onClick:()=>q(!r.current?.twist(e+(j&&"sq1"!==ex.kind?"'":""))),children:[e,j&&"sq1"!==ex.kind?"'":""]},e)),(0,t.jsx)("button",{className:"space-control",onClick:()=>{eS({...ex,moves:[]}),q(!1)},children:(0,_.tr)({zh:"还原魔方",en:"Reset puzzle"})}),W&&(0,t.jsx)("span",{role:"status",children:(0,_.tr)({zh:"请等当前转动结束；Square-1 切缝对齐后才能斜切。",en:"Wait for the turn to finish. Square-1 slices require aligned cuts."})})]}):null,(0,t.jsx)(A.CompactSelect,{label:`${Math.round(100*ex.scale)}%`,ariaLabel:(0,_.tr)({zh:"魔方大小",en:"Cube size"}),value:ex.scale,valueText:`${Math.round(100*ex.scale)}%`,items:[.04,.06,.1,.2,.4,.6,.85,1,1.15,1.5,2,2.5].map(e=>({value:e,label:`${Math.round(100*e)}%`})),onChange:e=>eS({...ex,scale:e})}),(0,t.jsxs)("div",{className:"space-row",children:[(0,t.jsx)("button",{className:"space-control","aria-label":(0,_.tr)({zh:"向左旋转 15°",en:"Rotate left 15°"}),onClick:()=>eS({...ex,rotation:[ex.rotation[0],(ex.rotation[1]-Math.PI/12)%(2*Math.PI),ex.rotation[2]]}),children:(0,t.jsx)(w.RotateCcw,{size:17})}),(0,t.jsx)("button",{className:"space-control","aria-label":(0,_.tr)({zh:"向右旋转 15°",en:"Rotate right 15°"}),onClick:()=>eS({...ex,rotation:[ex.rotation[0],(ex.rotation[1]+Math.PI/12)%(2*Math.PI),ex.rotation[2]]}),children:(0,t.jsx)(y.RotateCw,{size:17})}),(0,t.jsx)("button",{className:"space-control","aria-label":(0,_.tr)({zh:"聚焦魔方",en:"Focus cube"}),onClick:()=>r.current?.focus(),children:(0,t.jsx)(u,{size:17})})]}),(0,t.jsxs)("div",{className:"space-row",children:[(0,t.jsxs)("button",{className:"space-control",onClick:function(){if(!ex)return;if(eg.length>=64)return void em("limit");let e={...ex,id:crypto.randomUUID(),position:tz([ex.position[0]+2,ex.position[1]+1],O)};L(t=>tD(t,{...t.current,objects:[...t.current.objects,e]})),E(e.id)},disabled:eg.length>=64,children:[(0,t.jsx)(d.Copy,{size:16}),(0,_.tr)({zh:"复制",en:"Duplicate"})]}),(0,t.jsxs)("button",{className:"space-control",onClick:eC,children:[(0,t.jsx)(x.Trash2,{size:16}),(0,_.tr)({zh:"删除",en:"Delete"})]})]})]}):null,(0,t.jsx)(C.default,{value:O,onChange:G,label:(0,_.tr)({zh:"网格吸附",en:"Snap to grid"})})]}),(0,t.jsxs)("div",{className:"space-view-tools space-row",children:[(0,t.jsxs)("label",{className:"space-zoom",children:[(0,_.tr)({zh:"缩放",en:"Zoom"}),(0,t.jsx)("span",{"aria-hidden":"true",children:"−"}),(0,t.jsx)("input",{className:"space-zoom-input",type:"range",min:0,max:100,step:.1,value:ei,disabled:!X||ep,"aria-label":(0,_.tr)({zh:"画面缩放",en:"Scene zoom"}),title:(0,_.tr)({zh:"也可将鼠标移到画面上，滚动滚轮缩放",en:"You can also scroll over the scene to zoom"}),onChange:e=>r.current?.setZoom(Number(e.currentTarget.value))}),(0,t.jsx)("span",{"aria-hidden":"true",children:"+"})]}),(0,t.jsx)(A.CompactSelect,{label:(0,t.jsxs)("span",{className:"space-weather-label",children:[(0,t.jsx)(e_,{size:17}),ez.label]}),ariaLabel:(0,_.tr)({zh:"镜头控制模式",en:"Camera controls"}),value:Y,items:eD.map(e=>({...e,disabled:!X||ep})),onChange:e=>{"orbit"!==e&&(n.current=null,N(!1),E(null)),r.current?.setDroneSpeed(J),r.current?.setNavigation(e)}}),(0,t.jsx)(A.CompactSelect,{label:(0,_.tr)({zh:"视角",en:"View"}),ariaLabel:(0,_.tr)({zh:"切换视角",en:"Change view"}),items:eL,onChange:e=>r.current?.view(e)}),(0,t.jsx)("button",{className:"space-control","aria-label":(0,_.tr)({zh:"回到全景",en:"Reset view"}),onClick:()=>r.current?.view("shanghai"===eb?"huangpu":"home"),children:(0,t.jsx)(f,{size:17})})]}),et&&!ep&&(0,t.jsxs)("div",{className:"space-navigation","aria-label":(0,_.tr)({zh:"镜头操作",en:"Camera navigation"}),children:["drone"===Y&&(0,t.jsxs)("div",{className:"space-flight-settings space-row",children:[(0,t.jsxs)("label",{className:"space-altitude",children:[(0,_.tr)({zh:"高度",en:"Height"}),(0,t.jsx)(D,{className:"space-flight-input",value:$,min:r.current?.droneMinHeight??1,max:6e3,step:1,"aria-label":(0,_.tr)({zh:"无人机高度（米）",en:"Drone height in metres"}),title:(0,_.tr)({zh:"相对场景基准面，输入后按回车确认",en:"Relative to the scene datum. Press Enter to apply."}),onFocus:()=>r.current?.cancel(),onCommit:e=>r.current?.setDroneHeight(e)}),(0,t.jsx)("span",{children:"m"})]}),(0,t.jsxs)("div",{className:"space-flight-speed",children:[(0,t.jsx)(D,{className:"space-flight-input",value:J,min:.1,max:2e3,allowDecimal:!0,step:"any",inputMode:"decimal","aria-label":(0,_.tr)({zh:"飞行速度（米/秒）",en:"Flight speed in metres per second"}),title:(0,_.tr)({zh:"自定义速度 0.1–2000 m/s，按回车确认",en:"Custom speed 0.1–2000 m/s. Press Enter to apply."}),onFocus:()=>r.current?.cancel(),onCommit:eM}),(0,t.jsx)(A.CompactSelect,{variant:"plain",label:"m/s",value:J,valueText:`${J} m/s`,ariaLabel:(0,_.tr)({zh:"快捷飞行速度",en:"Preset flight speed"}),items:r$.map(e=>({value:e,label:`${e} m/s`})),onChange:eM})]})]}),(0,t.jsx)("div",{className:"space-direction-pad","data-navigation":Y,children:[...r3.map(e=>({id:"drone"===Y?e.look:e.move,icon:e.icon,label:"drone"===Y?e.lookLabel:e.label,shortcut:"drone"===Y?e.arrow:`${e.key} / ${e.arrow}`})),..."drone"===Y?[{id:"up",icon:h,label:{zh:"上升",en:"Ascend"},shortcut:"R / E"},{id:"down",icon:o,label:{zh:"下降",en:"Descend"},shortcut:"F / Q"},...r3.map(e=>({id:e.move,icon:null,label:e.label,shortcut:e.key}))]:[]].map(({id:e,icon:i,label:a,shortcut:o})=>(0,t.jsxs)("button",{className:"space-control space-direction","data-direction":e,"aria-label":(0,_.tr)(a),title:`${(0,_.tr)(a)} (${o})`,onPointerDown:t=>{t.preventDefault(),t.currentTarget.setPointerCapture(t.pointerId),r.current?.navigationInput(e,!0,`pointer:${t.pointerId}`)},onPointerUp:t=>r.current?.navigationInput(e,!1,`pointer:${t.pointerId}`),onPointerCancel:t=>r.current?.navigationInput(e,!1,`pointer:${t.pointerId}`),onLostPointerCapture:t=>r.current?.navigationInput(e,!1,`pointer:${t.pointerId}`),onKeyDown:t=>{(" "===t.key||"Enter"===t.key)&&(t.preventDefault(),r.current?.navigationInput(e,!0,`button:${e}`))},onKeyUp:()=>r.current?.navigationInput(e,!1,`button:${e}`),onBlur:()=>r.current?.navigationInput(e,!1,`button:${e}`),children:[i?(0,t.jsx)(i,{size:18}):o,("up"===e||"down"===e)&&(0,t.jsx)("span",{children:(0,_.tr)(a)})]},e))})]}),U&&(0,t.jsxs)("div",{className:"space-placement",role:"status",children:[(0,t.jsx)("span",{children:(0,_.tr)({zh:"点击地面、展台或桌面；桌上自动使用手持大小",en:"Click a floor, plinth or tabletop. Tables use a handheld cube size."})}),(0,t.jsx)(k.ClearButton,{variant:"standalone",onClick:eT,ariaLabel:(0,_.tr)({zh:"取消摆放",en:"Cancel placement"})})]}),ep&&(0,t.jsxs)("div",{className:"space-unavailable",role:"alert",children:[(0,t.jsx)("p",{children:(0,_.tr)({zh:"3D 画面暂时不可用，请开启浏览器硬件加速后刷新。已有布局仍可导出。",en:"The 3D view is unavailable. Enable browser hardware acceleration and reload. You can still export your layout."})}),(0,t.jsxs)("button",{className:"space-control",onClick:eA,children:[(0,t.jsx)(o,{size:16}),(0,_.tr)({zh:"导出布局",en:"Export layout"})]})]})]}),(0,t.jsxs)("footer",{className:"space-footer",children:["ready"!==es&&(0,t.jsx)("span",{role:"status",children:"loading"===es?(0,t.jsx)(r2.LoadingIndicator,{children:(0,_.tr)({zh:"正在载入房间模型…",en:"Loading the room model…"})}):(0,_.tr)({zh:"房间模型加载失败，请切换风格后重试。",en:"Room model failed to load. Switch styles to retry."})}),"shanghai"===eb&&(0,t.jsxs)("span",{role:"status",children:["loading"===er?(0,t.jsx)(r2.LoadingIndicator,{children:(0,_.tr)({zh:"正在载入黄浦江两岸…",en:"Loading both banks of the Huangpu…"})}):"error"===er?(0,_.tr)({zh:"上海场景加载失败，请切换环境后重试。",en:"Shanghai failed to load. Switch environments to retry."}):(0,_.tr)({zh:"部分建筑和桥梁已单独重建，仍有估算尺寸；其余多为简化底模。",en:"Selected buildings and bridges have individual reconstructions with estimated dimensions; much of the city remains simplified."})," ",(0,t.jsx)("a",{href:"https://www.openstreetmap.org/copyright",target:"_blank",rel:"noreferrer",children:"© OpenStreetMap contributors"})]}),(0,t.jsx)("span",{id:"space-instructions",children:"drone"===Y?(0,_.tr)({zh:"键盘与屏幕箭头均原地转镜头：↑ ↓ 俯仰，← → 转向；WASD 平移，R / E 上升、F / Q 下降。屏幕按钮可长按，拖动画面环顾、滚轮缩放。点击速度数字自定义，Esc 退出无人机。",en:"Keyboard and onscreen arrows look in place: ↑ ↓ tilt, ← → turn. WASD moves; R / E ascends, F / Q descends. Hold onscreen buttons, drag to look, scroll to zoom. Click the speed to customize; Esc exits Drone."}):"walk"===Y?(0,_.tr)({zh:"WASD、方向键或按住箭头行走；拖动画面环顾、滚轮缩放，Esc 退出漫游。",en:"Walk with WASD, arrow keys or hold the arrows. Drag to look, scroll to zoom; Esc exits walking."}):"twist"===B?(0,_.tr)({zh:"拖动魔方表面转层，也可点击转动按钮；拖动空白处环绕，双指或滚轮缩放。",en:"Drag a puzzle face or use the move buttons to turn a layer. Drag empty space to orbit; pinch or scroll to zoom."}):(0,_.tr)({zh:"选中后拖动魔方；拖动空白处环绕，双指或滚轮缩放。方向键也可移动。",en:"Select, then drag a cube. Drag empty space to orbit; pinch or scroll to zoom. Arrow keys move the selected cube."})}),"rainbow"===ew&&(0,t.jsx)("span",{children:(0,_.tr)({zh:"彩虹出现在太阳的相反方向，清晨或傍晚更容易看到；夜间不显示。",en:"Look away from the sun for the rainbow, best seen in the morning or late afternoon. It is hidden at night."})}),(0,t.jsx)("span",{role:"status",children:"saved"===ec?(0,_.tr)({zh:"布局已保存在此浏览器",en:"Layout saved in this browser"}):"blocked"===ec?(0,_.tr)({zh:"原有存档未覆盖；请导出当前布局保存",en:"Existing save preserved; export to save this layout"}):(0,_.tr)({zh:"自动保存失败，请导出布局",en:"Autosave failed; export your layout"})})]}),(0,t.jsxs)("details",{className:"space-sources",open:!0,children:[(0,t.jsx)("summary",{children:(0,_.tr)({zh:"本页来源与建模说明",en:"Sources and modeling notes"})}),(0,t.jsx)("ul",{children:r9.map(e=>(0,t.jsxs)("li",{children:[(0,t.jsx)("a",{href:e.url,target:"_blank",rel:"noopener noreferrer",children:e.name}),(0,t.jsx)("span",{children:(0,_.tr)(e)})]},e.url))}),(0,t.jsx)(S.default,{href:"/about",prefetch:!1,children:(0,_.tr)({zh:"查看全站致谢",en:"All site credits"})})]}),eu&&(0,t.jsxs)("p",{className:"space-message",role:"alert",children:["weather"===eu?(0,_.tr)({zh:"天气加载失败，请刷新重试。已保存的空间布局仍然保留。",en:"Weather failed to load. Refresh to retry. Your saved layout is preserved."}):"time"===eu?(0,_.tr)({zh:"无法导入：时间必须为 00:00 至 23:59，格式为 HH:mm。当前布局未更改。",en:"Import failed. Time must be HH:mm from 00:00 to 23:59. Your layout has not changed."}):"import"===eu?(0,_.tr)({zh:"无法导入：请使用有效的魔方空间 JSON，最多 64 个物件。当前布局未更改。",en:"Import failed. Use a valid Cube space JSON with up to 64 objects. Your layout has not changed."}):(0,_.tr)({zh:"空间最多容纳 64 个魔方。",en:"The space holds up to 64 cubes."}),(0,t.jsx)(k.ClearButton,{variant:"standalone",onClick:()=>em(null),ariaLabel:(0,_.tr)({zh:"关闭提示",en:"Dismiss message"})})]})]})}],23094)},420171,function(e){e.n(e.i(23094))},692212,(e,t,i)=>{t.exports={villa:{interior:[[-9.3,1.65,-3.4],[-4.8,1.2,-6.5]],study:[[-20,1.75,5],[-25,1.35,-.5]],bedroom:[[-20,6.75,3.8],[-24.3,6.1,-.9]],bathroom:[[-19.9,7,-5.1],[-23.5,6.5,-11.5]],courtyard:[[-13.4,2.1,10],[-13.4,2.5,-5]],garage:[[13.7,1.65,-5.2],[22,.85,-11]],cinema:[[13.8,1.65,7.8],[26,1.4,2.8]],gym:[[13.3,1.65,15.5],[24,1.1,19]]},company:{interior:[[-21.5,1.7,4.9],[-23.3,1.15,.8]],study:[[-8.2,1.65,3.8],[-13.3,1.25,-2.4]],courtyard:[[-14.3,1.7,12],[-16.5,1.15,8.6]]}}},994612,(e,t,i)=>{t.exports=[{building:5,lines:[{text:"华夏银行",xFraction:-.4,y:4.55,z:-.78,height:.55,width:3.2,panel:"bronze"},{text:"华夏银行",xFraction:.4,y:4.55,z:-.78,height:.55,width:3.2,panel:"bronze"}]},{building:6,lines:[{text:"DOLCE&GABBANA",bay:-5,y:3.65,z:.24,height:.2,width:1.8,finish:"ivory",panel:"ink"},{text:"DOLCE&GABBANA",bay:-4,y:3.65,z:.24,height:.2,width:1.8,finish:"ivory",panel:"ink"},{text:"DOLCE&GABBANA",bay:-3,y:3.65,z:.24,height:.2,width:1.8,finish:"ivory",panel:"ink"},{text:"DOLCE&GABBANA",bay:-2,y:3.65,z:.24,height:.2,width:1.8,finish:"ivory",panel:"ink"},{text:"DOLCE&GABBANA",bay:2,y:3.65,z:.24,height:.2,width:1.8,finish:"ivory",panel:"ink"},{text:"DOLCE&GABBANA",bay:3,y:3.65,z:.24,height:.2,width:1.8,finish:"ivory",panel:"ink"},{text:"DOLCE&GABBANA",bay:4,y:3.65,z:.24,height:.2,width:1.8,finish:"ivory",panel:"ink"},{text:"DOLCE&GABBANA",bay:5,y:3.65,z:.24,height:.2,width:1.8,finish:"ivory",panel:"ink"}]},{building:7,lines:[{text:"盘谷银行",y:5.8,z:-1.05,height:.78,width:7.5,panel:"bronze"},{text:"Bangkok Bank",y:5.12,z:-1.06,height:.36,width:6}]},{building:12,lines:[{text:"上海浦东发展银行",y:6.25,z:-1.15,height:.76,width:13,panel:"bronze"}]},{building:14,lines:[{text:"上海市总工会",y:4.75,z:-1,height:.64,width:7.6,panel:"bronze"}]},{building:15,lines:[{text:"中国外汇交易中心",y:17.1,z:-1.91,height:.91,width:18}]},{building:16,lines:[{text:"招商银行",y:17.1,z:-1.92,height:1.16,width:10.5},{text:"CHINA MERCHANTS BANK",y:5.65,z:-.96,height:.43,width:9,panel:"bronze"}]},{building:17,lines:[{text:"AIA",y:33.15,z:-1.22,height:2.7,width:7.8,finish:"red"},{text:"AMERICAN INTERNATIONAL ASSURANCE",y:9.58,z:-1.45,height:.38,width:12.5,panel:"bronze"}]},{building:18,lines:[{text:"Cartier",bay:2,y:4.92,z:.24,height:.31,width:1.5,finish:"ivory",panel:"bronze"},{text:"Cartier",bay:1,y:4.92,z:.24,height:.31,width:1.5,finish:"ivory",panel:"bronze"},{text:"Ermenegildo Zegna",bay:-1,y:4.92,z:.24,height:.22,width:2.2,finish:"ivory",panel:"bronze"},{text:"Ermenegildo Zegna",bay:-2,y:4.92,z:.24,height:.22,width:2.2,finish:"ivory",panel:"bronze"}]},{building:19,lines:[{text:"THE SWATCH ART PEACE HOTEL",y:26.75,z:-.86,height:.58,width:17}]},{building:20,lines:[{text:"PEACE HOTEL",x:-1309.42,y:4.92,z:1366.5,yaw:1.5707963267948966,height:.7,width:9.3,finish:"warm",panel:"bronze"},{text:"和平饭店",x:-1309.4,y:4.04,z:1366.5,yaw:1.5707963267948966,height:.65,width:5,finish:"warm"}],blade:{text:"和平饭店",english:"PEACE HOTEL"}},{building:23,lines:[{text:"中国银行",y:4.65,z:-.9,height:.65,width:5,finish:"ink",panel:"lightbox"},{text:"BANK OF CHINA",y:3.95,z:-.91,height:.28,width:5,finish:"ink",panel:"lightbox"}]},{building:24,lines:[{text:"ICBC  中国工商银行",y:25.15,z:-1.92,height:.92,width:18,finish:"ink"}]},{building:26,lines:[{text:"ABC  中国农业银行",y:17.5,z:-.74,height:.87,width:13,finish:"teal"},{text:"AGRICULTURAL BANK OF CHINA",y:5.2,z:-1.12,height:.39,width:10,panel:"bronze"}]},{building:27,lines:[{text:"THE HOUSE OF ROOSEVELT",bay:1,y:3.45,z:.22,height:.21,width:2.1,panel:"bronze"},{text:"THE HOUSE OF ROOSEVELT",bay:2,y:3.45,z:.22,height:.21,width:2.1,panel:"bronze"},{text:"THE HOUSE OF ROOSEVELT",bay:3,y:3.45,z:.22,height:.21,width:2.1,panel:"bronze"},{text:"ROLEX",bay:-5,y:1.8,z:.25,height:.2,width:.75,finish:"ivory"},{text:"ROLEX",bay:-4,y:1.8,z:.25,height:.2,width:.75,finish:"ivory"},{text:"ROLEX",bay:-3,y:1.8,z:.25,height:.2,width:.75,finish:"ivory"},{text:"ROLEX",bay:-2,y:1.8,z:.25,height:.2,width:.75,finish:"ivory"},{text:"ROLEX",bay:-1,y:1.8,z:.25,height:.2,width:.75,finish:"ivory"},{text:"ROLEX",bay:1,y:1.8,z:.25,height:.2,width:.75,finish:"ivory"},{text:"ROLEX",bay:2,y:1.8,z:.25,height:.2,width:.75,finish:"ivory"},{text:"ROLEX",bay:3,y:1.8,z:.25,height:.2,width:.75,finish:"ivory"},{text:"ROLEX",bay:4,y:1.8,z:.25,height:.2,width:.75,finish:"ivory"},{text:"ROLEX",bay:5,y:1.8,z:.25,height:.2,width:.75,finish:"ivory"}]},{building:29,lines:[{text:"中国光大银行",y:16.94,z:-.94,height:.72,width:13.5}]}]},887553,(e,t,i)=>{t.exports=JSON.parse('[{"name":"Roboto Condensed / Google · Fontsource","url":"https://fontsource.org/fonts/roboto-condensed","zh":"复盘 PNG 可选 Roboto Condensed Regular 字体；通过 Fontsource 5.3.0 分发，遵循 SIL OFL 1.1 许可。","en":"Reconstruction PNG exports offer Roboto Condensed Regular, distributed through Fontsource 5.3.0 under SIL OFL 1.1."},{"name":"AI SDK / Vercel","url":"https://github.com/vercel/ai","zh":"助手通过 Apache-2.0 许可的 AI SDK 使用标准模型工具调用及服务端流式响应。","en":"The assistant uses the Apache-2.0 AI SDK for native model tools and server-side streaming."},{"name":"LangChain text splitters","url":"https://github.com/langchain-ai/langchainjs","zh":"公开资料通过 MIT 许可的 LangChain 文本分段器按段落拆分。","en":"Public documents are split into passages with MIT-licensed LangChain text splitters."},{"name":"MiniSearch / Luca Ongaro","url":"https://github.com/lucaong/minisearch","zh":"公开资料使用 MIT 许可的 MiniSearch 提供中文分词后的关键词检索与降级检索。","en":"Public documents use MIT-licensed MiniSearch for tokenized lexical search and retrieval fallback."},{"name":"pgvector","url":"https://github.com/pgvector/pgvector","zh":"公开资料向量检索使用 PostgreSQL 许可的 pgvector 扩展。","en":"Public document vector retrieval uses the PostgreSQL-licensed pgvector extension."},{"name":"WeChat emoji / Tencent · xxk8","url":"https://github.com/xxk8/wechat-emojis","zh":"微信表情图片版权归腾讯；非官方整理来自 xxk8/wechat-emojis。授权尚未确认，素材已移出公开资源和聊天清单，来源与声明仅保留在归档中。","en":"WeChat artwork copyright Tencent; unofficial collection from xxk8/wechat-emojis. Rights remain unconfirmed; assets are withheld from public resources and chat catalogs, with provenance retained in the archive."},{"name":"Emoji Mart / Missive","url":"https://github.com/missive/emoji-mart","zh":"聊天内置 emoji 分类和肤色数据来自 MIT 许可的 @emoji-mart/data；使用设备系统字体显示，未分发 Apple 表情图片。","en":"Built-in chat emoji categories and skin tones use MIT-licensed @emoji-mart/data, rendered with device fonts without distributing Apple emoji artwork."},{"name":"nissy-core H48 / Sebastiano Tronto and Enrico Tenuti","url":"https://github.com/sebastianotronto/nissy-core","zh":"H48 h10 原生整解表使用 nissy-core 源码生成；独立 Rust H0～H11 实验移植其坐标、对称变换和表格式；固定 H10 版本已复用已有表验收，通用版仅经编译和小数据检查，H11 未运行。固定源码及 GPL-3.0-or-later 许可保留在 solver/vendor/nissy-core，组合 Rust H48 程序遵循该许可。","en":"The native H48 h10 whole-cube table is generated with nissy-core. A separate Rust H0–H11 experiment ports its coordinates, symmetry transforms and table format. The fixed H10 build was validated with the existing table; the generic build has compilation and small-data checks only, and H11 has not been run. The pinned GPL-3.0-or-later source remains in solver/vendor/nissy-core, and the combined Rust H48 program uses that license."},{"name":"cubeopt-wasm / Chen Shuang","url":"https://github.com/cs0x7f/cubeopt-wasm","zh":"三阶最优求解使用其 MIT 许可的 cube48opt WASM。独立的 Mac Rust 实验根据固定 opt1–9 编译产物恢复状态、坐标与搜索，原版用于建表和差分验证；实验尚未替换现用引擎。","en":"Optimal 3×3 solving uses its MIT-licensed cube48opt WASM. A separate Mac Rust experiment reconstructs state, coordinates and search from pinned opt1–9 artifacts, retaining the original for table generation and differential validation; it has not replaced the current engine."},{"name":"The Math Flow: Rubik’s Cube ring animation","url":"https://x.com/themathflow/status/2101154346583154801","zh":"魔方与图论页面的圆环布局视觉参考，扇形参考见 GitHub issue #81。位置映射和交互独立实现，未复制第三方源码或将原视频、图片用作运行资源；发布账号不作为原作者归属证明。","en":"Visual reference for the ring layout on the cube graph page; the sector reference is in GitHub issue #81. Coordinate mappings and interactions are independently implemented without copying third-party source or embedding the original media. The posting account is not verified as the original creator."},{"name":"Poly Haven: Tree Small 02 / Rico Cilliers","space":true,"url":"https://polyhaven.com/a/tree_small_02","zh":"阿里巴巴 X/Y/Z 园区植被使用 Rico Cilliers 制作的 CC0 枝叶颜色、镂空轮廓、法线和树皮贴图，贴图随 Blender 工程打包并本地导出。保留已有树位，树种仅作视觉替代，未核实为园区实种；树池覆盖层复用树皮作为覆盖物近似。查阅于 2026-09-12","en":"Alibaba X/Y/Z planting uses Rico Cilliers\' CC0 leaf color, cutout, normal and bark textures, packed into Blender and exported locally. Existing tree positions are retained; the species is a visual proxy, not verified campus planting. Recessed beds reuse bark as approximate mulch. Accessed 2026-09-12"},{"name":"Poly Haven: Concrete Floor 02 / Rob Tuytel","space":true,"url":"https://polyhaven.com/a/concrete_floor_02","zh":"阿里园区铺地与树池使用 Rob Tuytel 制作的 CC0 法线和粗糙度贴图，以约 2 米重复尺度增加表面细节，保留建筑材质原有底色；不是现场石材扫描。查阅于 2026-09-12","en":"Alibaba paving and planters use Rob Tuytel\'s CC0 normal and roughness textures at an approximately 2 m repeat scale, retaining the authored base colors. These are surface proxies, not scans of campus stone. Accessed 2026-09-12"},{"name":"上海徐汇: 西岸艺岛 Art Tower","space":true,"url":"https://m.thepaper.cn/baijiahao_9917546","zh":"上海徐汇于 2020-11-09 发布的西岸艺岛实拍，位于龙耀路 8 号。用于 X 区七栋彼此倾斜的子楼、转折轮廓、绕角水平金属线条和入口场地参考。单栋层数、倾角和构件尺寸仍为照片估算；照片未用作运行贴图。查阅于 2026-09-12","en":"Shanghai Xuhui\'s built photographs of Art Tower at 8 Longyao Road, published 2020-11-09. References X\'s seven differently leaning wings, folded silhouettes, continuous horizontal metal fins and entrance site. Storeys, lean angles and component dimensions remain photo estimates; photographs are not runtime textures. Accessed 2026-09-12"},{"name":"SOM: Alibaba Shanghai Campus design","space":true,"url":"https://www.som.com/news/som-designs-dynamic-user-controlled-headquarters-for-alibabas-shanghai-campus/","zh":"SOM 于 2022-07-25 发布的阿里巴巴上海园区设计，参考 Z 区错层悬挑、玻璃幕墙、露台、开放中庭、连桥和屋顶花园。这是设计效果图依据，未核实为当前竣工状态，也非官方 BIM；模型尺寸及细节有估算。查阅于 2026-09-12","en":"SOM\'s Shanghai campus design published 2022-07-25. References Z\'s staggered cantilevers, glass facades, terraces, open court, bridges and roof gardens. Based on design renderings, not verified present-day as-built conditions or official BIM; model dimensions and details are estimated. Accessed 2026-09-12"},{"name":"SOM / gooood: Alibaba design images and section","space":true,"url":"https://www.gooood.cn/som-designs-headquarters-for-alibabas-shanghai-campus.htm","zh":"2022-07-26 发布、SOM 提供的设计图与剖面，用于 Z 区俯拍轮廓、露台种植、屋顶光伏、悬挑木色底面及中庭 Alibaba 标识。图像仅作本地建模参考，未作为实景照片或运行贴图。查阅于 2026-09-12","en":"Design images and section supplied by SOM, published 2022-07-26. References Z\'s aerial massing, terrace planting, rooftop solar panels, timber-colored soffits and courtyard Alibaba lettering. Images are local modeling references, not built photographs or runtime textures. Accessed 2026-09-12"},{"name":"上海市规划和自然资源局: 阿里巴巴上海徐汇项目","space":true,"url":"https://ghzyj.sh.gov.cn/sj/20221008/f0f0cd851f8c4708835dac11d2dad17c.html","zh":"2022-08-30 的项目建设资料用于核对 Y 区四至和北侧 Z 区的独立地块关系。模型沿用 OSM 场景坐标定位，并只替换对应旧建筑轮廓；未将早期用地资料当作当前施工完成证明。查阅于 2026-09-12","en":"Project update dated 2022-08-30 establishes Y\'s street boundaries and the separate Z parcel to its north. Models retain OSM scene coordinates and replace only matched old footprints. The early planning record is not evidence of present-day construction completion. Accessed 2026-09-12"},{"name":"Foster + Partners: Alibaba Shanghai Campus / Fangfang Tian","space":true,"url":"https://www.archdaily.com/1020980/alibaba-shanghai-campus-foster-plus-partners","zh":"2024-09-10 发布的阿里巴巴徐汇滨江 Y 区竣工资料，摄影 Fangfang Tian。实拍用于 Blender 主楼的阶梯形开口、多层连廊、铝框幕墙、露台绿化、Alibaba 招牌与入口线性灯具。仅作本地建模参考，未将照片用于运行贴图；不是官方 BIM，构件、纹理及照明尺寸仍有估算。查阅于 2026-09-12","en":"Completed Y-campus project published 2024-09-10, photographed by Fangfang Tian. References the Blender building\'s stepped voids, bridges, aluminum curtain wall, planted terraces, Alibaba lettering and entrance strip lights. Photographs are local modeling references, not runtime textures. This is not official BIM; details, textures and lighting dimensions remain estimated. Accessed 2026-09-12"},{"name":"Alizila: Inside Alibaba\'s New Shanghai Campus","space":true,"url":"https://www.alizila.com/podcast/redefining-the-workplace-inside-alibabas-new-shanghai-campus/","zh":"阿里巴巴官方于 2024-12-11 发布的设计师访谈，用于核对 Y 区模块化开间、屋顶与立面开口、室外协作空间；不作为测绘尺寸来源。徐汇园区 X、Y、Z 不同片区分别建模。查阅于 2026-09-12","en":"Alibaba\'s architect interview published 2024-12-11 references Y\'s modular bays, roof and facade openings and outdoor collaboration spaces, without supplying survey dimensions. The X, Y and Z parcels are modeled separately. Accessed 2026-09-12"},{"name":"高层总部办公建筑生态共享空间设计研究","space":true,"url":"https://journals.nassg.org/index.php/edc/article/download/7859/pdf","zh":"魏倩、韩贵红的 2025 年案例研究列出阿里巴巴徐汇滨江 Y 区地上 11 层、约 56 米建筑高度及分层层高，用于模型尺度参考。非竣工测绘；平面定位另据 OSM way/792384120，开间与退台由实拍估算。查阅于 2026-09-12","en":"The 2025 case study by Wei Qian and Han Guihong documents 11 above-ground storeys, approximately 56 m height and floor heights for the Alibaba Xuhui Y campus. Used for scale, not as an as-built survey. Placement follows OSM way/792384120; bays and setbacks are photo estimates. Accessed 2026-09-12"},{"name":"Blender / KhronosGroup glTF-Blender-IO","space":true,"url":"https://github.com/KhronosGroup/glTF-Blender-IO","zh":"魔方空间的住宅、公司、海岛和上海静态场景使用 Blender 5.2.1 编辑，以内置 glTF 插件导入、导出 GLB。首次迁移使用 Three.js GLTFExporter；本站维护场景属性、纹理去重和网页加载脚本，未复制 Blender 插件源码。魔方、天气、水面和交通仍由 Three.js 实时运行。查阅于 2026-09-08","en":"Homes, office, island and Shanghai static scenes are edited in Blender 5.2.1 and imported/exported as GLB through its bundled glTF add-on. The initial migration used Three.js GLTFExporter. CubeRoot maintains scene metadata, texture deduplication and web loading scripts without copying the Blender add-on source. Puzzles, weather, water and traffic still run in Three.js. Accessed 2026-09-08"},{"name":"FFmpeg","url":"https://ffmpeg.org/","zh":"网盘云端视频转码与媒体校验，使用独立部署的 FFmpeg 和 ffprobe","en":"Cloud video transcoding and media verification for Drive, using separately deployed FFmpeg and ffprobe"},{"name":"SVT-AV1","url":"https://gitlab.com/AOMediaCodec/SVT-AV1","zh":"网盘压缩副本使用的开源 AV1 编码器","en":"Open-source AV1 encoder used for compressed Drive copies"},{"name":"Netflix VMAF","url":"https://github.com/Netflix/vmaf","zh":"网盘视频压缩后的感知画质检查","en":"Perceptual quality checks for compressed Drive videos"},{"name":"汇丰大楼照明设计实拍 / HSBC lighting project photographs","space":true,"url":"https://www.elicht.com/view/100309.html","zh":"2019-04-28 发布的 2018 年汇丰大楼照明项目，设计署名 FMS 与十聿照明。已查看夜间实拍及屋顶灯位图，用于区分街边灯杆投光、柱廊阴影和屋顶独立照亮穹顶，并调整石材色彩。本站使用固定数量的 Three.js 投光灯，灯位、强度与尺寸仍为估算，未取得实测配光或现状测绘；照片仅本地对照，未作为运行贴图。查阅于 2026-09-08","en":"Published 2019-04-28 about the 2018 HSBC lighting project, credited to FMS and 十聿照明. Reviewed night photographs and roof luminaire diagrams to distinguish street-pole facade lighting, colonnade shadows and separate dome lighting, and to adjust stone colour. Implemented with a bounded Three.js spotlight pool; positions, intensity and dimensions remain estimates without measured photometry or an as-built survey. Photographs are local references, not runtime textures. Accessed 2026-09-08"},{"name":"上海市政府：外滩亮灯 / Shanghai Government: Bund lighting","space":true,"url":"https://www.shanghai.gov.cn/nw4411/20260820/f441a5da943447e79613ab4d5dbcc0a5.html","zh":"夜景参考：2026-08-20 转载解放日报关于外滩 38 栋建筑、约 2000K 日常暖金照明与分层景观的报道。用于照明色彩和层次，不代表取得现场灯位、配光或测绘；不将夏季开灯时间套用到场景的固定春秋分时钟。查阅于 2026-09-08","en":"Night reference: the 2026-08-20 Jiefang Daily report on 38 Bund buildings, roughly 2000K everyday warm lighting and layered city illumination. Guides colour and hierarchy, without surveyed luminaire positions or photometry; its summer switch-on schedule is not applied to the scene\'s fixed-equinox clock. Accessed 2026-09-08"},{"name":"新华社：上海夜景实拍 / Xinhua: Shanghai night photographs","space":true,"url":"https://www.xinhuanet.com/photo/20251231/f4a640207f67437c86c2d5db1b82644c/c.html","zh":"实拍参考：王翔于 2025-12-31 拍摄的外滩和陆家嘴，用于建筑照明的明暗关系、江岸层次、水面倒影及白色前灯、红色尾灯的街道层次。滨江步道、路灯和长椅沿 OSM 位置近似重建，设施细节未实测。照片包含跨年特别灯光，不将红色活动灯幕作为日常现状；图片仅本地审图，未用作运行贴图。模型与灯光仍含估算。查阅于 2026-09-08","en":"Photo reference: Wang Xiang\'s 2025-12-31 Bund and Lujiazui photographs, used for lighting contrast, riverbank layers, water reflections and white headlights/red taillights at street level. Promenade paving, lamps and benches follow OSM alignment with estimated fixture details. They show special New Year lighting; red event displays are not treated as everyday conditions. Photos were reviewed locally, not distributed as runtime textures. Geometry and lighting remain estimates. Accessed 2026-09-08"},{"name":"文汇报：外滩 15-1 号 / Wenhui: Bund 15-1","space":true,"url":"https://wenhui.whb.cn/third/yidian/201911/15/303082.html","zh":"实拍对照：外滩公共服务中心的五层立面、中央通高玻璃入口及简洁竖向构件。采用 2019 年报道组合图最下方建成照片，不采用上方未建方案；OSM 平面，垂直尺寸估算，未获现状测绘。查阅于 2026-09-07","en":"Photo reference: the five-storey Bund Public Service Center, tall central glazed entrance and restrained vertical members. Uses the bottom completed-building photo in the 2019 report, not the unbuilt proposals above; OSM plan and estimated vertical dimensions, without a current survey. Accessed 2026-09-07"},{"name":"NOAA Global Monitoring Laboratory","space":true,"url":"https://gml.noaa.gov/grad/solcalc/solareqns.PDF","zh":"魔方空间太阳方向的时角与天顶角公式参考；场景采用固定春秋分的太阳时近似，查阅于 2026-09-07","en":"Hour-angle and zenith equations for Cube Space sun direction, using a fixed equinox and local solar time approximation; accessed 2026-09-07"},{"name":"Three.js","space":true,"url":"https://github.com/mrdoob/three.js","zh":"魔方空间的 3D 渲染、物理材质、视角控制、镜面反射、江水及后期处理；外滩立体招牌复用官方 TTFLoader、FontLoader 和 ExtrudeGeometry，使用本地字体子集","en":"3D rendering, physical materials, camera controls, reflections, river water and postprocessing in Cube Space; raised Bund signs reuse official TTFLoader, FontLoader and ExtrudeGeometry with a local font subset","long_en":"Three.js is licensed under the MIT license. Cube Space reuses its renderer, controls, Water shader, Reflector and postprocessing modules. The water normal texture from r183 is bundled locally."},{"name":"和平饭店入口与灯牌实拍 / Peace Hotel entrance and blade sign","space":true,"url":"https://n.sinaimg.cn/sinakd20119/320/w717h403/20220831/51c5-e438a768e27ecac8115bad5575bd3b71.jpg","zh":"新浪图床的 2022 年文章配图，用于和平饭店南侧双面弧顶竖灯牌、中英文并列竖排、入口与临江立面较亮而侧翼较暗的夜间层次。原文章现不可用，实际拍摄日期未确认；比例、字形和灯光为估算，未作为运行贴图。查阅于 2026-09-08","en":"Sina-hosted photo from a 2022 article: curved double-faced blade, adjacent vertical Chinese and English lettering, entrance and brighter riverfront versus dimmer wings at night. The article is unavailable and the capture date is unconfirmed. Dimensions, lettering and lighting are estimated, not a runtime texture. Accessed 2026-09-08"},{"name":"携程：原汇丰大楼实拍 / Ctrip: former HSBC Building","space":true,"url":"https://you.ctrip.com/sight/shanghai2/1831446.html","zh":"游客实拍用于上海浦东发展银行位于底层入口上方的招牌，避免误放到高处柱廊檐口；尺寸和字体未实测，照片未作为运行贴图。查阅于 2026-09-08","en":"Visitor photographs locate the Shanghai Pudong Development Bank sign above the ground-floor entrances, rather than the upper portico cornice. Dimensions and typeface are not surveyed; photos are not runtime textures. Accessed 2026-09-08"},{"name":"文泉驿微米黑 / WenQuanYi Micro Hei","space":true,"url":"https://sourceforge.net/projects/wqy/files/wqy-microhei/","zh":"外滩招牌复用仓库现有字体，经 Three.js TTFLoader 提取 70 个字形，本地托管约 40 KB 轮廓数据。字体内嵌 Apache-2.0 许可和作者信息随子集保留，许可证随资源附带；通用字体不等于实物品牌字体。生成于 2026-09-08","en":"Bund signs subset 70 glyphs from the font already in this repository using Three.js TTFLoader, serving about 40 KB of outlines locally. Embedded Apache-2.0 and author notices are preserved and the license accompanies the asset. This general typeface is not an exact brand font. Generated 2026-09-08"},{"name":"Permasteelisa: Jin Mao Tower curtain wall","space":true,"url":"https://www.permasteelisagroup.com/historic-project/jin-mao-tower/","zh":"幕墙承建方记录金茂大厦 420.5 米、88 层，以及铝制翼片、不锈钢构件和退台铝板。已查看其俯拍、塔冠近景及幕墙细部照片，用于 Blender 工程的分段幕墙、横向栏杆、退台构件和分层翼片塔冠。宽度、层高、构件尺寸与照明仍为照片估算，未取得竣工测绘；照片仅作对照，未作为运行贴图。查阅于 2026-09-08","en":"The facade contractor documents Jin Mao Tower\'s 420.5 m height, 88 storeys, aluminum fins, stainless-steel members and aluminum-clad terraces. Aerial, crown and facade-detail photographs guide the Blender model\'s tiered curtain wall, horizontal rails, setback members and layered crown fins. Widths, floor heights, member dimensions and lighting remain photo estimates without an as-built survey. Photos are references, not runtime textures. Accessed 2026-09-08"},{"name":"Permasteelisa: Jin Mao crown photograph","space":true,"url":"https://www.permasteelisagroup.com/wp-content/uploads/2025/07/Jin-Mao-Tower-Shanghai2.jpg","zh":"塔冠近景用于校正密集退台、V 形金属面、两层翼片、包覆桅杆和圆形灯具外壳。尺寸、分板和灯具数量按照片估算，未取得施工图；照片拍摄日期未知，仅作对照，未作为运行贴图。查阅于 2026-09-13","en":"This crown close-up guides the closely spaced setbacks, V-shaped metal plates, two stages of fins, clad mast and round lamp housings. Dimensions, panel divisions and lamp counts are photo estimates without construction drawings. The capture date is unknown; this is a reference, not a runtime texture. Accessed 2026-09-13"},{"name":"Permasteelisa: Jin Mao facade photograph","space":true,"url":"https://www.permasteelisagroup.com/wp-content/uploads/2025/07/Jin-Mao-Tower-Shanghai3.jpg","zh":"幕墙近景用于金茂的成对铝翼片、层间金属板、三道外置横杆、连接夹板与紧固件。构件截面随各面转向；开间、深度、螺栓尺寸及数量仍为照片估算。拍摄日期未知，照片仅作建模对照，未作为运行贴图。查阅于 2026-09-13","en":"This curtain-wall close-up guides Jin Mao\'s paired aluminum fins, metal spandrels, three external rails, connecting plates and fasteners. Member sections turn with each facade. Bay spacing, projections, bolt dimensions and counts remain photo estimates. The capture date is unknown; the photograph is a modeling reference, not a runtime texture. Accessed 2026-09-13"},{"name":"The Skyscraper Museum: SOM Jin Mao section and plans","space":true,"url":"https://old.skyscraper.org/EXHIBITIONS/CHINA_PROPHECY/jin_mao.php","zh":"博物馆展示 SOM 提供的金茂剖面、平面和施工照片，用于核对分段轮廓与八角形结构关系。公开剖面图只有 300 × 834 像素，无法可靠读取精确尺寸，不能作为竣工测绘；塔身宽度和统一层高仍待校准。查阅于 2026-09-13","en":"The museum presents Jin Mao\'s section, plans and construction photographs courtesy of SOM, informing the tiered silhouette and octagonal structure. The public section image is only 300 by 834 pixels, so precise dimensions cannot be read reliably or treated as an as-built survey. Body widths and the uniform floor-height estimate still need calibration. Accessed 2026-09-13"},{"name":"SOM: Jin Mao Tower","space":true,"url":"https://www.som.com/projects/jin-mao-tower/","zh":"设计事务所的实拍用于金茂长塔身、上部退台、凹槽与塔冠对照。Tim Griffith 日景和文件标注 China Jin Mao Group 的夜景用于银色金属、深色玻璃与竖向亮线；夜景未列单张摄影署名，不代表当前灯光实测。© Nick Merrick | Hedrich Blessing 的入口照片用于裙房百叶、雨棚、石柱和悬挂遮板。拍摄日期未知，照片未作为运行贴图；三座超高层为本站独立几何，尺寸、材质和照明参数仍为估算。查阅于 2026-09-13","en":"The architect\'s photographs guide Jin Mao\'s shaft, setbacks, recesses and crown. Tim Griffith\'s daytime view and a night image whose filename identifies China Jin Mao Group inform metal, glass and vertical lighting; the latter has no individual photographer credit and is not a current lighting survey. Entrance photographs © Nick Merrick | Hedrich Blessing guide podium louvers, canopies, stone columns and suspended shades. Capture dates are unknown. Photos are not runtime textures; the three supertalls use locally authored geometry with estimated dimensions, materials and lighting. Accessed 2026-09-13"},{"name":"SKYDB / Nephilim: Jin Mao base detail","space":true,"url":"https://www.skydb.net/file/678996762/jin-mao-tower-shanghai/","zh":"Nephilim 的塔楼基部近照用于石材分缝、细方孔格栅、圆孔金属遮阳板与成对竖肋。公开页面未注明拍摄日期，照片只供建模对照，不作为运行贴图；开孔、构件尺寸和重复数量仍为估算。查阅于 2026-09-13","en":"Nephilim\'s close-up guides the stone joints, fine square grilles, circular perforations in metal shades and paired vertical fins at the tower base. The public page gives no capture date. The photograph is a modeling reference, not a runtime texture; openings, member dimensions and repetition counts remain estimates. Accessed 2026-09-13"},{"name":"SKYDB / Nephilim: Jin Mao circular entrance","space":true,"url":"https://www.skydb.net/file/534491510/jin-mao-tower-shanghai/","zh":"Nephilim 的入口实拍用于圆形门框、玻璃分格、门扇、石材分缝，以及雨棚交叉拉杆、悬挂遮板、灯具和灰红色方形铺地。页面日期为 2005-02-22，日期字段未明确区分拍摄与发布，历史照片不能证明当前装修。入口方位、构件尺寸、铺地范围与配色仍为估算；照片未作为运行贴图。查阅于 2026-09-13","en":"Nephilim\'s entrance photograph guides the circular frame, glazing grid, doors, stone joints, canopy cross rods, suspended shades, lights and grey/red square paving. The page lists 2005-02-22 without distinguishing capture from publication; this historical view does not establish the current fit-out. Entrance orientation, member dimensions, paving extent and colours remain estimates. The photograph is not a runtime texture. Accessed 2026-09-13"},{"name":"AS+GG: Jin Mao podium and atrium","space":true,"url":"https://www.smithgill.com/work/jin_mao_tower/","zh":"六层裙房说明及第三张中庭实拍（© Adrian Smith）用于拱顶、玻璃端墙和内部空间对照。尺寸仍为估算，内部连桥和灯具尚未完成；照片拍摄日期未知，未作为运行贴图。查阅于 2026-09-13","en":"The six-story podium description and third atrium photograph (© Adrian Smith) guide the vaulted roof, glazed end walls and interior. Dimensions remain estimates; bridges and lighting are unfinished. The capture date is unknown, and the photograph is not a runtime texture. Accessed 2026-09-13"},{"name":"Architectural Record: Jin Mao, January 2000","space":true,"url":"https://www.usmodernist.org/AR/AR-2000-01.pdf","zh":"Thomas J. Campanella 的金茂文章（印刷页 82–89）中，第 84、85、87 页用于北入口、连接体和裙房中庭对照。刊期 2000-01，摄影日期未知；历史资料不代表当前装修，照片未作为运行贴图。查阅于 2026-09-13","en":"Thomas J. Campanella\'s Jin Mao article (printed pages 82–89), especially pages 84, 85 and 87, references the north entrance, connector and podium atrium. Published January 2000; capture dates are unknown. Historical material does not establish the current fit-out, and photographs are not runtime textures. Accessed 2026-09-13"},{"name":"The Skyscraper Museum: Jin Mao","space":true,"url":"https://old.skyscraper.org/EXHIBITIONS/BIG_BUILDINGS/CONTENT/jumbos/j_27.htm","zh":"博物馆引用 SOM 的 88 层分段规则：底部 16 层，先每段减 2 层，再每段减 1 层。本站据此推导分段序列，宽度、层高和塔冠仍待施工图校准。查阅于 2026-09-07","en":"The museum quotes SOM\'s 88-floor setback rule: start with 16 floors, then reduce sections by two floors and subsequently by one. The model derives its sequence from this rule; widths, floor heights and crown details still lack construction-drawing calibration. Accessed 2026-09-07"},{"name":"Jinmao: 2014 prospectus","space":true,"url":"https://www.hkexnews.hk/listedco/listconews/sehk/2014/0619/LTN20140619048_C.pdf","zh":"业主 2014 年招股资料提供金茂大厦 420.5 米、88 层依据；用于模型总高，不代表其他尺寸已经测绘。查阅于 2026-09-07","en":"The owner\'s 2014 prospectus documents Jin Mao Tower\'s 420.5 m height and 88 floors. It supplies the overall model height, not a survey of other dimensions. Accessed 2026-09-07"},{"name":"Gensler: Shanghai Tower facade design","space":true,"url":"https://www.gensler.com/uploads/document/242/file/Shanghai_Tower_Facade_Design_Process_11_10_2011.pdf","zh":"设计研究用于上海中心 632 米轮廓、120° 扭转、圆角三角形外皮、收窄与倾斜塔顶。图 4 的 56.86% 上部比例作为建模参考；资料属于设计阶段，不能代替竣工测绘。查阅于 2026-09-07","en":"Design research references Shanghai Tower\'s 632 m profile, 120-degree twist, rounded triangular skin, taper and sloping crown. Figure 4\'s 56.86% upper-profile scale informs the model; this design-stage document is not an as-built survey. Accessed 2026-09-07"},{"name":"Gensler: Shanghai Tower project photographs","space":true,"url":"https://www.gensler.com/projects/shanghai-tower","zh":"2026-09-08 查看建筑师的竣工远景与仰拍照片，用于 Blender 上海中心的浅银蓝幕墙、水平分格、银色螺旋接缝和倾斜冠部。顶部内层与支撑尺寸仍为估算；程序石材微表面为本站制作，照片未用作运行贴图。尚未通过测绘 1:1 或电影级验收。","en":"Completed-building distance and upward photographs reviewed 2026-09-08 for the Blender model\'s pale silver-blue glazing, horizontal grid, silver spiral seam and sloping crown. Inner crown and strut dimensions remain estimates. Procedural stone micro-surfaces are original work; photographs are not runtime textures. Surveyed 1:1 and cinematic quality remain unverified."},{"name":"Masato Nawate: SWFC observation hall at night","space":true,"url":"https://yakei.jp/abroad/shanghai/shanhai-hills-photo.html","zh":"2026-09-13 对照绳手真人的夜间实拍，补充 100F 中央黑色灯槽、暖色筒灯、窗边扶手与反光柱饰。拍摄日期未列；照片仅作建模参考，未作为网页贴图。灯具间距、扶手尺寸和光度仍为估算。","en":"Masato Nawate\'s night photograph, reviewed 2026-09-13, references the 100F black central ceiling channel, warm recessed lamps, window handrails and reflective pier cladding. Capture date is unlisted. The photo is a modeling reference, not a runtime texture; fixture spacing, rail dimensions and photometry remain estimates."},{"name":"Carsten Ullrich: SWFC Skywalk, September 2008","space":true,"url":"https://commons.wikimedia.org/wiki/File:The_top_observatory_in_the_Shanghai_World_Financial_Center,_called_Skywalk.jpg","zh":"Carsten Ullrich 于 2008-09-11 拍摄，CC BY-SA 2.0，查阅于 2026-09-13。用于核对 100F 一端的门洞、浅色面板、金属收边及绿色疏散灯；照片未作为网页贴图。端部方位、尺寸和灯具间距仍为估算，简化图形不是原标识的精确复制，背后电梯厅与另一端尚待补证。","en":"Photographed by Carsten Ullrich on 2008-09-11, CC BY-SA 2.0; reviewed 2026-09-13. References one 100F end elevation\'s doorway, pale panels, metal trim and green exit fixtures. The photo is not a runtime texture. End orientation, dimensions and fixture spacing remain estimates; simplified pictograms are not facsimiles. The rear lift lobby and opposite end need further evidence."},{"name":"Gerhard Huber: SWFC observation deck, April 2012","space":true,"url":"https://global-geography.org/af/Geography/Asia/China/Pictures/Shanghai_2/Shanghai_World_Financial_Center_-_Observation_Deck_at_Night","zh":"Gerhard Huber 于 2012 年 4 月拍摄的观光厅夜景，页面标注 CC BY-NC 4.0 + Edu，查阅于 2026-09-13。用于交叉核对筒灯、扶手、折面镜顶及柱脚绿色疏散灯；曝光与镜面波纹不能作为实测光度。照片未作为网页贴图，灯具间距、标识细字和精确材料参数尚待核定。","en":"Gerhard Huber\'s observation-hall night photograph from April 2012, labeled CC BY-NC 4.0 + Edu and reviewed 2026-09-13, cross-checks the downlights, handrails, folded reflective ceiling and low green exit fixtures. Exposure and panel ripples do not establish measured photometry. The photo is not a runtime texture; fixture spacing, fine sign lettering and exact material parameters remain unverified."},{"name":"KPF: Shanghai World Financial Center","space":true,"url":"https://www.kpf.com/project/shanghai-world-financial-center","zh":"设计事务所的建成实拍与双向剖面，用于核对环球金融中心方形基部、弧形收削、顶部开口及观光桥底。2008 年为竣工年，照片作者与拍摄日期未列，未核得开放许可。顶部修订仍处于参考核查与候选准备，曲面、洞口尺寸及幕墙分格含估算，尚未完成模型验收。查阅于 2026-09-10","en":"The architect\'s completed-building photographs and two sectional views reference SWFC\'s square base, curved cuts, top aperture and observation-bridge underside. 2008 is the completion year; photo authors and capture dates are unlisted, with no open license established. Top revisions remain in reference review and candidate preparation. Curves, aperture dimensions and curtain-wall spacing include estimates; model acceptance is pending. Accessed 2026-09-10"},{"name":"Shanghai World Financial Center: project facts","space":true,"url":"https://www.swfc-shanghai.com/pdf/swfc_project_brochure_cn.pdf","zh":"业主项目册提供 492 米总高、地上 101 层，以及约 58×58 米标准办公层和北箭头。观光层图文用于核对 97 层玻璃顶与 100 层玻璃地板；顶部尺寸及跨图推定的朝向仍需校准。PDF 元数据日期为 2014-01-16，不代表照片拍摄日；单张图片作者与开放许可未核得。查阅于 2026-09-10","en":"The owner\'s brochure documents the 492 m height, 101 above-ground floors and an approximately 58×58 m standard office floor with a north arrow. Observatory text and images reference the 97F glass roof and 100F glass floor. Top dimensions and orientation inferred across drawings still need calibration. The PDF metadata date, 2014-01-16, is not a photo capture date; individual image authors and an open license were not established. Accessed 2026-09-10"},{"name":"Mori Building: SWFC observatory announcement","space":true,"url":"https://www.mori.co.jp/press/release/post_202/","zh":"2009-08-27 业主公告区分 100 层地上 474 米与海拔 477.96 米，并说明约 55 米观光桥和 97 层可开启玻璃顶。用于楼层与尺度核对；楼面标高不是桥底高度，走廊长度不是冠部外宽，也不代表当前灯光实测。查阅于 2026-09-10","en":"The owner\'s 2009-08-27 announcement distinguishes 100F at 474 m above ground from 477.96 m above sea level, and describes the approximately 55 m observation bridge and openable 97F glass roof. These anchor floor levels and scale: floor elevation is not the bridge underside, corridor length is not crown width, and the announcement provides no current lighting measurements. Accessed 2026-09-10"},{"name":"Quan et al. (2013): SWFC field measurements","space":true,"url":"https://doi.org/10.1155/2013/902643","zh":"同济大学 Quan、Wang、Gu、Kuang 的现场测风论文，2013 年发表，采用知识共享署名许可。图 2、5 及北箭头确认塔顶长轴沿东北—西南，用于纠正候选模型的对角朝向；示意图不能提供精确测绘方位。仪器间距与安装高度不作为观光桥尺寸。查阅于 2026-09-10","en":"The 2013 field-measurement paper by Quan, Wang, Gu and Kuang at Tongji University is published under a Creative Commons Attribution license. Figures 2 and 5 establish the northeast–southwest rooftop axis, informing correction of the candidate model\'s diagonal. These diagrams do not provide surveyed bearings; instrument spacing and mounting height are not observation-bridge dimensions. Accessed 2026-09-10"},{"name":"The Skyscraper Museum: SWFC drawings","space":true,"url":"https://old.skyscraper.org/EXHIBITIONS/TEN_TOPS/swfc.php","zh":"博物馆发布、署名 KPF 的逐层平面与剖面，用于核对方形向对角收削截面的变化，以及 98/99 层两端分离、100 层由桥连接的关系。立面配图为渲染图，图纸日期未列，未见开放许可；图线不能替代竣工尺寸测绘。查阅于 2026-09-10","en":"Museum-published floor plans and sections credited to KPF reference the square-to-diagonally-cut profile and the separated ends at 98/99F joined by the 100F bridge. The accompanying elevations are renderings. Drawing dates are unlisted and no open license was found; the drawings do not replace an as-built dimensional survey. Accessed 2026-09-10"},{"name":"Irie Miyake Architects & Engineers: SWFC photographs","space":true,"url":"https://www.imae.co.jp/en/works/shanghai-world-financial-center","zh":"项目页建成实拍用于核对 97 层白色玻璃顶框、100 层桥底与两端连接，以及高位外观。页面记载 2008 年竣工，未列摄影者或拍摄日，未核得开放许可。照片仅作参考，构件尺寸与材料参数仍为估算。查阅于 2026-09-10","en":"Completed-building photographs on the project page reference the white 97F glass-roof framing, the 100F bridge underside and end connections, and the elevated exterior view. The page records completion in 2008, without a photographer or capture date; no open license was established. Photos are references only, with member dimensions and material parameters still estimated. Accessed 2026-09-10"},{"name":"ArcelorMittal HISTAR: SWFC aerial photograph","space":true,"url":"https://constructalia.arcelormittal.com/files/5_3_1_HISTAR_web--01d1dbea37a973eac1d0153ef74c1d7e.pdf","zh":"2020 年 HISTAR 技术册第 34 页的建成俯照，原图署名 © Teri Meyer Boake / CTBUH，用于核对顶桥、97 层顶棚及冠部设备槽。2020 年为技术册版权年，照片拍摄日期未列，未见开放许可。照片仅作参考，槽深、设备尺寸与准确数量尚未核定。查阅于 2026-09-10","en":"The completed-building aerial photograph on page 34 of the 2020 HISTAR brochure is credited exactly as © Teri Meyer Boake / CTBUH. It references the top bridge, 97F canopy and crown equipment channel. 2020 is the brochure copyright year; the photo capture date is unlisted and no open license was found. The photo is a reference only; channel depth, equipment dimensions and exact counts remain unverified. Accessed 2026-09-10"},{"name":"上海绿色照明发展报告 2022","space":true,"url":"https://www.shgbc.org/uploads/202311/08/231108103633829.pdf","zh":"报告第 41–42 页的金外滩与汇丰穹顶夜景，用于暖色洗墙、檐口、绿色铜顶和金色穹顶对照。本站按建筑分层近似照明，未取得现场灯位、配光或色温测量；报告照片不代表当天亮灯状态。查阅于 2026-09-07","en":"Pages 41–42 show the Golden Bund and HSBC dome, referencing warm facade washes, cornices, green copper and a golden dome. Lighting is approximated per building without measured fixtures, photometry or color temperatures; historical photos do not document today\'s lighting state. Accessed 2026-09-07"},{"name":"上海市政府：外滩综合改造","space":true,"url":"https://www.shanghai.gov.cn/nw9822/20200906/0001-9822_397499.html","zh":"2010-03-23 改造报道提供地面四车道依据；本站沿 OSM 道路线重建外滩路面、标线、铺装和路灯。每侧 7 米宽度、铺装与灯具为估算，未取得现状测绘。查阅于 2026-09-07","en":"Shanghai\'s 2010-03-23 Bund renovation report documents four surface lanes. Roads, markings, paving and lamps follow OSM alignment; 7 m carriageways, paving and fixtures are estimates without a current street survey. Accessed 2026-09-07"},{"name":"Three.js: Shadows","space":true,"url":"https://threejs.org/manual/en/shadows.html","zh":"官方阴影文档用于外滩近景的阴影覆盖与分辨率调整；汇丰和江海关的窗洞、石材及夜间洗墙为本站实现，尺寸和灯光尚未实测校准。查阅于 2026-09-07","en":"Official shadow documentation informs shadow coverage and resolution for close Bund views. Recessed windows, stone and night facade wash are local implementations, without surveyed dimensions or measured lighting. Accessed 2026-09-07"},{"name":"ABYSSAL / natural-disasters","space":true,"url":"https://github.com/Token-Gremlin/natural-disasters","zh":"魔方空间的大气散射、体积云、雨幕、分叉闪电、体积龙卷风、FFT 海浪与 GPU 飞沫，MIT，已适配住宅、孤岛海岸与镜面","en":"Atmospheric scattering, volumetric clouds, rain, branching lightning, volumetric tornadoes, FFT ocean waves and GPU spray in Cube Space, adapted for buildings, island shores and mirrors under MIT","long_en":"Copyright (c) 2026 Davi (Token-Gremlin), MIT. Weather and ocean sources are pinned to d2bae38301ff43bc1d43bfdfd9477a552ca5420b. Adaptations include per-scene uniforms, resource disposal, a corrected 3D noise atlas, cloud sampling and spatial resolve, roof shelter, three-cascade FFT waves, projected-grid water shading, foam and ripple baking, airborne GPU spray, and integration with architectural lighting and planar reflections. Island terrain and shoreline attenuation are local additions. Disaster event simulation and demo postprocessing are omitted. Snow, hail, dust, mudslide, rainbow and surface wetness remain local effects."},{"name":"OpenStreetMap contributors","space":true,"url":"https://www.openstreetmap.org/copyright","zh":"上海河道、道路、绿地与建筑平面轮廓，ODbL 1.0。建筑由 Three.js 向上拉伸：优先使用记录高度，其次按楼层数 × 3.2 米估算，缺失时默认 12 米。目前多数建筑使用默认高度；地标外形、立面和窗光由本站代码简化生成，并非实景三维扫描。2026-09-08 从既有缓存补入道路单行方向与车道数，车流沿道路及桥面行驶；车辆外形、数量、速度和灯光为本站演示估算，未接入实时交通","en":"Shanghai water, roads, parks and building footprints, ODbL 1.0. Three.js extrudes footprints using recorded heights, then floor counts × 3.2 m, or a 12 m fallback. Most buildings currently use the fallback. Landmark shapes, facades and window lights are simplified local models, not a 3D scan. On 2026-09-08, one-way and lane-count tags were added from existing cached extracts. Cars follow roads and bridge elevations; vehicle shapes, counts, speeds and lighting are locally authored visual estimates, not live traffic","long_en":"Map data copyright OpenStreetMap contributors, distributed under ODbL 1.0. Local extracts acquired 2026-09-07; bounds, source snapshots, height completeness and texture provenance are recorded in assets/space/shanghai-v1/SOURCE.json. Road metadata was reprocessed on 2026-09-08 without changing geographic coverage. Lane counts are retained as source metadata; traffic uses one central stream per one-way carriageway and two right-hand streams on two-way roads. Missing building heights use an explicit fallback; authored landmark meshes are approximate."},{"name":"上海市土木工程学会：南浦大桥","space":true,"url":"https://www.cnssce.org/50/201308/1188.html","zh":"南浦大桥主桥 846 米、主跨 423 米、桥宽 30.35 米、塔高 150 米及拉索、横梁尺寸参考。本站重建几何，引桥高程和构件细部仍有估算。查阅于 2026-09-07","en":"Shanghai Society of Civil Engineering: Nanpu\'s 846 m main bridge, 423 m main span, 30.35 m width, 150 m towers, stays and crossbeams. Locally reconstructed geometry; approach elevations and some details remain estimated. Accessed 2026-09-07"},{"name":"上海市土木工程学会：卢浦大桥","space":true,"url":"https://www.cnssce.org/50/201308/1191.html","zh":"卢浦大桥 100＋550＋100 米跨径、40 米桥宽、100 米拱矢高和 1:5 内倾比例参考。本站重建双拱与吊杆，拱线、杆件截面及高程未按施工图校准。查阅于 2026-09-07","en":"Shanghai Society of Civil Engineering: Lupu\'s 100 + 550 + 100 m spans, 40 m width, 100 m arch rise and 1:5 inward inclination. Locally reconstructed arches and hangers; profiles, member sections and elevations are not calibrated to construction drawings. Accessed 2026-09-07"},{"name":"上海市档案馆：外白渡桥","space":true,"url":"https://www.shda.gov.cn/archives/gdxw/202601/t20260120_76430.html","zh":"外白渡桥 107 米长度、18 米宽度、11 米车行道及不等高桁架形式参考。桁架高度、节点板和铆钉仍为形态重建，未取得完整工程模型。查阅于 2026-09-07","en":"Shanghai Municipal Archives: Waibaidu\'s 107 m length, 18 m width, 11 m carriageway and variable-height trusses. Truss heights, gussets and rivets are approximations; no complete engineering model was obtained. Accessed 2026-09-07"},{"name":"Tomson Group：Tomson Riviera","space":true,"url":"https://en.tomson-group.com/product/20.html","zh":"汤臣一品开发商项目实拍，用于四栋塔楼的石材、阳台、玻璃和冠顶对照。塔楼、五处裙房及泳池保留 OSM 轮廓；逐栋高度、立面和景观细节仍为估算，庭院没有实测图纸。实拍未作为运行贴图。查阅于 2026-09-07","en":"Developer photographs reference the four towers\' stone, balconies, glazing and crowns. Tower, five podium and pool footprints follow OSM; individual heights, facades and landscape details remain estimated, without a surveyed garden plan. Photos are not runtime textures. Accessed 2026-09-07"},{"name":"新华社：上海海关钟楼","space":true,"url":"https://www.news.cn/20251001/b3a3d636f61c47e4a23226b8f1680323/c.html","zh":"2025-10-01 现场报道与实拍，提供江海关 79.2 米总高及钟楼形态参考。模型按 OSM 六处主体/附属轮廓重建，补正面凹窗、铜色窗间板和钟楼百叶；钟径、分层高度及构件尺寸仍为估算，四面指针随场景时间同步。查阅于 2026-09-07","en":"Xinhua onsite report and photographs, 2025-10-01: Customs House\'s 79.2 m overall height and clock-tower form. The local model uses six OSM building parts, with recessed front windows, bronze-colored spandrels and tower louvers. Dial diameter, stage heights and details remain estimated; all four clocks follow scene time. Accessed 2026-09-07"},{"name":"乐游上海：外滩汇丰银行大楼","space":true,"url":"https://www.thepaper.cn/newsDetail_forward_16367281","zh":"上海旅游图文，经澎湃号转载于 2022-01-20；实拍用于六柱门廊、拱门铜格、凹窗与三角窗饰、八角塔楼、穹顶和石材层次对照。模型保留 OSM 内院，总高暂取 46.3 米，未获测绘证实，雕像等细部尚缺；夜景为近似照明。查阅于 2026-09-07","en":"Shanghai tourism text and photographs, republished on The Paper on 2022-01-20, reference the six-column portico, bronze arch grilles, recessed windows and pediments, octagonal drum, dome and stone facade. The OSM courtyard remains open; the model\'s 46.3 m height is unverified, statues remain missing and night lighting is approximate. Accessed 2026-09-07"},{"name":"上海市政府：和平饭店建筑沿革","space":true,"url":"https://www.shanghai.gov.cn/nw5827/20200905/0001-5827_632318.html","zh":"和平饭店 77 米总高、19 米铜皮金字塔屋顶及花岗岩外墙参考；模型保留 OSM 三处内院，窗格、退台和楼层分配仍有估算。查阅于 2026-09-07","en":"Shanghai municipal architectural history: Peace Hotel\'s 77 m overall height, 19 m copper pyramid roof and granite facade. The model preserves three OSM courtyards; windows, setbacks and floor distribution remain approximate. Accessed 2026-09-07"},{"name":"上海市民政局：外滩建筑群","space":true,"url":"https://mzj.sh.gov.cn/lnb-wsws/20200518/MZ_LNB12_9104.html","zh":"外滩建筑名称、门牌、年代与建筑风格的研究清单，用于后续逐栋核对；不代表文中建筑已全部精细复刻。查阅于 2026-09-07","en":"Shanghai Civil Affairs Bureau: a research inventory of Bund building names, addresses, dates and styles for individual reconstruction. Inclusion here does not mean every listed building has been rebuilt in detail. Accessed 2026-09-07"},{"name":"Asisbiz: 外滩 12 汇丰大楼 / HSBC Building","space":true,"url":"https://www.asisbiz.com/China/12-Zhongshan-Rd.html","zh":"实拍用于六柱门廊、柱头叶饰、窗下线脚、入口银行招牌，以及两级八角鼓座、上层平头窗、石栏和穹顶轮廓。石材图为原创程序纹理，非照片扫描；尺寸、雕饰及全圈灯具布置含估算，穹顶雕像和完整立面未达到 1:1。拍摄日期未知，不能据档案照片判断当前招牌与灯光。实拍复核于 2026-09-10","en":"Photographs guide the six-column portico, capital leaves, window mouldings, bank sign, two octagonal drum levels, flat-headed upper windows, balustrades and dome silhouette. Masonry maps are original procedural textures, not scans. Dimensions, ornament and fixtures around the dome remain estimates; statues and the complete facade are not verified 1:1. Capture date unknown; archive photos do not establish current signage or lighting. Reviewed 2026-09-10"},{"name":"ScareCriterion12：汇丰大楼正立面 / HSBC frontal photograph","space":true,"url":"https://commons.wikimedia.org/wiki/File:上海外滩汇丰银行大楼2021.jpg","zh":"ScareCriterion12 于 2021-06-20 拍摄，CC BY-SA 4.0。用于纠正六柱门廊的两组内侧成对柱列，柱间距依次为宽、窄、宽、窄、宽；取代此前误判的等距排列。照片未做正射校正，模型米制间距仍为估算；仅作几何对照，未作为运行贴图。查阅于 2026-09-10","en":"Photographed by ScareCriterion12 on 2021-06-20, CC BY-SA 4.0. Corrects the six-column portico to two close inner pairs with wide, narrow, wide, narrow, wide gaps, replacing the previously misread equal spacing. The photograph is not orthorectified; model dimensions in metres remain estimates. Used as a geometry reference, not a runtime texture. Accessed 2026-09-10"},{"name":"Hermann Luyken：汇丰外部穹顶夜景 / HSBC exterior dome at night","space":true,"url":"https://commons.wikimedia.org/wiki/File:2014.11.15.192101_Dome_HSBC_Building_Bund_night_Shanghai.jpg","zh":"Hermann Luyken 于 2014-11-15 19:21:01 拍摄，CC0。对照外部平滑穹顶、水平细线、矩形窗亭、石栏、成组投光器和尖顶；不是室内马赛克穹顶。照片仅本地审图，未作为运行贴图。细部尺寸与灯具总数含估算，照片不代表当前配光或实测色温。查阅于 2026-09-10","en":"Photographed by Hermann Luyken on 2014-11-15 at 19:21:01, CC0. References the smooth exterior dome, horizontal details, rectangular dormers, balustrades, grouped floodlights and finial, rather than the interior mosaic ceiling. Reviewed locally, not used as a runtime texture. Fine dimensions and total fixture count remain estimates; this photo does not establish current photometry or measured color temperature. Accessed 2026-09-10"},{"name":"Asisbiz: 外滩 13 江海关 / Customs House","space":true,"url":"https://www.asisbiz.com/China/13-Zhongshan-Rd.html","zh":"实拍用于七条主窗带、铜饰板、入口石柱、钟楼格栅及双侧亭；本轮核对六层转折檐口、基座正面可见的五个投光器，保留场景时间驱动的四面钟表。原图署名 Matthew Laird Acred，CC BY-SA 3.0；嵌套 EXIF 的 DateTimeOriginal 和 DateTimeDigitized 均标记 2008-11-14 17:25:05，纠正此前日期未知的说明。相机时钟与时区未经独立核验，页面更新于 2020-01-27；旧照不能作为当前灯光实测。石材图为原创程序纹理；尺寸、颜色及灯具均含估算，新增灯具外形不等于现场配光已还原。侧后立面、钟面与夜景待校准，尚非测绘 1:1。查阅于 2026-09-10","en":"Photographs guide seven window bands, bronze panels, entrance columns, tower grilles and paired roof pavilions. This review covers six-layer cornice returns and five visible front plinth floodlights; all four clocks retain scene-time control. The original credits Matthew Laird Acred, CC BY-SA 3.0. Nested EXIF DateTimeOriginal and DateTimeDigitized both report 2008-11-14 17:25:05, correcting the earlier unknown-date statement. The camera clock and timezone have not been independently verified; the page was updated on 2020-01-27. This older photo does not establish present-day lighting measurements. Masonry maps are original procedural textures. Dimensions, colors and fixtures remain estimates; modeled lamp housings do not establish restored photometry. Other elevations, clock faces and night lighting remain uncalibrated, not surveyed 1:1. Accessed 2026-09-10"},{"name":"Wikimedia Commons: DvTor8303 江海关夜景 / Customs House at night","space":true,"url":"https://commons.wikimedia.org/wiki/File:HSBC_Building_and_Custom_House,_Shanghai_at_night_20260417_(2).jpg","zh":"DvTor8303 自摄，CC0 1.0；文件页与原图 EXIF 均标记 2026-04-17 20:34:53，相机时钟与时区未经独立核验。江海关夜景的首要实拍参考，用于核对钟盘石框、暖色塔冠、基座下亮上暗、檐下阴影与底层石墙的照明层次。照片仅本地审图，未作为运行贴图；六盏聚合投光代理的灯位与光度仍为估算，尚非现场配光或 1:1 复原。查阅于 2026-09-10","en":"Own photograph by DvTor8303, CC0 1.0. The file page and original EXIF both report 2026-04-17 20:34:53; camera clock and timezone have not been independently verified. The primary night reference for Customs House, covering the clock surround, warm crown, brighter lower plinth, cornice shadows and lower stonework. Reviewed locally, not used as a runtime texture. Positions and photometry of the six aggregate spotlights remain estimates, not a surveyed lighting scheme or a verified 1:1 replica. Accessed 2026-09-10"},{"name":"Fairmont: 和平饭店官方夜景 / Peace Hotel night exterior","space":true,"url":"https://www.fairmont.com/en/hotels/shanghai/fairmont-peace-hotel.html","zh":"业主图集 aja_p_6133-03 与 HCM_P_6963970 用于铜顶下沿局部绿光、上部深绿、顶冠暖光及退台檐线的照明层次。官网未标明拍摄者和日期，原图没有相关 EXIF；不按照片反推光度。六盏 Blender 灯是合并视觉代理，灯位、颜色与强度含估算，未作为运行贴图，未通过 1:1 验收。查阅于 2026-09-10","en":"Owner gallery images aja_p_6133-03 and HCM_P_6963970 guide localized green light along the lower copper roof, a darker upper slope, a warm crown and lit setback cornices. Photographer and capture date are unspecified, with no corresponding EXIF; photographs are not photometric measurements. Six Blender lamps are grouped visual proxies with estimated positions, colors and intensities. Photos are not runtime textures; the replica is not verified 1:1. Accessed 2026-09-10"},{"name":"Suicasmo: 和平饭店夜景 2025 / Peace Hotel at night","space":true,"url":"https://commons.wikimedia.org/wiki/File:Peace_Hotel_20250503.jpg","zh":"Suicasmo 自摄，CC0 1.0；文件页和 EXIF 均标记 2025-05-03 23:04:28，时区与相机时钟未经独立校验。用于交叉核对整楼铜顶下亮上暗、暖色顶冠、檐线与暗拱洞。仅作夜景结构参考，不是当前现场的测量，也未作为运行贴图。查阅于 2026-09-10","en":"Own photograph by Suicasmo, CC0 1.0. Both the file page and EXIF report 2025-05-03 23:04:28; timezone and camera clock have not been independently verified. Cross-checks the brighter lower roof, dark upper slope, warm crown, cornices and dark ground arches. A lighting reference, not a present-day survey or runtime texture. Accessed 2026-09-10"},{"name":"Asisbiz: 外滩 20 和平饭店 / Peace Hotel","space":true,"url":"https://www.asisbiz.com/China/20-Zhongshan-Rd.html","zh":"实拍用于截顶铜屋面、咬口、上部退台、七层 63 扇窗及底层双拱窗；本轮核对塔顶百叶凹腔、窄柱、分层铜檐、连续弧纹及屋脊接缝，保留现有灯牌。铜板与石材图为原创程序纹理，已纠正颜色编码造成的偏暗；板缝与细部数量为照片估算，背面缺少独立实拍，浮雕、旗帜与夜间铜顶照明未完成。原图 01、03、05 的 EXIF 标记拍摄于 2008-11-14，时区未知且相机时钟未经独立校验；文件名 1929 是建筑年代，旧照片不能证明当前招牌与灯光。查阅于 2026-09-10","en":"Photographs guide the truncated copper roof, seams, upper setbacks, 63 windows across seven levels and two ground arches. This review covers recessed crown louvers, narrow posts, layered copper eaves, repeated arcs and hip joints, retaining existing signs. Copper and masonry maps are original procedural textures; an encoding error that darkened them has been corrected. Joint spacing and detail counts are estimates; the rear lacks independent photographs, and relief, flags and roof night lighting remain unfinished. Originals 01, 03 and 05 carry EXIF capture dates of 2008-11-14, with no timezone or independent camera-clock verification. The filename year 1929 identifies construction; these older photos do not establish current signage or lighting. Accessed 2026-09-10"},{"name":"Asisbiz: 外滩 1 亚细亚大楼 / Asia Building","space":true,"url":"https://www.asisbiz.com/China/1-Zhongshan-Rd.html","zh":"实拍对照：平顶阁楼、半圆窗、女儿墙端部凹曲线、成对入口柱和弧形门廊。平面据 OSM，高度、柱式及雨棚尺寸仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考，拍摄时期不代表当前现状。查阅于 2026-09-08","en":"Photo reference: flat attic caps, semicircular windows, curved parapet ends, paired entrance columns and a barrel-vaulted portico. OSM plan; heights, column details and canopy dimensions remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only and do not establish current conditions. Accessed 2026-09-08"},{"name":"Asisbiz: 外滩 2 上海总会 / Shanghai Club","space":true,"url":"https://www.asisbiz.com/China/2-Zhongshan-Rd.html","zh":"实拍对照：六根暖色石柱、五组三联顶层拱窗、五组柱廊后墙成对窗、顶部双亭及端部山花、入口双圆窗和坡面金属玻璃雨棚。平面据 OSM，高度、窗距、雕饰和雨棚尺寸仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考，拍摄时期不代表当前现状。查阅于 2026-09-09","en":"Photo reference: six warm stone columns, five groups of three attic arches, five pairs of recessed upper gallery windows, twin roof pavilions, end pediments, entrance oculi and a pitched metal-and-glass canopy. OSM plan; heights, window spacing, reliefs and canopy dimensions remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only and do not establish current conditions. Accessed 2026-09-09"},{"name":"Asisbiz: 外滩 3 有利大楼 / Union Building","space":true,"url":"https://www.asisbiz.com/China/3-Zhongshan-Rd.html","zh":"实拍对照：东南角灯笼塔、拱窗、壁柱。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07","en":"Photo reference: southeast lantern tower, arched windows and pilasters. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07"},{"name":"Asisbiz: 外滩 5 日清大楼 / Nissin Building","space":true,"url":"https://www.asisbiz.com/China/5-Zhongshan-Rd.html","zh":"实拍对照：六层分区、四壁柱、双山花半圆窗。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：华夏银行。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: six-storey elevation, four pilasters and twin gables. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: 华夏银行. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 6 中国通商银行大楼 / China Commercial Bank","space":true,"url":"https://asisbiz.com/China/6-Zhongshan-Rd.html","zh":"实拍对照：五座主次山墙、四层不同窗型、门廊与八处 DOLCE&GABBANA 店招。2026-09-08 重新校正开间与店招位置。平面据 OSM，尺寸、字形及细部为照片估算，尚未通过 1:1 验收。实际拍摄日期未确认，不能据此认定当前租户；照片仅供建模参考。","en":"Photo reference: five gables of different sizes, four window orders, entrance portico and eight DOLCE&GABBANA signs. Bays and sign positions revised 2026-09-08. OSM plan; dimensions, lettering and details are estimates, not a verified 1:1 replica. Capture date is unconfirmed and does not establish current tenancy; reference photos only."},{"name":"上海城建档案：外滩 6 号 / Shanghai Urban Construction Archives","space":true,"url":"https://www.thepaper.cn/newsDetail_forward_25669123","zh":"2023-12-16 发布，2026-09-08 查阅。用于校正通商银行圆拱、弧拱、矩形、尖拱四层窗型，中央高山墙、三条窄缝、四座小山墙、附楼和屋顶栏杆。尺寸按 OSM 与照片比例估算；档案照与店招照并非同一时期。夜间灯位、光度与侧后立面尚未实测，不能认定 1:1 或电影级通过。照片未作为在线贴图。","en":"Published 2023-12-16; accessed 2026-09-08. Reference for the bank\'s round, segmental, rectangular and pointed window orders, tall central gable with three slits, four small gables, annex and roof balustrade. Dimensions use OSM and photo proportions; archival and storefront photos show different periods. Night fixtures, photometry and side/rear elevations remain unverified; neither 1:1 nor cinematic quality is certified. Photos are not runtime textures."},{"name":"商务旅行杂志：外滩 6 号夜景 / Business Travel Magazine","space":true,"url":"https://style.sina.com.cn/lei/travel/2010-07-29/155165252.shtml","zh":"新浪转载页面发表于 2010-07-29，2026-09-08 查阅并查看夜景照片。用于通商银行暖金色窗边照明、较亮的水平檐口与暗窗关系；小幅照片不用于精确配光或色温测量。拍摄日期与摄影者未标明，不代表当前灯光。本站灯位、光强及遮挡为近似，照片仅本地审图，不是运行贴图。","en":"Sina republication dated 2010-07-29; accessed and night photograph inspected 2026-09-08. Reference for warm window lighting, brighter horizontal cornices and dark glazing at the China Commercial Bank. The small image cannot establish exact photometry or color temperature. Capture date and photographer are unspecified; it does not establish current lighting. Fixture placement, intensity and occlusion are approximations. Local reference only, not a runtime texture."},{"name":"Asisbiz: 外滩 7 大北电报公司大楼 / Great Northern Telegraph","space":true,"url":"https://www.asisbiz.com/China/7-Zhongshan-Rd.html","zh":"实拍对照：双侧穹顶、中央坡顶老虎窗。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：盘谷银行 / Bangkok Bank。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: twin domes and central roof dormers. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: 盘谷银行 / Bangkok Bank. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 9 轮船招商局大楼 / China Merchants Building","space":true,"url":"https://www.asisbiz.com/China/9-Zhongshan-Rd.html","zh":"实拍对照：三层红砖、细柱廊道、栏杆与坡顶。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07","en":"Photo reference: three-storey red brick, slender veranda columns and hipped roof. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07"},{"name":"Asisbiz: 外滩 14 交通银行大楼 / Bank of Communications","space":true,"url":"https://www.asisbiz.com/China/14-Zhongshan-Rd.html","zh":"实拍对照：竖向翼墙、中央退台、深色入口。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：上海市总工会。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: vertical fins, stepped central crown and dark entrance. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: 上海市总工会. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 15 华俄道胜银行大楼 / Russo-Chinese Bank","space":true,"url":"https://www.asisbiz.com/China/15-Zhongshan-Rd.html","zh":"实拍对照：跨两层六柱廊、基座拱窗、檐口。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：中国外汇交易中心。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: two-storey six-column portico, base arches and cornices. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: 中国外汇交易中心. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 16 台湾银行大楼 / Bank of Taiwan","space":true,"url":"https://www.asisbiz.com/China/16-Zhongshan-Rd.html","zh":"实拍对照：四柱门廊、基座、上层窗区。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：招商银行 / CHINA MERCHANTS BANK。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: four-column portico, base and upper window level. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: 招商银行 / CHINA MERCHANTS BANK. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 17 字林西报大楼 / North China Daily News AIA","space":true,"url":"https://www.asisbiz.com/China/17-Zhongshan-Rd.html","zh":"实拍对照：深色基座及顶部、浅色主体、双亭和上层拱窗。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：AIA / AMERICAN INTERNATIONAL ASSURANCE。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: dark base and upper floors, pale shaft, twin pavilions and upper arches. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: AIA / AMERICAN INTERNATIONAL ASSURANCE. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 18 麦加利银行大楼 / Chartered Bank","space":true,"url":"https://asisbiz.com/China/18-Zhongshan-Rd.html","zh":"实拍对照：中央双柱深凹廊、退台山花；2026-09-08 补五处底层洞口、Cartier / Ermenegildo Zegna 店招与橱窗边框、展示台。平面据 OSM，字形、尺寸和室内深度为估算，尚未通过 1:1 验收。实际拍摄日期未确认，不能据此认定当前租户；照片仅供建模参考。","en":"Photo reference: recessed two-column portico and setback pediment; reviewed 2026-09-08 for five ground openings, Cartier / Ermenegildo Zegna signs, display surrounds and plinths. OSM plan; lettering, dimensions and interior depth are estimated, not verified 1:1. Capture date and current tenancy are unconfirmed; reference photos only."},{"name":"Asisbiz: 外滩 19 汇中饭店（和平南楼） / Palace Hotel Peace South","space":true,"url":"https://www.asisbiz.com/China/19-Zhongshan-Rd.html","zh":"实拍对照：红砖浅石分区、圆角窗、铜顶八角亭、南京路长翼。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：THE SWATCH ART PEACE HOTEL。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: red brick and pale stone, corner windows, copper-capped drums and Nanjing Road wing. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: THE SWATCH ART PEACE HOTEL. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 23 中国银行大楼 / Bank of China","space":true,"url":"https://www.asisbiz.com/China/23-Zhongshan-Rd.html","zh":"实拍对照：两侧石花格、三列竖向窗、退台翘檐及西侧附楼。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：中国银行 / BANK OF CHINA。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: stone lattice screens, three central window bands, stepped Chinese eaves and west wing. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: 中国银行 / BANK OF CHINA. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 24 横滨正金银行大楼 / Yokohama Specie Bank","space":true,"url":"https://www.asisbiz.com/China/24-Zhongshan-Rd.html","zh":"实拍对照：四根巨柱、上部小柱廊、檐口。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：ICBC  中国工商银行。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: four-column giant order, upper colonnade and cornices. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: ICBC  中国工商银行. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 26 扬子水火保险公司大楼 / Yangtze Insurance Building","space":true,"url":"https://www.asisbiz.com/China/26-Zhongshan-Rd.html","zh":"实拍对照：窄立面、上部双柱、双侧深色老虎窗。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：ABC  中国农业银行 / AGRICULTURAL BANK OF CHINA。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: narrow facade, upper paired columns and dark end dormers. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: ABC  中国农业银行 / AGRICULTURAL BANK OF CHINA. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 27 怡和洋行大楼 / Jardine Matheson Building","space":true,"url":"https://asisbiz.com/China/27-Zhongshan-Rd.html","zh":"实拍对照：六根巨柱、中央山花；2026-09-08 补 THE HOUSE OF ROOSEVELT / ROLEX 店招、绿色下窗与金属窗框。平面据 OSM，尺寸与灯光仍为估算，品牌专用字体及皇冠图形尚未复刻，未通过 1:1 验收。实际拍摄日期未确认，不能据此认定当前租户；照片仅供建模参考。","en":"Photo reference: six-column order and central pediment; reviewed 2026-09-08 for THE HOUSE OF ROOSEVELT / ROLEX signs, green lower panes and metal frames. OSM plan; dimensions and lighting remain estimated, with exact brand typefaces and crown symbols still missing. Not verified 1:1; capture date and current tenancy are unconfirmed. Reference photos only."},{"name":"Asisbiz: 外滩 28 格林邮船大楼 / Glen Line Building","space":true,"url":"https://www.asisbiz.com/China/2-Beijing-Rd.html","zh":"实拍对照：巨壁柱、中央逐级屋顶塔及半圆窗。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07","en":"Photo reference: giant pilasters, stepped central roof pavilion and semicircular window. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07"},{"name":"Asisbiz: 外滩 29 东方汇理银行大楼 / Banque de Indochine","space":true,"url":"https://www.asisbiz.com/China/29-Zhongshan-Rd.html","zh":"实拍对照：三层古典立面、壁柱与中央山花。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07；2026-09-08 补对照照片中的招牌：中国光大银行。字形、安装尺寸和夜间亮度仍为近似；照片年代不等于当前租户现状。","en":"Photo reference: three-storey classical facade, pilasters and central pediment. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07; signage reviewed 2026-09-08: 中国光大银行. Letterforms, mounting dimensions and night brightness remain approximations; photo dates do not establish the current tenant."},{"name":"Asisbiz: 外滩 33 英国领事馆 / Former British Consulate","space":true,"url":"https://www.asisbiz.com/China/32-Zhongshan-Rd/images/Wiki-The-Consulate-General-of-the-United-Kingdom-building-in-Shanghai-01.jpg","zh":"实拍对照：南侧两层主楼、坡顶烟囱、北侧官邸。平面据 OSM，高度和细部仍为照片估算，尚未通过 1:1 验收。照片仅供建模参考。查阅于 2026-09-07","en":"Photo reference: southern two-storey main house, hipped roof, chimneys and northern residence. OSM plan; heights and details remain photographic estimates, not a verified 1:1 replica. Photos are modeling references only. Accessed 2026-09-07"},{"name":"Car Concept: Eric Chadwick / DGG","space":true,"url":"https://github.com/KhronosGroup/glTF-Sample-Assets/tree/main/Models/CarConcept","zh":"魔方空间车库模型及贴图，Eric Chadwick / Darmstadt Graphics Group，2024，CC BY 4.0","en":"Garage model and textures by Eric Chadwick / Darmstadt Graphics Group, 2024, CC BY 4.0","long_en":"Car Concept from Khronos glTF Sample Assets. Model and textures copyright 2024 Darmstadt Graphics Group GmbH, by Eric Chadwick, licensed under https://creativecommons.org/licenses/by/4.0/. Khronos and 3D Commerce logos remain subject to the Khronos trademark notice in the source repository. Hosted locally; scaled and glass rendering adapted for the space."},{"name":"Poly Haven","space":true,"url":"https://polyhaven.com/license","zh":"魔方空间使用本地托管的 CC0 环境光、材质、家具与植物模型","en":"Self-hosted CC0 lighting, materials, furniture and plant models for Cube Space","long_en":"Cube Space uses Poly Haven\'s belfast_sunset_puresky, marble_01, wood_floor, fabric_pattern_07, rough_linen, dirty_carpet, herringbone_parquet, sofa_03, modern_arm_chair_01, potted_plant_01, potted_plant_02, island_tree_02 and throw_pillows_01 assets, distributed under CC0. Runtime assets are hosted locally with the application."},{"name":"Country State City","url":"https://github.com/dr5hn/countrystatecity-npm","zh":"账号国家、省份与城市选项数据（ODbL-1.0）","en":"Country, state or province, and city option data for account profiles (ODbL-1.0)","long_en":"The private account location selector uses a compact, self-hosted snapshot generated from Country State City."},{"name":"Feishin","url":"https://github.com/jeffvli/feishin","zh":"音乐播放器的信息层级、播放控制与同步歌词体验参考；CubeRoot 未复制其 GPL-3.0 源码或服务端适配","en":"UX reference for the music player\'s information hierarchy, playback controls, and synced lyrics; CubeRoot copies no GPL-3.0 source code or server adapters","long_en":"Feishin is the primary product and UX reference for CubeRoot\'s music player. The implementation uses CubeRoot\'s own React UI and browser-native audio transport without copying Feishin\'s GPL-3.0 source code or server integrations."},{"name":"YesPlayMusic","url":"https://github.com/qier222/YesPlayMusic","zh":"音乐播放器的视觉与产品分层参考；CubeRoot 未复制其 MIT 源码或第三方音乐服务实现","en":"Visual and product-structure reference for the music player; CubeRoot copies no MIT source code or third-party music-service implementation","long_en":"YesPlayMusic informed the visual and product-layering research for CubeRoot\'s music player. CubeRoot does not copy its source code or integrate its third-party music-service behavior."},{"name":"Apple Music Like Lyrics","url":"https://github.com/amll-dev/applemusic-like-lyrics","zh":"逐词歌词交互的调研参考；当前播放器未引入或复制其 AGPL-3.0 组件","en":"Research reference for word-synced lyric interactions; the current player neither imports nor copies its AGPL-3.0 components","long_en":"Apple Music Like Lyrics was evaluated as a reference for advanced word-synced lyric presentation. CubeRoot\'s current lightweight LRC implementation does not import or copy its AGPL-3.0 components."},{"name":"Handsontable/HyperFormula","url":"https://github.com/handsontable/hyperformula","zh":"在线协作表格的公式计算引擎（GPL-3.0）","en":"Formula engine for collaborative spreadsheets (GPL-3.0)","long_en":"HyperFormula evaluates formulas, ranges, and cross-sheet references in the collaborative spreadsheet editor."},{"name":"or18/RubiksSolverDemo","url":"https://github.com/or18/RubiksSolverDemo","zh":"3x3 求解器 demo + PWA 脚手架","en":"3×3 solver demo","long_en":"3×3 solver & trainer pages, PWA scaffolding"},{"name":"WACWCA/two-tool + Best 2x2 Algs","url":"https://github.com/WACWCA/two-tool","zh":"二阶实战解法查找器的双向搜索、手感排序与方法结构；公式数据合并自 Best 2x2 Algs 表格，状态计算和 3D 展示改用本站引擎","en":"Two-Tools bidirectional search, ergonomic ranking, and method structure; Best 2x2 Algs sheet data is merged into the library, with state math and 3D rendering moved to the site\'s own engines","long_en":"Will Callan\'s practical 2×2 solution finder provides the bidirectional face/layer search design, method filters, and measured three-move timing table. Its Best 2x2 Algs spreadsheet is normalized and merged into CubeRoot\'s algorithm database; the port replaces the upstream sticker mapper and twisty-player with CubeRoot\'s existing pocket-state solver and /sim engine."},{"name":"mikavilpas/squanmate","url":"https://github.com/mikavilpas/squanmate","zh":"Square-1 形状训练、奇偶分析、数位与学习工具的功能和算法参考；移植页面复用本站 SQ1 状态、公式库、SVG 与 /sim 绘图引擎（EPL-1.0）","en":"Feature and algorithm reference for the Square-1 shape trainer, parity analysis, count positions, and learning tools; the port reuses CubeRoot\'s SQ1 state, algorithm library, SVG, and /sim drawing engines (EPL-1.0)","long_en":"Squanmate by Mika Vilpas is the upstream functional reference for CubeRoot\'s Square-1 workspace: cubeshape and algorithm training, the 29 canonical single-layer shape names, scramble inspection, algorithm shape visualization and import, parity count positions, parity-sequence practice, and trainer controls. CubeRoot reuses its own notation/state implementation, algorithm database, SVG renderer, and /sim drawing system instead of carrying over Squanmate\'s ClojureScript UI stack."},{"name":"Daniel\'s Public PBL Doc","url":"https://docs.google.com/spreadsheets/d/1VQNYNwdOLqqBkacHcfYtEBst22FOVhH9EAhTOYOZTgo/","zh":"Square-1 PBL 公式数据与维护来源","en":"Square-1 PBL algorithm-data and maintenance source","long_en":"Daniel\'s public Square-1 PBL workbook is the source reference for the normalized PBL algorithm library presented on CubeRoot."},{"name":"Simple Square-1 PBL Finder v1.2 by Anuar and Lucas","url":"https://www.dropbox.com/scl/fi/b47zgzc2z8w8w818pzi1m/Square-1-PBL-Finder.jar?rlkey=rxnjgdf319zpq1ubr4bkrddab&e=2&dl=0","zh":"Square-1 PBL Finder 的行为参考；本站采用 clean-room 行为重实现，未复制源码，许可证尚未核实","en":"Behavioral reference for the Square-1 PBL Finder; CubeRoot uses a clean-room behavioral reimplementation, copies no source code, and has not verified the license","long_en":"The supplied Simple Square-1 PBL Finder v1.2 JAR by Anuar and Lucas is used only as a black-box behavioral reference. CubeRoot\'s finder is a clean-room reimplementation built on its own Square-1 state and UI infrastructure; no source code was copied, and the original JAR\'s license remains unverified."},{"name":"jonatanklosko/wca_statistics","url":"https://github.com/jonatanklosko/wca_statistics","zh":"WCA 统计管道原型(本站为 TS 重写版)","en":"WCA statistics pipeline (TS rewrite here)","long_en":"statistics engine, SQL queries, plugin framework (TS rewrite)"},{"name":"mihlefeld/Alg-Trainers","url":"https://github.com/mihlefeld/Alg-Trainers","zh":"公式训练器","en":"Algorithm trainer pages"},{"name":"carykh/hthgrapher","url":"https://github.com/carykh/hthgrapher","zh":"HTH 计算器(已 port 为 React)","en":"Head-to-Head Ao5 calculator (React port)"},{"name":"MatteoColombo/cube_challenge_timer","url":"https://github.com/MatteoColombo/cube_challenge_timer","zh":"1v1 对战计时器(已 port 为 React)","en":"1v1 battle timer logic (React port)"},{"name":"cs0x7f/cstimer","url":"https://github.com/cs0x7f/cstimer","zh":"csTimer 计时器(integrated)+ 非 WCA 打乱引擎(/scramble/gen 30+ puzzle 走 vendor 进 tools/cstimer-scramble/);部分 /scramble/solver 求解器也直接 wrap cstimer 自带 solver 当引擎(dino = redi IDA*、大金字塔 mpyrso = 两阶段、Square-1 = sq12phase 两阶段,后者上游只用于生成随机态打乱,我们在同一份搜索上加了求解入口);/timer 的智能魔方与智能计时器协议(GAN / 魔域 / 奇艺 / GoCube / Giiker)亦按其实现移植","en":"csTimer & WCA random-state scramble engine; non-WCA puzzle scramble engine for /scramble/gen (vendored in tools/cstimer-scramble/); a few /scramble/solver solvers also wrap cstimer\'s own solver as the solve engine (Dino = redi IDA*, Master Pyraminx = two-phase, Square-1 = sq12phase two-phase — upstream only generates random-state scrambles with it, we added a solve entry point on the same search); /timer\'s smart-cube and smart-timer protocols (GAN / MoYu / QiYi / GoCube / Giiker) are ported from its implementations too","long_en":"professional speedcubing timer & WCA random-state scramble engine; also vendored at tools/cstimer-scramble/ to power non-WCA puzzle generation (gear/ivy/dino/sq2/giga/pyracrystal/heli/curvycopter/cuboids/15-puzzle/bicube/siamese cubes/...) via classic Web Worker bridge; for a few puzzles whose state space is too large for a full BFS/table, cstimer\'s own solver is wrapped directly as the SOLVING engine in /scramble/solver (Dino = redi IDA*, Master Pyraminx = two-phase, Square-1 = sq12phase two-phase); cstimer\'s megascramble model + poly3dlib geometry (makePuzzle) are also used as the bit-exact piece-model oracle when building from-scratch reductions (e.g. the Helicopter Cube and the Siamese 2×2×2 solvers)"},{"name":"poliva/smartcube-web-bluetooth","url":"https://github.com/poliva/smartcube-web-bluetooth","zh":"全端共享的 MoYu32 地址发现参考其 MY32/MY33 有限候选探测设计；候选经加密状态校验后使用","en":"Reference for shared MoYu32 MY32/MY33 finite MAC candidate probing across clients; candidates are verified with encrypted state replies"},{"name":"mintydev789/RecordRanks","url":"https://github.com/mintydev789/RecordRanks","zh":"比赛管理、排名与纪录数据服务；/contests 以本站双语界面展示 Cubing Contests 公开数据，成绩格式与排名计算复用 RecordRanks","en":"Competition, ranking and record data service; /contests presents Cubing Contests public data in CubeRoot\'s bilingual UI, reusing RecordRanks result formatting and rankings"},{"name":"afedotov/gan-web-bluetooth","url":"https://github.com/afedotov/gan-web-bluetooth","zh":"GAN 智能魔方协议参考;/timer 的 GAN Gen2 / Gen4 陀螺仪四元数位布局按其规格实现","en":"GAN smart-cube protocol reference; /timer\'s GAN Gen2 / Gen4 gyroscope quaternion bit layouts follow its spec"},{"name":"lukeburong/weilong-v10-ai-protocol","url":"https://github.com/lukeburong/weilong-v10-ai-protocol","zh":"魔域 MoYu32 (威龙 V10 AI) 协议文档;/timer 的 MoYu32 驱动与陀螺仪解码据此实现","en":"MoYu32 (WeiLong V10 Ai) protocol documentation; /timer\'s MoYu32 driver and gyroscope decoding are built from it"},{"name":"cs0x7f/cube555","url":"https://github.com/cs0x7f/cube555","zh":"5x5 随机状态求解器(server-side daemon 驱动 /scramble/gen 5x5)","en":"5x5 random-state solver (server-side daemon powers /scramble/gen 5x5)","long_en":"five-phase reduction 5x5x5 solver — runs as a Java child process under our Hono server"},{"name":"Roman-/mosaic","url":"https://github.com/Roman-/mosaic","zh":"魔方马赛克(已 port 为 React)","en":"Cube mosaic generator (React port)"},{"name":"huazhechen/cuber","space":true,"url":"https://github.com/huazhechen/cuber","zh":"/sim 与 /space 共用的 three.js 魔方引擎(原 Vue + Vuetify,已 port 为 React)","en":"Shared three.js cube engine for /sim and /space (originally Vue + Vuetify, ported to React)","long_en":"Virtual cube engine (Three.js cube/cubelet/group/twister/controller core), MIT, Copyright (c) 2018 huazhechen, ported to React for /sim and reused in /space. Reviewed upstream through 3750b892691c4d7582fc13c857c3b79542bba4af on 2026-10-12. Ordinary stickered NxN cubes in /sim use bf18e8d\'s additive coloured emission, 0.9 ambient / 0.25 directional lighting and sRGB/NoToneMapping pipeline, with c3858e3\'s face, plastic and specular defaults. Emission is adapted to instancing, masks, pictures and SVG export. Custom colours, the WCA palette, high-order rendering and other puzzle rigs are retained. The original UI was Vue + Vuetify; upstream\'s later React/Vite UI is not imported."},{"name":"cubing/cubing.js","url":"https://github.com/cubing/cubing.js","zh":"Twizzle 同源的 cubing.js TwistyPlayer 用于模拟器与公式播放器，并提供智能魔方实况的可选三维引擎；公式解析与各项目随机状态打乱也复用此库","en":"cubing.js TwistyPlayer, also used by Twizzle, powers simulator and alg players and the optional live smart-cube 3D engine; alg parsing and per-event random-state scrambles also share this library","long_en":"Lucas Garron\'s cubing.js — Pyraminx / Skewb / Megaminx canvases in `/sim` embed `TwistyPlayer` to mirror the alpha.twizzle.net/edit demo; the `Alg` parser, `randomScrambleForEvent`, and several `PuzzleID` utilities are reused across alg/recon/training pages"},{"name":"huizhiLLL/DCTimer-BLE","url":"https://github.com/huizhiLLL/DCTimer-BLE","zh":"智能魔方专项训练规则参考；LSE/L10P 固定朝向随机状态约束参考其 Scrambler 实现，复用本站两阶段求解器生成打乱","en":"Reference for smart-cube training rules and fixed-grip LSE/L10P random-state constraints; scrambles use CubeRoot\'s existing two-phase solver"},{"name":"MeigenChou/DCTimer-Android","url":"https://github.com/MeigenChou/DCTimer-Android","zh":"BLE / 协议参考;对战计时器设计灵感","en":"BLE / protocol reference; battle-timer design inspiration","long_en":"design inspiration for the battle timer"},{"name":"MnlPhlp/tauri-plugin-blec","url":"https://github.com/MnlPhlp/tauri-plugin-blec","zh":"Windows/macOS Tauri 宿主的系统 BLE transport；GAN 协议与状态机仍复用 CubeRoot 共享实现（MIT OR Apache-2.0）","en":"Native BLE transport for the Windows/macOS Tauri host; GAN protocol and state remain in CubeRoot\'s shared implementation (MIT OR Apache-2.0)","long_en":"The installed Windows and macOS clients use tauri-plugin-blec only for native scanning, GATT connection, reads, writes, and notifications. Device selection, GAN v4 crypto, packet decoding, cube state, and timing behavior remain in CubeRoot\'s shared packages."},{"name":"HarmonyOS Samples/BluetoothLowEnergy","url":"https://gitee.com/harmonyos_samples/BluetoothLowEnergy","zh":"HarmonyOS NEXT 原生 BLE API 与生命周期参考；宿主 adapter 按本站共享 GAN transport 合同重写（Apache-2.0）","en":"HarmonyOS NEXT native BLE API and lifecycle reference; the host adapter is reimplemented against CubeRoot\'s shared GAN transport contract (Apache-2.0)","long_en":"Huawei\'s official BluetoothLowEnergy sample anchors the API 22 scan, GATT service, characteristic read/write, notification, and cleanup lifecycle used by the HarmonyOS NEXT thin host. CubeRoot keeps all GAN protocol and product behavior in the shared implementation."},{"name":"huizhiLLL/WCA-Nemesizer-API","url":"https://github.com/huizhiLLL/WCA-Nemesizer-API","zh":"宿敌算法参考(client-side TS 重写;UI 灵感 nemesizer.com);数据基于最近的 WCA developer dump,每周自动更新","en":"Nemesis algorithm reference (client-side TS reimpl; UI inspired by nemesizer.com); data refreshed weekly from the WCA developer dump","long_en":"nemesis-relation algorithm reference (client-side TS reimplementation; UI inspired by [nemesizer.com](https://nemesizer.com))"},{"name":"roudai/VisualCubeEditor2","url":"https://github.com/roudai/VisualCubeEditor2","zh":"VisualCube GUI 编辑器(UI 仿制,渲染换为 @cuberoot/visualcube)","en":"VisualCube GUI editor (UI replicated; renderer swapped to ours)","long_en":"Vue + sr-visualizer GUI cube image editor; UI replicated in React for our own image studio, now the /sim image panel (renderer swapped to our `@cuberoot/visualcube` package)"},{"name":"tdecker91/puzzle-gen","url":"https://github.com/tdecker91/puzzle-gen","zh":"非 NxN puzzle SVG 渲染(Square-1 / Megaminx / Pyraminx / Skewb)","en":"Non-NxN puzzle SVG renderer (Square-1 / Megaminx / Pyraminx / Skewb)","long_en":"non-cube WCA puzzle SVG renderer (`sr-puzzlegen` v1.0.4, vendored as `@cuberoot/vendor-sr-puzzlegen`; Square-1, Megaminx, Pyraminx, Skewb — iso / net / top variants) used by the image studio"},{"name":"cube.rider.biz/visualcube.php","url":"https://cube.rider.biz/visualcube.php","zh":"PHP VisualCube(Cride5 / Yan / Kira 一脉);URL query API + 扩展 mask 形状 + fcs_format_alg 记号 → @cuberoot/visualcube","en":"PHP VisualCube (Cride5 / Yan / Kira lineage); URL query API + extended masks + fcs_format_alg notation","long_en":"PHP VisualCube (Cride5 / Yan / Kira lineage); source of the URL query API (`pzl`/`alg`/`arw`/`ac`/`view=trans`/`stage` etc), extended mask shapes, and PHP `fcs_format_alg` notation extensions ported into our `@cuberoot/visualcube`"},{"name":"speedcubedb.com","url":"https://speedcubedb.com/","zh":"公式库(/algdb 数据源,2x2/3x3/4x4/5x5 alg sets,scraped)","en":"Algorithm database powering /algdb","long_en":"algorithm database powering `/algdb` (2x2/3x3/4x4/5x5 alg sets — F2L, OLL, PLL, COLL, ZBLL, 1LLL, OLLCP, VLS, parity, L2E, L2C, …; scraped via `scramble-stats-build/bin/scrape_speedcubedb.ts`)"},{"name":"Spencer Chubb / CubingApp","url":"https://cubingapp.com/","zh":"Square-1、3x3 入门顶层与桥式、4x4 PLL Parity、Pyraminx 公式数据，以及 WCA Kinch 排名、姓名排名、个人纪录连续场次工具逻辑 (MIT)","en":"Square-1, 3x3 beginner last layer and Roux, 4x4 PLL Parity, Pyraminx algorithms, plus WCA Kinch ranks, name ranks, and personal-record streak tool logic (MIT)","long_en":"Selected CubingApp data and calculator semantics ported from commit 613a49885dc618023368e5f0c2a25024b8c7e9a5 under the MIT License: Square-1 CS, CSP, CP, EO, EP and OBL; 2 Look OLL, PLL and CMLL; CMLL and OH CMLL supplements; Roux LSE EO and EOLR; 4x4 PLL Parity alternatives; Pyraminx last-layer and L4E supplements; Kinch rankings; name matching; and personal-record streaks"},{"name":"speedcubedb.com/analyze","url":"https://speedcubedb.com/analyze","zh":"打乱分析器算法来源(/scramble/analyzer 的 CFOP 解法枚举)","en":"Scramble analyzer algorithm (CFOP solution enumerator for /scramble/analyzer)","long_en":"CFOP solution-enumeration algorithm (cross + F2L + OLL + PLL) ported into the `/scramble/analyzer` page"},{"name":"Jobarion/cubelib + joba.me/mallard","url":"https://github.com/Jobarion/cubelib","zh":"FMC 分步还原链行为参考(/scramble/analyzer 底部 EO→DR→HTR→FR→Finish + NISS;UI 仿 joba.me/mallard,FR 坐标 / 链编排 / NISS 全用 Rust + TS 按其行为自有重写,未拷源码)","en":"FMC step-by-step solver reference (EO→DR→HTR→FR→Finish + NISS chain at the bottom of /scramble/analyzer; UI mirrors joba.me/mallard, engine reimplemented from scratch in Rust + TS — no code copied)","long_en":"Jobarion\'s cubelib Rust FMC solver + its joba.me/mallard web UI — behavior & UI reference for the step-by-step EO→DR→HTR→FR→Finish + NISS chain at the bottom of `/scramble/analyzer`. Our FR coordinate, chain orchestrator and NISS logic were reimplemented from scratch in Rust + TypeScript on our own solver engine; no cubelib source was copied"},{"name":"trangium/MovecountCoefficient","url":"https://github.com/trangium/trangium.github.io","zh":"MCC 公式测速算法(algSpeed.js 已 port 为 TS,/scramble/mcc;MIT)","en":"Movecount Coefficient alg-speed metric (algSpeed.js ported to TS for /scramble/mcc; MIT)","long_en":"trangium\'s Movecount Coefficient calculator — the algSpeed.js fingertrick-simulation metric is ported to TypeScript (golden-locked against upstream) to power the `/scramble/mcc` page; UI rebuilt in React"},{"name":"trangium/BatchSolver","url":"https://github.com/trangium/trangium.github.io","zh":"批量公式集求解引擎(worker.js 已 port 为 TS,/scramble/batch-solver 与 /scramble/sub-solver;MIT)","en":"Batch Solver algset-generation engine (worker.js ported to TS for /scramble/batch-solver and /scramble/sub-solver; MIT)","long_en":"trangium\'s Batch Solver — the worker.js permutation engine (custom puzzle definitions, equivalence reduction, weighted prune/search, adjust handling, scramble DSL) is ported to TypeScript (golden-locked against upstream message-for-message) to power `/scramble/batch-solver`; `/scramble/sub-solver` (Subsolver\'s successor) runs on the same engine; UIs rebuilt in React"},{"name":"nbwzx/commutator","url":"https://github.com/nbwzx/commutator","zh":"换位子分解 / 展开引擎(Zixing Wang;ES module 重封装,UI 重写 React)","en":"Commutator decomposition / expansion engine (Zixing Wang; ES module re-wrap, UI rebuilt in React)","long_en":"commutator decomposition / expansion engine (Zixing Wang) re-wrapped as ES module for the `/alg/commutator` tool; algorithm code unchanged from upstream, UI rebuilt in React"},{"name":"speedsolving.com/wiki: Pretty Pattern","url":"https://www.speedsolving.com/wiki/index.php/Pretty_pattern","zh":"/patterns 图案算法来源","en":"Pattern algorithms for /patterns"},{"name":"ruwix.com Rubik\'s Cube Patterns","url":"https://ruwix.com/the-rubiks-cube/rubiks-cube-patterns-algorithms/","zh":"/patterns 图案算法来源","en":"Pattern algorithms for /patterns"},{"name":"cubing.pro","url":"https://cubing.pro/","zh":"/wca 各子页与选手详情页 UI/概念参考；/sim 绘图模式的 SQ1、五魔方、Skewb、Pyraminx、FTO 平面模板与交互移植","en":"UI / concept reference for /wca pages; drawing templates and interactions for SQ1, Megaminx, Skewb, Pyraminx, and FTO in /sim","long_en":"UI/concept reference for `/wca` sub-pages and person details. The source also provides the flat SVG templates and puzzle-specific controls ported into `/sim` drawing mode for SQ1, Megaminx, Skewb, Pyraminx, and FTO; CubeRoot supplies the shared editor, theme, responsive UI, and export pipeline."},{"name":"LowCubes / Raul Low","url":"https://www.lowcubes.com/","zh":"移植 FTO Bencisco L3T、Megaminx Full PLL 公式数据及 FTO EIF 图片生成器；页面、渲染器与交互按本站架构重写","en":"FTO Bencisco L3T and Megaminx Full PLL data, plus the FTO EIF image-generator behavior; pages, renderer, and interactions are reimplemented for CubeRoot","long_en":"Source for the FTO Bencisco last-three-triangles library, Megaminx Full PLL library, and the EIF-notation FTO image generator behavior. CubeRoot reimplements the pages, strict notation parser, SVG renderer, simulator integration, responsive UI, and export flow in its own architecture."},{"name":"rullerzhou-afk/clawd-on-desk","url":"https://github.com/rullerzhou-afk/clawd-on-desk","zh":"桌面 AI 桌宠;右下角 Clawd 像素螃蟹的动画与交互移植自此(Clawd 形象版权归 Anthropic,非官方粉丝作品)","en":"Desktop AI pet; the corner Clawd pixel crab ports its animations + interactions (Clawd character © Anthropic; unofficial fan use)","long_en":"desktop pixel pet that reacts to AI coding agents; its Clawd crab artwork + the idle eye-tracking / state-machine interaction model are ported into the site-wide web desk pet. The Clawd character is the property of Anthropic — this is an unofficial fan use."},{"name":"spooncuber/bldtrainer","url":"https://github.com/spooncuber/spooncuber.github.io","zh":"三盲训练器引擎 + 各模块移植(/alg/3bld;作者 Zhi Qiao,GPL-3.0)","en":"3BLD trainer engine + modules ported (/alg/3bld; author Zhi Qiao, GPL-3.0)","long_en":"3BLD trainer engine + modules ported — read-code engine, helper / memo / commutator / parity / flip / twist / float trainers and the resources list under `/alg/3bld` (author Zhi Qiao, GPL-3.0)"},{"name":"zhucidong/三盲助手","url":"https://github.com/zhucidong/blindfolded_hepler","zh":"盲拧助手 App;记忆回想训练器 + 换位子公式库 + 联想词表合并自此","en":"Blindfolded helper app; memo recall trainer + commutator library + association words merged","long_en":"blindfolded helper Android app; its memo recall trainer, commutator library, and association-word dictionary are merged into the `/alg/3bld` modules"},{"name":"AnnikaStein/SkewbPage","url":"https://github.com/AnnikaStein/SkewbPage","zh":"Skewb 技巧训练器(SkewbSkills;三模式首层 / L2L 公式 / One-Look 全 port 为 React /alg/skewb-trainer;作者 Annika Stein,Apache-2.0)","en":"Skewb Skills trainer (SkewbSkills; three-mode First Layer / L2L Alg / One-Look ported to React at /alg/skewb-trainer; author Annika Stein, Apache-2.0)","long_en":"SkewbSkills web trainer — First Layer Trainer, L2L Algorithm Trainer, and One-Looking Trainer (alg database, RubiksSkewb→WCA notation conversion, scramble generation) ported to React for `/alg/skewb-trainer` (author Annika Stein, Apache-2.0)"},{"name":"onionhoney/roux-trainers","url":"https://github.com/onionhoney/roux-trainers","zh":"桥式训练器(/alg/roux;引擎 + three.js 渲染器全量 port 为 React、去 MUI;作者 Onionhoney,GPL-3.0)","en":"Roux trainer (/alg/roux page; engine + three.js renderer fully ported to React, de-MUI\'d; author Onionhoney, GPL-3.0)","long_en":"Roux-method trainer collection — first-block / analyzer / FS / SS / CMLL / LSE trainers + in-browser Roux solver + three.js cube renderer, ported to React (MUI removed) and embedded under the `/alg/roux` page (author Onionhoney, GPL-3.0)"},{"name":"WCA Regulations & 5b5f Visual Guide","url":"https://www.worldcubeassociation.org/regulations/full/","zh":"/regulation 规则页:检查 / 打乱 / 判定 / 罚时等核心条款整理自 WCA 官方《竞赛规则与指南》;末节「拼装缺陷判定」的 11 张配图 + 文字移植自 WCA Regulations Committee《Regulation 5b5f Visual Guide》(均已注明来源)","en":"/regulation page: core articles (inspection / scrambling / judging / penalties) compiled from the official WCA Regulations & Guidelines; the assembly-defect section reproduces the 11 photos + text from the WCA Regulations Committee\'s Regulation 5b5f Visual Guide (all credited)","long_en":"the `/regulation` page summarizes the most-asked WCA Regulations (inspection, scrambling, solved-state misalignment, +2/DNF, time limits, special events, puzzle rules) with diagrams; its final section reproduces, with attribution, the text and all example photos of the WCA Regulations Committee\'s official 5b5f Visual Guide slide deck on judging partially-detached / not-fully-placed pieces"},{"name":"Herbert Kociemba — Two-Phase Algorithm & Cube Explorer","url":"https://kociemba.org/cube.htm","zh":"Kociemba 两阶段算法 + 立方坐标模型(corner/edge 排列 / twist / flip 编码、面转表):/scramble/solver 的 3×3 两阶段解(含 crz3a 疯狂 3×3)、STM 最优解器的状态编码、cube48opt 服务端最优解器都基于此;Cube Explorer 是已知唯一的 STM 最优解器(参照);/scramble/pattern/search 的图案搜索移植自 Cube Explorer 的 Pattern Editor(PatternSearch.pas);/scramble/symmetry 的对称型搜索与 33 种类型数据移植自 Symmetry Editor(SymSearch.pas + Symmetries.pas + CubeDefs.pas)","en":"Kociemba\'s two-phase algorithm + cube coordinate model (corner/edge perm, twist, flip encoders; face-move tables) underpin the /scramble/solver 3×3 two-phase solve (incl. the crz3a Crazy-3×3 solver), the STM optimal solver\'s state encoding, and the server-side cube48opt optimal solver; Cube Explorer is the only known prior STM-optimal solver (reference); /scramble/pattern/search ports Cube Explorer\'s Pattern Editor (PatternSearch.pas), and /scramble/symmetry ports its Symmetry Editor (SymSearch.pas + Symmetries.pas + CubeDefs.pas)","long_en":"Herbert Kociemba\'s two-phase algorithm and the Singmaster cubie coordinate model (corner/edge permutation ranks, corner-twist / edge-flip ranks, face-move arrays — also as ported in cs0x7f\'s min2phase.js) are the basis of the site\'s client-side 3×3 two-phase solver (the derive-scramble flow + the crz3a solver), the new pure-TS 3×3×3 STM optimal solver\'s state encoding (cross-validated against these tables), and the server-side cube48opt optimal-solve daemon. Cube Explorer (kociemba.org) is the only known pre-existing STM-optimal solver — the reference our STM goal-test (centers must end home) follows. The /scramble/pattern/search page is a faithful port of Cube Explorer\'s Pattern Editor (PatternSearch.pas: abstract face-pattern DFS with color-class bijection matching, continuity check, and isomorphism dedup). The /scramble/symmetry page ports the Symmetry Editor: the 48 symmetry cubie tables of Symmetries.pas, the 33 subgroup bitmasks and per-type position counts of CubeDefs.pas / SymSearch.pas, and the symmetry-constrained DFS of SymSearch.pas (equivariant piece placement, antisymmetry, per-face colour counts, permutation parity modes, exact-symmetry filtering)"},{"name":"Richard E. Korf — IDA* + Pattern Databases","url":"https://web.cs.ucla.edu/~korf/","zh":"Korf 的 IDA* + 模式数据库(AAAI 1997)+ 滑块 walking-distance 启发:STM 最优解器的角表(8!×3⁷)+ 双 6 棱表(12P6×2⁶)、h=max(...) 可采纳启发,数字华容道 15p 的 walking-distance,cube48opt 3×3 最优解都出自此法","en":"Korf\'s IDA* with pattern databases (AAAI 1997) + the sliding-tile walking-distance heuristic: the STM optimal solver\'s corner PDB (8!×3⁷) + two 6-edge PDBs (12P6×2⁶) with h = max(...), the 15-puzzle (15p) walking-distance optimal solve, and cube48opt\'s 3×3 optimal solve all use this method","long_en":"Richard E. Korf\'s \'Finding Optimal Solutions to Rubik\'s Cube Using Pattern Databases\' (AAAI 1997) — max/additive pattern-database IDA* — is the method behind the pure-TS 3×3×3 STM optimal solver (corner PDB 8!×3⁷ + two disjoint 6-edge PDBs 12P6×2⁶, admissible h = max of EXACT BFS distances rebuilt over the 27 STM generators) and, via his walking-distance heuristic, the 15-puzzle optimal solver (/scramble/solver 15p); the server-side cube48opt 3×3 optimal-solve daemon is in the same lineage"},{"name":"thewca/tnoodle-lib","url":"https://github.com/thewca/tnoodle-lib","zh":"WCA 官方打乱程序库:二阶 TwoByTwoCubePuzzle / TwoByTwoSolver 的均匀随机状态、恰好 11 步求解与 computeCost 握位代价已移植为共享 WCA 二阶打乱生成器;魔表的 18 位状态模型与转动表(ClockPuzzle.java)移植为 clock_svg.ts,也是本站魔表求解器 @cuberoot/puzzle-solvers/clock 的转动语义锚点;打乱图渲染与各项目配色方案亦照其实现","en":"The WCA\'s official scrambling library: TwoByTwoCubePuzzle / TwoByTwoSolver\'s uniform random states, exact 11-move search, and computeCost grip model are ported as the shared WCA 2×2 generator; the Clock\'s 18-dial state model and move table (ClockPuzzle.java) are ported as clock_svg.ts and anchor our Clock solver\'s move semantics; the scramble-image renderer and per-event colour schemes follow TNoodle too","long_en":"TNoodle is the World Cube Association\'s official scramble generator. CubeRoot\'s runtime-neutral WCA 2×2 generator faithfully ports `TwoByTwoCubePuzzle` / `TwoByTwoSolver`: it samples a uniform normalized state, enumerates exact 11-move URF solutions, and selects the lowest-cost sequence under TNoodle\'s `computeCost` grip model. Its `ClockPuzzle.java` (18-dial posit model, the 18 pin-subset move rows, the y2 presentation flip, and the default per-part colour scheme) is also ported to `clock_svg.ts`, which serves as the independent gold standard for cell-by-cell cross-validation of the pure-TS optimal Clock solver"},{"name":"Jaap Scherphuis — Jaap\'s Puzzle Page","url":"https://www.jaapsch.net/puzzles/clock.htm","zh":"魔表的群论背景与 God\'s algorithm 距离分布表(12^14 个状态逐档统计):/scramble/stats 的魔表分布页与求解器回归测试都以此为基准","en":"Rubik\'s Clock group theory and the God\'s-algorithm distance distribution (per-depth counts over all 12^14 states): the basis for our Clock distribution page and the solver\'s regression tests"},{"name":"Rubik\'s Clock 最优求解先行工作(Kogler / Rokicki / OptClock / cs0x7f)","url":"http://cube20.org/clock/","zh":"魔表 God\'s number = 12 的证明与全空间分析:Jakob Kogler 2014 首证,Tomas Rokicki 用陪集求解器算出完整距离分布并公布 39,248 个距离 12 的位置(dist12.txt,本站用作求解器的精确对账集);Michael Gottlieb + Ben Whitmore 的 OptClock 与 Shuang Chen 的 ClockSolver.java 是两份独立的单状态最优求解器。四份代码原样收藏在 solver/reference/clock/(只读、不编译);本站 @cuberoot/puzzle-solvers/clock 为独立实现,未取用其代码","en":"The proof that God\'s number for Clock is 12 and the full-space analysis: first proven by Jakob Kogler (2014); Tomas Rokicki computed the complete distance distribution with a coset solver and published all 39,248 distance-12 positions (dist12.txt — used here as an exact regression oracle); OptClock (Michael Gottlieb + Ben Whitmore) and ClockSolver.java (Shuang Chen) are two independent single-position optimal solvers. All four are archived verbatim under solver/reference/clock/ (read-only, never compiled); our @cuberoot/puzzle-solvers/clock implementation is independent and uses none of their code","long_en":"Prior art for optimally solving the Rubik\'s Clock. Jakob Kogler (2014) first proved God\'s number is 12 using a one-side lookup table plus iterative-deepening DFS. Tomas Rokicki then computed the complete distance distribution over all 1,283,918,464,548,864 states with a coset solver (subgroup fixing the front cross, 248,832 cosets reduced to 9,906 by mirror / rotation / coprime-multiplication symmetry, ~3 days on a couple of desktops) and published both his source (clockcoset11.cpp) and the 39,248 distance-12 positions (dist12.txt). OptClock by Michael Gottlieb (qqwref) with a Qt GUI by Ben Whitmore is the two-phase single-position optimal solver used to verify those positions. Shuang Chen\'s ClockSolver.java (GPLv3) is an independent Java optimal solver. All are archived read-only under solver/reference/clock/ with a README explaining each algorithm; dist12.txt is wired into our test suite so the hardest depth bucket is verified exactly rather than by sampling"},{"name":"Dan Boharon — Cube Lookahead Challenge","url":"https://app--cube-lookahead-24bc12e4.base44.app/","zh":"/predict 预判训练的玩法原型(模式设定与 F2L 公式池)","en":"Gameplay original behind /predict (modes + F2L alg pool)","long_en":"lookahead challenge concept, game modes, F2L insertion pool"},{"name":"cubing/CubePB (James Chang)","url":"https://github.com/cubing/CubePB","zh":"WCA 选手页个人 PB、历史记录与编辑流程来源；用 CubeRoot 现有账号、WCA 项目和成绩格式能力重新实现","en":"Product flow behind personal PBs, history and editing on WCA person pages; reimplemented with CubeRoot\'s account, WCA event and result-formatting infrastructure","long_en":"CubePB established the personal-best profile, history and editing workflow. CubeRoot\'s implementation is a clean integration on WCA person pages, built on its existing authentication, WCA event selection, raw result encoding, bilingual UI and PostgreSQL API. Original project licensed under GPL-3.0."},{"name":"Cube Platform / 2017YANR02","url":"https://github.com/2017YANR02/cube-platform","zh":"学习空间、商业与二维码卡片功能源自维护者的原 Cube Platform；迁入主站后复用统一账号、论坛、讲师名录与媒体能力，保留原卡片模板和提示积木来源。","en":"Learning, commerce and QR card features originate from the maintainer’s Cube Platform. The main-site integration reuses canonical accounts, forums, teacher profiles and media while retaining the provenance of card templates and prompt blocks."},{"name":"GeoNames","url":"https://www.geonames.org/","zh":"账号地名中文补充参考 GeoNames 数据（CC BY 4.0）；结合行政区汉字、原始坐标与省份消歧，避免将历史别名或治所误用为当前名称。","en":"Supplemental account location labels use GeoNames data (CC BY 4.0), checked against administrative names, source coordinates and province context to avoid substituting historical aliases or administrative seats."},{"name":"Administrative divisions of China / modood","url":"https://github.com/modood/Administrative-divisions-of-China","zh":"账号中国城市中文标签的行政区汉字参考该项目整理的国家统计局行政区划数据；保留原始账号地点标识，按省份核对同音地名。","en":"Chinese account location labels reference National Bureau of Statistics administrative names collected by this project, preserving stored location identifiers and checking homographs by province."},{"name":"中国行政区划公开数据 / dataxiv archive","url":"https://github.com/dataxiv/data-district","zh":"账号中国地区选项以民政部2025年末公开行政区划存档为基础，结合地方政府后续公告及港澳台官方资料校核；保留来源、存档版本和核对日期。","en":"Chinese account location options use an archived year-end 2025 MCA administrative dataset, checked against later local-government announcements and official Hong Kong, Macao and Taiwan sources, with provenance and review dates recorded."},{"name":"QuickJS / Fabrice Bellard & Charlie Gordon","url":"https://bellard.org/quickjs/","zh":"Apple Watch 通过 MIT 许可的 QuickJS 核心直接运行既有智能魔方共享代码，避免另写协议和计时规则。","en":"Apple Watch uses the MIT-licensed QuickJS core to run existing shared smart-cube code without duplicating protocols or timing rules."},{"name":"Algorithm Translator / Conrad Rider","url":"https://cube.rider.biz/algtrans.html","zh":"模拟器公式变换与逐步改写的功能参考；实现复用本站公式解析和变换逻辑。","en":"Feature reference for simulator algorithm transformations and step editing, implemented with our existing algorithm parser and transformation utilities."}]')}]);