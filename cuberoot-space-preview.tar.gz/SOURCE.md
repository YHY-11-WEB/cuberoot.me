# CubeRoot Space static preview

Source: https://github.com/YHY-11-WEB/cuberoot.me
Upstream: https://github.com/2017YANR02/cuberoot.me
Commit: 7b0ccd546cb251fa3108a00d84d0e54b37fc2504
Source archive: https://github.com/YHY-11-WEB/cuberoot.me/archive/7b0ccd546cb251fa3108a00d84d0e54b37fc2504.tar.gz

The original repository is licensed under GNU GPL version 3; the complete license is in LICENSE.txt. Existing third-party asset notices remain in assets/space and fonts. In-page Space source credits are retained.

This preview uses genuine Next.js 16.3.8 output:export, trailingSlash:true, images.unoptimized:true, and a selective home + space build in the original project. No RSC files were renamed into exports. The space/ alias copies the genuine en/space export to support the existing English bare URL convention.

Production bootstrap geometry and artwork are unchanged. The newer Blender GLB/texture bundle is not included. Server routes/proxy/headers/rewrites/redirects were disabled temporarily for export and restored exactly afterward. Optional notices/pet catalog responses are empty local offline data. API origin is /preview-offline-api and connect-src is limited to self/data/blob. No author API is required.

This package contains only the selected pages, same-build _next/static, legacy Space assets, fonts/icons and public shell resources identified during browser verification. Other site features are outside this preview. Deploy all files at the host root, preserving /assets/space and /_next/static. Each file must remain at its original path.

Static-host payload aliases: zh.txt, en.txt, zh/space.txt, en/space.txt and space.txt are exact copies of genuine export index.txt payloads. Their original directory payloads and segment files are also retained. No ordinary-build .rsc files are used.

Browser check scope: actual static HTML hydration and Next client navigation were verified, with no external requests or page JavaScript exceptions. WebGL was disabled only in that cloud navigation test so software GPU compilation would not block it; the deployed renderer, architecture and artwork are unchanged. The user will accept the hosted 3D view in hardware Edge. Non-preview links such as Simulator and the complete Appearance page are intentionally outside this package.
